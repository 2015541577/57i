export default [
  {
    path: '/user',
    component: '../layouts/UserLayout',
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: './user/login',
      },
      {
        name: 'ChangePassword',
        path: '/user/ChangePassword',
        component: './user/ChangePassword',
      },
      {
        name: 'PasswordStatuspage',
        path: '/user/PasswordStatuspage',
        component: './user/PasswordStatuspage',
      },
      {
        component: './404',
      },
    ],
  },
  {
    path: '/',
    component: '../layouts/SecurityLayout',

    routes: [
      {
        path: '/',
        component: '../layouts/BasicLayout',
        // authority: ['admin', 'user'],
        routes: [
          {
            path: '/',
            redirect: '/Order/HomePage',
          },
          // 商品管理
          {
            path: '/goods',
            name: 'goods',
            icon: 'appstore',
            authority: ['商品审核'],
            routes: [
              {
                path: '/goods/index',
                name: 'index',
                component: './Goods',
                // newTab: true,
              },
              {
                path: '/goods/index/goodsDetail/:id/:actionId',
                name: 'goodsDetail',
                component: './Goods/goodsDetail',
                hideInMenu: true,
              },
              // {
              //   path: '/goods/Purchase/goodsDetail/:id/:actionId',
              //   name: 'PurchaseGoodsDetail',
              //   component: './Goods/Purchase/goodsDetail',
              //   hideInMenu: true,
              // },
              // 编辑商品
              {
                path: '/goods/list/detail/:id?',
                name: 'detail',
                component: './Goods/Detail',
                hideInMenu: true,
              },
            ],
          },
          {
            path: '/StoreAudit',
            name: 'StoreAudit',
            icon: 'shop',
            authority: ['店铺审核'],
            routes: [
              {
                path: '/StoreAudit/list',
                name: 'index',
                component: './StoreAudit',
                authority: ['店铺审核'],
                // newTab: true,
              },
              {
                path: '/StoreAudit/list/details',
                name: 'details',
                component: './StoreAudit/details',
                hideInMenu: true,
              },
              {
                component: './404',
              },
            ],
          },
          {
            path: '/Order',
            name: 'Order',
            icon: 'audit',
            hideInMenu: false,
            authority: ['订单管理'],
            routes: [
              {
                path: '/Order/HomePage',
                component: './Order/HomePage',
                hideInMenu: false,
                name: 'HomePage',
                authority: ['订单列表'],
              },
              {
                path: '/Order/SolveOverdue',
                component: './Order/SolveOverdue',
                hideInMenu: false,
                name: 'SolveOverdue',
                authority: ['逾期处理'],
              },
              {
                path: '/Order/makeUpOrder',
                component: './Order/makeUpOrder',
                hideInMenu: false,
                name: 'makeUpOrder',
                authority: ['补订单管理'],
              },
              {
                path: '/Order/ApplyTake',
                component: './Order/ApplyTake',
                hideInMenu: false,
                name: 'ApplyTake',
                authority: ['扣款申请表'],
              },

              {
                path: '/Order/BeOverdues',
                component: './Order/BeOverdues',
                hideInMenu: false,
                name: 'BeOverdues',
                authority: ['逾期订单'],
              },
              {
                path: '/Order/OverdueNoReturn',
                component: './Order/OverdueNoReturn',
                hideInMenu: false,
                name: 'OverdueNoReturn',
                authority: ['到期未归还订单'],
              },
              {
                path: '/Order/BuyOut',
                component: './Order/BuyOut',
                hideInMenu: false,
                name: 'BuyOut',
                authority: ['买断订单'],
              },
              {
                path: '/Order/RentRenewalNew',
                component: './Order/RentRenewalNew',
                hideInMenu: false,
                name: 'RentRenewalNew',
                authority: ['新续租列表'],
              },
              {
                path: '/Order/ApplyType',
                component: './Order/ApplyType',
                hideInMenu: false,
                name: 'ApplyType',
                authority: ['完结申请表'],
              },
              {
                path: '/Order/RentRenewal/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/HomePage/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/BeOverdue/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/OverdueNoReturn/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/Close/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/PublicityList/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                path: '/Order/Purchase/PurchaseDetails',
                component: './Order/PurchaseDetails',
                hideInMenu: true,
                name: 'Details',
              },

              {
                path: '/Order/BuyOut/BuyOutDetails',
                component: './Order/BuyOutDetails',
                hideInMenu: true,
                name: 'BuyOutDetails',
              },
              {
                path: '/Order/Online/Details',
                component: './Order/Details',
                hideInMenu: true,
                name: 'Details',
              },
              {
                component: './404',
              },
            ],
          },

          {
            path: '/Marketing',
            name: 'Marketing',
            icon: 'shopping-cart',
            authority: ['营销管理'],
            hideInMenu: false,
            routes: [
              {
                path: '/Marketing/serviceConfig',
                name: 'serviceConfig',
                component: './serviceConfig/index',
                authority: ['补订单配置'],
              },
              {
                path: '/Marketing/AdvertiserManagement',
                component: './Marketing/AdvertiserManagement',
                hideInMenu: false,
                name: 'AdvertiserManagement',
                authority: ['广告商管理'],
              },
              {
                path: '/Marketing/PromotionStatistics',
                component: './Marketing/PromotionStatistics',
                name: 'PromotionStatistics',
                authority: ['推广管理'],
              },
              {
                path: '/Marketing/Coupon/list',
                hideInMenu: false,
                name: 'Coupon',
                authority: ['优惠券管理'],
                routes: [
                  {
                    path: '/Marketing/Coupon/list',
                    component: './Marketing/Coupon/HomePage',
                    hideInMenu: true,
                  },
                  {
                    path: '/Marketing/Coupon/list/ToView',
                    component: './Marketing/Coupon/ToView',
                    hideInMenu: true,
                  },
                  {
                    path: '/Marketing/Coupon/list/toShopView',
                    component: './Marketing/Coupon/toShopView',
                    hideInMenu: true,
                  },
                  {
                    path: '/Marketing/Coupon/list/TheEditorList',
                    component: './Marketing/Coupon/TheEditorList',
                    hideInMenu: true,
                  },
                  {
                    path: '/Marketing/Coupon/list/add',
                    component: './Marketing/Coupon/AddList',
                    hideInMenu: true,
                  },
                ],
              },
              {
                path: '/Marketing/Comment',
                component: './Marketing/Comment',
                hideInMenu: false,
                name: 'Comment',
                authority: ['客诉中心'],
              },
              {
                path: '/Marketing/Comment/See',
                component: './Marketing/Comment/See',
                hideInMenu: true,
                name: 'See',
                authority: ['评论管理'],
              },
              {
                path: '/Marketing/ShopCoupon',
                component: './Marketing/ShopCoupon',
                name: 'ShopCoupon',
                authority: ['商家券中心'],
              },
            ],
          },
          // 配置管理
          {
            path: '/configure',
            name: 'configure',
            icon: 'setting',
            authority: ['配置管理'],
            routes: [
              {
                path: '/configure/index',
                name: 'index',
                component: './Configure/index',
                authority: ['首页模块配置'],
              },
              {
                path: '/configure/tab',
                name: 'tab',
                component: './Tab/index',
                authority: ['首页导航栏配置'],
              },
              {
                path: '/configure/coverHome',
                name: 'coverHome',
                component: './coverHome/index',
                authority: ['首页活动栏目'],
              },
              // {
              //   path: '/configure/tribe',
              //   name: 'tribe',
              //   component: './Tribe/index',
              //   authority: ['部落配置'],
              // },
              {
                path: '/configure/spike',
                name: 'spike',
                component: './Spike/index',
                authority: ['聚合页配置'],
              },
              {
                path: '/configure/homeClassify',
                name: 'HomeClassify',
                component: './HomeClassify/index',
                authority: ['图标列表配置'],
              },
              {
                path: '/configure/spike/topicDetail/:id',
                name: 'topicDetail',
                component: './Spike/TopicDetail',
                hideInMenu: true,
              },
              {
                path: '/configure/spike/TopicDetailCopy/:id',
                name: 'topicDetail',
                component: './Spike/TopicDetailCopy',
                hideInMenu: true,
              },

              {
                path: '/configure/spike/spikeDetail/:id',
                name: 'SpikeDetail',
                component: './Spike/SpikeDetail',
                hideInMenu: true,
              },
              {
                path: '/configure/tribe/publish',
                name: 'publish',
                component: './Tribe/publish',
                hideInMenu: true,
              },
              {
                path: '/configure/tribe/edit/:id',
                name: 'tribe-edit',
                component: './Tribe/publish',
                hideInMenu: true,
              },
              {
                path: '/configure/category/index',
                name: 'category',
                component: './Category/index',
                authority: ['分类配置'],
              },
              {
                path: '/configure/my/index',
                name: 'my',
                component: './My/index',
                authority: ['我的配置'],
              },
              {
                path: '/configure/Notice/index',
                name: 'Notice',
                component: './Notice/index',
                authority: ['公告配置'],
              },
              {
                path: '/configure/HistoryAnCt/index',
                name: 'HistoryAnCt',
                component: './HistoryAnCt/index',
                authority: ['公告'],
              },
              // Activity
              // {
              //   path: '/configure/Activity/index',
              //   name: 'Activity',
              //   component: './Activity/index',
              // },
              {
                path: '/configure/Activity/edit/:id',
                name: 'Apublish',
                component: './Activity/publish',
                hideInMenu: true,
              },
              {
                path: '/configure/Activity/index/publish',
                name: 'Apublish',
                component: './Activity/publish',
                hideInMenu: true,
              },
              {
                path: '/configure/StrictElection/StrictLabel',
                name: 'StrictLabel',
                component: './StrictLabel/index',
                hideInMenu: true,
                authority: ['严选标签配置'],
              },
              // {
              //   path: '/configure/ActivityMaterials/index',
              //   name: 'ActivityMaterials',
              //   component: './ActivityMaterials/index',
              // },
              // {
              //   // path: '/configure/abilityCenter',
              //   name: 'abilityCenter',
              //   routes: [
              //     {
              //       path: '/configure/abilityCenter/secondHand',
              //       name: 'secondHand',
              //       component: './Configure/AbilityCenter/SecondHand/index',
              //       authority: ['二手购买配置'],
              //     },
              //     {
              //       path: '/configure/abilityCenter/newPhone',
              //       name: 'newPhone',
              //       component: './Configure/AbilityCenter/SecondHand/index',
              //       authority: ['新机购买配置'],
              //     },
              //     {
              //       path: '/configure/abilityCenter/tribe',
              //       name: 'tribe',
              //       component: './Tribe/index',
              //       authority: ['部落配置'],
              //     },
              //   ],
              // },
            ],
          },
          // 报表查询
          {
            path: '/reportTable',
            name: 'reportTable',
            icon: 'table',
            authority: ['报表查询'],
            routes: [
              {
                path: '/reportTable/UserList',
                name: 'UserList',
                component: './ReportTable/UserList/index',
                authority: ['用户列表'],
              },
              {
                path: '/reportTable/RentPayment',
                name: 'RentPayment',
                component: './ReportTable/RentPayment/index',
                authority: ['交租状态一览表'],
              },
              {
                path: '/reportTable/OperateList',
                name: 'OperateList',
                component: './ReportTable/OperateList/index',
                authority: ['运营报表'],
              },
              //   {
              //     path: '/reportTable/Test',
              //     name: 'Test',
              //     component: './ReportTable/Test',
              //   },
            ],
          },

          // {
          //   path: '/Motion',
          //   name: 'Motion',
          //   icon: 'bar-chart',
          //   authority: ['点券商城'],
          //   routes: [
          //     {
          //       path: '/Motion/RollUp',
          //       name: 'RollUp',
          //       component: './Motion/RollUp',
          //       authority: ['点券商品'],
          //     },
          //     {
          //       path: '/Motion/RollUp/RollUpDetails',
          //       name: 'RollUpDetails',
          //       hideInMenu: true,
          //       component: './Motion/RollUpDetails',
          //       authority: ['首页模块配置'],
          //     },
          //     {
          //       path: '/Motion/RollUp/add',
          //       name: 'add',
          //       hideInMenu: true,
          //       component: './Motion/RollUpDetails',
          //       authority: ['首页模块配置'],
          //     },
          //     {
          //       path: '/Motion/Order',
          //       name: 'Order',
          //       component: './Motion/Order',
          //       authority: ['点券订单查询'],
          //     },
          //     {
          //       path: '/Motion/Order/OrderDetails',
          //       name: 'OrderDetails',
          //       hideInMenu: true,
          //       component: './Motion/OrderDetails',
          //     },
          //     // {
          //     //   path: '/Motion/DataView',
          //     //   name: 'DataView',
          //     //   component: './Motion/DataView',
          //     // },
          //   ],
          // },
          {
            path: '/permission',
            name: 'permission',
            icon: 'tool',
            authority: ['权限管理'],
            routes: [
              {
                path: '/permission/index',
                name: 'index',
                component: './Permission/index',
                authority: ['部门列表'],
              },
              {
                path: '/permission/index/config/:id',
                name: 'config',
                component: './Permission/PermissionConfig',
                hideInMenu: true,
              },
              {
                path: '/permission/member',
                name: 'member',
                component: './Member/index',
                authority: ['成员管理'],
              },
              {
                path: '/permission/member/config/:id',
                name: 'config',
                component: './Permission/PermissionConfig',
                hideInMenu: true,
              },
              {
                path: '/permission/AddbackstageUser',
                name: 'AddbackstageUser',
                component: './Permission/AddbackstageUser/index',
                authority: ['权限组管理'],
              },
              {
                path: '/permission/AddbackstageUser/config/:id',
                name: 'config',
                component: './Permission/AddbackstageUser/config/index',
                hideInMenu: true,
              },
              {
                path: '/permission/NavManager/config/:id',
                name: 'config',
                component: './Permission/PermissionConfig',
                hideInMenu: true,
              },
            ],
          },
          // 结算系统
          {
            path: '/Account',
            name: 'Account',
            icon: 'tool',
            authority: ['结算系统'],
            // authority: ['运营报表'],
            routes: [
              {
                path: '/Account/Balancelist',
                name: 'Balancelist',
                component: './Account/Balancelist/index',
                authority: ['账户余额列表'],
                // authority: ['运营报表'],
              },
              {
                path: '/Account/Detail',
                name: 'Detail',
                component: './Account/Detail/index',
                authority: ['账户明细'],
                // authority: ['运营报表'],
              },
              {
                path: '/Account/CoCheck',
                name: 'CoCheck',
                component: './Account/CoCheck/index',
                authority: ['消费对账单'],
              },
              {
                path: '/Account/Bill',
                name: 'Bill',
                component: './Account/Bill/index',
                authority: ['租金对账单'],
                // authority: ['运营报表'],
              },
              {
                path: '/Account/Business',
                name: 'Business',
                component: './Account/Business/index',
                authority: ['提现明细'],
                // authority: ['运营报表'],
              },
              {
                path: '/Account/RunningLog',
                name: 'RunningLog',
                component: './Account/RunningLog/index',
                authority: ['流水生成日志'],
                // authority: ['运营报表'],
              },
              // {
              //   path: '/Account/SaasBalance',
              //   name: 'SaasBalance',
              //   component: './Account/SaasBalance/index',
              //   // authority: ['SaaS余额'],
              //   authority: ['运营报表'],
              // },
              // {
              //   path: '/Account/RiskCenterAliPayLease/config/:id',
              //   name: 'config',
              //   component: './RiskCenter/RiskCenterConfig',
              //   hideInMenu: true,
              // },
            ],
          },
          {
            component: './404',
          },
        ],
      },
      {
        component: './404',
      },
    ],
  },
  {
    component: './404',
  },
];
