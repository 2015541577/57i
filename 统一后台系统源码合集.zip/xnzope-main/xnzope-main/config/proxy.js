/**
 * 在生产环境 代理是无法生效的，所以这里没有生产环境的配置
 * The agent cannot take effect in the production environment
 * so there is no configuration of the production environment
 * For details, please see
 * https://pro.ant.design/docs/deploy
 */
export default {
  dev: {
    '/hzsx/': {
      target: 'https://ope.xxx.com/',
      // target: 'http://192.168.0.244:80/hzsx/', // marketing-center/product-center
      // target: 'http://192.168.0.78:80/hzsx/', // order-center/components-center
      // target: 'http://192.168.0.160:80/hzsx/', // api-web/user-center
      // target: 'http://172.16.0.66:80/hzsx/',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
  test: {
    '/api/': {
      target: 'https://preview.pro.ant.design',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
  pre: {
    '/api/': {
      target: 'your pre url',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
};
