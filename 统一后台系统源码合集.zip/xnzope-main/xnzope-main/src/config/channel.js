export default [
  '1/零零享租',
];
