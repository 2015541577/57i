module.exports = {
  navTheme: 'light',
  primaryColor: '#5476F0',
  layout: 'sidemenu',
  contentWidth: 'Fluid',
  fixedHeader: false,
  autoHideHeader: false,
  fixSiderbar: false,
  menu: {
    disableLocal: false,
  },
  title: '零零享租运营中心',
  pwa: true,
  iconfontUrl: '',
  collapse: true,
  newChannelGroupCode:"066"
};
