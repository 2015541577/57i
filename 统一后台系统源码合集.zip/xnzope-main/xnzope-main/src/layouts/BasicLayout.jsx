/**
 * Ant Design Pro v4 use `@ant-design/pro-layout` to handle Layout.
 * You can view component api by:
 * https://github.com/ant-design/ant-design-pro-layout
 */
import ProLayout, { DefaultFooter } from '@ant-design/pro-layout';
import React, { useEffect } from 'react';
import { Link } from 'umi';
import { connect } from 'dva';
import { Icon, Result, Button } from 'antd';
import { formatMessage } from 'umi-plugin-react/locale';
import Authorized from '@/utils/Authorized';
import RightContent from '@/components/GlobalHeader/RightContent';
import { isAntDesignPro, getAuthorityFromRouter } from '@/utils/utils';
import { Redirect } from 'umi';
import logoPng from '@/assets/operation.png';

const noMatch = (
  // <Result
  //   status={403}
  //   title="403"
  //   subTitle="Sorry, you are not authorized to access this page."
  //   extra={
  //     <Button type="primary">
  //       <Link to="/user/login">Go Login</Link>
  //     </Button>
  //   }
  // />
  <Result
    icon={
      <img
        src="https://oss.llxzu.com/8ffbb42588ed4df396076b6c608b9820.png"
        alt="logo"
        width="400"
      />
    }
    title="欢迎您的使用！"
  />
);

/**
 * use Authorized check all menu item
 */
const menuDataRender = menuList =>
  menuList.map(item => {
    const localItem = { ...item, children: item.children ? menuDataRender(item.children) : [] };
    return Authorized.check(item.authority, localItem, null);
  });

// const defaultFooterDom = (
//   <DefaultFooter
//     copyright="2019 蚂蚁金服体验技术部出品"
//     links={[
//       {
//         key: 'Ant Design Pro',
//         title: 'Ant Design Pro',
//         href: 'https://pro.ant.design',
//         blankTarget: true,
//       },
//       {
//         key: 'github',
//         title: <Icon type="github" />,
//         href: 'https://github.com/ant-design/ant-design-pro',
//         blankTarget: true,
//       },
//       {
//         key: 'Ant Design',
//         title: 'Ant Design',
//         href: 'https://ant.design',
//         blankTarget: true,
//       },
//     ]}
//   />
// );

const footerRender = () => {
  // if (!isAntDesignPro()) {
  //   return defaultFooterDom;
  // }

  return (
    <>
      {/* {defaultFooterDom} */}
      <div
        style={{
          padding: '0px 24px 24px',
          textAlign: 'center',
        }}
      >
        <a href="https://www.netlify.com" target="_blank" rel="noopener noreferrer">
          <img
            src="https://www.netlify.com/img/global/badges/netlify-color-bg.svg"
            width="82px"
            alt="netlify logo"
          />
        </a>
      </div>
    </>
  );
};

const BasicLayout = props => {
  const {
    dispatch,
    children,
    settings,
    location = {
      pathname: '/',
    },
  } = props;
  /**
   * constructor
   */

  // useEffect(() => {
  //   if (dispatch) {
  //     dispatch({
  //       type: 'user/fetchCurrent',
  //     });
  //   }
  // }, []);
  /**
   * init variables
   */

  const handleMenuCollapse = payload => {
    if (dispatch) {
      dispatch({
        type: 'global/changeLayoutCollapsed',
        payload,
      });
    }
  }; // get children authority

  const authorized = getAuthorityFromRouter(props.route.routes, location.pathname || '/') || {
    authority: undefined,
  };
  // 点击菜单时的跳转
  const clickMenuHandler = (menuProps = {}) => {
    const { path = '' } = menuProps; // 路由
    const { origin } = location;
    let fullUrl;
    if (path.startsWith('/')) fullUrl = `${origin}/#${path}`;
    else fullUrl = `${origin}/#/${path}`;
    window.open(fullUrl, '_blank');
  };

  return (
    <ProLayout
      logo={logoPng}
      menuHeaderRender={(logoDom, titleDom) => (
        <Link to="/" style={{ position: 'sticky' }}>
          {logoDom}
          {localStorage.getItem(`SaasDisplay`) == 1 ? (
            <h1 style={{ padding: '0 0 0 12px' }}>运营平台</h1>
          ) : (
            <h1 style={{ padding: '0 0 0 12px' }}>后台管理系统</h1>
          )}
          {/* {titleDom} */}
        </Link>
      )}
      onCollapse={handleMenuCollapse}
      menuItemRender={(menuItemProps, defaultDom) => {
        if (menuItemProps.isUrl || menuItemProps.children || !menuItemProps.path) {
          return defaultDom;
        }
        if (menuItemProps.newTab) {
          // 外链跳转的
          return (
            <div
              onClick={() => {
                clickMenuHandler(menuItemProps);
              }}
            >
              {defaultDom}
            </div>
          );
        } else {
          return <Link to={menuItemProps.path}>{defaultDom}</Link>;
        }
      }}
      breadcrumbRender={(routers = []) => [
        {
          path: '/',
          breadcrumbName: formatMessage({
            id: 'menu.home',
            defaultMessage: 'home',
          }),
        },
        ...routers,
      ]}
      itemRender={(route, params, routes, paths) => {
        let { breadcrumbName } = route;
        const first = routes.indexOf(route) === 0;
        const third = routes.indexOf(route) === 2;
        if (first) {
          return (
            <Link className="lz-breadcrumb-click" to={paths.join('/')}>
              {breadcrumbName}
            </Link>
          );
        }
        if (third) {
          return (
            <Link className="lz-breadcrumb-click" to={route.path}>
              {breadcrumbName}
            </Link>
          );
        }
        breadcrumbName = /\/add$/g.test(route.path) ? '新增' : breadcrumbName;
        return <span>{breadcrumbName}</span>;
      }}
      // footerRender={footerRender}
      menuDataRender={menuDataRender}
      formatMessage={formatMessage}
      rightContentRender={() => <RightContent />}
      {...props}
      {...settings}
    >
      <Authorized authority={authorized.authority} noMatch={noMatch}>
        {children}
        {!!localStorage.getItem('tokens') ? null : <Redirect to="/user/login" />}
      </Authorized>
    </ProLayout>
  );
};

export default connect(({ global, settings }) => ({
  collapsed: global.collapsed,
  settings,
}))(BasicLayout);
