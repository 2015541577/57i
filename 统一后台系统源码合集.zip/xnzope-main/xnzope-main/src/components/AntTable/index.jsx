import React, { Component } from 'react';
import { Table } from 'antd';
import { connect } from 'dva';
@connect(() => ({}))
export default class AntTable extends Component {
  render() {
    return (
      <div style={{ marginBottom: '28px' }}>
        <Table
          columns={this.props.columns}
          dataSource={this.props.dataSource}
          pagination={false}
          size="middle"
          tableLayout="fixed"
        //   scroll={{ y: 430, x: this.props.scrollx }}
        />
      </div>
    );
  }
}
