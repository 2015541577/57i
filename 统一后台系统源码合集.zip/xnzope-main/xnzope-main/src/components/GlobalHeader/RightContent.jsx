import React, { PureComponent } from 'react';
import { FormattedMessage } from 'umi/locale';
import { Tag, Icon, Badge } from 'antd';
import { connect } from 'dva';
import { router } from 'umi';
import moment from 'moment';
import axios from 'axios';
import groupBy from 'lodash/groupBy';
import styles from './index.less';
import { ConsoleSqlOutlined, SoundOutlined } from '@ant-design/icons';
import { getPageQuery } from '@/utils/utils';
import { stringify } from 'querystring';
import Watermark from './watermark.js';
import { getToken } from '@/utils/localStorage';
@connect(({ batch }) => ({
  ...batch,
}))
// @connect()
export default class GlobalHeaderRight extends PureComponent {
  state = {
    totalNum: 0,
    shopExpireContractNum: 0,
    SaasDisplay: null,
    SaasStatus: null
  }
  handleMenuClick = ({ key }) => {
    const { dispatch } = this.props;
    console.log(dispatch, 'dispatchieeeiei')
    if (key === 'userCenter') {
      router.push('/account/center');
      return;
    }
    if (key === 'triggerError') {
      router.push('/exception/trigger');
      return;
    }
    if (key === 'userinfo') {
      router.push('/account/settings/base');
      return;
    }
    if (key === 'logout') {
      console.log(key, 'keyueuuueueu', window.location.href)
      dispatch({
        type: 'login/logout',
      });
      //  const { redirect } = getPageQuery(); 
      // if (window.location.pathname !== '/user/login' && !redirect) {
      //     router.replace({
      //       pathname: '/user/login',
      //       search: stringify({
      //         redirect: window.location.href,
      //       }),
      //     });
      // }
    }
  };
  componentDidMount() {
    this.props.dispatch({
      type: 'batch/getOrderComplaintWaitNum',
      payload: { status: '0' },
      callback: res => {
        localStorage.setItem('SaasDisplay', res.data.display ? 1 : 0);
        localStorage.setItem('disTransferOrder', res.data.disTransferOrder ? 0 : 1);
        //disTransferOrder 为true时 隐藏
        this.setState({
          totalNum: res.data.totalNum,
          shopExpireContractNum: res.data.shopExpireContractNum,
          SaasDisplay: res.data.display,   // 非SaaS展示  status
          SaasStatus: res.data.status,    //客诉处理的Saas展示
          // disTransferOrder: res.data.disTransferOrder,  //是否隐藏转单
        });
      },
    });

    // 增加水印
    if (localStorage.getItem('mobile')) {
      Watermark.set(
        `${localStorage.getItem('watermark')}`
      );
    }
  }
  toMarking = () => {
    router.push('/Marketing/Comment')
  }
  toExpire = () => {
    router.push('/StoreAudit/list')
  }
  render() {
    const { onMenuClick, theme } = this.props;
    const { totalNum, shopExpireContractNum, SaasDisplay, SaasStatus } = this.state
    let className = styles.right;
    if (theme === 'dark') {
      className = `${styles.right}  ${styles.dark}`;
    }
    return (
      <div className={className}>
        <div style={{ cursor: 'pointer', marginRight: '10px' }}>
          {/* {SaasDisplay ? (
            <span onClick={this.toExpire} style={{marginRight:'22px'}}>快到期商家： <Badge count={shopExpireContractNum} size="small" offset={[10,-3]}><SoundOutlined width="20px"/></Badge></span>
          ): null} */}
          {/* {
            SaasStatus ? (
              <span onClick={this.toMarking} style={{marginRight:'22px'}}>待处理客诉： <Badge count={totalNum} size="small" offset={[10,-3]}><SoundOutlined width="20px"/></Badge></span>
            ) : null
          } */}
          <span style={{ paddingLeft: '20px' }}>登陆账号：{localStorage.getItem('mobile')}</span>
          <span onClick={() => this.handleMenuClick({ key: 'logout' })}>
            <Icon type="logout" style={{ paddingRight: '5px', paddingLeft: '20px' }} />
            <FormattedMessage id="menu.account.logout" defaultMessage="logout" />
          </span>
        </div>
      </div>
    );
  }
}
