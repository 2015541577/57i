'use strict'

let watermark = {}

let setWatermark = (str) => {
  let id = '7.1548523441'

  if (document.getElementById(id) !== null) {
    document.body.removeChild(document.getElementById(id))
  }

  let can = document.createElement('canvas')
  can.width = 300
  can.height = 150

  let cans = can.getContext('2d')
  cans.rotate(-10 * Math.PI / 180)
  cans.font = '20px 微软雅黑'
  cans.fillStyle = 'rgba(200, 200, 200, 0.35)'
  cans.textAlign = 'left'
  cans.textBaseline = 'Middle'
  cans.fillText(str, 20, 150)

  let div = document.createElement('div')
  div.id = id
  div.style.pointerEvents = 'none'
  div.style.top = '30px'
  div.style.left = '30px'
  div.style.position = 'fixed'
  div.style.zIndex = '1'
  div.style.width = document.documentElement.clientWidth + 'px'
  div.style.height = document.documentElement.clientHeight + 'px'
  div.style.background = `url(${can.toDataURL('image/png')}) left top repeat`
  const root = document.getElementById('root');
  // document.body.appendChild(div)
  document.body.insertBefore(div, root);
  return id
}

// 该方法只允许调用一次
watermark.set = (str) => {
  let id = setWatermark(str)
  setInterval(() => {
    if (document.getElementById(id) === null) {
      id = setWatermark(str)
    }
  }, 500)
  window.onresize = () => {
    setWatermark(str)
  }
}

export default watermark