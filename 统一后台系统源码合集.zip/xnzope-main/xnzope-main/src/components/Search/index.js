import React, { Component, Fragment } from 'react';
import moment from 'moment';
import { Form, DatePicker, Input, Select, Button,Cascader,Message } from 'antd';
import SearchItemEnum from '@/components/Search/SearchItemEnum';
import { connect } from 'dva';
import axios from 'axios';
import { getToken } from '@/utils/localStorage';
import { getParam } from '@/utils/utils.js';
import { ConsoleSqlOutlined } from '@ant-design/icons';
import defaultSettings from '@/defaultSettings.js'
const FormItem = Form.Item;
const { RangePicker } = DatePicker;
const { Option } = Select;
@connect(({ goodsIndex }) => ({
  ...goodsIndex,
}))
@Form.create()
export default class Search extends Component {
  state={
    editSelectData:[],
    tableData:[],
    channelGroupCode:'',
  }
  componentDidMount(){
  }

  GroupCode =()=>{
     this.props.form.validateFields((err, value) => {
      //  优化小提示
       axios({
         url:'/hzsx/examineProduct/findCategories',
         method:'GET',
         headers:{token:getToken()},
         params:{
          pageSize:99999,
          pageNumber:1,
          channelGroupCode:'066',
        }
       }).then(res=>{
         if(res.data.data==null){
           Message.error('请先选择平台')
         }else{
           this.setState({
                  editSelectData:res.data.data
           })
         }
       })
    });
  }
  //查询
  handleFilter = () => {
    this.props.form.validateFields((err, value) => {
      this.setState({
        channelGroupCode:'066',
      },()=>{

      })
      this.props.handleFilter(value);
    });
  };
  // 获取数据
  getServceList=()=>{
    console.log('ieieieiie获取焦点')
    this.props.form.validateFields((err,value)=>{
        axios({
        url:'/hzsx/repairOrder/selectRepairOrderList',
        method:'GET',
        headers:{token:getToken()},
        params:{
          pageSize:99999,
          pageNumber:1,
          channelGroupCode:'066',
        }
      }).then(res=>{
        if(res.data.data==null){
          Message.error('请先选择平台')
        }else {
          this.setState({
            tableData:res.data.data.records,
          })
        }
      })
    })
  }
  // 重置
  handleReset = async () => {
    this.props.form.resetFields();
    this.props.form.setFieldsValue({
      auditState: undefined,
      type: undefined,
      isDelete: undefined,
    });
    // this.props.handleFilter();
  };
  // 导出
  exportData = () => {
    this.props.form.validateFields((err, value) => {
      this.props.exportData(value);
    });
  };
  // 生成注册码
  // theProductKey = () => {
  //   this.props.form.validateFields((err, value) => {
  //     this.props.theProductKey(value);
  //   });
  // };
  // 给搜索组件的选择框传递选项数据
  renderLZSearch = searchConfigs => {

    const { getFieldDecorator } = this.props.form;
    let allOptions = this.props.options || [];

    return (
      <Fragment>
        {searchConfigs.map(searchConfig => {
          let _options = [];
          let Channels=[]
         let optiontype=[]
          if (allOptions) {
            const item = allOptions.find(f => f.field === searchConfig||f.owningPlatform === searchConfig||f.accountType === searchConfig) || [];
            if (item) {
              _options = item.options;
              Channels=item.Channels;
              optiontype=item.Types
            }
          }
          return SearchItemEnum[searchConfig](getFieldDecorator, _options,Channels,optiontype);
        })}
      </Fragment>
    );
  };

  // 判断不同的来源展示不同的搜索组件
  selectForms = source => {
    let searchConfigs = [];
    switch (source) {
      case '店铺审核':
        searchConfigs = [
          'companyName',
          // 'isPhoneExamination',
          'shopId',
          'shopName',
          'shopCreateDate',
          'shopAuditStatus',
        ];
      case '店铺审核':
        searchConfigs = [
          'shopName',
          // 'isPhoneExamination',
          'shopId',
          'companyName',
          'shopCreateDate',
          'shopAuditStatus',
          //   "shopChannelGroupCode",

        ];
        break;
      case '商品审核':
        searchConfigs = [
          'goodsAuditStatus',
          'goodsAuditUpStatus',
          'productName',
          'productId',
          'shopId',
          'shopName',
          'creatTime',
          // 'categoryId',
        ];
        break;
        case '商品购买':
        searchConfigs = [
          'goodsAuditStatus',
          'goodsAuditUpStatus',
          'productName',
          'productId',
          'shopId',
          'shopName',
          'creatTime',
          // 'categoryId',
        ];
        break;
      case '佣金设置':
        searchConfigs = ['shopName', 'applicant', 'type', 'status'];
        break;
      case '佣金审批':
        searchConfigs = ['shopName', 'type', 'status'];
        break;
      case '常规订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'orderStatus',
        ];
        break;
      case '买断订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'buyOutOrderStatus',
        ];
        break;
      case '购买订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'purchaseOrderStatus',
        ];
        break;
      case '部落配置':
        searchConfigs = ['tribeTitle', 'tribeStatus'];
        break;
      case '成员管理':
        searchConfigs = ['memberName', 'departments','mobile'];
        break;
        case '登录用户列表':
        searchConfigs = ['memberName', 'departments','mobile','owningPlatform','accountType'];
        break;
      case '商品列表':
        searchConfigs = ['productName', 'categoryIds', 'shangjiaStatus', 'auditStatus'];
        break;
      case '大礼包':
        searchConfigs = ['packageName', 'packageStatus'];
        break;
      case '活动配置':
        searchConfigs = ['activityName'];
        break;

      default:
        break;
    }
    return this.renderLZSearch(searchConfigs);
  };
  selectForms1 = source1 => {
    let searchConfigs = [];
    switch (source1) {
      case '店铺审核':
        searchConfigs = [
          'companyName',
          // 'isPhoneExamination',
          'shopId',
          'shopName',
          'shopCreateDate',
          'shopAuditStatus',
        ];
      case '店铺审核':
        searchConfigs = [
          'shopName',
          // 'isPhoneExamination',
          'shopId',
          // 'companyName',
          'shopCreateDate',
          'shopAuditStatus',

        ];
        break;
      case '商品审核':
        searchConfigs = [
          "channelGroupCode",
          'goodsAuditStatus',
          'goodsAuditUpStatus',
          'productName',
          'productId',
          'shopId',
          'shopName',
          'creatTime',
          // 'categoryId',
        ];
        break;
        case '商品购买':
        searchConfigs = [
          'goodsAuditStatus',
          'goodsAuditUpStatus',
          'productName',
          'productId',
          'shopId',
          'shopName',
          'creatTime',
          // 'categoryId',
        ];
        break;
      case '佣金设置':
        searchConfigs = ['shopName', 'applicant', 'type', 'status'];
        break;
      case '佣金审批':
        searchConfigs = ['shopName', 'type', 'status'];
        break;
      case '常规订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'orderStatus',
        ];
        break;
      case '买断订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'buyOutOrderStatus',
        ];
        break;
      case '购买订单':
        searchConfigs = [
          'productName',
          'withBusinessSettleStatus',
          'orderer',
          'ordererPhone',
          'orderId',
          'createTimeStart',
          'purchaseOrderStatus',
        ];
        break;
      case '部落配置':
        searchConfigs = ['tribeTitle', 'tribeStatus'];
        break;
      case '成员管理':
        searchConfigs = ['memberName', 'departments','mobile'];
        break;
        case '登录用户列表':
          searchConfigs = ['memberName', 'departments','mobile','owningPlatform','accountType'];
          break;
      case '商品列表':
        searchConfigs = ['productName', 'categoryIds', 'shangjiaStatus', 'auditStatus'];
        break;
      case '大礼包':
        searchConfigs = ['packageName', 'packageStatus'];
        break;
      case '活动配置':
        searchConfigs = ['activityName'];
        break;

      default:
        break;
    }
    return this.renderLZSearch(searchConfigs);
  };

  renderFooter = () => {
    const { needExport, needReset = true,source } = this.props;
    return (
      <div>
        <FormItem style={{ textAlign: 'center' }}>
          <Button type="primary"  onClick={this.handleFilter}>
            查询
          </Button>
          {needReset ? (
            <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
              重置
            </Button>
          ) : null}
          {needExport ? (
            <Button style={{ marginLeft: 8 }} onClick={this.exportData}>
              导出
            </Button>
          ) : null}
          {/* {
            source == "店铺审核" && localStorage.getItem('permissionTags') && localStorage.getItem('permissionTags').includes("opeGenerateShopRegCd") ? (
              <Button style={{ marginLeft: 8,color:"#fff", background:"#02BB78",borderColor:"#02BB78" }} onClick={this.theProductKey}>
                生成注册码
              </Button>
            ) : null
          } */}
        </FormItem>
      </div>
    );
  };
  renderFooter1 = () => {
    const { needExport, needReset = true,source1 } = this.props;
    return (
      <div>
        <FormItem style={{ textAlign: 'center' }}>
          <Button type="primary"  onClick={this.handleFilter}>
            查询
          </Button>
          {needReset ? (
            <Button style={{ marginLeft: 8 }} onClick={this.handleReset}>
              重置
            </Button>
          ) : null}
          {needExport ? (
            <Button style={{ marginLeft: 8 }} onClick={this.exportData}>
              导出
            </Button>
          ) : null}
          {/* {
            source1 == "店铺审核" && localStorage.getItem('permissionTags')? (
              <Button style={{ marginLeft: 8,color:"#fff", background:"#02BB78",borderColor:"#02BB78" }} onClick={this.theProductKey}>
                生成注册码
              </Button>
            ) : null
          } */}
        </FormItem>
      </div>
    );
  };

  render() {
    const { source ,source1,getId} = this.props;
    const {editSelectData,tableData} = this.state
    const { getFieldDecorator } = this.props.form;
    return (
      <Form layout="inline">
        {this.selectForms(source)}
        {this.selectForms1(source1)}
        {this.props.channelList ? (
          <FormItem>
            {getFieldDecorator('channelId', {
              initialValue: '',
            })(
              <Select style={{ width: 180 }}>
                {this.props.channelList.map(item => {
                  return (
                    <Option key={item.channelId} value={item.channelId}>
                      {item.channelName}
                    </Option>
                  );
                })}
              </Select>,
            )}
          </FormItem>
        ) : null}
        {
          this.props.getId==true?(
            <>
             <FormItem label="商品类目">
              {getFieldDecorator('category', {
                // initialValue: editInfo && editInfo.category && editInfo.category.categoryId,
              })(<Cascader onClick={()=> this.GroupCode()} options={editSelectData} placeholder="请选择类目" allowClear/>)}
              </FormItem>
               {/* <FormItem label="质选服务" >
                  {getFieldDecorator('servceId', {
                    // initialValue: '',
                  })(
                    <Select  placeholder="请输入质选服务"  allowClear onFocus={()=> this.getServceList()} style={{ width: 180 }}>
                      {tableData.map(item => {
                        return (
                          <Option key={item.id} value={item.id}>
                            {item.name}
                          </Option>
                        );
                      })}
                    </Select>,
                  )}
                </FormItem> */}
            </>
          ):null
        }
        {this.renderFooter()}
        {/* {this.renderFooter1()} */}

      </Form>
    );
  }
}
