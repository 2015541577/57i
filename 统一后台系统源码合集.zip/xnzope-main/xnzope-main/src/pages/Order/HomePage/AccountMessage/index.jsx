
import styles from './index.less';
import { Modal,Statistic } from 'antd';
const { Countdown } = Statistic;
import { router } from 'umi';

export default  function AccountMessage(saasAccountMesage) {
  // console.log(saasAccountMesage[0]);
  const deadline =Date.now()+saasAccountMesage[0]?saasAccountMesage[0].billsDueTime:[] * 1000
  let flg=false
  //  let setimon=saasAccountMesage[0].billsDueTime
  //  function countDown(){
  //   setimon--
  
  //   if(setimon==0){
      
  //     router.push("/user/login")
  //   }
  //  }
  
  // setInterval(countDown, 1000);
  // window.onbeforeunload = function(e) {
  //   var e = window.event ||e;
  //   e.returnValue=("是否确定关闭页面");
  // }
  if(saasAccountMesage[0]&&saasAccountMesage[0].balanceAmount<=0){
    flg=true
  }
  console.log(flg);
   if(flg){
  let confirm= Modal.warning({
       title: '您的账户',
       width:500,
        className:styles.accountMesage,
      //  className:saasAccountMesage[0].billsDueTime<=0?styles.accountMesage:"",
      //  maskClosable:saasAccountMesage[0].billsDueTime<=0?false:true,
       maskClosable:true,
       content:<div>
         {
           saasAccountMesage.map((item, ind) => (
             <div key={ind}>
               <span>{item.company}</span>账户余额为 
               <span style={{color: 'red'}}>{ item.balanceAmount}元</span>
             </div>
           ))
         }
         {
           saasAccountMesage[0].billsDueTime>0?
           <div> 
            <span className='input' style={{color:"red"}}>
             <Countdown value={deadline}  format=" H 时 m 分 s 秒"  onFinish={()=>{
              router.push("/user/login")
              confirm.destroy()
              // flg=false
             }} />
             </span>后平台各项功能停止服务，请尽快充值!</div>:
            <div>您的账户已欠费，请尽快充值!!!!!!!!</div>
         } 
       </div>,
       okText: "去充值",
       onOk:()=>{
       router.push('/Platform/SaasBalance');
       }
     })
   }
     
}


