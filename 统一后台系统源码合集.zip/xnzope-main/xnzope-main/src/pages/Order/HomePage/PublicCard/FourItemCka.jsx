import React, { Component } from 'react';
import styles from './index.less';
import { Descriptions } from 'antd';

class FourItem extends Component {
  render() {
    const { style, title,data={} } = this.props;

    return (
      <div className={styles.fourWrap} style={{ ...style }}>
        <Descriptions column={4} layout="vertical" bordered>
          <Descriptions.Item label={title.first}>{data.rent_history_times_d7 === '无记录' ? '----' : data.rent_history_times_d7}</Descriptions.Item>
          <Descriptions.Item label={title.second}>{data.rent_history_times_m1 === '无记录' ? '----' : data.rent_history_times_m1}</Descriptions.Item>
          <Descriptions.Item label={title.three}>{data.rent_history_times_m3 === '无记录' ? '----' : data.rent_history_times_m3}</Descriptions.Item>
          <Descriptions.Item label={title.four}>{data.rent_history_times_m6 === '无记录' ? '----' : data.rent_history_times_m6}</Descriptions.Item>
        </Descriptions>
      </div>
    )
  }
}
export default FourItem;