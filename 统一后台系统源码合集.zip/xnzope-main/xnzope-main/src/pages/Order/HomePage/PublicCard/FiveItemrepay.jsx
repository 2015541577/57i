import React, { Component } from 'react';
import styles from './index.less';
import { Descriptions } from 'antd';

class Fiveitem extends Component {
  render() {
    const { title, style, text, data = {} } = this.props;

    return (
      <div className={styles.fiveWrap} style={{ ...style }}>
        {title.five ? (
          <>
            <Descriptions column={5} layout="vertical" bordered>
              <Descriptions.Item label={title.first}>
                {data.lenders === '' ? 0 : data.lenders}
              </Descriptions.Item>
              <Descriptions.Item label={title.second}>
                {data.cflenders === '' ? 0 : data.cflenders}
              </Descriptions.Item>
              <Descriptions.Item label={title.three}>
                {data.nllenders === '' ? 0 : data.nllenders}
              </Descriptions.Item>
              <Descriptions.Item label={title.four}>
                {data.lend_time === '' ? 0 : data.lend_time}
              </Descriptions.Item>
              <Descriptions.Item label={title.five}>
                {data.lend_time_distance === '' ? 0 : data.lend_time_distance}
              </Descriptions.Item>
            </Descriptions>
          </>
        ) : title.name == 'suggest' ? (
          <>
            <Descriptions column={5} layout="vertical" bordered>
              <Descriptions.Item label={title.first}>
                {data.goods_type === '' ? 0 : data.goods_type}
              </Descriptions.Item>
              <Descriptions.Item label={title.second}>
                {data.status === 0 ? '新品' : data.status === 1 ? '二手' : ''}
              </Descriptions.Item>
              <Descriptions.Item label={title.three}>
                {data.total_rent === '' ? 0 : data.total_rent}
              </Descriptions.Item>
              <Descriptions.Item label={title.four}>
                {data.total_periods === '' ? 0 : data.total_periods}
              </Descriptions.Item>
              <Descriptions.Item label={title.one}>
                {data.price === '' ? 0 : data.price}
              </Descriptions.Item>
            </Descriptions>
          </>
        ) : title.name == 'dict' ? (
          <>
            <Descriptions column={5} layout="vertical" bordered>
              <Descriptions.Item label={title.first}>
                {data.identity_two_elements === '01'
                  ? '不一致'
                  : data.identity_two_elements === '02'
                  ? '一致'
                  : ''}
              </Descriptions.Item>
              <Descriptions.Item label={title.second}>
                {data.network_triple_elements === '01'
                  ? '不一致'
                  : data.network_triple_elements === '02'
                  ? '一致'
                  : ''}
              </Descriptions.Item>
              <Descriptions.Item label={title.three}>
                {data.time_online ? data.time_online : ''}
              </Descriptions.Item>
            </Descriptions>
          </>
        ) : (
          <>
            <Descriptions column={5} layout="vertical" bordered>
              <Descriptions.Item label={title.first}>
                <span style={{ fontWeight: 'bold' }}>{text}</span>
              </Descriptions.Item>
              <Descriptions.Item label={title.second}>
                {data.lend_number1 === '' ? 0 : data.lend_number1}
              </Descriptions.Item>
              <Descriptions.Item label={title.three}>
                {data.lend_number3 === '' ? 0 : data.lend_number3}
              </Descriptions.Item>
              <Descriptions.Item label={title.four}>
                {data.lend_number6 === '' ? 0 : data.lend_number6}
              </Descriptions.Item>
            </Descriptions>
          </>
        )}
        {/* <Descriptions column={5} layout="vertical" bordered>
          <Descriptions.Item label={title.first}><span style={{ fontWeight: 'bold' }}>{text}</span></Descriptions.Item>
          <Descriptions.Item label={title.second}>{data.lend_number1 === '无记录' ? 0 : data.lend_number1}</Descriptions.Item>
          <Descriptions.Item label={title.three}>{data.lend_number3 === '无记录' ? 0 : data.lend_number3}</Descriptions.Item>
          <Descriptions.Item label={title.four}>{data.lend_number6 === '无记录' ? 0 : data.lend_number6}</Descriptions.Item>
        </Descriptions> */}
      </div>
    );
  }
}
export default Fiveitem;
