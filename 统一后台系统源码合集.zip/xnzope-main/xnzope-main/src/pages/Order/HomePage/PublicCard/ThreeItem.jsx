import React, { Component } from 'react';
import styles from './index.less';
import { Descriptions } from 'antd';

class Threeitem extends Component {
  render() {
    const { style, title,data={} } = this.props;

    return (
      <div className={styles.threeWrap} style={{ ...style }}>
        {
          title.name=='threeName'?(
          <>
           <tbody style={{border:'1px solid #eee',width:'99%',height:'110px',textAlign:'center',marginTop:'220px'}}>
                  <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}></td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.one}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.first}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.two}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.three}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.second}</td>
                  </tr>
                    <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.observeNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.d7_apply_agency_time === '' ? 0 : data.d7_apply_agency_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m1_apply_agency_time === '' ? 0 : data.m1_apply_agency_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m3_apply_agency_time === '' ? 0 : data.m3_apply_agency_time}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m6_apply_agency_time === '' ? 0 : data.m6_apply_agency_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m12_apply_agency_time === '' ? 0 : data.m12_apply_agency_time}</td>
                  </tr>
                   <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.unobserveNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.d7_apply_time === '' ? 0 : data.d7_apply_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m1_apply_time === '' ? 0 : data.m1_apply_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m3_apply_time === '' ? 0 : data.m3_apply_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m6_apply_time === '' ? 0 : data.m6_apply_time}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.m12_apply_time === '' ? 0 : data.m12_apply_time}</td>
                  </tr>
            </tbody>
              {/* <Descriptions column={6} layout="vertical" bordered>
              <Descriptions.Item label=""><span style={{ fontWeight: 'bold' }}>{title.observeNum}</span></Descriptions.Item>
              <Descriptions.Item label={title.one}>{data.d7_apply_agency_time === '无记录' ? 0 : data.d7_apply_agency_time}</Descriptions.Item>
              <Descriptions.Item label={title.first}>{data.m1_apply_agency_time === '无记录' ? 0 : data.m1_apply_agency_time}</Descriptions.Item>
              <Descriptions.Item label={title.two}>{data.m3_apply_agency_time === '无记录' ? 0 : data.m3_apply_agency_time}</Descriptions.Item>
              <Descriptions.Item label={title.three}>{data.m6_apply_agency_time === '无记录' ? 0 : data.m6_apply_agency_time}</Descriptions.Item>
              <Descriptions.Item label={title.second}>{data.m12_apply_agency_time === '无记录' ? 0 : data.m12_apply_agency_time}</Descriptions.Item>
            </Descriptions>
            <div className={styles.threeAbnormal}>
              <span style={{ fontWeight: 'bold' }}>{title.unobserveNum}</span>
              <span>{data.d7_apply_time === '无记录' ? 0 : data.d7_apply_time}</span>
              <span>{data.m1_apply_time === '无记录' ? 0 : data.m1_apply_time}</span>
              <span>{data.m3_apply_time === '无记录' ? 0 : data.m3_apply_time}</span>
              <span>{data.m6_apply_time === '无记录' ? 0 : data.m6_apply_time}</span>
              <span>{data.m12_apply_time === '无记录' ? 0 : data.m12_apply_time}</span>
            </div> */}
          </>):title.name=='threeNames'?(
           <>
             <tbody style={{border:'1px solid #eee',width:'99%',height:'130px',textAlign:'center',marginTop:'220px'}}>
                  <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}></td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.one}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.first}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.two}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.three}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.second}</td>
                  </tr>
                    <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.observeNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_succ1 === '' ? 0 : data.repay_succ1}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_succ3 === '' ? 0 : data.repay_succ3}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_succ6 === '' ? 0 : data.repay_succ6}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_succ12 === '' ? 0 : data.repay_succ12}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_succ24 === '' ? 0 : data.repay_succ24}</td>
                  </tr>
                   <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.unobserveNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_money1 === '' ? 0 : data.repay_money1}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_money3 === '' ? 0 : data.repay_money3}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_money6 === '' ? 0 : data.repay_money6}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_money12 === '' ? 0 : data.repay_money12}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_money24 === '' ? 0 : data.repay_money24}</td>
                  </tr>
                   <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.unobserveNums}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_fail1 === '' ? 0 : data.repay_fail1}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_fail3 === '' ? 0 : data.repay_fail3}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_fail6 === '' ? 0 : data.repay_fail6}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_fail12 === '' ? 0 : data.repay_fail12}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.repay_fail24 === '' ? 0 : data.repay_fail24}</td>
                  </tr>
                </tbody>
              {/* <Descriptions column={6} layout="vertical" bordered>
                <Descriptions.Item label=""><span style={{ fontWeight: 'bold' }}>{title.observeNum}</span></Descriptions.Item>
                <Descriptions.Item label={title.one}>{data.repay_succ1 === '无记录' ? 0 : data.repay_succ1}</Descriptions.Item>
                <Descriptions.Item label={title.first}>{data.repay_succ3 === '无记录' ? 0 : data.repay_succ3}</Descriptions.Item>
                <Descriptions.Item label={title.two}>{data.repay_succ6 === '无记录' ? 0 : data.repay_succ6}</Descriptions.Item>
                <Descriptions.Item label={title.three}>{data.repay_succ12 === '无记录' ? 0 : data.repay_succ12}</Descriptions.Item>
                <Descriptions.Item label={title.second}>{data.repay_succ24 === '无记录' ? 0 : data.repay_succ24}</Descriptions.Item>
              </Descriptions>
               <Descriptions column={6} layout="vertical" bordered>
                <Descriptions.Item label=""><span style={{ fontWeight: 'bold' }}>{title.unobserveNum}</span></Descriptions.Item>
                <Descriptions.Item label={title.one}>{data.repay_money1 === '无记录' ? 0 : data.repay_money1}</Descriptions.Item>
                <Descriptions.Item label={title.first}>{data.repay_money3 === '无记录' ? 0 : data.repay_money3}</Descriptions.Item>
                <Descriptions.Item label={title.two}>{data.repay_money6 === '无记录' ? 0 : data.repay_money6}</Descriptions.Item>
                <Descriptions.Item label={title.three}>{data.repay_money12 === '无记录' ? 0 : data.repay_money12}</Descriptions.Item>
                <Descriptions.Item label={title.second}>{data.repay_money24 === '无记录' ? 0 : data.repay_money24}</Descriptions.Item>
              </Descriptions>
               <Descriptions column={6} layout="vertical" bordered>
                <Descriptions.Item label=""><span style={{ fontWeight: 'bold' }}>{title.unobserveNums}</span></Descriptions.Item>
                <Descriptions.Item label={title.one}>{data.repay_fail1 === '无记录' ? 0 : data.repay_fail1}</Descriptions.Item>
                <Descriptions.Item label={title.first}>{data.repay_fail3 === '无记录' ? 0 : data.repay_fail3}</Descriptions.Item>
                <Descriptions.Item label={title.two}>{data.repay_fail6 === '无记录' ? 0 : data.repay_fail6}</Descriptions.Item>
                <Descriptions.Item label={title.three}>{data.repay_fail12 === '无记录' ? 0 : data.repay_fail12}</Descriptions.Item>
                <Descriptions.Item label={title.second}>{data.repay_fail24 === '无记录' ? 0 : data.repay_fail24}</Descriptions.Item>
              </Descriptions> */}
              {/* <div className={styles.threeAbnormals}>
                <span style={{ fontWeight: 'bold' }}>{title.unobserveNum}</span>
                <span>{data.repay_money1 === '无记录' ? 0 : data.repay_money1}</span>
                <span>{data.repay_money3 === '无记录' ? 0 : data.repay_money3}</span>
                <span>{data.repay_money6 === '无记录' ? 0 : data.repay_money6}</span>
                <span>{data.repay_money12 === '无记录' ? 0 : data.repay_money12}</span>
                <span>{data.repay_money24 === '无记录' ? 0 : data.repay_money24}</span>
              </div> */}
              {/* <div className={styles.threeAbnormals}>
                <span style={{ fontWeight: 'bold' }}>{title.unobserveNums}</span>
                <span>{data.repay_fail1 === '无记录' ? 0 : data.repay_fail1}</span>
                <span>{data.repay_fail3 === '无记录' ? 0 : data.repay_fail3}</span>
                <span>{data.repay_fail6 === '无记录' ? 0 : data.repay_fail6}</span>
                <span>{data.repay_fail12 === '无记录' ? 0 : data.repay_fail12}</span>
                <span>{data.repay_fail24 === '无记录' ? 0 : data.repay_fail24}</span>
              </div> */}
            </>
          ):(
              <>
               <tbody style={{border:'1px solid #eee',width:'99%',height:'110px',textAlign:'center',marginTop:'220px'}}>
                  <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}></td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.one}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.first}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.two}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.three}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.second}</td>
                  </tr>
                    <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.observeNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_number1 === '' ? 0 : data.lend_number1}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_number3 === '' ? 0 : data.lend_number3}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_number6 === '' ? 0 : data.lend_number6}</td>
                     <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_number12 === '' ? 0 : data.lend_number12}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_number24 === '' ? 0 : data.lend_number24}</td>
                  </tr>
                   <tr>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee',fontWeight: 'bold'}} colSpan={2}>{title.unobserveNum}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_money1 === '' ? 0 : data.lend_money1}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_money3 === '' ? 0 : data.lend_money3}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_money6 === '' ? 0 : data.lend_money6}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_money12 === '' ? 0 : data.lend_money12}</td>
                    <td  style={{width:'400px',verticalAlign:'center',border:'1px solid #eee'}} colSpan={2}>{data.lend_money24 === '' ? 0 : data.lend_money24}</td>
                  </tr>
            </tbody>
                {/* <Descriptions column={6} layout="vertical" bordered>
                  <Descriptions.Item label=""><span style={{ fontWeight: 'bold' }}>{title.observeNum}</span></Descriptions.Item>
                  <Descriptions.Item label={title.one}>{data.repay_succ1 === '无记录' ? 0 : data.repay_succ1}</Descriptions.Item>
                  <Descriptions.Item label={title.first}>{data.repay_succ3 === '无记录' ? 0 : data.repay_succ3}</Descriptions.Item>
                  <Descriptions.Item label={title.two}>{data.repay_succ6 === '无记录' ? 0 : data.repay_succ6}</Descriptions.Item>
                  <Descriptions.Item label={title.three}>{data.repay_succ12 === '无记录' ? 0 : data.repay_succ12}</Descriptions.Item>
                  <Descriptions.Item label={title.second}>{data.repay_succ24 === '无记录' ? 0 : data.repay_succ24}</Descriptions.Item>
                </Descriptions>
                <div className={styles.threeAbnormals}>
                  <span style={{ fontWeight: 'bold' }}>{title.unobserveNum}</span>
                  <span>{data.repay_money1 === '无记录' ? 0 : data.repay_money1}</span>
                  <span>{data.repay_money3 === '无记录' ? 0 : data.repay_money3}</span>
                  <span>{data.repay_money6 === '无记录' ? 0 : data.repay_money6}</span>
                  <span>{data.repay_money12 === '无记录' ? 0 : data.repay_money12}</span>
                  <span>{data.repay_money24 === '无记录' ? 0 : data.repay_money24}</span>
                </div> */}
            </>
          )
        }
      </div>
    )
  }
}
export default Threeitem;