import React, { Component, Fragment } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { router } from 'umi';
import {
  message,
  Card,
  Tooltip,
  Button,
  Form,
  Input,
  Select,
  DatePicker,
  Spin,
  Modal,
  Radio,
  List,
  Badge,
  Drawer,
  Tabs,
  Descriptions,
  Divider,
  Table,
  Popconfirm,
  Row,
  Col,
  Pagination,
  Timeline,
  InputNumber,
  Icon,
  Cascader,
  Checkbox,
} from 'antd';
import { onTableData, getParam } from '@/utils/utils.js';
import { getTimeDistance, throttle } from '@/utils/utils';
import AntTable from '@/components/AntTable';
import RiskControlReport from './components/RiskControlReport/index.jsx';
import moment from 'moment';
import { orderStatusMap, orderCloseStatusMaps } from '@/utils/enum';
import { optionsdata } from './data';
import copy from 'copy-to-clipboard';
import axios from 'axios';
import styles from './index.less';
import CustomCard from '@/components/CustomCard';
import OrderService from '@/services/order';
import qs from 'qs';
import { getToken } from '@/utils/localStorage';
import { EditOutlined, FormOutlined } from '@ant-design/icons';

const { Option } = Select;
const { TextArea } = Input;
const { RangePicker } = DatePicker;
const { TabPane } = Tabs;
const FormItem = Form.Item;

const columnsByStagesStute = {
  '1': '待支付',
  '2': '已支付',
  '3': '逾期已支付',
  '4': '逾期待支付',
  '5': '已取消',
  '6': '已结算',
  '7': '已退款,可用',
};

const skuTypeInfo = {
  '1': { skuInfo: '高分专享：芝麻分700-749分', color: '#F7C100' },
  '2': { skuInfo: '高分专享：芝麻分650-699分', color: '#3DB027' },
  '3': { skuInfo: '高分专享：芝麻分649分以下', color: '#169BD5' },
  '4': { skuInfo: '高分专享：芝麻分750-950分', color: '#FFC806' },
};

// 操作纪录表头
const columnsOperation = [
  {
    title: '内容',
    dataIndex: 'notes',
    width: 350,
    render: (_, record) =>
      record.notes == null ? (
        <>{record.note}</>
      ) : (
        !!record.notes &&
        !!record.notes.length &&
        record.notes.map((val, index) => (
          <>
            <span key={val}>{val} </span>
            <br />
          </>
        ))
      ),
  },
  {
    title: '用户类型',
    dataIndex: 'operatorUserTypeShowName',
    width: 150,
  },
  {
    title: '操作人',
    dataIndex: 'userName',
    width: 150,
    render: (text, record) => (
      <Tooltip placement="topLeft" title={record.mobile}>
        {record.userName}
      </Tooltip>
    ),
  },
  {
    title: '操作时间',
    dataIndex: 'createTime',
    width: 200,
  },
];
const columnsBuyOutYes = [
  {
    title: '是否已买断',
    dataIndex: 'createTime',
    render: () => '是',
  },
  {
    title: '买断价格',
    dataIndex: 'buyOutAmount',
  },
];
const columnsBuyOutNo = [
  {
    title: '是否已买断',
    dataIndex: 'createTime',
    render: () => '否',
  },
  {
    title: '当前买断价格',
    dataIndex: 'currentBuyOutAmount',
  },
  {
    title: '到期买断价格',
    dataIndex: 'dueBuyOutAmount',
  },
];
const advises = [
  {
    name: '老客户，建议免审',
    value: '1',
  },
  {
    name: '[极低风险],该类用户守约率97%以上，建议用户支付首期租金发货',
    value: '7',
  },
  {
    name: '[优]该类用户守约率85%以上，建议用户支付两期租金发货',
    value: '2',
  },
  {
    name: '[良]建议适当预收客户租金，正常电审，谨慎发货',
    value: '3',
  },
  {
    name:
      '[一般]该类用户资质一般，建议电审如 1.通过核实用户的工作情况和累计贷款金额等，判断偿还能力;2.核实常驻地址;3.增加紧急联系人。',
    value: '4',
  },
  {
    name: '[差]风控不通过，风险较高。建议预收到设备价值或者拒绝。',
    value: '5',
  },
];
const advisesAll = [
  {
    name: '全部',
    value: '0',
    label: '全部',
  },
  {
    name: '待确定风控',
    value: '6',
    label: '待确定风控',
  },
  {
    name: '老客户，建议免审',
    value: '1',
    label: '老客户',
  },
  {
    name: '[极低风险],该类用户守约率97%以上，建议用户支付首期租金发货',
    value: '7',
    label: 'A',
  },
  {
    name: '[优]该类用户守约率85%以上，建议用户支付两期租金发货',
    value: '2',
    label: 'B',
  },
  {
    name: '[良]建议适当预收客户租金，正常电审，谨慎发货',
    value: '3',
    label: 'C',
  },
  {
    name:
      '[一般]该类用户资质一般，建议电审如 1.通过核实用户的工作情况和累计贷款金额等，判断偿还能力;2.核实常驻地址;3.增加紧急联系人。',
    value: '4',
    label: 'D',
  },
  {
    name: '[差]风控不通过，风险较高。建议预收到设备价值或者拒绝。',
    value: '5',
    label: 'E',
  },
];
let timer = null;
@connect(({ order, loading }) => ({
  ...order,
  loading: loading.effects['order/queryOpeOrderByConditionList'],
}))
@Form.create()
export default class HomePage extends Component {
  state = {
    expand: false, // 表单折叠展开状态
    old_name: '',
    new_name: '',
    riskRemark: '',
    current: 1,
    wlList: [],
    picList: [],
    datas: {},
    visible: false,
    voucher: false,
    advise: false,
    yunTime: getTimeDistance('month'),
    gBtusua: '', // 默认状态: 待发货-取消该初始状态
    idurl: [],
    imgvisi: false,
    orderId: '',
    identity: false,
    isFormOutlined: null,
    logistics: false,
    returnlogistics: false,
    imgInfo: '',
    indent: '',
    jsonValue: '',
    pudate: false,
    submitTrue: false,
    transfer: false,
    placementVisible: false, // 风控报告
    billInformation: false, //账单信息的抽屉控制变量
    queryOrderStagesDetail: {},
    electronicVisible: false,
    depositScore: null,
    depositOutScore: null,
    leaseLinkVisible: false,
    insureVisible: false,
    insureObj: {},
    leaseLinkUrl: null,
    productspceList: [],
    productspceId: null,
    day_price: '',
    deposit: '',
    count_price: '',
    salePrice: '',
    day: '',
    name: '',
    order_id: '',
    orderStagePeriod: '',
    istoRefund: false, //退款弹框变量
    refundRemark: '',
    sku_id: '',
    modification_price: 0, //修改价格
    old_price: null, // 储存刚开始日租金
    transferList: [],
    recordList: [],
    transferId: null,
    price: '',
    timeVisible: false, //时间记录弹框变量
    remarkVisible: false, // 备注弹窗
    tiemData: [], //定义时间记录的数组
    recordVisible: false, // 查看记录
    record_list: [], // 查看记录列表
    riskControlData: {},
    redatas: {},
    leaseLoading: false,
    brokerageRateVisible: false, // 佣金比率弹窗
    rate: null,
    logisticsInformation: false, //这是物流弹框
    returnLogisticsInformation: false, // 归还物流信息
    drawerVisible: false, //这是物流信息的弹框
    receiptExpressInfo: {}, // 这是物流单号的数据
    giveBackExpressInfo: {}, //这是归还物流单号的数据
    getPicPushExpressList: {}, //查询推送物流图片的数据
    orderVisible: '',
    deliverOptions: [],
    address: '',
    tele: '',
    realName: '',
    orderAddressDto: {},
    checkBoxStatusList: [], //  保存状态列表
    check_box_status: false,
    depositDeductHistory: [],
    onShowPay: false,
    billSplitVisible: false,
    IsStatusList: [
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
      {
        IsStatus: false,
      },
    ],
    b_Backspace: 0,
    rules: {},
    overrule: false,
    overruleId: '',
    userUid: '',
    isOpenBtn: false,
    seletctId: null,
    currentPeriods: null, //拆分账期
    recordSelect: [],
    newValue: [],
    isrisk: false,
    isRiskStatus: false,
    phone: '',
    dialogueList: [],
    unRuning: {},
    isRiskgc: false,
    runingList: [],
    runingYyzsList: [],
    modelResultList: {},
    endPrice: '',
    countersignVisible: false,
    imageVisible: false,
    returnCountersignVisible: false,
    returnImageVisible: false,
    runingYyzs: {},
    identification: [],
    status: '',
    orderByStagesDtoList: [],
    nextXuZuOrderByStagesList: [],
    uid: '',
    userOrderStatus: '',
    EchophoneNumber: '', //回显手机号
    Echoname: '', //回显名字
  };
  newWithholdType = null;
  columnsByStages = [
    {
      title: '总期数',
      dataIndex: 'totalPeriods',
      width: '6%',
    },
    {
      title: '当前期数',
      dataIndex: 'currentPeriods',
      width: '6%',
      align: 'center',
    },
    {
      title: '租期',
      align: 'center',
      width: '12%',
      render: (e, record) => (
        <span>
          {e.rentStartDtStr == null && e.rentEndDtStr == null ? (
            ''
          ) : (
            <>
              {e.rentStartDtStr}至{e.rentEndDtStr}
            </>
          )}
        </span>
      ),
    },
    {
      title: '租金',
      dataIndex: 'currentPeriodsRent',
      width: '7%',
    },
    {
      title: '备注-优惠券',
      width: '7%',
      render: (e, record) => (
        <Tooltip title={e.voucherRemarkInfo}>
          {e.voucherRemarkInfo == null ? (
            ''
          ) : (
            <p style={{ background: '#45b97c', textAlign: 'center', color: '#ffff' }}>查看</p>
          )}
        </Tooltip>
      ),
    },
    {
      title: '状态',
      width: '7%',
      render: (e, record) => {
        return record.status == '2' && record.isOfflinePayed == 1 ? (
          '已线下还款'
        ) : (
          <span>{columnsByStagesStute[record.status]}</span>
        );
      },
    },
    {
      title: '支付时间',
      dataIndex: 'repaymentDate',
      align: 'center',
    },
    {
      title: '账单到期时间',
      align: 'center',
      render: (e, record) => <span>{moment(e.statementDate).format('YYYY-MM-DD')}</span>,
    },
    {
      title: '支付方式',
      dataIndex: 'payTypeStrName',
      align: 'center',
    },
    {
      title: '操作',
      width: 170,
      align: 'center',
      render: (e, record) => {
        return (
          <div>
            {(e.status == '1' || e.status == '4') &&
              !e.isNeedXuZuFlag &&
              this.newWithholdType !== 2 ? (
              <Popconfirm
                title="是否确定扣款？"
                onConfirm={() =>
                  axios(`/hzsx/ope/order/userStageOrderPay`, {
                    method: 'get',
                    headers: { token: getToken() },
                    params: {
                      order_id: e.orderId,
                      num: e.currentPeriods,
                    },
                  }).then(res => {
                    if (res.data.data == null) {
                      message.error(res.data.errorMessage);
                    } else {
                      message.success('扣款请求已提交');
                    }
                  })
                }
              >
                <Button type="danger">扣款</Button>
              </Popconfirm>
            ) : null}
            &nbsp;&nbsp;
            {e.isNeedXuZuFlag == true ? (
              <Popconfirm
                title="是否确定续租？"
                onConfirm={() =>
                  axios('/hzsx/ope/order/userAllNewOrderReletOnBackstage', {
                    method: 'post',
                    headers: { token: getToken() },
                    data: {
                      orderId: e.orderId,
                    },
                  }).then(res => {
                    if (res.data.data == null) {
                      message.error(res.data.errorMessage);
                    } else {
                      message.success('续租请求已提交');
                      this.isBillInformation(e);
                    }
                  })
                }
              >
                <Button style={{ border: '1px solid #ed1941', color: '#ed1941' }}>续租</Button>
              </Popconfirm>
            ) : null}
            &nbsp;&nbsp;
            {e.outTransNo &&
              e.status == '2' &&
              e.outTransNo &&
              !e.isNeedXuZuFlag &&
              localStorage.getItem('permissionTags') &&
              localStorage.getItem('permissionTags').includes('alipayPayInfoReturnOrderStageTag') ? (
              <Button
                onClick={() => this.toRefund(e)}
                style={{ border: '1px solid #ffd400', color: '#ffd400' }}
              >
                退款
              </Button>
            ) : null}
            {/* {(e.status == '1' || e.status == '4') &&
              !e.isNeedXuZuFlag &&
              this.newWithholdType !== 2 ? (
              <Button
                type="primary"
                style={{ marginTop: '10px' }}
                onClick={() => {
                  this.billSplit(e);
                }}
              >
                账单拆分
              </Button>
            ) : null} */}
          </div>
        );
      },
    },
  ];

  columnsZixun = [
    {
      title: '查询时间',
      dataIndex: 'message',
    },
    {
      title: '查询条件',
      dataIndex: 'code',
    },
    {
      title: '安全等级',
      dataIndex: 'level',
    },
    {
      title: '含义',
      dataIndex: 'content',
    },
  ];
  createUrl = url => {
    let protocol = window.location.protocol,
      host = window.location.host;
    var domain = `${protocol}//${host}`;
    return domain + url;
  };

  // 账单拆分
  handlebillSplit = e => {
    this.props.form.validateFields(['splitAmount'], (err, values) => {
      if (!err) {
        axios({
          url: `/hzsx/ope/order/splitOrderByStages`,
          method: 'POST',
          headers: {
            token: getToken(),
          },
          params: {
            orderId: this.state.order_id,
            currentPeriods: this.state.currentPeriods,
            splitAmount: values.splitAmount,
          },
        }).then(res => {
          if (!res.data.errorMessage) {
            if (res.data.data) {
              message.success('拆分成功!');
              this.setState({
                billSplitVisible: false,
              });
              this.isBillInformation({
                orderId: this.state.order_id,
              });
            } else {
              message.error('拆分失败！输入金额不得高于本期租金！');
            }
          } else {
            message.error('请正确输入！');
          }
        });
      }
    });
  };
  billSplit = e => {
    this.setState({
      billSplitVisible: true,
      order_id: e.orderId,
      currentPeriods: e.currentPeriods,
    });
  };

  // 查看说明
  explain = () => {
    this.setState({
      explainSm: true,
    });
  };

  toRefund = e => {
    this.setState({
      istoRefund: true,
      order_id: e.orderId,
      orderStagePeriod: e.currentPeriods,
    });
  };
  toOkRefund = () => {
    axios({
      url: '/hzsx/ope/finance/alipayPayInfoReturnOrderStage',
      method: 'POST',
      headers: { token: getToken() },
      data: {
        orderId: this.state.order_id,
        orderStagePeriod: this.state.orderStagePeriod,
        refundRemark: this.state.refundRemark,
      },
    }).then(res => {
      if (res.data.data == null) {
        this.setState({
          istoRefund: false,
          refundRemark: '',
        });
        message.error(res.data.errorMessage);
        this.props.form.resetFields();
      } else {
        message.success('退款成功了');
        this.props.form.resetFields();
        this.setState({
          istoRefund: false,
          refundRemark: '',
        });
        this.isBillInformation({
          orderId: this.state.order_id,
        });
      }
    });
  };
  isOpenBtn = e => {
    let uid = e.orderAddressDto.uid;
    this.setState({
      isOpenBtn: true,
      userUid: uid,
    });
  };

  handleCancelBtn = e => {
    this.setState({
      isOpenBtn: false,
    });
  };
  // 转单
  transfer = e => {
    axios({
      url: `/hzsx/opeShop/disShopList?order_id=${e.orderId}`,
      method: 'get',
      headers: {
        token: getToken(),
      },
    }).then(res => {
      if (res.data.code && res.data.code == '-1') {
        message.error('您无权限操作转单！！');
      } else {
        axios({
          url: `/hzsx/ope/order/getOrderDisPatShopidList?order_id=${e.orderId}`,
          method: 'get',
          headers: {
            token: getToken(),
          },
        }).then(ress => {
          this.setState({
            order_id: e.orderId,
            transferList: res.data.data,
            recordList: ress.data.data,
            transfer: true,
          });
        });
      }
    });
  };

  // 投保链接
  setInsureLink = e => {
    if (e.policyUrl) {
      this.setState({
        leaseLinkVisible: true,
        leaseLinkUrl: e.policyUrl,
      });
    }
  };
  // 发货物流信息
  renderExpressTab = e => {
    if (e.receiptExpressInfo == null) {
      this.onLogistics('发货物流信息', '');
    } else {
      this.onLogistics('发货物流信息', e.receiptExpressInfo, e.orderId);
    }
    this.setState({
      logisticsInformation: true,
      orderId: e.orderId,
      receiptExpressInfo: e.receiptExpressInfo,
      giveBackExpressInfo: e.giveBackExpressInfo,
    });
  };
  // 归还物流信
  renderExpressTab1 = e => {
    if (e.giveBackExpressInfo == null) {
      this.onLogistics('发货物流信息', '');
    } else {
      this.onLogistics('归还物流信息', e.giveBackExpressInfo, e.orderId);
    }
    this.setState({
      logisticsInformation: true,
      orderId: e.orderId,
      receiptExpressInfo: e.receiptExpressInfo,
      giveBackExpressInfo: e.giveBackExpressInfo,
    });
  };
  onLogistics = (e, i, orderId) => {
    this.setState(
      {
        drawerVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressInfo(i, orderId);
      },
    );
  };
  onQueryExpressInfo = (i, orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryExpressInfo',
      payload: {
        expressNo: i.expressNo,
        receiverPhone: i.receiverPhone,
        shortName: i.shortName,
        orderId: orderId,
      },
      callback: res => {
        if (res.data.result == null) {
          message.error(res.data.reason);
        } else {
          this.setState({
            wlList: res.data.result.list,
          });
        }
      },
    });
  };
  //   推送图片
  onQueryExpressPushPicture = (i, orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/picPushExpress',
      payload: {
        expressNo: i.expressNo,
        receiverPhone: i.receiverPhone,
        shortName: i.shortName,
        orderId: orderId,
      },
      callback: res => {
        const _data1 = JSON.parse(res.data);
        const _data2 = JSON.parse(_data1.apiResultData);
        if (_data2.errorMsg == null) {
          message.success('推送成功');
        } else {
          message.error(_data2.errorMsg);
        }
      },
    });
  };
  //   查看推送图片
  onQueryExpressgetPicRead = (i, orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/getPicPushExpressList',
      payload: {
        expressNo: i.expressNo,
        receiverPhone: i.receiverPhone,
        shortName: i.shortName,
        orderId: orderId,
      },
      callback: res => {
        if (res.data == null) {
          message.error('查询失败', res.data.errorMessage);
        } else {
          this.setState({
            picList: res.data,
          });
        }
      },
    });
  };

  //   发货推送图片
  onPicClick = (e, i, orderId) => {
    this.setState(
      {
        countersignVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressPushPicture(i, orderId);
      },
    );
  };
  //   发货查看推送图片
  onImageClick = (e, i, orderId) => {
    this.setState(
      {
        imageVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressgetPicRead(i, orderId);
      },
    );
  };
  //   归还推送图片
  onReturnPicClick = (e, i, orderId) => {
    this.setState(
      {
        returnCountersignVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressPushPicture(i, orderId);
      },
    );
  };
  //   归还推送图片
  onReturnImageClick = (e, i, orderId) => {
    this.setState(
      {
        returnImageVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressgetPicRead(i, orderId);
      },
    );
  };
  // 修改收货信息
  handleOkaddress = () => {
    const { dispatch } = this.props;
    const { orderVisible, orderId } = this.state;
    this.props.form.validateFields(['realName', 'address', 'city', 'telePhone'], (err, values) => {
      if (err) return;
      dispatch({
        type: 'order/opeOrderAddressModify',
        payload: {
          realName: values.realName,
          street: values.address,
          telephone: values.telePhone,
          province: values && values.city && values.city[0],
          city: values && values.city && values.city[1],
          area: values && values.city && values.city[2],
          orderId,
        },
        callback: res => {
          this.handleSubmit();
          this.handleCancel();
        },
      });
    });
  };
  submitInsure = e => {
    axios({
      url: '/hzsx/business/order/insureOrder',
      method: 'post',
      headers: {
        token: getToken(),
      },
      data: qs.stringify({ orderId: this.state.orderId }),
    }).then(res => {
      if (!res.data.errorMessage) {
        message.success('发送成功!');
      } else {
        message.error(res.data.errorMessage);
      }
    });
  };
  // 投保
  setInsure = e => {
    axios({
      url: '/hzsx/ope/lease/order/queryLeaseOrderProduct',
      method: 'get',
      headers: {
        token: getToken(),
      },
      params: { order_id: e.orderId },
    }).then(res => {
      if (res.data.data) {
        this.setState({
          insureVisible: true,
          insureObj: res.data.data,
          orderId: e.orderId,
        });
      }
    });
  };
  // 电子签章
  electronicSeal = e => {
    axios({
      url: '/hzsx/ope/order/getExistingEvidence',
      method: 'get',
      headers: {
        token: getToken(),
      },
      params: {
        orderId: e.orderId,
      },
    }).then(res => {
      if (!!(res.data.data == null)) {
        message.error('请联系管理员进行获取');
      } else {
        this.setState({
          electronicVisible: true,
          depositScore: res.data.data.chuchun,
          depositOutScore: res.data.data.cunzeng,
        });
      }
    });
  };

  setPudate = e => {
    this.setState({
      endPrice: e.endPrice,
      old_name: e.spec,
    });
    axios({
      url: '/hzsx/product/getProductParameters',
      method: 'get',
      headers: {
        token: getToken(),
      },
      params: {
        order_id: e.orderId,
      },
    }).then(res => {
      if (res.data.data == null) {
        message.error(res.data.errorMessage);
      } else {
        for (let i = 0; i < res.data.data.productspceList.length; i++) {
          const item = res.data.data.productspceList[i];
          if (
            res.data.data.order.skuId == item.skuId &&
            res.data.data.order.rentDuration == item.days
          ) {
            this.setState({
              productspceList: res.data.data.productspceList,
              productspceId: item.id,
              price: item.price,
              salePrice: item.salePrice,
              day: item.days,
              sku_id: item.skuId,
              order_id: res.data.data.order.orderid,
              pudate: true,
              submitTrue: true,
              modification_price: item.price * item.days,
              old_price: item.price,
            });
          } else if (res.data.data.order.skuId == 0) {
            this.setState({
              productspceList: res.data.data.productspceList,
              order_id: res.data.data.order.orderid,
              pudate: true,
            });
          }
        }
      }
    });
  };
  // 这里的是风控建议的按钮
  riskAdvise = e => {
    this.setState({
      advise: true,
      orderId: e.orderId,
    });
  };
  // 这里的是手动风控的触发按钮
  riskAdvises = e => {
    axios({
      url: `/hzsx/ope/order/handRunRisk?orderId=${e.orderId}`,
      method: 'get',
      headers: {
        token: getToken(),
      },
    }).then((res => {
      console.log(res, '===========================');
      if (res.data.httpStatus==200) {
        message.success('风控触发成功!');
        this.handleSubmit();
        this.handleCancel();
      }
    }))
  };
  // 这里的是确认风控建议的弹框
  handleOkAdvise = e => {
    this.props.form.validateFields(['riskRemark', 'advisestatus'], (err, values) => {
      if (!err) {
        axios({
          url: '/hzsx/ope/order/riskRemark',
          method: 'POST',
          headers: {
            token: getToken(),
          },
          data: {
            orderId: this.state.orderId,
            riskType: values.advisestatus,
            riskRemark: values.riskRemark,
          },
        }).then(res => {
          if (res.data.data == null) {
            message.error(res.data.errorMessage);
          } else {
            message.success('提交完成');
            this.setState({
              advise: false,
            });
            this.handleSubmit();
          }
        });
      }
    });
  };
  //   时间记录回显
  timePudate = e => {
    axios({
      url: ` /hzsx/business/order/queryActionAuditListByOrderId?orderId=${e.orderId}`,
      method: 'get',
      headers: {
        token: getToken(),
      },
    }).then(res => {
      this.setState({
        timeVisible: true,
        tiemData: res.data.data,
      });
    });
  };
  // 佣金比率
  brokerageRate = e => {
    this.setState({
      brokerageRateVisible: true,
      order_id: e.orderId,
      rate: e.leaseRate,
    });
  };
  // 提交佣金比率
  handlebrokerageRate = e => {
    this.props.form.validateFields(['rate'], (err, values) => {
      if (!err) {
        const { dispatch } = this.props;
        dispatch({
          type: 'order/setUserOrderRate',
          payload: {
            orderid: this.state.order_id,
            rate: values.rate,
            type: 1,
          },
          callback: res => {
            this.setState({
              brokerageRateVisible: false,
            });
            this.handleSubmit();
          },
        });
      }
    });
  };

  //当选中的模块发生改变时，改变赋值数据，提交的时候就是当前选中的数据
  changeRadio = e => {
    for (let i = 0; i < this.state.productspceList.length; i++) {
      const item = this.state.productspceList[i];
      if (e.target.value == item.id) {
        const spec = item.value_row;
        const specValue = spec.map((values, index) => {
          return values.platformSpecValue;
        });
        const specStr = specValue.join();
        this.setState({
          price: item.price,
          salePrice: item.salePrice,
          day: item.days,
          sku_id: item.skuId,
          productspceId: item.id,
          modification_price: item.price * item.days,
          old_price: item.price,
          submitTrue: true,
          new_name: specStr,
        });
      }
    }
  };
  // 转单提交数据
  submitTransfer = () => {
    axios({
      url: '/hzsx/ope/order/set_order_to_shop',
      method: 'get',
      headers: { token: getToken() },
      params: {
        order_id: this.state.order_id,
        shop_id: this.state.transferId,
      },
    }).then(res => {
      if (res.data.data == null) {
        message.error('请选择转单商家!');
      } else if (!res.data.data) {
        this.setState({
          transfer: false,
        });
        message.error('此商家不能二次派单!');
      } else {
        this.setState({
          transfer: false,
        });
        this.handleSubmit();
        message.success('转单成功!');
      }
    });
  };
  //将修改后的数据发送给后端
  submitPackage = () => {
    const { count_price, endPrice } = this.state;
    if (this.state.submitTrue) {
      axios({
        url: '/hzsx/ope/order/updateOrderStages',
        method: 'get',
        headers: {
          token: getToken(),
        },
        params: {
          order_id: this.state.order_id,
          day_price: this.state.day_price ? this.state.day_price : this.state.price, // 日租金
          deposit: this.state.deposit ? this.state.deposit : 0,
          count_price: this.state.count_price
            ? this.state.count_price
            : this.state.modification_price, // 总价值salePrice
          day: this.state.day,
          sku_id: this.state.sku_id,
          salePrice: this.state.salePrice, // 列表中的总价值
          modification_price: this.state.modification_price, //修改价格
          old_price: this.state.old_price,
          new_name: this.state.new_name,
          old_name: this.state.old_name,
        },
      }).then(res => {
        if (res.data.data == null) {
          this.setState({
            pudate: false,
            submitTrue: false,
          });
          message.error(res.data.errorMessage);
        } else {
          message.success('修改成功了');
          this.setState({
            pudate: false,
            submitTrue: false,
            count_price: '',
            deposit: '',
          });
          this.handleSubmit();
        }
      });
    } else {
      message.error('请选择套餐后提交！');
    }
  };
  // 提交备注
  handleOk = e => {
    this.props.form.validateFields(['beizhu'], (err, values) => {
      if (!err) {
        const { dispatch } = this.props;
        dispatch({
          type: 'order/orderRemark',
          payload: {
            orderId: this.state.order_id,
            remark: values.beizhu,
            orderType: '01',
          },
          callback: res => {
            this.setState({
              remarkVisible: false,
            });
            this.props.form.resetFields('beizhu');
            this.handleSubmit();
          },
        });
      }
    });
  };
  // 驳回归还的按钮
  handleOkOver = e => {
    this.props.form.validateFields(['rejectReason'], (err, values) => {
      if (!err) {
        axios({
          url: '/hzsx/ope/order/rejectOpeGivebackOrder',
          method: 'POST',
          headers: { token: getToken() },
          data: {
            orderId: this.state.overruleId,
            rejectReason: values.rejectReason,
          },
        }).then(res => {
          this.setState({
            overrule: false,
          });
          this.props.form.resetFields('rejectReason');
          this.handleSubmit();
        });
      }
    });
  };
  // 提交拉黑逻辑
  handleOkisOpenBtn = e => {
    let protocol = window.location.protocol,
      host = window.location.host;
    let urll = `${protocol}//${host}`;
    axios({
      url: urll + '/hzsx/user/setUserBlackStatus',
      method: 'get',
      headers: { token: getToken() },
      params: {
        uid: this.state.userUid,
        time: this.state.seletctId,
      },
    }).then(res => {
      if (res.data.data === true) {
        message.success('拉黑成功了');
        this.handleSubmit();
      }
    });
    this.setState({
      isOpenBtn: false,
    });
  };
  columnsTile = [
    {
      title: '商家信息',
      align: 'center',
      width: 160,
    },
    {
      title: '商品信息',
      align: 'center',
      width: 150,
    },
    {
      title: '租押金',
      align: 'center',
      width: 150,
    },
    {
      title: '用户信息',
      align: 'center',
      width: 160,
    },
    {
      title: '付款信息',
      width: 180,
      align: 'center',
    },
    {
      title: '交易状态',
      width: 120,
      align: 'center',
    },
    {
      title: '操作',
      width: 120,
      align: 'center',
    },
  ];

  // 关闭订单接口
  portclose() {
    if (!this.state.indent) return message.error('拒绝原因不能空');
    const { dispatch } = this.props;
    dispatch({
      type: 'order/closeUserOrderAndRefundPrice',
      payload: {
        orderId: this.state.orderId,
        closeReason: this.state.indent,
        closeType: '07',
      },
      callback: res => {
        message.success('关闭成功');
        this.handleSubmit();
        this.setState({
          visible: false,
          orderId: null,
        });
      },
    });
  }
  goRecord(e) {
    axios({
      url: '/hzsx/business/order/queryActionAuditListByOrderId',
      method: 'get',
      headers: { token: getToken() },
      params: {
        orderId: e.orderId,
      },
    }).then(res => {
      this.setState({
        record_list: res.data.data,
        recordVisible: true,
      });
    });
  }
  // 操作
  operate(index, e) {
    const jsonValue = `${e.realName},${e.addressUserPhone},${e.address},${e.productName}`;
    index === 0
      ? this.setState({ voucher: true, jsonValue })
      : index === 1
        ? this.voucher(e)
        : null;
  }

  // 复制订单信息
  orderinformation() {
    copy(this.state.jsonValue);
    message.success('复制成功!');
  }

  // 租户凭证
  voucher = e => {
    let idurl = [];
    const data = e;
    if (data.idCardBackUrl && data.idCardFrontUrl) {
      idurl = [data.idCardBackUrl || null, data.idCardFrontUrl || null];
    }
    this.setState({
      imgvisi: true,
      idurl,
    });
  };

  //   账单信息的处理事件
  isBillInformation = e => {
    this.newWithholdType = e.withholdType;
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryOrderStagesDetail',
      payload: {
        orderId: e.orderId,
      },
      callback: res => {
        if (res.responseType === 'SUCCESS') {
          this.setState({
            queryOrderStagesDetail: res.data,
            orderByStagesDtoList: res.data && res.data.orderByStagesDtoList,
            nextXuZuOrderByStagesList: res.data && res.data.nextXuZuOrderByStagesList,
            orderId: res.data.orderId,
            billInformation: true,
          });
        }
      },
    });
  };

  // 账单弹框关闭的事件
  onCloseBill = () => {
    this.setState({
      billInformation: false,
    });
  };

  // 风控报告
  viewCredit = (e) => {
    this.props.dispatch({
      type: 'order/getCredit',
      payload: {
        uid: e.uid,
        orderId: e.orderId,
      },
      callback: res => {
        const { data, errorMessage } = res;
        console.log('data', data);
        if (!errorMessage) {
          this.setState({
            riskControlData: JSON.parse(data) || {},
            placementVisible: true,
          });
        } else {
          message.error(res.errorMessage);
        }
      },
    });
  };

  componentDidMount() {
    let id = this.props.location.query.id;
    if (!id) {
      this.onList(this.state.current, 10, { status: this.state.gBtusua });
    } else {
      this.onList(1, 10, { orderId: id, status: this.state.gBtusua });
    }
    this.props.dispatch({
      type: 'order/PlateformChannel',
    });
    this.props.dispatch({
      type: 'order/guanggao_items',
    });
    this.props.dispatch({
      type: 'order/promotion_items',
    });
  }
  // 获取订单详情接口
  detail = orderId => {
    const { dispatch } = this.props;
    let idurl = [];
    dispatch({
      type: 'order/queryOpeUserOrderDetail',
      payload: {
        orderId,
      },
      callback: res => {
        const data = res.data.userOrderInfoDto;
        if (data.idCardBackUrl && data.idCardFrontUrl) {
          idurl = [data.idCardBackUrl || null, data.idCardFrontUrl || null];
        }
        this.setState({
          imgvisi: true,
          idurl,
        });
      },
    });
  };
  onList = (pageNumber, pageSize, data = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryOpeOrderByConditionList',
      payload: {
        pageSize,
        pageNumber,
        userOrderStatus: getParam('userOrderStatus') || '',
        uid: getParam('uid') || '',
        ...data,
      },
      callback: res => {
        if (res.responseType === 'SUCCESS') {
          this.setState({
            checkBoxStatusList: res.data.records,
          });
        } else {
          message.error(res.msg);
        }
      },
    });
  };

  // 重置
  handleReset = e => {
    this.setState({
      EchophoneNumber: '', //回显手机号
      Echoname: '', //回显名字
    });
    if (e === 1) {
      this.props.form.resetFields();
      this.props.form.setFieldsValue({
        status: undefined,
      });
    } else {
      this.setState(
        {
          gBtusua: '',
          uid: '',
          userOrderStatus: '',
        },
        () => {
          this.props.form.resetFields();
          this.props.form.setFieldsValue({
            status: undefined,
          });
        },
      );
    }
  };
  handleSubmit = throttle((e, index) => {
    e && e.preventDefault();
    this.setState({
      uid: '',
    });
    let a_Backspace = 0;
    this.props.form.validateFields(
      [
        'uid',
        'userOrderStatus',
        'productName',
        'shopName',
        'guangGaoId',
        'userName',
        'telephone',
        'addressUserPhone',
        'idCard',
        'orderId',
        'createDate',
        'createDates',
        'status',
        'nextStatementDate',
        'nextStatementStatus',
        'closeType',
        'riskType',
        'productId',
        'promotionCode',
      ],
      (err, values) => {
        for (let key in values) {
          if (values[key] != undefined && values[key] != '') {
            a_Backspace++;
          }
        }
        if (values.createDate && values.createDate.length < 1) {
          values.createTimeStart = '';
          values.createTimeEnd = '';
          if (values.createDates && values.createDates.length < 1) {
            values.updateTimeStart = '';
            values.updateTimeEnd = '';
          } else if (values.createDates) {
            values.updateTimeStart =
              moment(values.createDates[0]).format('YYYY-MM-DD') + ' 00:00:00';
            values.updateTimeEnd = moment(values.createDates[1]).format('YYYY-MM-DD') + ' 23:59:59';
          }
          this.setState(
            {
              datas: { ...values },
            },
            () => {
              if (index == 1) {
                this.onList(1, 10, { ...values });
                this.setState({
                  current: 1,
                });
              } else {
                this.onList(this.state.current, 10, { ...values });
              }
            },
          );
        } else if (values.createDate) {
          values.createTimeStart = moment(values.createDate[0]).format('YYYY-MM-DD HH:mm:ss');
          values.createTimeEnd = moment(values.createDate[1]).format('YYYY-MM-DD HH:mm:ss');
          if (values.createDates && values.createDates.length < 1) {
            values.updateTimeStart = '';
            values.updateTimeEnd = '';
          } else if (values.createDates) {
            values.updateTimeStart =
              moment(values.createDates[0]).format('YYYY-MM-DD') + ' 00:00:00';
            values.updateTimeEnd = moment(values.createDates[1]).format('YYYY-MM-DD') + ' 23:59:59';
          }
          this.setState(
            {
              datas: { ...values },
            },
            () => {
              if (index == 1) {
                this.onList(1, 10, { ...values });
                this.setState({
                  current: 1,
                });
              } else {
                this.onList(this.state.current, 10, { ...values });
              }
            },
          );
        } else if (values.nextStatementDate) {
          values.nextStatementDate = moment(values.nextStatementDate).format('YYYY-MM-DD');
          if (values.createDates && values.createDates.length < 1) {
            values.updateTimeStart = '';
            values.updateTimeEnd = '';
          } else if (values.createDates) {
            values.updateTimeStart =
              moment(values.createDates[0]).format('YYYY-MM-DD') + ' 00:00:00';
            values.updateTimeEnd = moment(values.createDates[1]).format('YYYY-MM-DD') + ' 23:59:59';
          }
          this.setState(
            {
              datas: { ...values },
            },
            () => {
              if (index == 1) {
                this.onList(1, 10, { ...values });
                this.setState({
                  current: 1,
                });
              } else {
                this.onList(this.state.current, 10, { ...values });
              }
            },
          );
        } else if (a_Backspace > this.state.b_Backspace || a_Backspace < this.state.b_Backspace) {
          if (values.createDates && values.createDates.length < 1) {
            values.updateTimeStart = '';
            values.updateTimeEnd = '';
          } else if (values.createDates) {
            values.updateTimeStart =
              moment(values.createDates[0]).format('YYYY-MM-DD') + ' 00:00:00';
            values.updateTimeEnd = moment(values.createDates[1]).format('YYYY-MM-DD') + ' 23:59:59';
          }
          this.setState(
            {
              datas: { ...values },
            },
            () => {
              if (index == 1) {
                this.onList(1, 10, { ...values });
                this.setState({
                  current: 1,
                });
              } else {
                this.onList(this.state.current, 10, { ...values });
              }
            },
          );
        } else {
          this.setState(
            {
              datas: { ...values },
            },
            () => {
              if (index == 1) {
                this.onList(1, 10, { ...values });
                this.setState({
                  current: 1,
                });
              } else {
                this.onList(this.state.current, 10, { ...values });
              }
            },
          );
        }
      },
    );
    this.setState({
      IsStatusList: [
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
        {
          IsStatus: false,
        },
      ],
      check_box_status: false,
      b_Backspace: a_Backspace,
    });
  }, 700);
  onexport = () => {
    const { yunTime } = this.state;
    if (this.props.form.getFieldValue('createDate')) {
      this.props.dispatch({
        type: 'order/exportOpeAllUserOrders',
        payload: {
          createTimeEnd: moment(this.props.form.getFieldValue('createDate')[1]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
          createTimeStart: moment(this.props.form.getFieldValue('createDate')[0]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
        },
      });
    } else {
      this.props.dispatch({
        type: 'order/exportOpeAllUserOrders',
        payload: {
          createTimeEnd: moment(yunTime[1]).format('YYYY-MM-DD HH:mm:ss'),
          createTimeStart: moment(yunTime[0]).format('YYYY-MM-DD HH:mm:ss'),
        },
      });
    }
  };

  // table 页数新版
  onPage = e => {
    const data = {
      userOrderStatus: this.state.userOrderStatus,
      uid: this.state.uid,
      ...this.state.datas,
    };
    this.setState(
      {
        current: e,
      },
      () => {
        this.onList(e, 10, data);
      },
    );
  };

  getExpressList = e => {
    this.setState({
      orderId: e.orderId,
    });
    OrderService.selectExpressList().then(res => {
      this.setState({
        deliverOptions: res || [],
      });
    });
  };
  selectCheckbox = (e, index) => {
    const { checkBoxStatusList } = this.state.checkBoxStatusList;

    return (
      <Checkbox
        className={styles.wrapper}
        checked={this.state.IsStatusList[index].IsStatus}
        onChange={() => this.onCheckBox(e, index)}
      ></Checkbox>
    );
  };
  // 全选
  onCheckBox_s = e => {
    if (this.state.check_box_status) {
      let a_data = this.state.IsStatusList;
      let b_data = this.state.checkBoxStatusList;
      for (let i = 0; i < a_data.length; i++) {
        const item1 = a_data[i];
        item1.IsStatus = false;
      }
      for (let i = 0; i < b_data.length; i++) {
        const item1 = b_data[i];
        item1.checkBoxStatus = false;
      }
      this.setState({
        check_box_status: false,
        IsStatusList: a_data,
        checkBoxStatusList: b_data,
      });
    } else {
      let a_data = this.state.IsStatusList;
      let b_data = this.state.checkBoxStatusList;
      for (let i = 0; i < a_data.length; i++) {
        const item1 = a_data[i];
        item1.IsStatus = true;
      }
      for (let i = 0; i < b_data.length; i++) {
        const item1 = b_data[i];
        item1.checkBoxStatus = true;
      }
      this.setState({
        check_box_status: true,
        IsStatusList: a_data,
        checkBoxStatusList: b_data,
      });
    }
  };
  onCheckBox = (e, index) => {
    if (this.state.IsStatusList[index].IsStatus) {
      this.state.IsStatusList[index].IsStatus = false;
    } else {
      this.state.IsStatusList[index].IsStatus = true;
    }
    let c_data = this.state.checkBoxStatusList;
    (c_data[index].checkBoxStatus = c_data[index].checkBoxStatus ? false : true),
      this.setState({
        checkBoxStatusList: c_data,
      });
  };
  // 审批通过 拒绝 关闭订单 的按钮逻辑
  showOrderModal = (type, flag, e, index) => {
    if (['express', 'deliver'].includes(type)) {
      this.getExpressList(e);
    }
    if (type === 'settle') {
      this.settleDia();
    }
    if (type === 'audit') {
      this.setState({
        titles: flag ? '审批通过' : '审批拒绝',
      });
    }
    if (type === 'close') {
      this.closeId(e);
    }
    if (type === 'address') {
      this.address(e);
    }
    this.setState({
      orderVisible: type,
    });
  };
  closeId = e => {
    this.setState({
      orderId: e.orderId,
    });
  };
  address = e => {
    this.setState({
      orderId: e.orderId,
      realName: e.orderAddressDto.realname,
      tele: e.orderAddressDto.telephone,
      address: e.orderAddressDto.street,
      orderAddressDto: e.orderAddressDto,
    });
  };
  //   这里是关闭订单的逻辑
  handleOkClose = () => {
    const { form } = this.props;
    const { orderVisible, orderId } = this.state;
    this.props.form.validateFields(['closeReason'], (err, fieldsValue) => {
      if (err) return;
      OrderService.closeUserOrderAndRefundPrice({
        ...fieldsValue,
        closeType: '07',
        orderId,
      }).then(res => {
        this.handleSubmit();
        this.handleCancel();
      });
    });
  };
  // 这里是发货的逻辑事件
  handleOkDeliver = () => {
    const { form } = this.props;
    const { leaseLoading, orderId } = this.state;
    const generateOrderContract = this.state.generateOrderContract;
    this.props.form.validateFields(['expressId', 'expressNo'], (err, fieldsValue) => {
      if (err) return;
      this.setState({
        leaseLoading: true,
      });
      OrderService.orderDelivery({
        ...fieldsValue,
        orderId: orderId,
        generateOrderContract,
      }).then(res => {
        this.handleSubmit();
        this.handleCancel();
      });
    });
    this.setState({
      orderVisible: false,
    });
  };

  handleCancel = () => {
    this.setState({
      orderVisible: false,
    });
  };
  // 新增风控建议的弹框处理
  changesAdvises = e => {
    this.setState({
      riskRemark: advises.find(item => item.value === e).name,
    });
    this.props.form.setFieldsValue({
      riskRemark: advises.find(item => item.value === e).name,
    });
  };
  changesTextArea = e => {
    this.props.form.setFieldsValue({
      riskRemark: e.target.value,
    });
  };

  handleCancelAdvise = () => {
    this.setState({
      advise: false,
    });
  };

  toFormOutlined = e => {
    this.setState({
      isFormOutlined: e.orderId,
    });
  };
  onCancelOutLined = () => {
    this.setState({
      isFormOutlined: null,
    });
  };
  onOkLind = e => {
    const { isFormOutlined } = this.state;
    e & e.preventDefault();
    this.props.form.validateFields(['inputLined'], (err, values) => {
      if (err || values.inputLined == undefined || values.inputLined == '') {
        return message.error('请输入合计进货价');
      } else {
        axios({
          url: `/hzsx/business/order/updatePurchasePrice?orderId=${isFormOutlined}&price=${values.inputLined}`,
          method: 'GET',
          headers: { token: getToken() },
        }).then(res => {
          message.success('添加数据成功');
          this.setState({
            isFormOutlined: null,
          });
          this.handleSubmit();
        });
      }
    });
  };
  // 风险咨询
  riskIdentification = (e, item) => {
    axios({
      url: '/hzsx/ope/order/getIdentification',
      method: 'POST',
      headers: {
        token: getToken(),
      },
      data: {
        orderId: e.orderId,
      },
    }).then(res => {
      if (res.data.errorMessage == null) {
        message.success('获取数据成功');
        this.setState(
          {
            isRiskgc: true,
            orderId: e.orderId,
          },
          () => {
            this.getRiskList();
          },
        );
        if (res.data.data == 'SUCCESS') {
          this.handleSubmit();
        }
      } else {
        message.error(res.data.errorMessage);
        this.setState(
          {
            isRiskgc: true,
            orderId: e.orderId,
          },
          () => {
            this.getRiskList();
          },
        );
        if (res.data.data == 'SUCCESS') {
          this.handleSubmit();
        }
      }
    });
  };
  // 再次外呼按钮
  intelligentCalls = () => {
    const datas = {
      orderId: this.state.orderId,
      phoneNumber: this.state.phone,
    };
    axios({
      url: '/hzsx/ope/order/unRuningRisk',
      method: 'POST',
      headers: {
        token: getToken(),
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(datas),
    }).then(res => {
      if (res.data.errorMessage == null) {
        message.success('已触发智能外呼，请等待结果');
        this.getRiskList();
      } else {
        message.error(res.data.errorMessage);
        this.getRiskList();
      }
    });
  };
  // 交互式风控
  hundredRiskClick = e => {
    this.setState(
      {
        isrisk: true,
        orderId: e.orderId,
        phone: e.telephone,
      },
      () => {
        this.getRiskList();
      },
    );
  };
  // 交互式的逻辑事件
  getRiskList = () => {
    axios({
      url: '/hzsx/ope/order/getInteractiveRiskInfo',
      method: 'GET',
      headers: {
        token: getToken(),
      },
      params: {
        orderId: this.state.orderId,
      },
    }).then(res => {
      this.setState({
        identification:
          res.data.data && res.data.data.identification ? res.data.data.identification : [], //风险咨询的数据
        // 交互风控数据
        runingList:
          res.data.data.runingAqbb && res.data.data.runingAqbb.dialogue
            ? res.data.data.runingAqbb.dialogue
            : [],
        runingYyzsList:
          res.data.data.runingYyzs && res.data.data.runingYyzs.dialogue
            ? res.data.data.runingYyzs.dialogue
            : [],
        runingYyzs: res.data.data && res.data.data.runingYyzs ? res.data.data.runingYyzs : {},
        //  modelResultList:modelResultList ? JSON.parse(modelResultList):null,
        // 智能外呼的数据
        dialogueList: res.data.data && res.data.data.unRuning ? res.data.data.unRuning : [],
      });
    });
  };
  //   订单跳转

  // userOrderStatus;//用作查询指定用户订单状态：1表示申请中 2表示成功订单 3表示总计下单
  // 总计下单数
  AllOrderList = e => {
    const data1 = {
      uid: e.uid,
    };
    this.setState(
      {
        uid: e.uid,
        current: 1,
      },
      () => {
        this.toOrderLists(1, 10, data1);
      },
    );
  };
  // 申请中
  ApplicationOrderList = e => {
    const data1 = {
      uid: e.uid,
      userOrderStatus: '1',
    };

    this.setState(
      {
        uid: e.uid,
        current: 1,
      },
      () => {
        this.toOrderLists(1, 10, data1);
      },
    );
  };
  // 成功订单数
  SuccessdOrderList = e => {
    const data1 = {
      uid: e.uid,
      userOrderStatus: '2',
    };
    this.setState(
      {
        uid: e.uid,
        current: 1,
      },
      () => {
        this.toOrderLists(1, 10, data1);
      },
    );
  };
  toOrderLists = (pageNumber, pageSize, data1 = {}) => {
    const { dispatch } = this.props;
    this.setState(
      {
        datas: data1,
      },
      () => {
        dispatch({
          type: 'order/queryOpeOrderByConditionList',
          payload: {
            pageNumber,
            pageSize,
            uid: getParam('uid') || '',
            userOrderStatus: getParam('userOrderStatus') || '',
            ...this.state.datas,
          },
          callback: res => {
            this.handleReset(1);
            if (res.responseType === 'SUCCESS') {
              this.setState({
                checkBoxStatusList: res.data.records,
                Echoname: res.data.records[0].realName,
                EchophoneNumber: res.data.records[0].telephone,
              });
            } else {
              message.error(res.msg);
            }
          },
        });
      },
    );
  };

  // 监听输入框下拉change事件
  onChangeSelect = (value, i, option) => {
    const { recordSelect, transferList } = this.state;
    recordSelect[i] = value || '';
    this.setState({
      recordSelect,
      transferId: option,
    });
  };
  onSearchSelect = (value, index) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      const { newValue } = this.state;
      if (!!value) {
        newValue[index] = value || '';
        this.setState({ newValue });
      }
    }, 1000);
  };
  onBlurSelect = index => {
    const { newValue } = this.state;
    const value = newValue[index];
  };
  toWindowOpen = e => {
    window.open(e);
  };

  render() {
    const { orderBuyOutDto = {}, isNeedXuZuFlag } = this.state.queryOrderStagesDetail;
    const { allList, allTotal, loading, form, guanggao_list, promotion_list } = this.props;
    const {
      nextXuZuOrderByStagesList,
      orderByStagesDtoList,
      advise,
      wlList,
      picList,
      productspceList,
      productspceId,
      transferList,
      recordList,
      tiemData,
      record_list,
      leaseLinkUrl,
      insureObj,
      leaseLoading,
      logisticsInformation,
      returnLogisticsInformation,
      drawerVisible,
      giveBackExpressInfo,
      receiptExpressInfo,
      getPicPushExpressList,
      riskControlData,
      isFormOutlined,
      redatas,
      orderVisible,
      deliverOptions,
      realName,
      tele,
      address,
      orderAddressDto,
      isRiskStatus,
      dialogueList,
      runingYyzs,
      identification,
      EchophoneNumber,
      Echoname,
    } = this.state;
    if (nextXuZuOrderByStagesList[0]) {
      nextXuZuOrderByStagesList[0].isNeedXuZuFlag = isNeedXuZuFlag;
    }
    const queryOrderStagesDetails = orderByStagesDtoList.concat(nextXuZuOrderByStagesList);

    // 订单状态 1:代支付 2支付中 3 已支付申请关单  4代发货
    allList.forEach(i => {
      i.statext = orderStatusMap[i.status];
      i.frostnum =
        i.depositReduction === 0 || !i.idepositReduction ? 0 : i.totalDeposit - i.depositReduction;
      i.withouti = orderStatusMap[i.status] !== '交易关闭';
      i.IsStatus = false;
    });

    const paginationProps = {
      current: this.state.current,
      pageSize: 10,
      total: allTotal,
      showTotal: total => (
        <span style={{ fontSize: '14px' }}>
          <span>共{Math.ceil(total / 10)}页</span>&emsp;
          <span>共{total}条</span>
        </span>
      ),
    };
    const { getFieldDecorator } = form;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    return (
      <PageHeaderWrapper title={false}>
        <Card bordered={false}>
          <Form
            {...{
              labelCol: { xs: { span: 24 }, sm: { span: 7 } },
              wrapperCol: { xs: { span: 24 }, sm: { span: 17 } },
            }}
            onSubmit={e => {
              this.handleSubmit(e, 1);
              e && e.preventDefault();
            }}
          >
            <Row style={{ display: 'flex', flexWrap: 'wrap' }}>
              <Col span={6}>
                <Form.Item label="订单状态">
                  {getFieldDecorator('status')(
                    <Select
                      placeholder="请选择订单状态"
                      allowClear
                      style={{ minWidth: 200 }}
                      onChange={(value) => {
                        this.setState({
                          gBtusua: value,
                        });
                      }}
                    >
                      {['01', '11', '04', '05', '06', '07', '08', '09', '10', '13', '14', '15'].map(
                        value => {
                          return (
                            <Option value={value.toString()} key={value.toString()}>
                              {orderStatusMap[value.toString()]}
                            </Option>
                          );
                        },
                      )}
                    </Select>,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="商品名称">
                  {getFieldDecorator('productName')(
                    <Input allowClear placeholder="请输入商品名称" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="店铺名称">
                  {getFieldDecorator('shopName')(
                    <Input placeholder="请输入店铺名称" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单来源">
                  {getFieldDecorator('guangGaoId')(
                    <Select placeholder="请选择订单来源" style={{ minWidth: 200 }} allowClear>
                      {guanggao_list &&
                        guanggao_list.map((item, val) => {
                          return (
                            <Option value={item.code} key={val}>
                              {item.name}
                            </Option>
                          );
                        })}
                    </Select>,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人姓名">
                  {getFieldDecorator('userName', {
                    initialValue: Echoname ? Echoname : null,
                  })(<Input allowClear placeholder="请输入下单人姓名" style={{ minWidth: 200 }} />)}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人手机">
                  {getFieldDecorator('telephone')(
                    <Input allowClear placeholder="请输入下单人手机号" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单编号">
                  {getFieldDecorator('orderId')(
                    <Input allowClear placeholder="请输入订单编号" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="身份证号">
                  {getFieldDecorator('idCard')(
                    <Input
                      allowClear
                      placeholder="请输入下单人身份证号"
                      style={{ minWidth: 200 }}
                    />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="商品编号">
                  {getFieldDecorator('productId')(
                    <Input allowClear placeholder="请输入商品编号" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="下单时间">
                  {getFieldDecorator('createDate')(<RangePicker style={{ minWidth: 200 }} />)}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="更新时间">
                  {getFieldDecorator('createDates')(<RangePicker style={{ minWidth: 200 }} />)}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="收货人手机">
                  {getFieldDecorator('addressUserPhone', {
                    initialValue: EchophoneNumber ? EchophoneNumber : null,
                  })(
                    <Input allowClear placeholder="请输入收货人手机号" style={{ minWidth: 200 }} />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="账单日">
                  {getFieldDecorator('nextStatementDate')(
                    <DatePicker style={{ minWidth: '100%' }} allowClear />,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="状态码">
                  {getFieldDecorator('nextStatementStatus')(
                    <Select placeholder="请选择状态码" style={{ minWidth: 200 }} allowClear>
                      <Option value={1} key={1}>
                        待还款
                      </Option>
                      <Option value={2} key={2}>
                        已还款
                      </Option>
                    </Select>,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.gBtusua === '10' && this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="关单类型">
                  {getFieldDecorator('closeType')(
                    <Select placeholder="请选择关单类型" allowClear style={{ minWidth: 200 }}>
                      {orderCloseStatusMaps.map(value => {
                        return (
                          <Option value={value.value} key={value.value}>
                            {value.content}
                          </Option>
                        );
                      })}
                    </Select>,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="风控建议">
                  {getFieldDecorator('riskType')(
                    <Select placeholder="请选择风控建议" style={{ minWidth: 200 }} allowClear>
                      {advisesAll.map((item, val) => {
                        return (
                          <Option value={item.value} key={val}>
                            {item.label}
                          </Option>
                        );
                      })}
                    </Select>,
                  )}
                </Form.Item>
              </Col>
              <Col span={6} style={{ display: this.state.expand ? 'block' : 'none' }}>
                <Form.Item label="推广来源">
                  {getFieldDecorator('promotionCode')(
                    <Select placeholder="请选择推广来源" style={{ minWidth: 200 }} allowClear>
                      {promotion_list &&
                        promotion_list.map((item, val) => {
                          return (
                            <Option value={item.code} key={val}>
                              {item.name}
                            </Option>
                          );
                        })}
                    </Select>,
                  )}
                </Form.Item>
              </Col>
            </Row>
            <Row>
              <Col span={24} style={{ textAlign: 'right' }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button htmlType="button" onClick={this.handleReset}>
                  重置
                </Button>
                <a
                  style={{ marginLeft: 8, fontSize: 12 }}
                  onClick={() => {
                    this.setState({ expand: !this.state.expand });
                  }}
                >
                  展开折叠 <Icon type={this.state.expand ? 'up' : 'down'} />
                </a>
              </Col>
            </Row>
          </Form>
          <Spin spinning={loading}>
            <div>
              <table
                className={styles.wPercentage}
                style={{ border: '1px solid #eee', borderBottom: '0 solid #eee' }}
              >
                <tbody>
                  <tr>
                    <td className={styles.sramtextl}>商品信息</td>
                    <td className={styles.td13}>租押金</td>
                    <td className={styles.td13}>租期</td>
                    <td className={styles.td16}>付款信息</td>
                    <td className={styles.td9}>交易状态</td>
                    <td className={styles.td19}>
                      用户信息
                      <Checkbox
                        checked={this.state.check_box_status}
                        className={styles.c_wrapper}
                        onChange={() => this.onCheckBox_s()}
                      ></Checkbox>
                    </td>
                  </tr>
                </tbody>
              </table>
              {onTableData(allList).length > 0 ? (
                onTableData(allList).map((e, index) => {
                  return (
                    <div>
                      <div className={styles.tableBody}>
                        <div className={styles.tableContent}>
                          <table className={styles.sramTextC}>
                            <tbody className={styles.dpTitle}>
                              <tr style={{ background: 'rgb(245, 245, 245)', width: '100%' }}>
                                <td className={styles.firstA} colSpan={'7'}>
                                  <div className={styles.createDate}>{e.placeOrderTime}</div>
                                  <div className={styles.orderNum}>订单号：{e.orderId}</div>
                                  <div className={styles.sramPullLeft}>
                                    <span style={{ marginRight: '10px' }}>商铺：{e.shopName} </span>
                                    <span style={{ marginRight: '10px' }}>
                                      渠道：{e.channelName}
                                    </span>
                                    <span style={{ marginRight: '50px' }}>
                                      订单来源：{e.guangGaoName ? e.guangGaoName : '无'}{' '}
                                    </span>
                                    <span style={{ marginRight: '40px' }}>
                                      推广来源：{e.promotionName ? e.promotionName : '无'}{' '}
                                    </span>
                                    <span style={{ marginRight: '50px' }}>
                                      订单结算比例：
                                      <span
                                        onClick={() => this.brokerageRate(e)}
                                        style={{
                                          dispatch: 'inline',
                                          color: '#0084F8',
                                          textDecoration: 'underline',
                                        }}
                                      >
                                        {e.leaseRate ? e.leaseRate : 0}
                                      </span>
                                    </span>
                                    {e.receiptExpressInfo && e.receiptExpressInfo.expressNo ? (
                                      <span>
                                        <a
                                          className={styles.expressNo}
                                          onClick={() => this.renderExpressTab(e)}
                                        >
                                          发货物流：
                                          {e.receiptExpressInfo && e.receiptExpressInfo.expressNo
                                            ? e.receiptExpressInfo.expressNo
                                            : null}
                                        </a>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        {e.status == '05' ? (
                                          <EditOutlined
                                            onClick={() =>
                                              this.showOrderModal('express', '', e, index)
                                            }
                                          />
                                        ) : null}
                                      </span>
                                    ) : null}
                                    {e.giveBackExpressInfo && e.giveBackExpressInfo.expressNo ? (
                                      <span>
                                        <a
                                          className={styles.expressNo}
                                          onClick={() => this.renderExpressTab1(e)}
                                        >
                                          归还物流：
                                          {e.giveBackExpressInfo && e.giveBackExpressInfo.expressNo
                                            ? e.giveBackExpressInfo.expressNo
                                            : null}
                                        </a>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        {e.status == '05' ? (
                                          <EditOutlined
                                            onClick={() =>
                                              this.showOrderModal('express', '', e, index)
                                            }
                                          />
                                        ) : null}
                                      </span>
                                    ) : null}
                                  </div>
                                </td>
                                <td className={styles.firstB} colSpan={'3'}>
                                  {this.selectCheckbox(e, index)}
                                </td>
                              </tr>
                            </tbody>

                            <tbody className={styles.dpDesc}>
                              <tr>
                                <td className={styles.commodityDescBox} style={{ width: '30%' }}>
                                  <div className={styles.cellBox}>
                                    <div className={styles.cellLeft}>
                                      <div className={styles.commodityImg}>
                                        <img src={e.productImage} alt="商品图片" width="100%" />
                                      </div>
                                    </div>
                                    <div className={styles.cellBody}>
                                      <div className={styles.commodityTitle}>
                                        {e.skuType && (
                                          <div
                                            style={{
                                              color: skuTypeInfo[e.skuType].color,
                                              border: '1px solid #F7C100',
                                              textAlign: 'center',
                                              lineHeight: '30px',
                                            }}
                                          >
                                            {skuTypeInfo[e.skuType].skuInfo}
                                          </div>
                                        )}
                                        {e.oldNewDegreeName} {e.productName}
                                        <div className={styles.commoditySku}>{e.spec}</div>
                                        <a
                                          className={styles.commodityProductId}
                                          onClick={() =>
                                            router.push(
                                              `/goods/list/detail/${e.orderId}#true&channelGroupCode=${e.channelGroupCode}`,
                                            )
                                          }
                                        >
                                          商品编号： {e.productId}
                                        </a>
                                      </div>
                                    </div>
                                    {['01', '02', '13', '14'].includes(e.status) && (
                                      <Button
                                        type="link"
                                        style={{
                                          background: '#F29B76',
                                          marginBottom: 20,
                                        }}
                                        onClick={() => this.setPudate(e)}
                                      >
                                        修改套餐
                                      </Button>
                                    )}
                                  </div>
                                  <div className={styles.cellBox} style={{ marginTop: '20px' }}>
                                    {e.riskRemark ? (
                                      <div style={{ color: 'red' }}>{e.riskRemark}</div>
                                    ) : (
                                      <Button
                                        type="primary"
                                        style={{
                                          background: '#f90',
                                          marginBottom: 20,
                                        }}
                                        onClick={() => this.riskAdvise(e)}
                                      >
                                        风控建议
                                      </Button>
                                    )}
                                    {!e.riskRemark  ?
                                     <Button
                                      type="primary"
                                      style={{
                                        background: '#f90',
                                        marginBottom: 20,
                                      }}
                                      onClick={() => this.riskAdvises(e)}
                                      >
                                         手动风控
                                     </Button>
                                      :''
                                    }
                                  </div>
                                </td>
                                <td style={{ width: '13%', verticalAlign: 'top' }}>
                                  <div style={{ paddingTop: '12px' }}>
                                    <p>免押金额/总押金</p>
                                    <p>
                                      免¥{e.creditDeposit ? e.creditDeposit.toFixed(2) : 0}/¥
                                      {e.freezePrice}
                                      <p style={{ color: 'red' }}>已冻结:¥{e.fundAmount}</p>
                                    </p>
                                    <p>剩余押金:¥{e.residueDeposit ? e.residueDeposit : 0}</p>
                                    <button
                                      onClick={() => {
                                        this.setState({
                                          onShowPay: true,
                                          depositDeductHistory: e.depositDeductHistory,
                                        });
                                      }}
                                    >
                                      查看支付记录
                                    </button>
                                  </div>
                                </td>
                                <td
                                  style={{
                                    width: '13%',
                                    verticalAlign: 'top',
                                    borderRight: '1px solid #eee',
                                  }}
                                >
                                  <div style={{ paddingTop: '12px' }}>
                                    <p>{e.rentStart}</p>
                                    <p>至</p>
                                    <p>{e.unrentTime}</p>
                                    <p>
                                      {e.rentDuration}天（{e.totalPeriods}期）
                                    </p>
                                    {e.reletCount ? (
                                      <p style={{ color: 'red' }}>续租{e.reletCount}次</p>
                                    ) : null}
                                  </div>
                                </td>
                                <td
                                  style={{
                                    width: '16%',
                                    verticalAlign: 'top',
                                    borderRight: '1px solid #eee',
                                  }}
                                >
                                  <div
                                    className={styles.t_payment}
                                    style={{ paddingTop: '12px', paddingBottom: '12px' }}
                                  >
                                    <p style={{ color: '#000' }}>
                                      ¥{e.payedRentAmount}({e.payedPeriods}/{e.totalPeriods})
                                    </p>
                                    {[
                                      '03',
                                      '04',
                                      '05',
                                      '06',
                                      '07',
                                      '08',
                                      '09',
                                      '10',
                                      '11',
                                      '12',
                                      '13',
                                      '14',
                                      '15',
                                      '16',
                                      '17',
                                    ].includes(e.status) ? (
                                      e.withholdType == 1 ? (
                                        <p className={styles.co}>预授权免密支付</p>
                                      ) : e.withholdType == 2 ? (
                                        <p className={styles.cm}>
                                          蚂蚁链合同代扣
                                          {e.userIsSigned == 2 ? '/已签署' : '/未签署'}
                                        </p>
                                      ) : (
                                        ''
                                      )
                                    ) : null}
                                    <p>
                                      {e.actionTime}{' '}
                                      <Button
                                        type="primary"
                                        style={{
                                          borderRadius: '10px',
                                          height: '22px',
                                          width: '88px',
                                        }}
                                        onClick={() => this.timePudate(e)}
                                      >
                                        时间记录
                                      </Button>
                                    </p>
                                    <p>买断价:¥{e.endPrice}</p>
                                    {e.payedRentAmount === 0 ? (
                                      <p
                                        className={styles.avoid}
                                        onClick={() => this.isBillInformation(e)}
                                      >
                                        已付：￥{e.payedRentAmount}/￥{e.totalRentAmount}
                                      </p>
                                    ) : (
                                      <p
                                        className={styles.avoid}
                                        onClick={() => this.isBillInformation(e)}
                                      >
                                        已付：￥{e.payedRentAmount}/￥{e.totalRentAmount}
                                      </p>
                                    )}
                                    {e.orderId == isFormOutlined ? (
                                      <p style={{ marginTop: '10px', marginLeft: '-3px' }}>
                                        <Form layout="inline" onSubmit={this.onOkLind}>
                                          <Form.Item label="合计进货价">
                                            {getFieldDecorator('inputLined', {
                                              rules: [
                                                {
                                                  required: false,
                                                  message: '请输入合计进货价',
                                                },
                                              ],
                                              initialValue: e.purchasePrice,
                                            })(<Input style={{ width: '60px', height: '20px' }} />)}
                                          </Form.Item>
                                          <Form.Item>
                                            <Button
                                              htmlType="submit"
                                              style={{
                                                width: '40px',
                                                height: '20px',
                                                borderRadius: '8px',
                                                backgroundColor: '#cccc',
                                                padding: '0',
                                                color: '#fff',
                                                fontSize: '8px',
                                                marginLeft: '-10px',
                                              }}
                                            >
                                              保存
                                            </Button>
                                          </Form.Item>
                                          <Form.Item>
                                            <Button
                                              onClick={this.onCancelOutLined}
                                              style={{
                                                width: '40px',
                                                height: '20px',
                                                borderRadius: '8px',
                                                padding: '0',
                                                marginLeft: '-12px',
                                                fontSize: '8px',
                                              }}
                                            >
                                              取消
                                            </Button>
                                          </Form.Item>
                                        </Form>
                                      </p>
                                    ) : (
                                      <p style={{ marginTop: '10px' }}>
                                        合计进货价：
                                        {e.purchasePrice
                                          ? e.purchasePrice.toFixed(2)
                                          : '0.00'}￥{' '}
                                        <FormOutlined onClick={() => this.toFormOutlined(e)} />
                                      </p>
                                    )}
                                    {e.statext === '订单完成' ? null : (
                                      <>
                                        {e.nextStatementDate ? (
                                          <div>
                                            <p
                                              style={{
                                                color: '#CC1F1B',
                                                marginTop: '18px',
                                                marginBottom: '0',
                                              }}
                                            >
                                              最近还款日期
                                            </p>
                                            <p style={{ color: '#CC1F1B', marginBottom: '0' }}>
                                              {e.nextStatementDate}（
                                              {e.nextStatementStatus == '1' ? '待还款' : '已还款'}）
                                            </p>
                                          </div>
                                        ) : null}
                                      </>
                                    )}
                                  </div>
                                </td>
                                <td
                                  style={{
                                    width: '9%',
                                    verticalAlign: 'top',
                                    borderRight: '1px solid #eee',
                                  }}
                                >
                                  <div className={styles.state} style={{ paddingTop: '12px' }}>
                                    {(e.status == '06' ||
                                      e.status == '07' ||
                                      e.status == '08' ||
                                      e.status == '09') &&
                                      !e.policyUrl &&
                                      e.leaseStatus ? (
                                      <p
                                        style={{ background: '#FF715A' }}
                                        onClick={() => this.setInsure(e)}
                                      >
                                        投保
                                      </p>
                                    ) : null}
                                    {e.policyUrl ? (
                                      <p
                                        style={{ background: '#FF715A' }}
                                        onClick={() => this.setInsureLink(e)}
                                      >
                                        查看链接
                                      </p>
                                    ) : null}
                                    <p
                                      style={{
                                        borderRadius: '0',
                                        color: '#444',
                                        cursor: 'context-menu',
                                        marginBottom: '50px',
                                      }}
                                    >
                                      {e.statext}
                                    </p>
                                    {e.status == '04' ||
                                      e.status === '05' ||
                                      e.status === '11' ||
                                      e.status === '13' ||
                                      e.status === '14' ||
                                      e.status === '15' ||
                                      e.status === '01' ? (
                                      <p
                                        style={{ background: '#D95350', marginTop: '200' }}
                                        onClick={() =>
                                          this.setState({ orderId: e.orderId, visible: true })
                                        }
                                      >
                                        关闭订单
                                      </p>
                                    ) : null}

                                    {e.status == '05' ? (
                                      <Popconfirm
                                        title="确定要收货吗？"
                                        style={{ background: '#1890FF', width: 100 }}
                                        onConfirm={() => {
                                          axios({
                                            url: `/hzsx/ope/order/userConfirmReceipt`,
                                            method: 'GET',
                                            headers: {
                                              token: getToken(),
                                            },
                                            params: {
                                              orderId: e.orderId,
                                            },
                                          }).then(res => {
                                            if (res.data) {
                                              message.success('收货成功');
                                            } else {
                                              message.error('收货失败');
                                            }
                                          });
                                        }}
                                      >
                                        <p style={{ background: '#1890FF', width: 100 }}>
                                          后台确认收货
                                        </p>
                                      </Popconfirm>
                                    ) : null}
                                    {e.piccLog == null ? (
                                      ''
                                    ) : (
                                      <Tooltip title={e.piccLog}>
                                        <p style={{ background: '#90d7ec' }}>人保投保信息</p>
                                      </Tooltip>
                                    )}
                                    {e.status == '07' ? (
                                      <p
                                        style={{ background: '#1890FF' }}
                                        onClick={() =>
                                          this.setState({ overrule: true, overruleId: e.orderId })
                                        }
                                      >
                                        驳回归还
                                      </p>
                                    ) : null}

                                    {e.payedRentAmount <= 0 &&
                                      localStorage.getItem(`disTransferOrder`) == 1 &&
                                      (e.status == '11' ||
                                        e.status == '13' ||
                                        e.status == '14' ||
                                        e.status == '15' ||
                                        e.status == '01') ? (
                                      <p
                                        style={{ background: '#1890FF' }}
                                        onClick={() => this.transfer(e)}
                                      >
                                        转单
                                      </p>
                                    ) : null}
                                    {e.backCount > 1 ? (
                                      <p style={{ background: '#D95350' }}>回捞订单</p>
                                    ) : null}
                                  </div>
                                </td>
                                <td style={{ width: '19%', verticalAlign: 'top' }}>
                                  <div style={{ paddingTop: '12px', padding: '12px 20px 0 20px' }}>
                                    {e.status == '13' || e.status == '14' || e.status == '04' ? (
                                      <EditOutlined
                                        onClick={() => this.showOrderModal('address', '', e, index)}
                                        style={{ float: 'right' }}
                                      />
                                    ) : null}
                                  </div>
                                  <p>{e.receiverName}</p>
                                  <p>{e.addressUserPhone}</p>
                                  <p>{e.address}</p>
                                  {e.alertAddress == 1 ? (
                                    <p style={{ color: 'red' }}>(请注意：该地区为高风险区域)</p>
                                  ) : e.alertAddress == 2 ? (
                                    <p style={{ color: '#F7C100' }}>(请注意：该地区为中风险区域)</p>
                                  ) : (
                                    ''
                                  )}
                                  { }
                                  <p>{e.telephone}</p>
                                  <p>
                                    <a onClick={() => this.ApplicationOrderList(e)}>
                                      申请中:{e.hisRentingOrderCount ? e.hisRentingOrderCount : 0}
                                    </a>
                                  </p>
                                  <p>
                                    <a onClick={() => this.SuccessdOrderList(e)}>
                                      成功订单数:
                                      {e.hisTransactionOrderCount ? e.hisTransactionOrderCount : 0}
                                    </a>
                                  </p>
                                  <p>
                                    <a onClick={() => this.AllOrderList(e)}>
                                      总计下单数:{e.hisSubmitOrderCount ? e.hisSubmitOrderCount : 0}
                                    </a>
                                  </p>
                                </td>
                              </tr>
                            </tbody>
                            <tbody className={styles.harryVerify}>
                              <tr>
                                <td colSpan={'7'}>
                                  <div className={styles.dataMain}>
                                    <div className={styles.dataNeme}>
                                      认证资料: {e.realName}（{e.idCard ? e.idCard : '未认证'}
                                      ）&nbsp; | &nbsp;{' '}
                                      {e.userFaceCertStatus ? (
                                        '人脸识别通过'
                                      ) : (
                                        <span style={{ color: 'red' }}>人脸识别未通过</span>
                                      )}{' '}
                                      &nbsp; | &nbsp; 性别:{e.gender ? e.gender : '未认证'} &nbsp; |
                                      &nbsp; 年龄:{e.age ? e.age : '未认证'} &nbsp; | &nbsp;
                                      普通会员 &nbsp; &nbsp;
                                      <div className={styles.c_icon}>
                                        <img
                                          src="https://oss.llxzu.com/b708a605ff2a4efbb5d289f2836fee1d.png"
                                          alt="icon"
                                          width="100%"
                                        />
                                      </div>
                                      &nbsp; &nbsp;
                                      {e.localAddress ? e.localAddress : null}&nbsp; &nbsp;
                                      {e.isRiskAddress == 1 ? (
                                        <span style={{ color: 'red' }}>
                                          (请注意：该地区为高风险区域)
                                        </span>
                                      ) : e.isRiskAddress == 2 ? (
                                        <span style={{ color: '#F7C100' }}>
                                          (请注意：该地区为中风险区域)
                                        </span>
                                      ) : (
                                        ''
                                      )}
                                    </div>
                                    <div className={styles.dataButton}>
                                      <Button
                                        type="primary"
                                        style={{ background: '#4CAF50' }}
                                        onClick={() => this.operate(0, e)}
                                      >
                                        复制订单
                                      </Button>
                                      {e.userCertification ? (
                                        <Button
                                          type="primary"
                                          style={{ background: '#1eabff' }}
                                          onClick={() => this.operate(1, e)}
                                          key={1}
                                        >
                                          租户凭证
                                        </Button>
                                      ) : (
                                        <Button
                                          type="primary"
                                          style={{ background: '#1eabff', color: 'red' }}
                                          onClick={() => this.operate(1, e)}
                                          key={1}
                                        >
                                          租户凭证
                                        </Button>
                                      )}
                                      {e.blackTime ? (
                                        <Popconfirm
                                          title="是否确认解除黑名单？"
                                          onConfirm={() =>
                                            axios({
                                              url: this.createUrl('/hzsx/user/setUserBlackStatus'),
                                              method: 'GET',
                                              headers: { token: getToken() },
                                              params: {
                                                uid: e.orderAddressDto.uid,
                                                time: 0,
                                              },
                                            }).then(res => {
                                              this.handleSubmit();
                                              message.success('解除黑名单成功了');
                                            })
                                          }
                                        >
                                          <Button type="primary" style={{ background: '#45b97c' }}>
                                            解除黑名单
                                          </Button>
                                        </Popconfirm>
                                      ) : (
                                        <Button
                                          type="primary"
                                          style={{ background: '#bec8c8' }}
                                          onClick={() => this.isOpenBtn(e)}
                                        >
                                          拉黑
                                        </Button>
                                      )}
                                      <Button
                                        type="primary"
                                        style={{ background: '#0f1362' }}
                                        onClick={() => {
                                          this.setState({
                                            orderId: e.orderId,
                                          });
                                          this.viewCredit(e);
                                        }}
                                      >
                                        风控一
                                      </Button>
                                      {/* {e.status === '06' && (
                                        <Popconfirm
                                          placement="bottom"
                                          title="首次下载需商家支付20元，是否下载?(自动扣除，重复下载不收费)"
                                          onConfirm={() => this.electronicSeal(e)}
                                        >
                                          <Button type="primary" style={{ background: '#083c5a' }}>
                                            电子签章
                                          </Button>
                                        </Popconfirm>
                                      )} */}
                                      {e.orderContractUrl && (
                                        <Button
                                          type="primary"
                                          onClick={() => {
                                            window.open(e.orderContractUrl);
                                          }}
                                        >
                                          租赁协议
                                        </Button>
                                      )}
                                      {e.interactiveRisk && e.interactiveRisk.length > 0 && (
                                        <>
                                          {e.interactiveRisk.map((item, index) => {
                                            return (
                                              <>
                                                {item.type === 'sync' && e.channelId == '006' && (
                                                  <Button
                                                    type="primary"
                                                    style={{
                                                      background:
                                                        item.data == null && item.isExist == false
                                                          ? '#d3d7d4'
                                                          : item.data == null &&
                                                            item.isExist == true
                                                            ? '#33a3dc'
                                                            : item.data == '0'
                                                              ? '#1d953f'
                                                              : item.data == '1'
                                                                ? '#ffe600'
                                                                : item.data == '2'
                                                                  ? '#ed1941'
                                                                  : '',
                                                    }}
                                                    onClick={() => this.hundredRiskClick(e)}
                                                  >
                                                    {item.data
                                                      ? `交互风控:${item.data}`
                                                      : '交互风控'}
                                                  </Button>
                                                )}
                                                {item.type == 'consult' && (
                                                  <Button
                                                    type="primary"
                                                    style={{
                                                      background:
                                                        item.data == null
                                                          ? '#d3d7d4'
                                                          : ['0', '1', '2', '3'].includes(item.data)
                                                            ? '#1d953f'
                                                            : item.data == '4'
                                                              ? '#ffe600'
                                                              : item.data == '5'
                                                                ? '#f47920'
                                                                : item.data == '6'
                                                                  ? '#ed1941'
                                                                  : '',
                                                    }}
                                                    onClick={() => this.riskIdentification(e, item)}
                                                  >
                                                    {item.isExist == true
                                                      ? `风险咨询:${item.data}`
                                                      : '风险咨询'}
                                                  </Button>
                                                )}
                                              </>
                                            );
                                          })}
                                        </>
                                      )}
                                    </div>
                                  </div>
                                </td>
                                <td className={styles.firstB} colSpan={'3'}></td>
                              </tr>
                            </tbody>
                            <tbody className={styles.remark}>
                              <tr>
                                <td colSpan={'7'}>
                                  <div className={styles.remarkMain}>
                                    <div className={styles.remarkNeme}>
                                      <div>
                                        <span
                                          onClick={() =>
                                            this.setState({
                                              remarkVisible: true,
                                              order_id: e.orderId,
                                            })
                                          }
                                          className={styles.t_remark}
                                        >
                                          备注:{' '}
                                          {(e.lastActionNote
                                            ? e.lastActionNote.replace('null', '')
                                            : e.lastActionNote) || '暂无备注'}{' '}
                                        </span>
                                        <p
                                          className={styles.remarkButton}
                                          style={{ background: '#478AFF' }}
                                          onClick={() => this.goRecord(e)}
                                        >
                                          {e.actionCount}次记录
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className={styles.firstB} colSpan={'3'}></td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p>暂无信息</p>
              )}
              <Pagination {...paginationProps} onChange={this.onPage} />
            </div>
          </Spin>
        </Card>
        <Modal
          title="是否关闭订单?"
          visible={this.state.visible}
          onCancel={() => this.setState({ visible: false })}
          onOk={() => this.portclose()}
        >
          <Input.TextArea
            rows={4}
            onChange={e => {
              this.setState({ indent: e.target.value });
            }}
            placeholder="请填写拒绝原因"
          />
        </Modal>
        <Modal
          title="确定退款吗？退款成功后，下次代扣可能会造成失败。"
          visible={this.state.istoRefund}
          onCancel={() => this.setState({ istoRefund: false, refundRemark: '' })}
          onOk={() => this.toOkRefund()}
        >
          <Input.TextArea
            rows={4}
            onChange={e => {
              this.setState({ refundRemark: e.target.value });
            }}
            placeholder="请填写退款原因"
          />
        </Modal>
        <Modal
          title="身份证照片"
          visible={this.state.imgvisi}
          onCancel={() => {
            this.setState({ imgvisi: false });
          }}
          onOk={() => {
            this.setState({ imgvisi: false });
          }}
        >
          <div className={styles.visiimgbox}>
            {this.state.idurl.length > 0 && this.state.idurl ? (
              this.state.idurl.map(value => {
                return (
                  <img
                    src={value}
                    className={styles.visiimg}
                    onClick={() => this.setState({ identity: true, imgInfo: value })}
                  />
                );
              })
            ) : (
              <p>暂无身份证图片</p>
            )}
          </div>
        </Modal>
        <Modal
          title="订单信息复制"
          visible={this.state.voucher}
          onCancel={() => this.setState({ voucher: false })}
          footer={null}
          width={600}
          destroyOnClose
        >
          <Input.TextArea
            rows={5}
            value={this.state.jsonValue}
            onChange={e => this.setState({ jsonValue: e.target.value })}
          />
          <div className={styles.copy_color}>
            <span onClick={() => this.orderinformation()}>复制到粘贴板</span>
          </div>
        </Modal>
        <Modal
          title="身份证信息"
          visible={this.state.identity}
          onCancel={() => this.setState({ identity: false })}
          footer={null}
          destroyOnClose
        >
          <img src={this.state.imgInfo} alt="alt" style={{ width: '100%' }} />
        </Modal>
        <Modal
          title="修改套餐"
          visible={this.state.pudate}
          onCancel={() => this.setState({ pudate: false, count_price: null, deposit: null })}
          footer={null}
          width="50%"
          destroyOnClose
        >
          <div className={styles.radio_main}>
            <span className={styles.radio_span}>套餐名</span>
            <Radio.Group defaultValue={productspceId} size="large">
              {productspceList.map((item, index) => {
                return (
                  <Radio.Button
                    value={item.id}
                    key={index}
                    onChange={this.changeRadio}
                    style={{ display: 'block' }}
                    className={styles.radio_button}
                  >
                    {item.value_row[0].platformSpecValue}/{item.value_row[1].platformSpecValue} (
                    {item.days}天) ({(item.price * item.days).toFixed(2)}元)
                    {item.value_row.spec}
                  </Radio.Button>
                );
              })}
            </Radio.Group>
            <br />
            修改价格：
            <Input
              allowClear
              placeholder="请输入"
              value={this.state.count_price}
              onChange={e =>
                this.setState({
                  count_price: e.target.value,
                  day_price: (e.target.value / this.state.day).toFixed(2),
                })
              }
              style={{ width: 200 }}
              className={styles.radio_input}
            />
            <br />
            押金：
            <Input
              allowClear
              placeholder="请输入押金"
              value={this.state.deposit}
              onChange={e => this.setState({ deposit: e.target.value })}
              style={{ width: 200 }}
              className={styles.radio_input}
            />
          </div>
          <Button type="primary" block className="querenbtn" onClick={() => this.submitPackage()}>
            确认
          </Button>
        </Modal>
        <Modal
          title="转单"
          visible={this.state.transfer}
          onCancel={() => this.setState({ transfer: false })}
          footer={null}
          destroyOnClose
        >
          <div className={styles.radio_main}>
            <span className={styles.radio_span}>转单商家名</span>
            <Select
              placeholder="转单商家"
              onChange={(e, option) =>
                this.onChangeSelect(e, '0', option && option.key ? option.key : null)
              }
              onSearch={value => this.onSearchSelect(value, '0')}
              style={{ width: 200 }}
              className={styles.radio_Select}
              value={this.state.recordSelect[0]}
              allowClear
              showSearch
            >
              {transferList.map((item, val) => {
                return (
                  <Option value={item.name} key={item.shopId}>
                    {item.name}
                  </Option>
                );
              })}
            </Select>
            <div className={styles.radio_remark}>
              {recordList.map((item, val) => {
                return (
                  <div>
                    {' '}
                    <div>
                      {val + 1}.{item.name} {item.time}
                    </div>
                    <div>{item.remark}</div>
                  </div>
                );
              })}
            </div>
          </div>
          <Button type="primary" block className="querenbtn" onClick={() => this.submitTransfer()}>
            确认
          </Button>
        </Modal>
        {/* 投保链接展示 */}
        <Modal
          title="投保链接"
          visible={this.state.leaseLinkVisible}
          onCancel={() => this.setState({ leaseLinkVisible: false })}
          footer={null}
          destroyOnClose
        >
          {/* 投保价格 */}
          <a href={leaseLinkUrl}>{leaseLinkUrl}</a>
          <Button
            type="primary"
            block
            className="querenbtn"
            onClick={() => {
              this.setState({ leaseLinkVisible: false });
              window.open(leaseLinkUrl);
            }}
          >
            确认
          </Button>
        </Modal>
        {/* 投保展示 */}
        <Modal
          title="投保"
          visible={this.state.insureVisible}
          onCancel={() => this.setState({ insureVisible: false })}
          footer={null}
          destroyOnClose
        >
          {/* 投保价格  设备价值 */}
          <div>
            <span style={{ color: '#262626' }}>
              设备价值：{parseFloat(insureObj.productPrice / 10000).toFixed(2)}
            </span>
            <br />
            <span style={{ color: '#FF1A2E', marginBottom: '20px' }}>
              注意：投保费用为{parseFloat(insureObj.leasePrice).toFixed(2)}
              元，本次计算可能存在误差，以实际账单为准
            </span>
          </div>
          <Row>
            <Col span={24} style={{ textAlign: 'center' }}>
              <Button
                style={{ marginLeft: 8 }}
                onClick={() => this.setState({ insureVisible: false })}
              >
                我再想想
              </Button>
              <Button type="primary" htmlType="submit" onClick={this.submitInsure}>
                确定投保
              </Button>
            </Col>
          </Row>
        </Modal>
        <Modal
          title="时间记录"
          visible={this.state.timeVisible}
          onOk={() => {
            this.setState({ timeVisible: false });
          }}
          onCancel={() => {
            this.setState({ timeVisible: false });
          }}
        >
          <List
            itemLayout="horizontal"
            dataSource={tiemData}
            renderItem={item => (
              <List.Item>
                <List.Item.Meta
                  avatar={<Badge status="processing"></Badge>}
                  title={
                    <a>
                      {item.actionName}:{item.createTime}
                    </a>
                  }
                />
              </List.Item>
            )}
          />
        </Modal>
        <Modal
          title="驳回原因"
          visible={this.state.overrule}
          onOk={this.handleOkOver}
          onCancel={() => {
            this.setState({ overrule: false });
            this.props.form.resetFields('rejectReason');
          }}
        >
          <Form>
            <Form.Item label="驳回原因" {...formItemLayout}>
              {getFieldDecorator('rejectReason', {
                rules: [{ required: true, message: '请输入驳回原因' }],
              })(<TextArea placeholder="请输入" />)}
            </Form.Item>
          </Form>
        </Modal>
        <Modal
          title="备注"
          visible={this.state.remarkVisible}
          onOk={this.handleOk}
          onCancel={() => {
            this.setState({ remarkVisible: false });
            this.props.form.resetFields('beizhu');
          }}
        >
          <Form>
            <Form.Item label="备注内容" {...formItemLayout}>
              {getFieldDecorator('beizhu', {
                rules: [{ required: true, message: '请输入备注' }],
              })(<TextArea placeholder="请输入" />)}
            </Form.Item>
          </Form>
        </Modal>
        <Modal
          title="佣金比率"
          visible={this.state.brokerageRateVisible}
          onOk={this.handlebrokerageRate}
          onCancel={() => this.setState({ brokerageRateVisible: false })}
        >
          <Form>
            <Form.Item label="佣金比率" {...formItemLayout}>
              {getFieldDecorator('rate', {
                rules: [{ required: true, message: '请输入佣金比率' }],
              })(
                <Input
                  onChange={e => this.setState({ rate: e.target.value })}
                  style={{ width: 200 }}
                  className={styles.radio_input}
                />,
              )}
            </Form.Item>
          </Form>
        </Modal>
        <Modal
          title="记录"
          width="60%"
          wrapClassName={styles.bodyStyles}
          visible={this.state.recordVisible}
          onOk={() => {
            this.setState({ recordVisible: false });
          }}
          onCancel={() => {
            this.setState({ recordVisible: false });
          }}
        >
          <Table
            columns={columnsOperation}
            dataSource={record_list}
            pagination={false}
            scroll={{ y: 500 }}
          />
        </Modal>
        <Modal
          title="记录"
          width={500}
          visible={this.state.onShowPay}
          onOk={() => {
            this.setState({ onShowPay: false });
          }}
          onCancel={() => {
            this.setState({ onShowPay: false });
          }}
        >
          <div className={styles.c_record}>
            {this.state.depositDeductHistory ? (
              this.state.depositDeductHistory.map((item, index) => {
                return <div key={index}>{item}</div>;
              })
            ) : (
              <p>暂无数据</p>
            )}
            <div></div>
          </div>
        </Modal>
        <Modal
          title="电子签章 （后续下载免除费用）"
          width={500}
          visible={this.state.electronicVisible}
          onOk={() => {
            this.setState({ electronicVisible: false });
          }}
          onCancel={() => {
            this.setState({ electronicVisible: false });
          }}
        >
          <div className={styles.riskNeme}>
            <button style={{ marginLeft: '25%' }}>
              <a href={this.state.depositScore}>存证下载</a>
            </button>
            <button style={{ marginLeft: '10%' }}>
              <a href={this.state.depositOutScore}>存出下载</a>
            </button>
          </div>
        </Modal>
        {/* 发货推送图片 */}
        <Modal
          title="发货推送图片"
          width={800}
          visible={this.state.countersignVisible}
          onOk={() => {
            this.setState({ countersignVisible: false });
          }}
          onCancel={() => {
            this.setState({ countersignVisible: false });
          }}
        >
          <Descriptions.Item label="发货物流公司">
            物流公司：{' '}
            {receiptExpressInfo && receiptExpressInfo.expressCompany
              ? receiptExpressInfo.expressCompany
              : ''}
            ，&nbsp;&nbsp;&nbsp;&nbsp;
          </Descriptions.Item>
          <Descriptions.Item label="发货物流单号">
            物流单号：{' '}
            {receiptExpressInfo && receiptExpressInfo.expressNo ? receiptExpressInfo.expressNo : ''}
          </Descriptions.Item>
        </Modal>
        {/* 发货查询推送图片 */}
        <Modal
          title="发货查询推送图片"
          width={800}
          visible={this.state.imageVisible}
          onOk={() => {
            this.setState({ imageVisible: false });
          }}
          onCancel={() => {
            this.setState({ imageVisible: false });
          }}
        >
          {getPicPushExpressList ? (
            <>
              {
                <Descriptions.Item label="发货物流pic">
                  物流图片：{' '}
                  {getPicPushExpressList && getPicPushExpressList.pic
                    ? getPicPushExpressList.pic
                    : ''}
                </Descriptions.Item>
              }
              <Divider />
            </>
          ) : null}
          {
            <Timeline>
              {picList.map((item, idx) => {
                let color = 'blue';
                if (idx === 0) {
                  color = 'green';
                }
                return (
                  <Timeline.Item
                    style={{ color: idx !== 0 ? '#aaa' : '#333' }}
                    key={idx}
                    color={color}
                  >
                    <p>{item.waybillNo}</p>
                    <img
                      style={{ width: '100px', height: '100px' }}
                      src={item.pic}
                      onClick={() => this.setState({ logistics: true, imgInfo: item.pic })}
                    />
                  </Timeline.Item>
                );
              })}
            </Timeline>
          }
        </Modal>
        <Modal
          title="发货物流图片信息"
          visible={this.state.logistics}
          onCancel={() => this.setState({ logistics: false })}
          footer={null}
          destroyOnClose
        >
          <img src={this.state.imgInfo} alt="alt" style={{ width: '100%' }} />
        </Modal>
        {/* 归还电子回签 */}
        <Modal
          title="归还电子回签"
          width={800}
          visible={this.state.returnCountersignVisible}
          onOk={() => {
            this.setState({ returnCountersignVisible: false });
          }}
          onCancel={() => {
            this.setState({ returnCountersignVisible: false });
          }}
        >
          <Descriptions.Item label="归还物流公司">
            物流公司：{' '}
            {giveBackExpressInfo && giveBackExpressInfo.expressCompany
              ? giveBackExpressInfo.expressCompany
              : ''}
            ，&nbsp;&nbsp;&nbsp;&nbsp;
          </Descriptions.Item>
          <Descriptions.Item label="归还物流单号">
            物流单号：{' '}
            {giveBackExpressInfo && giveBackExpressInfo.expressNo
              ? giveBackExpressInfo.expressNo
              : ''}
          </Descriptions.Item>
        </Modal>
        {/* 归还图片回传 */}
        <Modal
          title="归还图片回传"
          width={800}
          visible={this.state.returnImageVisible}
          onOk={() => {
            this.setState({ returnImageVisible: false });
          }}
          onCancel={() => {
            this.setState({ returnImageVisible: false });
          }}
        >
          {getPicPushExpressList ? (
            <>
              {
                <Descriptions.Item label="归还物流pic">
                  物流图片：{' '}
                  {getPicPushExpressList && getPicPushExpressList.pic
                    ? getPicPushExpressList.pic
                    : ''}
                </Descriptions.Item>
              }
              <Divider />
            </>
          ) : null}
          {
            <Timeline>
              {picList.map((item, idx) => {
                let color = 'blue';
                if (idx === 0) {
                  color = 'green';
                }
                return (
                  <Timeline.Item
                    style={{ color: idx !== 0 ? '#aaa' : '#333' }}
                    key={idx}
                    color={color}
                  >
                    <p>{item.waybillNo}</p>
                    <img
                      style={{ width: '100px', height: '100px' }}
                      src={item.pic}
                      onClick={() => this.setState({ returnlogistics: true, imgInfo: item.pic })}
                    />
                  </Timeline.Item>
                );
              })}
            </Timeline>
          }
        </Modal>
        <Modal
          title="归还物流图片信息"
          visible={this.state.returnlogistics}
          onCancel={() => this.setState({ returnlogistics: false })}
          footer={null}
          destroyOnClose
        >
          <img src={this.state.imgInfo} alt="alt" style={{ width: '100%' }} />
        </Modal>
        {/* 账单拆分 */}
        <Modal
          title="账单拆分"
          visible={this.state.billSplitVisible}
          onOk={this.handlebillSplit}
          onCancel={() => this.setState({ billSplitVisible: false })}
        >
          <Form>
            <Form.Item label="拆分金额" {...formItemLayout}>
              {getFieldDecorator('splitAmount', {
                rules: [{ required: true, message: '请输入拆分金额' }],
              })(
                <Input
                  onChange={e => this.setState({ rate: e.target.value })}
                  style={{ width: 200 }}
                  className={styles.radio_input}
                />,
              )}
            </Form.Item>
          </Form>
        </Modal>
        {/* 账单信息 */}
        <Drawer
          closable={false}
          visible={this.state.billInformation}
          onClose={() => this.onCloseBill()}
          width="50%"
        >
          <Tabs activeKey={'1'}>
            <TabPane tab="账单信息" key="1">
              <CustomCard title="分期信息" style={{ marginBottom: 20 }} />
              <AntTable
                columns={this.columnsByStages}
                dataSource={onTableData(queryOrderStagesDetails)}
              />
              {orderBuyOutDto.orderId ? (
                <>
                  <CustomCard title="买断信息" style={{ marginBottom: 20 }} />
                  <AntTable
                    columns={orderBuyOutDto.payFlag ? columnsBuyOutYes : columnsBuyOutNo}
                    dataSource={onTableData([orderBuyOutDto])}
                    paginationProps={paginationProps}
                  />
                </>
              ) : null}
            </TabPane>
          </Tabs>
        </Drawer>
        {/* 发货物流信息 */}
        <Drawer
          closable={false}
          visible={logisticsInformation}
          width="50%"
          onClose={() =>
            this.setState({ logisticsInformation: false, drawerVisible: false, wlList: [] })
          }
        >
          {receiptExpressInfo ? (
            <>
              <Descriptions title={<CustomCard title="发货物流信息" />}>
                <Descriptions.Item label="发货物流公司">
                  {receiptExpressInfo && receiptExpressInfo.expressCompany
                    ? receiptExpressInfo.expressCompany
                    : ''}
                </Descriptions.Item>
                <Descriptions.Item label="发货物流单号">
                  {receiptExpressInfo && receiptExpressInfo.expressNo
                    ? receiptExpressInfo.expressNo
                    : ''}
                </Descriptions.Item>
                <Descriptions.Item label="发货时间">
                  {receiptExpressInfo.deliveryTime}
                </Descriptions.Item>
              </Descriptions>
              {receiptExpressInfo.shortName == 'sf' ? (
                <>
                  <Popconfirm
                    placement="bottom"
                    title="是否推送"
                    onConfirm={() =>
                      this.onPicClick('发货推送图片', receiptExpressInfo, this.state.orderId)
                    }
                  >
                    <Button>发货推送图片</Button>
                  </Popconfirm>
                  <Button
                    onClick={() =>
                      this.onImageClick('发货照片回传信息', receiptExpressInfo, this.state.orderId)
                    }
                  >
                    发货查询图片
                  </Button>
                </>
              ) : null}
              <Divider />
            </>
          ) : null}
          {drawerVisible == true ? (
            <Timeline>
              {wlList.map((item, idx) => {
                let color = 'blue';
                if (idx === 0) {
                  color = 'green';
                }
                return (
                  <Timeline.Item
                    style={{ color: idx !== 0 ? '#aaa' : '#333' }}
                    key={idx}
                    color={color}
                  >
                    <p>{item.remark}</p>
                    <p>{item.datetime}</p>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          ) : null}
        </Drawer>
        {/* 归还物流信息 */}
        <Drawer
          closable={false}
          visible={returnLogisticsInformation}
          width="50%"
          onClose={() =>
            this.setState({ returnLogisticsInformation: false, drawerVisible: false, wlList: [] })
          }
        >
          {giveBackExpressInfo ? (
            <>
              <Descriptions title={<CustomCard title="归还物流信息" />}>
                <Descriptions.Item label="发货物流公司">
                  {giveBackExpressInfo && giveBackExpressInfo.expressCompany
                    ? giveBackExpressInfo.expressCompany
                    : ''}
                </Descriptions.Item>
                <Descriptions.Item label="发货物流单号">
                  {giveBackExpressInfo && giveBackExpressInfo.expressNo
                    ? giveBackExpressInfo.expressNo
                    : ''}
                </Descriptions.Item>
                <Descriptions.Item label="归还时间">
                  {giveBackExpressInfo.deliveryTime}
                </Descriptions.Item>
              </Descriptions>
              {giveBackExpressInfo.shortName == 'sf' ? (
                <>
                  <Popconfirm
                    placement="bottom"
                    title="是否推送"
                    onConfirm={() =>
                      this.onReturnPicClick('归还推送图片', receiptExpressInfo, this.state.orderId)
                    }
                  >
                    <Button>归还推送图片</Button>
                  </Popconfirm>
                  <Button
                    onClick={() =>
                      this.onReturnImageClick(
                        '归还查询推送图片信息',
                        giveBackExpressInfo,
                        this.state.orderId,
                      )
                    }
                  >
                    归还推送图片
                  </Button>
                </>
              ) : null}
              <Divider />
            </>
          ) : null}
          {drawerVisible == true ? (
            <Timeline>
              {wlList.map((item, idx) => {
                let color = 'blue';
                if (idx === 0) {
                  color = 'green';
                }
                return (
                  <Timeline.Item
                    style={{ color: idx !== 0 ? '#aaa' : '#333' }}
                    key={idx}
                    color={color}
                  >
                    <p>{item.remark}</p>
                    <p>{item.datetime}</p>
                  </Timeline.Item>
                );
              })}
            </Timeline>
          ) : null}
        </Drawer>
        {/* 风控报告 */}
        <Drawer
          placement="right"
          closable={false}
          width="50%"
          onClose={() => this.setState({ placementVisible: false })}
          visible={this.state.placementVisible}
          bodyStyle={{ padding: '0' }}
        >
          <RiskControlReport redata={riskControlData} />
        </Drawer>
        {/* 关闭订单 */}
        <Modal
          destroyOnClose
          title={'关闭订单'}
          visible={orderVisible === 'close'}
          onOk={this.handleOkClose}
          width="450px"
          onCancel={this.handleCancel}
        >
          <Form>
            <FormItem label="小记">
              {form.getFieldDecorator('closeReason', {})(<Input placeholder="请输入关单原因" />)}
            </FormItem>
          </Form>
        </Modal>
        {/* 新增风控建议的弹框 */}
        <Modal
          destroyOnClose
          title={'新增风控建议'}
          visible={advise}
          onOk={this.handleOkAdvise}
          width="650px"
          onCancel={this.handleCancelAdvise}
        >
          <Form>
            <Form.Item label="风控建议选项">
              {getFieldDecorator('advisestatus', {
                rules: [{ required: true, message: '请选择风控建议' }],
              })(
                <Select
                  placeholder="请选择风控建议"
                  onChange={this.changesAdvises}
                  style={{ width: 450 }}
                  allowClear
                >
                  {advises.map((item, val) => {
                    return (
                      <Option value={item.value} key={val}>
                        {item.name}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </Form.Item>
            <FormItem name="riskRemark">
              {form.getFieldDecorator('riskRemark')(
                <TextArea
                  onChange={this.changesTextArea}
                  placeholder="可修改 仅可提交一次哦"
                  rows={4}
                  style={{ width: 450 }}
                />,
              )}
            </FormItem>
          </Form>
        </Modal>
        {/* 修改物流信息或者修改收货地址 */}
        <Modal
          destroyOnClose
          title={orderVisible === 'express' ? '修改物流信息' : '快速发货'}
          visible={orderVisible === 'deliver' || orderVisible === 'express'}
          onOk={this.handleOkDeliver}
          width="450px"
          maskClosable={false}
          onCancel={this.handleCancel}
        >
          <Spin spinning={leaseLoading}>
            <Form>
              <FormItem>
                {form.getFieldDecorator('expressId', {
                  rules: [{ required: true, message: '请选择物流公司' }],
                })(
                  <Select style={{ width: '100%' }} placeholder="请选择物流公司" allowClear>
                    {deliverOptions.map(option => {
                      return (
                        <Option key={option.id} value={option.id}>
                          {option.name}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </FormItem>
              <FormItem>
                {form.getFieldDecorator('expressNo', {
                  rules: [{ required: true, message: '请输入物流单号' }],
                })(<Input allowClear placeholder="请输入物流单号" />)}
              </FormItem>
            </Form>
          </Spin>
        </Modal>
        {/* 修改收货信息 */}
        <Modal
          title="修改收货信息"
          destroyOnClose={true}
          visible={orderVisible === 'address'}
          onOk={this.handleOkaddress}
          onCancel={this.handleCancel}
        >
          <Form>
            <Form.Item label="所在城市" {...formItemLayout}>
              {getFieldDecorator('city', {
                rules: [
                  {
                    required: true,
                    message: '请输入备注',
                  },
                ],
                initialValue: [
                  orderAddressDto &&
                  orderAddressDto.province &&
                  orderAddressDto.province.toString(),
                  orderAddressDto && orderAddressDto.city && orderAddressDto.city.toString(),
                  orderAddressDto && orderAddressDto.area && orderAddressDto.area.toString(),
                ],
              })(
                <Cascader
                  options={optionsdata}
                  fieldNames={{ label: 'name', value: 'value', children: 'subList' }}
                />,
              )}
            </Form.Item>
            <Form.Item label="收货人姓名" {...formItemLayout}>
              {getFieldDecorator('realName', {
                rules: [{ required: true, message: '请输入姓名' }],
                initialValue: realName,
              })(<Input placeholder="请输入姓名" />)}
            </Form.Item>
            <Form.Item label="收货人手机号" {...formItemLayout}>
              {getFieldDecorator('telePhone', {
                rules: [{ required: true, message: '请输入手机号' }],
                initialValue: tele,
              })(<Input placeholder="请输入手机号" />)}
            </Form.Item>
            <Form.Item label="详细地址" {...formItemLayout}>
              {getFieldDecorator('address', {
                rules: [{ required: true, message: '请输入地址' }],
                initialValue: address,
              })(<TextArea placeholder="请输入地址" />)}
            </Form.Item>
          </Form>
        </Modal>
        {/* 拉黑弹框 */}
        <Modal
          title="请确认拉黑用户时间"
          visible={this.state.isOpenBtn}
          onOk={this.handleOkisOpenBtn}
          onCancel={this.handleCancelBtn}
        >
          <Select
            placeholder="请选择拉黑时间"
            onChange={e => this.setState({ seletctId: e })}
            style={{ width: 200 }}
          >
            <Option value={1}>将用户移至黑名单1个月</Option>
            <Option value={3}>将用户移至黑名单3个月</Option>
            <Option value={12}>将用户移至黑名单12个月</Option>
          </Select>
        </Modal>
        <Drawer
          placement="right"
          closable={false}
          width="50%"
          onClose={() =>
            this.setState({
              isrisk: false,
              isRiskStatus: false,
              modelResultList: {},
              runingList: [],
              unRuning: {},
              runingYyzsList: [],
              dialogueList: [],
            })
          }
          visible={this.state.isrisk}
          bodyStyle={{ padding: '0' }}
        >
          <div className={styles.c_drawer_main}>
            {isRiskStatus == true ? (
              !!dialogueList && !!dialogueList.length ? (
                dialogueList.map((item, index) => (
                  <>
                    <Divider key={index} style={{ fontSize: '20px', marginTop: 20 }}>
                      {item.gmtOccur}
                    </Divider>
                    {index == 0 ? (
                      <>
                        <button
                          onClick={this.intelligentCalls}
                          style={{
                            width: '80px',
                            height: '30px',
                            lineHeight: '30px',
                            background: '#d3d7d4',
                            border: 'none',
                            color: '#ffff',
                            borderRadius: '4px',
                          }}
                        >
                          再次外呼
                        </button>
                      </>
                    ) : (
                      ''
                    )}
                    <Descriptions column={2}>
                      <Descriptions.Item label="通话结果">
                        {item && item.errorCode ? item.errorCode : '暂无交互'}
                      </Descriptions.Item>
                      <Descriptions.Item label="通话状态">
                        {item && item.status ? item.status : '暂无交互'}
                      </Descriptions.Item>
                    </Descriptions>
                    <div
                      style={{
                        display: 'flex',
                        textAlign: 'middle',
                        margin: '20px 0',
                        fontSize: '18px',
                      }}
                    >
                      <div
                        style={{
                          height: '22px',
                          width: '6px',
                          backgroundColor: '#449ae7',
                          marginRight: '10px',
                        }}
                      ></div>
                      <div> 智能外呼模型分析</div>
                    </div>
                    <Descriptions column={3}>
                      {!!item.modelResultArr && !!item.modelResultArr.length ? (
                        item.modelResultArr.map((items, index) => (
                          <Descriptions.Item key={index}>{items}</Descriptions.Item>
                        ))
                      ) : (
                        <Descriptions.Item>暂无信息</Descriptions.Item>
                      )}
                    </Descriptions>
                    <List
                      itemLayout="horizontal"
                      dataSource={item && item.dialogue ? item.dialogue : []}
                      renderItem={items => (
                        <List.Item>
                          <List.Item.Meta
                            avatar={<Badge status="processing"></Badge>}
                            title={<a>{items.question}</a>}
                            description={items.answer ? items.answer : '客户无回答'}
                          />
                        </List.Item>
                      )}
                    />
                  </>
                ))
              ) : (
                '暂无信息'
              )
            ) : (
              <>
                <Divider style={{ fontSize: '20px', marginTop: 20 }}>端内交互风控</Divider>
                <Descriptions column={2}>
                  <Descriptions.Item label="通话结果">
                    {runingYyzs && runingYyzs.errorCode ? runingYyzs.errorCode : '暂无'}
                  </Descriptions.Item>
                  <Descriptions.Item label="通话状态">
                    {runingYyzs && runingYyzs.status ? runingYyzs.status : '暂无'}
                  </Descriptions.Item>
                </Descriptions>
                <div
                  style={{
                    display: 'flex',
                    textAlign: 'middle',
                    margin: '20px 0',
                    fontSize: '18px',
                  }}
                >
                  <div
                    style={{
                      height: '22px',
                      width: '6px',
                      backgroundColor: '#449ae7',
                      marginRight: '10px',
                    }}
                  ></div>
                  <div> 端内交互模型分析</div>
                </div>
                <Descriptions column={3}>
                  {!!runingYyzs &&
                    !!runingYyzs.modelResultArr &&
                    !!runingYyzs.modelResultArr.length ? (
                    runingYyzs.modelResultArr.map((item, index) => (
                      <Descriptions.Item key={index}>{item}</Descriptions.Item>
                    ))
                  ) : (
                    <Descriptions.Item>暂无信息</Descriptions.Item>
                  )}
                </Descriptions>
                <div
                  style={{
                    display: 'flex',
                    textAlign: 'middle',
                    margin: '20px 0',
                    fontSize: '18px',
                  }}
                >
                  <div
                    style={{
                      height: '22px',
                      width: '6px',
                      backgroundColor: '#449ae7',
                      marginRight: '10px',
                    }}
                  ></div>
                  <div> 端内交互风控</div>
                </div>
                <List
                  itemLayout="horizontal"
                  dataSource={this.state.runingList}
                  renderItem={item => (
                    <List.Item>
                      <List.Item.Meta
                        avatar={<Badge status="processing"></Badge>}
                        title={
                          <a>
                            {item.questionDto && item.questionDto.text
                              ? item.questionDto.text
                              : item.questionDto.message}
                          </a>
                        }
                        description={
                          item.answerDto && item.answerDto.curAnswerType == 'image' ? (
                            <a onClick={() => this.toWindowOpen(item.answerDto.curAnswerInfo)}>
                              {item.answerDto && item.answerDto.curAnswerInfo
                                ? item.answerDto.curAnswerInfo
                                : '客户无回答'}
                            </a>
                          ) : (
                            <>
                              {item.answerDto && item.answerDto.curAnswerInfo
                                ? item.answerDto.curAnswerInfo
                                : '客户无回答'}
                            </>
                          )
                        }
                      />
                    </List.Item>
                  )}
                />
                <List
                  itemLayout="horizontal"
                  dataSource={this.state.runingYyzsList}
                  renderItem={item => (
                    <List.Item>
                      <List.Item.Meta
                        avatar={<Badge status="processing"></Badge>}
                        title={<a>{item.question ? item.question : ''}</a>}
                        description={item.answer ? item.answer : '客户无回答'}
                      />
                    </List.Item>
                  )}
                />
              </>
            )}
          </div>
        </Drawer>
        <Modal
          width="60%"
          visible={this.state.isRiskgc}
          onOk={() =>
            this.setState({
              isRiskgc: false,
              identification: [],
            })
          }
          onCancel={() =>
            this.setState({
              isRiskgc: false,
              identification: [],
            })
          }
        >
          <Table
            columns={this.columnsZixun}
            dataSource={identification}
            pagination={false}
            scroll={{ y: 500 }}
          />
          <div style={{ color: '#5476F0' }}>说明： </div>
          <div style={{ color: '#5476F0' }}>
            1. 安全等级为1~3时 建议通过 直接发货；4建议审核；5~6不建议发货
          </div>
          <div style={{ color: '#5476F0' }}> 2.T0表示当天查</div>
          <div style={{ color: '#5476F0' }}>
            3.T1表示第二天9点后查的数据,下单后查询越早结果越准,第二天9:00后查询的结果只能判断下单到第二天这个时间段的异变。
          </div>
          <div style={{ color: '#5476F0' }}>
            4.查询条件生成规则：下单后24小时内，第二天9点前查询条件为T0。下单第二天9点后查询条件为T1
          </div>
          <div style={{ color: '#5476F0' }}>
            5.触发新记录规则：订单状态（待支付、交易关闭）以及未预授权均不能触发查询。相同查询条件距上一次查询时间超3小时触发新记录。下单后第三天不再触发新记录。
          </div>
          <div style={{ color: '#5476F0' }}>
            6.补充说明：没有T0查询记录，触发T1查询结果大概率是等级0。无实意！
          </div>
        </Modal>
      </PageHeaderWrapper>
    );
  }
}
