import { Component } from 'react';
import { Tabs, Descriptions, Divider, Table, Popover } from 'antd';
import styles from './index.less';
const { TabPane } = Tabs;

export default class RiskReportNewDrawer extends Component {
  state = {};
  render() {
    const columns = [
      { title: '序号', dataIndex: 'key' },
      { title: '审结日期', dataIndex: 'sortTimeString' },
      { title: '类型', dataIndex: 'dataType' },
      {
        title: '摘要说明',
        dataIndex: 'title',
        render: (text) => {
          return (
            <Popover content={<div style={{ maxWidth: 400, maxHeight: 300, overflowY: 'scroll' }}>{text}</div>}>
              {text.substring(0, 8)}
            </Popover >
          )
        }
      },
      { title: '匹配度', dataIndex: 'matchRatio' },
      {
        title: '具体情形',
        dataIndex: 'jtqx',
        render: (text) => {
          return (
            <Popover content={<div style={{ maxWidth: 600, maxHeight: 600, overflowY: 'scroll' }} dangerouslySetInnerHTML={{ __html: text }} />}>
              具体情形
            </Popover >
          )
        }
      },
    ];
    const { redata } = this.props;
    const customData = redata.fa_hai_risk_list && redata.fa_hai_risk_list.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    return (
      <div className={styles.c_drawer_main}>
        <Tabs defaultActiveKey="1">
          <TabPane tab="风险报告" key="1">
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>基本信息</Divider>
            <Descriptions column={2} bordered>
              <Descriptions.Item label="姓名">
                {redata.basicInfo && redata.basicInfo.userName}
              </Descriptions.Item>
              <Descriptions.Item label="身份证号">
                {redata.basicInfo && redata.basicInfo.idCard}
              </Descriptions.Item>
              <Descriptions.Item label="手机号">
                {redata.basicInfo && redata.basicInfo.phone}
              </Descriptions.Item>
              <Descriptions.Item label="年龄">
                {redata.basicInfo && redata.basicInfo.age}
              </Descriptions.Item>
              <Descriptions.Item label="户籍">
                {redata.basicInfo && redata.basicInfo.residence || '-'}
              </Descriptions.Item>
              {/* <Descriptions.Item label="号码归属地">
                {redata.basicInfo && redata.basicInfo.phone_address}
              </Descriptions.Item> */}
            </Descriptions>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>身份信息核验</Divider>
            <Descriptions column={5} layout="vertical" bordered>
              <Descriptions.Item label="实名核验">
                {redata.wisely_operator && redata.wisely_operator.real_name_verify}
              </Descriptions.Item>
              <Descriptions.Item label="运营商核验">
                {redata.wisely_operator && redata.wisely_operator.operator_verify}
              </Descriptions.Item>
              <Descriptions.Item label="运营商在网状态">
                {redata.wisely_operator && redata.wisely_operator.operator_online_state}
              </Descriptions.Item>
              <Descriptions.Item label="运营商在网时长">
                {redata.wisely_operator && redata.wisely_operator.operator_online_time}
              </Descriptions.Item>
            </Descriptions>
            <div>
              说明：运营商在⽹时⻓ 1:[0,3） 2:[3,6） 3:[6,12） 4:[12,24） 5:[24,+)
              0：查⽆此号或已注销 -1：不⽀持该运营商 999: ⼿机状态异常（注:1、销号6⽉
              以上；2、携号转⽹；3、未放出去的 号码）；⾮本⽹⼿机号码
            </div>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>机构查询概况</Divider>
            <Descriptions layout="vertical" column={2} bordered>
              <Descriptions.Item label="机构总查询次数">
                {redata.loan_org_query_overview && redata.loan_org_query_overview.loan_org_query_num}
              </Descriptions.Item>
              <Descriptions.Item label="最近一次查询时间">
                {redata.loan_org_query_overview && redata.loan_org_query_overview.loan_org_query_last_time}
              </Descriptions.Item>
            </Descriptions>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>机构查询历史</Divider>
            <tbody
              style={{
                border: '1px solid #eee',
                width: '99%',
                height: '100px',
                textAlign: 'center',
              }}
            >
              <tr>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >时间周期</td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近1个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近3个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近6个月
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  机构查询总数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loan_org_query_his && redata.loan_org_query_his.loan_org_query_his_last_1m || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loan_org_query_his && redata.loan_org_query_his.loan_org_query_his_last_3m || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loan_org_query_his && redata.loan_org_query_his.loan_org_query_his_last_6m || '-'}
                </td>
              </tr>
            </tbody>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>历史借贷行为</Divider>
            <div style={{ display: 'flex', textAlign: 'middle', margin: '20px 0' }}>
              <div
                style={{
                  height: '22px',
                  width: '6px',
                  backgroundColor: '#449ae7',
                  marginRight: '10px',
                }}
              ></div>
              <div> 近24个月申请情况</div>
            </div>
            <Descriptions column={3} layout="vertical" bordered>
              <Descriptions.Item label="申请机构总数">
                {redata.loans_behavior_his_last_24m && redata.loans_behavior_his_last_24m.loan_apply_org_num}
              </Descriptions.Item>
              <Descriptions.Item label="申请消金类机构总数">
                {redata.loans_behavior_his_last_24m && redata.loans_behavior_his_last_24m.loan_apply_finance_org_num}
              </Descriptions.Item>
              <Descriptions.Item label="申请网贷类机构总数">
                {redata.loans_behavior_his_last_24m && redata.loans_behavior_his_last_24m.loan_apply_credit_org_num}
              </Descriptions.Item>
            </Descriptions>
            <div style={{ display: 'flex', textAlign: 'middle', margin: '20px 0' }}>
              <div
                style={{
                  height: '22px',
                  width: '6px',
                  backgroundColor: '#449ae7',
                  marginRight: '10px',
                }}
              ></div>
              <div> 近24个月放款概况</div>
            </div>
            <div>
              <Descriptions column={3} layout="vertical" bordered>
                <Descriptions.Item label="最近一次放款日期">
                  {redata.loans_overview_last_24m && redata.loans_overview_last_24m.disbursement_last_day}
                </Descriptions.Item>
                <Descriptions.Item label="距离最近一次放款日期已有（天）">
                  {redata.loans_overview_last_24m && redata.loans_overview_last_24m.disbursement_last_date}
                </Descriptions.Item>
              </Descriptions>
            </div>
            <div style={{ display: 'flex', textAlign: 'middle', margin: '20px 0' }}>
              <div
                style={{
                  height: '22px',
                  width: '6px',
                  backgroundColor: '#449ae7',
                  marginRight: '10px',
                }}
              ></div>
              <div> 近24个月放款情况细化</div>
            </div>
            <tbody
              style={{
                border: '1px solid #eee',
                width: '99%',
                height: '150px',
                textAlign: 'center',
              }}
            >
              <tr>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                ></td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近12个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近24个月
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  消费金融类放款机构数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.disbursements_last_24m && redata.disbursements_last_24m.lenders_org_num_12m && redata.disbursements_last_24m.lenders_org_num_12m.cons_finance_lenders_org_num_12m || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.disbursements_last_24m && redata.disbursements_last_24m.lenders_org_num_24m && redata.disbursements_last_24m.lenders_org_num_24m.cons_finance_lenders_org_num_24m || '-'}
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  网络贷款类放款机构数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.disbursements_last_24m && redata.disbursements_last_24m.lenders_org_num_12m && redata.disbursements_last_24m.lenders_org_num_12m.online_loans_lenders_org_num_12m || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.disbursements_last_24m && redata.disbursements_last_24m.lenders_org_num_24m && redata.disbursements_last_24m.lenders_org_num_24m.online_loans_lenders_org_num_24m || '-'}
                </td>
              </tr>
            </tbody>
            <div style={{ display: 'flex', textAlign: 'middle', margin: '20px 0' }}>
              <div
                style={{
                  height: '22px',
                  width: '6px',
                  backgroundColor: '#449ae7',
                  marginRight: '10px',
                }}
              ></div>
              <div> 贷款详情</div>
            </div>
            <tbody
              style={{
                border: '1px solid #eee',
                width: '99%',
                height: '200px',
                textAlign: 'center',
              }}
            >
              <tr>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                ></td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近1个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近3个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近6个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近12个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近24个月
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  贷款笔数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_1m && redata.loans_details_last_24m.loans_last_1m.loans_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_3m && redata.loans_details_last_24m.loans_last_3m.loans_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_6m && redata.loans_details_last_24m.loans_last_6m.loans_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_12m && redata.loans_details_last_24m.loans_last_12m.loans_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_24m && redata.loans_details_last_24m.loans_last_24m.loans_num || '-'}
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  贷款总金额
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_1m && redata.loans_details_last_24m.loans_last_1m.loans_total_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_3m && redata.loans_details_last_24m.loans_last_3m.loans_total_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_6m && redata.loans_details_last_24m.loans_last_6m.loans_total_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_12m && redata.loans_details_last_24m.loans_last_12m.loans_total_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_24m && redata.loans_details_last_24m.loans_last_24m.loans_total_amount || '-'}
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  贷款机构数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_1m && redata.loans_details_last_24m.loans_last_1m.loans_org_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_3m && redata.loans_details_last_24m.loans_last_3m.loans_org_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_6m && redata.loans_details_last_24m.loans_last_6m.loans_org_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_12m && redata.loans_details_last_24m.loans_last_12m.loans_org_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.loans_details_last_24m && redata.loans_details_last_24m.loans_last_24m && redata.loans_details_last_24m.loans_last_24m.loans_org_num || '-'}
                </td>
              </tr>
            </tbody>
            <div style={{ display: 'flex', textAlign: 'middle', margin: '20px 0' }}>
              <div
                style={{
                  height: '22px',
                  width: '6px',
                  backgroundColor: '#449ae7',
                  marginRight: '10px',
                }}
              ></div>
              <div> 近24个月履约详情</div>
            </div>
            <tbody
              style={{
                border: '1px solid #eee',
                width: '99%',
                height: '200px',
                textAlign: 'center',
              }}
            >
              <tr>
                <td
                  style={{ width: '600px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                ></td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近1个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近3个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近6个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近12个月
                </td>
                <td
                  style={{
                    width: '400px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  近24个月
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '600px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  履约成功次数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_1m && redata.performance_details_last_24m.honour_suc_num_last_1m.honour_suc_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_3m && redata.performance_details_last_24m.honour_suc_num_last_3m.honour_suc_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_6m && redata.performance_details_last_24m.honour_suc_num_last_6m.honour_suc_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_12m && redata.performance_details_last_24m.honour_suc_num_last_12m.honour_suc_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m.honour_suc_num || '-'}
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '600px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  履约失败次数
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_1m && redata.performance_details_last_24m.honour_suc_num_last_1m.honour_fail_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_3m && redata.performance_details_last_24m.honour_suc_num_last_3m.honour_fail_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_6m && redata.performance_details_last_24m.honour_suc_num_last_6m.honour_fail_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_12m && redata.performance_details_last_24m.honour_suc_num_last_12m.honour_fail_num || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m.honour_fail_num || '-'}
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    width: '600px',
                    verticalAlign: 'center',
                    border: '1px solid #eee',
                    fontWeight: 'bold',
                  }}
                  colSpan={2}
                >
                  履约成功金额
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_1m && redata.performance_details_last_24m.honour_suc_num_last_1m.honour_suc_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_3m && redata.performance_details_last_24m.honour_suc_num_last_3m.honour_suc_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_6m && redata.performance_details_last_24m.honour_suc_num_last_6m.honour_suc_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_12m && redata.performance_details_last_24m.honour_suc_num_last_12m.honour_suc_amount || '-'}
                </td>
                <td
                  style={{ width: '400px', verticalAlign: 'center', border: '1px solid #eee' }}
                  colSpan={2}
                >
                  {redata.performance_details_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m && redata.performance_details_last_24m.honour_suc_num_last_24m.honour_suc_amount || '-'}
                </td>
              </tr>
            </tbody>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>历史逾期行为</Divider>
            <Descriptions column={3} layout="vertical" bordered>
              <Descriptions.Item label="近6个月逾期总次数">
                {redata.overdue_behavior_his && redata.overdue_behavior_his.overdue_behavior_his_6m_num || '-'}
              </Descriptions.Item>
              <Descriptions.Item label="近6个月逾期机构数">
                {redata.overdue_behavior_his && redata.overdue_behavior_his.overdue_behavior_his_6m_org_num || '-'}
              </Descriptions.Item>
              <Descriptions.Item label="近6个月逾期总金额(元)">
                {redata.overdue_behavior_his && redata.overdue_behavior_his.overdue_behavior_his_6m_amount || '-'}
              </Descriptions.Item>
            </Descriptions>
            <Divider style={{ fontSize: '20px', marginTop: 50 }}>司法风险列表</Divider>
            <Table
              locale={{ emptyText: '暂无记录' }}
              bordered={true}
              columns={columns}
              dataSource={customData}
              pagination={false}
            />
          </TabPane>
        </Tabs>
        <div style={{ height: 60 }}></div>
      </div>
    );
  }
}
