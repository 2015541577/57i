import React, { Component } from 'react';
import styles from './index.less';
import { Descriptions, Table } from 'antd';

class Courtrisklist extends Component {
  render() {
    const { data = [] } = this.props;
    const columns = [
      { title: '案号', dataIndex: 'caseNo' },
      { title: '法院名称', dataIndex: 'court' },
      { title: '姓名', dataIndex: 'pname' },
      { title: '审结日期', dataIndex: 'sortTimeString' },
      { title: '类型', dataIndex: 'dataType' },
      { title: '摘要说明', dataIndex: 'body' },
      { title: '匹配度', dataIndex: 'matchRatio' },
    ];
    const customData = data.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    return (
      <div className={styles.tableHeader}>
        <Table
          locale={{ emptyText: '暂无记录' }}
          bordered={true}
          columns={columns}
          dataSource={customData}
          pagination={false}
        />
      </div>
    );
  }
}

export default Courtrisklist;
