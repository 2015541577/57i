import React, { Component } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'dva';
import {
  Card,
  Button,
  Form,
  Row,
  Col,
  Input,
  DatePicker,
  Select,
  Tooltip,
  Spin,
  Badge,
  Modal,
  List,
  message,
} from 'antd';
import MyPageTable from '@/components/MyPageTable';
import { onTableData } from '@/utils/utils.js';
import CopyToClipboard from '@/components/CopyToClipboard';
import moment from 'moment';
import styles from './index.less';
import axios from 'axios';
import { routerRedux } from 'dva/router';

import { getTimeDistance } from '@/utils/utils';

const { RangePicker } = DatePicker;
const { Option } = Select;
import { getToken } from '@/utils/localStorage';
const advisesAll = [
  {
    name: '全部',
    value: '0',
  },
  {
    name: '待确定风控',
    value: '6',
  },
  {
    name: '老客户，建议免审',
    value: '1',
  },
  {
    name: '[极低风险],该类用户守约率97%以上，建议用户支付首期租金发货',
    value: '7',
  },
  {
    name: '[优]该类用户守约率85%以上，建议用户支付两期租金发货',
    value: '2',
  },
  {
    name: '[良]建议适当预收客户租金，正常电审，谨慎发货',
    value: '3',
  },
  {
    name:
      '[一般]该类用户资质一般，建议电审如 1.通过核实用户的工作情况和累计贷款金额等，判断偿还能力;2.核实常驻地址;3.增加紧急联系人。',
    value: '4',
  },
  {
    name: '[差]风控不通过，风险较高。建议预收到设备价值或者拒绝。',
    value: '5',
  },
];
@connect(({ order, loading }) => ({
  ...order,
  loading: loading.effects['order/queryOpeOverDueOrdersByCondition'],
}))
@Form.create()
export default class BeOverdue extends Component {
  state = {
    current: 1,
    datas: {},
    yunTime: getTimeDistance('month'),
    RemarkVisible: false,
    remarkData: [],
  };

  componentDidMount() {
    this.props.dispatch({
      type: 'order/PlateformChannel',
    });
    this.onList(1, 10);
  }

  onList = (pageNumber, pageSize, data = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryOpeOverDueOrdersByCondition',
      payload: {
        pageSize,
        pageNumber,
        ...data,
      },
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
      if (values.createDate && values.createDate.length < 1) {
        values.createTimeStart = '';
        values.createTimeEnd = '';
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
            this.setState({
              current: 1,
            });
          },
        );
      } else if (values.createDate) {
        values.createTimeStart = moment(values.createDate[0]).format('YYYY-MM-DD HH:mm:ss');
        values.createTimeEnd = moment(values.createDate[1]).format('YYYY-MM-DD HH:mm:ss');
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
            this.setState({
              current: 1,
            });
          },
        );
      } else {
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
            this.setState({
              current: 1,
            });
          },
        );
      }
    });
  };

  // table 页数
  onPage = e => {
    this.setState(
      {
        current: e.current,
      },
      () => {
        this.onList(e.current, 10, this.state.datas);
      },
    );
  };

  // 重置
  handleReset = e => {
    this.props.form.resetFields();
    // this.handleSubmit(e);
  };

  confirm = () => { };
  onexports = () => {
    const { yunTime } = this.state;
    this.props.form.validateFields((err, values) => {
      if ((values.createDate && values.createDate.length < 1) || values.createDate == undefined) {
        message.error('请选择导出日期区间在31天内');
        return false;
      } else {
        this.props.dispatch({
          type: 'order/exportOpeOverDueUserOrders',
          payload: {
            createTimeEnd: moment(this.props.form.getFieldValue('createDate')[1]).format(
              'YYYY-MM-DD HH:mm:ss',
            ),
            createTimeStart: moment(this.props.form.getFieldValue('createDate')[0]).format(
              'YYYY-MM-DD HH:mm:ss',
            ),
          },
        });
      }
    });
  };
  onexport = () => {
    const { yunTime } = this.state;
    if (this.props.form.getFieldValue('createDate')) {
      console.log(this.props.form.getFieldValue('createDate').length, '9999999999999999');
      //   if(this.props.form.getFieldValue('createDate').length===0)
      this.props.dispatch({
        type: 'order/exportOpeOverDueUserOrders',
        payload: {
          createTimeEnd: moment(this.props.form.getFieldValue('createDate')[1]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
          createTimeStart: moment(this.props.form.getFieldValue('createDate')[0]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
        },
        callback: res => {
        },
      });
    } else {
    }
  };
  remarkState = e => {
    axios({
      url: `/hzsx/business/order/queryActionAuditListByOrderId?orderId=${e.orderId}`,
      method: 'get',
      headers: {
        token: getToken(),
      },
    }).then(res => {
      console.log(res.data.data, '数据呢');
      this.setState({
        RemarkVisible: true,
        remarkData: res.data.data,
      });
    });
  };
  //   跳转到订单列表中的详情页面的账单信息
  homePageDetail = e => {
    // 现改为跳转到订单列表页面
    window.open(`#/Order/HomePage?id=${e.orderId}`);
  };
  //   跳转到订单列表
  homePage = e => {
    window.open(`#/Order/HomePage?id=${e.orderId}`);
  };
  render() {
    const { conditionList, conditionTotal, loading } = this.props;
    const paginationProps = {
      current: this.state.current,
      pageSize: 10,
      total: conditionTotal,
      showTotal: total => (
        <span style={{ fontSize: '14px' }}>
          <span>共{Math.ceil(total / 10)}页</span>&emsp;
          <span>共{total}条</span>
        </span>
      ),
    };

    const columns = [
      {
        title: '商家信息',
        align: 'center',
        width: 160,
        render: e => {
          return (
            <div className={styles.sMessages}>
              <p>
                <span style={{ color: '#E60012' }}>下单时间:{e.placeOrderTime}</span>
                <a style={{ color: '#1890FF' }} onClick={() => this.homePage(e)}>
                  订单号 :{e.orderId}
                </a>{' '}
              </p>
              <div>商铺：{e.shopName}</div>
              <div>渠道：{e.channelName}</div>
              {e.riskRemark == '' ? (
                ''
              ) : (
                <div style={{ color: 'red' }} className={styles.c_riskRemark}>
                  {e.riskRemark}
                </div>
              )}
            </div>
          );
        },
      },
      {
        title: '商品信息',
        align: 'left',
        width: 180,

        render: e => {
          return (
            <div style={{ padding: '20px 0 20px 0' }}>
              <div>{e.productName}</div>
              <div>{e.spec}</div>
            </div>
          );
        },
      },
      {
        title: '租期',
        align: 'center',
        width: 150,
        render: e => {
          return (
            <div>
              <p>
                {e.rentStart}至{e.unrentTime}({e.totalPeriods})月
              </p>
            </div>
          );
        },
      },
      {
        title: '逾期天数',
        width: 120,
        align: 'center',
        render: e => {
          return (
            <div>
              <p style={{ color: '#FD574D' }}>逾期{e.overdueDays}天</p>
            </div>
          );
        },
      },
      {
        title: '价值',
        width: 180,
        align: 'left',
        render: e => {
          return (
            <div>
              {e.badDebtReserves <= 0 ? null : (
                <div
                  style={{
                    backgroundColor: '#FD574D',
                    borderRadius: '5px',
                    width: '150px',
                    color: '#ccc',
                  }}
                >
                  预计坏账金额￥{e.badDebtReserves}
                </div>
              )}
              <div>坏账金额￥{e.badDebt}</div>
              <div>原押金￥{e.totalDeposit}</div>
              <button
                style={{ backgroundColor: '#5CB85C', borderRadius: '5px', border: '0' }}
                onClick={() => this.homePageDetail(e)}
              >
                已付：￥{e.payedRentAmount}/￥{e.totalRentAmount}
              </button>
            </div>
          );
        },
      },
      {
        title: '用户信息',
        align: 'left',
        width: 160,
        render: e => {
          return (
            <div>
              <div>收件人：{e.realName}</div>
              <div>手机号码：{e.telephone}</div>
              <div>地址：{e.address}</div>
              {/* <p style={{color:'red'}}>{e.telephone}</p> */}
            </div>
          );
        },
        // ellipsis: true,
      },
      // createTime

      {
        title: '备注',
        width: 120,
        align: 'center',
        key: 'action',
        render: e => {
          return (
            <div>
              <p>{e.lastActionName}</p>
              {/* <p>-买家余额不足</p> */}
              <button style={{ color: '#FD574D' }} onClick={() => this.remarkState(e)}>
                {' '}
                <Badge status="error" />
                {e.actionCount}次记录
              </button>
            </div>
          );
        },
      },
    ];

    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };

    return (
      <PageHeaderWrapper title={false}>
        <Card bordered={false} style={{ marginBottom: 20 }}>
          <Form
            {...{
              labelCol: { xs: { span: 24 }, sm: { span: 7 } },
              wrapperCol: { xs: { span: 24 }, sm: { span: 17 } },
            }}
            onSubmit={e => {
              e && e.preventDefault();
              this.handleSubmit();
            }}
          >
            <Row style={{ display: 'flex', flexWrap: 'wrap' }}>
              <Col span={6}>
                <Form.Item label="商品名称">
                  {getFieldDecorator('productName')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入商品名称" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="店铺名称">
                  {getFieldDecorator('shopName')(
                    <Input style={{ minWidth: 200 }} placeholder="请输入店铺名称" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人姓名">
                  {getFieldDecorator('userName')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入下单人姓名" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人手机号">
                  {getFieldDecorator('telephone')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入下单人手机号" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单编号">
                  {getFieldDecorator('orderId')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入订单编号" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="创建时间">
                  {getFieldDecorator('createDate')(
                    <RangePicker allowClear />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="风控建议">
                  {getFieldDecorator('riskType')(
                    <Select placeholder="请选择风控建议" style={{ minWidth: 200 }} allowClear>
                      {advisesAll.map((item, val) => {
                        return (
                          <Option value={item.value} key={val}>
                            {item.name}
                          </Option>
                        );
                      })}
                    </Select>
                  )}
                </Form.Item>
              </Col>
              <div style={{ flex: 1, textAlign: 'right', marginBottom: 20 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button htmlType="button" onClick={this.handleReset}>
                  重置
                </Button>
                {localStorage.getItem(`SaasDisplay`) == 1 && (
                  <Button onClick={this.onexports}>导出</Button>
                )}
              </div>
            </Row>
          </Form>
        </Card>
        <Card>
          <Spin spinning={loading}>
            <MyPageTable
              onPage={this.onPage}
              paginationProps={paginationProps}
              dataSource={onTableData(conditionList)}
              columns={columns}
            />
          </Spin>
        </Card>
        <Modal
          title="备注"
          visible={this.state.RemarkVisible}
          onOk={() => {
            this.setState({ RemarkVisible: false });
          }}
          // confirmLoading={this.setState({RemarkVisible:true})}
          onCancel={() => {
            this.setState({ RemarkVisible: false });
          }}
        >
          <List
            itemLayout="horizontal"
            dataSource={this.state.remarkData}
            renderItem={item => (
              <List.Item>
                <List.Item.Meta
                  avatar={<Badge status="processing"></Badge>}
                  title={
                    <a>
                      {item.actionName}&nbsp;:&nbsp;{item.createTime}
                    </a>
                  }
                />
              </List.Item>
            )}
          />
          ,
        </Modal>
      </PageHeaderWrapper>
    );
  }
}
