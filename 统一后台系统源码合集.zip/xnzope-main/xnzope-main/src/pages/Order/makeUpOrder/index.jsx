import React, { Component } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card, Spin, Form, Row, Col, Button, Input, Popconfirm, Select, message, DatePicker } from 'antd';
import MyPageTable from '@/components/MyPageTable';
import { onTableData } from '@/utils/utils.js';
import { getToken } from '@/utils/localStorage';
import indexServices from '../../Configure/service';
import moment from 'moment';
import axios from 'axios';
const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
@Form.create()
class makeUpOrder extends Component {
  state = {
    makeUpOrderList: [],
    loading: false,
    pageNumber: 1,
    pageSize: 10,
    orderId: '',
    total: 0,
    current: 1,
    ChannelGroupList: [],
    tableData: [],
    statusChange: false,
    ChannelGroupId: '',
    datas: {},
  };
  columns = [
    {
      title: '订单编号',
      dataIndex: 'orderId',
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
    },
    {
      title: '原订单编号',
      // dataIndex:'originalOrderId',
      render: e => {
        return <a onClick={() => this.toOrderHome(e)}>{e.originalOrderId}</a>;
      },
    },
    {
      title: '订单类型',
      dataIndex: 'goodsName',
    },
    {
      title: '价格',
      dataIndex: 'servicePrice',
    },
    {
      title: '结算比例',
      dataIndex: 'settlementProportion',
    },
    {
      title: '备注',
      dataIndex: 'beizhu',
    },
    {
      title: '实付款',
      dataIndex: 'orderPaymentAmount',
    },
    {
      title: '支付时间',
      dataIndex: 'paymentTime',
    },
    {
      title: '订单状态',
      dataIndex: 'status',
      render: status => {
        return <div>{status == '01' ? '待支付' : status == '09' ? '已完成' : '交易关闭'}</div>;
      },
    },
    {
      title: '操作',
      render: e => (
        <>
          {e.status == '01' ? (
            <Popconfirm title="确定要取消吗？" onConfirm={() => this.onCancel(e)}>
              <a style={{ color: 'red' }}>取消订单</a>
            </Popconfirm>
          ) : (
            ''
          )}
        </>
      ),
    },
  ];
  componentDidMount() {
    const { orderId } = this.props.location.query;
    if (orderId) {
      //    this.setState({
      //   orderId:this.props.location.query.orderId,
      // },()=>{
      //    this.getMakeUpOrder(1,10,orderId)
      // })
      this.getMakeUpOrder(1, 10, { orderId: this.props.location.query.orderId });
    } else {
      this.getMakeUpOrder(this.state.current, 10, '');
    }
    this.ChannelGroup();
  }
  getMakeUpOrder = (pageNumber, pageSize, data = {}) => {
    this.setState({
      loading: true,
    });
    axios({
      url: '/hzsx/ope/order/queryOpeMakeOrderList',
      method: 'POST',
      headers: { token: getToken() },
      data: {
        pageNumber: pageNumber,
        pageSize,
        ...data,
      },
    }).then(res => {
      if (res.data.data == null) {
        message.error(res.data.errorMessage);
      } else {
        message.success('获取数据成功');
        this.setState({
          makeUpOrderList: res.data.data.records,
          total: res.data.data.total,
          current: res.data.data.current,
          loading: false,
        });
      }
    });
  };
  toOrderHome = e => {
    window.open(`#/order/HomePage?id=${e.originalOrderId}`);
  };

  // 获取sass列表
  ChannelGroup = () => {
    indexServices.getChannelGroup({}).then(res => {
      this.setState({
        ChannelGroupList: res,
      });
    });
  };
  onCancel = e => {
    axios({
      url: '/hzsx/ope/order/updateOpeMakeOrder',
      method: 'POST',
      headers: {
        token: getToken(),
      },
      data: {
        orderId: e.orderId,
      },
    }).then(res => {
      if (res.data.data == null) {
        message.error(res.data.errorMessage);
      } else {
        message.success('取消成功');
        // this.getMakeUpOrder(1,10,'')
        this.handleSubmit();
      }
    });
  };
  handleSubmit = e => {
    this.props.form.validateFields((err, value) => {
      if (err) return;
      if (value.createDate == undefined || (value.createDate && value.createDate.length < 1)) {
        value.paymentTimeStart = '';
        value.paymentTimeEnd = '';
      } else {
        value.paymentTimeStart = moment(value.createDate[0]).format('YYYY-MM-DD');
        value.paymentTimeEnd = moment(value.createDate[1]).format('YYYY-MM-DD');
      }
      this.setState(
        {
          ChannelGroupId: value.ChannelGroupId,
          datas: {
            pageNumber: this.state.pageNumber,
            pageSize: 10,
            orderId: value.orderId ? value.orderId : '',
            status: value.status,
            goodsName: value.goodsName ? value.goodsName : '',
            channelGroupId: value.ChannelGroupId ? value.ChannelGroupId : this.state.ChannelGroupId,
            paymentTimeStart: value.paymentTimeStart,
            paymentTimeEnd: value.paymentTimeEnd,
          },
        },
        () => {
          this.getMakeUpOrder(1, 10, this.state.datas);
          this.setState({
            current: 1,
            pageNumber: 1,
          });
        },
      );
    });
  };

  // 切换分页
  onPageChange = e => {
    this.setState(
      {
        pageNumber: e.current,
      },
      () => {
        this.handleSubmit();
        // this.getMakeUpOrder(e.current,10,{ChannelGroupId:this.state.ChannelGroupId})
      },
    );
  };

  // 重置
  handleReset = e => {
    this.props.form.resetFields();
    // this.handleSubmit(e);
  };
  // 获取订单类型的数据
  getService = () => {
    this.props.form.validateFields((err, value) => {
      axios({
        url: '/hzsx/repairOrder/selectRepairOrderList',
        method: 'GET',
        headers: { token: getToken() },
        params: {
          pageSize: 1000,
          pageNumber: 1,
          channelGroupCode: value.ChannelGroupId,
          name: '',
        },
      }).then(res => {
        if (res.data.data == null) {
          message.error('请先选中平台');
        } else {
          this.setState({
            tableData: res.data.data.records,
            // total:res.data.data.total,
            // current:res.data.data.current,
            loading: false,
          });
        }
      });
    });
  };
  render() {
    const { makeUpOrderList, loading, ChannelGroupList, tableData } = this.state;
    const { getFieldDecorator } = this.props.form;
    const paginationProps = {
      current: this.state.current,
      pageSize: 10,
      total: this.state.total,
      showTotal: total => (
        <span style={{ fontSize: '14px' }}>
          <span>共{Math.ceil(total / 10)}页</span>&emsp;
          <span>共{total}条</span>
        </span>
      ),
    };
    const arr1 = this.state.ChannelGroupList[0]?.code;
    return (
      <PageHeaderWrapper title={false}>
        <Card style={{ marginBottom: 20 }}>
          <Form
            {...{
              labelCol: { xs: { span: 24 }, sm: { span: 7 } },
              wrapperCol: { xs: { span: 24 }, sm: { span: 17 } },
            }}
            onSubmit={e => {
              e && e.preventDefault();
              this.handleSubmit();
            }}
          >
            <Row style={{ display: 'flex', flexWrap: 'wrap' }}>
              <Col span={6}>
                <Form.Item label="平台">
                  {ChannelGroupList && ChannelGroupList.length > 2 ? (
                    <>
                      {getFieldDecorator('ChannelGroupId', {
                        rules: [
                          {
                            required: true,
                            message: '平台不能为空',
                          },
                        ],
                      })(
                        <Select style={{ minWidth: 200 }} placeholder="请选择平台" allowClear>
                          {ChannelGroupList.map((item, sign) => {
                            return (
                              <Option key={item.code} value={item.code}>
                                {item.groupName}
                              </Option>
                            );
                          })}
                        </Select>,
                      )}
                    </>
                  ) : (
                    <>
                      {getFieldDecorator('ChannelGroupId', {
                        rules: [
                          {
                            required: true,
                            message: '平台不能为空',
                          },
                        ],
                        initialValue: arr1 || [],
                      })(
                        <Select style={{ minWidth: 200 }} placeholder="请选择平台" allowClear>
                          {ChannelGroupList.map((item, sign) => {
                            return (
                              <Option key={item.code} value={item.code}>
                                {item.groupName}
                              </Option>
                            );
                          })}
                        </Select>,
                      )}
                    </>
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单编号">
                  {getFieldDecorator('orderId')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入订单号" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="支付时间">
                  {getFieldDecorator('createDate')(
                    <RangePicker style={{ minWidth: 200 }} placeholder="时间范围输入" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单状态">
                  {getFieldDecorator('status')(
                    <Select placeholder="订单状态" allowClear style={{ minWidth: 200 }}>
                      <Option value="">全部</Option>
                      <Option value="10">交易关闭</Option>
                      <Option value="09">已完成</Option>
                      <Option value="01">待支付</Option>
                    </Select>
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单类型" onClick={this.getService}>
                  {getFieldDecorator('goodsName')(
                    <Select placeholder="请先选中平台" allowClear style={{ minWidth: 200 }}>
                      {tableData.map((item, sign) => {
                        return (
                          <Option key={item.id} value={item.name}>
                            {item.name}
                          </Option>
                        );
                      })}
                    </Select>
                  )}
                </Form.Item>
              </Col>
              <div style={{ flex: 1, textAlign: 'right', marginBottom: 20 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button htmlType="button" onClick={this.handleReset}>
                  重置
                </Button>
              </div>
            </Row>
          </Form>
        </Card>
        <Card>
          <Spin spinning={loading}>
            <MyPageTable
              columns={this.columns}
              onPage={this.onPageChange}
              paginationProps={paginationProps}
              dataSource={onTableData(makeUpOrderList)}
            />
          </Spin>
        </Card>
      </PageHeaderWrapper>
    );
  }
}

export default makeUpOrder;
