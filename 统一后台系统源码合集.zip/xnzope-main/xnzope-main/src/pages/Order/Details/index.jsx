import React, { Component, Fragment } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'dva';
import {
  Card,
  Button,
  Form,
  Input,
  Modal,
  Descriptions,
  Steps,
  Divider,
  Drawer,
  Timeline,
  Spin,
  Cascader,
  message,
  Tabs,
  Select,
  Radio,
  InputNumber,
  Table,
  Popconfirm,
} from 'antd';
import MyPageTable from '@/components/MyPageTable';
import AntTable from '@/components/AntTable';
import { onTableData, getParam } from '@/utils/utils.js';
import OrderService from '@/services/order';
import axios from 'axios';
import CustomCard from '@/components/CustomCard';
import {
  AuditReason,
  AuditStatus,
  confirmSettlementStatus,
  confirmSettlementType,
  orderStatusMap,
} from '@/utils/enum';
import { router } from 'umi';
import CreditDetail from './creditDetail';
import CreditDetailOld from './creditDetailOld';
import CreditDetailThree from './creditDetailThree';
import FourItemapply from './PublicCard/FourItemapply';
import FiveItem from './PublicCard/FiveItem';
import FourItem from './PublicCard/FourItem';
import FiveItemrepay from './PublicCard/FiveItemrepay';
import ThreeItem from './PublicCard/ThreeItem';
import Historyoverdue from './Historyoverdue';
import CourtriskList from './CourtriskList';
import { apply, optionsdata } from './data';
// import { getParam } from '@/utils/utils';
import styles from './index.less';
import { reloadAuthorized } from '@/utils/Authorized';
function getToken() {
  const token = localStorage.getItem('tokens');
  return token;
}

const { TextArea } = Input;
const FormItem = Form.Item;
const { Option } = Select;
const { Step } = Steps;
const { TabPane } = Tabs;

const StepsData = {
  '01': 0,
  '02': 0,
  '03': 1,
  '04': 1,
  '05': 2,
  '06': 3,
  '07': 4,
  '08': 4,
  '09': 5,
  '10': 5,
};
const columnsByStagesStute = {
  '1': '待支付',
  '2': '已支付',
  '3': '逾期已支付',
  '4': '逾期待支付',
  '5': '已取消',
  '6': '已结算',
  '7': '已退款,可用',
};
const collstus = {
  '01': '承诺还款',
  '02': '申请延期还款',
  '03': '拒绝还款',
  '04': '电话无人接听',
  '05': '电话拒接',
  '06': '电话关机',
  '07': '电话停机',
  '08': '客户失联',
};
const BusinessCollection = [
  {
    title: '记录人',
    dataIndex: 'userName',
  },
  {
    title: '记录时间',
    dataIndex: 'createTime',
  },
  {
    title: '结果',
    dataIndex: 'result',
    render: result => collstus[result],
  },
  {
    title: '小记',
    dataIndex: 'notes',
  },
];
const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 6 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 16 },
  },
};
// 平台备注
const columns = [
  {
    title: '备注人姓名',
    dataIndex: 'userName',
  },
  {
    title: '备注时间',
    dataIndex: 'createTime',
  },
  {
    title: '备注内容',
    dataIndex: 'remark',
  },
];
// 商家备注
const columnsBusiness = [
  {
    title: '备注人姓名',
    dataIndex: 'userName',
  },
  {
    title: '备注时间',
    dataIndex: 'createTime',
  },
  {
    title: '备注内容',
    dataIndex: 'remark',
  },
];
// 增值服务
const columnsAddService = [
  {
    title: '增值服务ID',
    dataIndex: 'shopAdditionalServicesId',
  },
  {
    title: '增值服务名称',
    dataIndex: 'shopAdditionalServicesName',
  },
  {
    title: '增值服务价格',
    dataIndex: 'price',
  },
];
// 商品信息
const columnsInformation = [
  {
    title: '商品图片',
    dataIndex: 'imageUrl',
    render: imageUrl => {
      return (
        <img
          src={imageUrl}
          style={{
            width: 116,
            height: 62,
          }}
        />
      );
    },
  },
  {
    title: '商品名称',
    dataIndex: 'productName',
  },
  {
    title: '商品编号',
    dataIndex: 'productId',
    render: (text, record) => {
      return (
        <a className="primary-color" onClick={() => router.push(`/goods/list/detail/${record.id}`)}>
          {text}
        </a>
      );
    },
  },
  {
    title: '规格颜色',
    dataIndex: 'spec',
  },
  {
    title: '数量',
    dataIndex: 'num',
  },
  {
    title: '是否可买断',
    dataIndex: 'buyOutSupport',
    render: buyOutSupport => {
      return <span>{buyOutSupport ? '可买断' : '不可买断'}</span>;
    },
  },
];

// 账单信息
const columnsBill = [
  // {
  //   title: '总押金',
  //   dataIndex: 'totalDeposit',
  // },
  // {
  //   title: '押金减免',
  //   dataIndex: 'depositReductions',
  // },
  {
    title: '冻结额度',
    dataIndex: 'freezePrice',
  },
  {
    title: '信用减免',
    dataIndex: 'creditDeposit',
  },
  {
    title: '实际冻结',
    dataIndex: '', // todo
    render: (text, record) => {
      return record.freezePrice - record.creditDeposit;
    },
  },
  {
    title: '总租金',
    dataIndex: 'totalRent',
  },
  {
    title: '运费',
    dataIndex: 'freightPrice',
  },
  {
    title: '平台优惠',
    dataIndex: 'platformCouponReduction',
  },
  {
    title: '店铺优惠',
    dataIndex: 'couponReduction',
  },
];

// 分期
const columnsByStages = [
  {
    title: '总期数',
    dataIndex: 'totalPeriods',
  },
  {
    title: '当前期数',
    dataIndex: 'currentPeriods',
  },
  {
    title: '租金',
    dataIndex: 'currentPeriodsRent',
  },
  {
    title: '状态',
    dataIndex: 'status',
    render: status => <span>{columnsByStagesStute[status]}</span>,
  },
  {
    title: '支付时间',
    dataIndex: 'repaymentDate',
  },
  {
    title: '账单到期时间',
    dataIndex: 'statementDate',
  },
  {
    title: '操作',
    width: 120,
    fixed: 'right',
    align: 'center',
    render: (e, record) => {
      return (
        <div>
          <a
            className="primary-color"
            onClick={() =>
              axios(`/hzsx/ope/lease/order/uploadOrderStages`, {
                method: 'get',
                headers: { token: getToken() },
                params: {
                  orderId: e.orderId,
                  index: e.currentPeriods,
                },
              }).then(res => {
                console.log(e.id);
              })
            }
            target="_blank"
          >
            上传
          </a>
          &nbsp;&nbsp;
          {e.status == '1' || e.status == '4' ? (
            <Popconfirm
              title="是否确定扣款？"
              onConfirm={() =>
                axios(`/hzsx/ope/order/userStageOrderPay`, {
                  method: 'get',
                  headers: { token: getToken() },
                  params: {
                    order_id: e.orderId,
                    num: e.currentPeriods,
                  },
                })
                  .then(res => {
                    // e.status = '2';
                    message.success('扣款请求已提交');
                  })
                  .catch(err => {
                    // message.error('提交失败');
                  })
              }
            >
              <button style={{ backgroundColor: '#FD574D', border: 0 }}>扣款</button>
            </Popconfirm>
          ) : null}
        </div>
      );
    },
  },
];
// 买断
const columnsBuyOutYes = [
  {
    title: '是否已买断',
    dataIndex: 'createTime',
    render: () => '是',
  },
  {
    title: '买断价格',
    dataIndex: 'buyOutAmount',
  },
];
const columnsBuyOutNo = [
  {
    title: '是否已买断',
    dataIndex: 'createTime',
    render: () => '否',
  },
  {
    title: '当前买断价格',
    dataIndex: 'currentBuyOutAmount',
  },
  {
    title: '到期买断价格',
    dataIndex: 'dueBuyOutAmount',
  },
];
/* const columnsBuyOut = [
  {
    title: '创建时间',
    dataIndex: 'createTime',
  },
  {
    title: '订单编号',
    dataIndex: 'buyOutOrderId',
  },
  {
    title: '商品名称',
    dataIndex: 'productName',
  },
  {
    title: '销售价',
    dataIndex: 'realSalePrice',
  },
  {
    title: '已付租金',
    dataIndex: 'paidRent',
  },
  {
    title: '买断尾款',
    dataIndex: 'endFund',
  },
]; */
// 结算
const columnsSettlement = [
  {
    title: '宝贝状态',
    dataIndex: 'settlementType',
    render: (text, record) => {
      return confirmSettlementType[text];
    },
  },
  {
    title: '违约金',
    dataIndex: 'amount',
  },
  {
    title: '是否支付',
    dataIndex: 'settlementStatus',
    render: (text, record) => {
      return confirmSettlementStatus[text];
    },
  },
];
const paginationProps = {
  current: 1,
  pageSize: 1000,
  total: 1,
};

@connect(({ order, loading, RentRenewalLoading }) => ({
  ...order,
  loading: loading.effects['order/queryOpeUserOrderDetail'],
  RentRenewalLoading: loading.effects['order/queryUserReletOrderDetail'],
}))
@Form.create()
export default class Details extends Component {
  getupload = id => {
    axios(`/hzsx/ope/lease/order/uploadOrderStages`, {
      method: 'get',
      headers: { token: getToken() },
      params: {
        orderId: id,
      },
    }).then(res => {
      console.log(id);
    });
  };

  state = {
    drawerVisible: false,
    drawerData: [],
    visible: false,
    visibles: false,
    visibles2: false,
    visibles3: false,
    visiblesimg: false,
    settlement: null,
    xcurrent: 1,
    scurrent: 1,
    titles: '',
    subLists: [],
    creditInfo: {}, // 信用详情
    img: '',
    comprehensiveSuggest: '',
    deliverOptions: [],
    auditRecord: {},
    processDetail: [],

    orderVisible: '',
    orderId: '',
    radioValue: '',
    damageValue: '',

    queryOrderStagesDetail: {},

    activeTab: '1',
    creditEmpty: false,

    HastenList: [],
    HastenTotal: 1,
    HastenCurrent: 1,

    opeHastenList: [],
    opeHastenTotal: 1,
    opeHastenCurrent: 1,
    antiCheatingLevel: '',

    redata: {},
  };

  componentDidMount() {
    const { dispatch } = this.props;
    const orderId = getParam('id');
    this.setState({
      orderId,
    });
    this.onRentRenewalDetail();
    this.onPageBusiness({ current: 1 });
    this.onPage({ current: 1 });
    if (getParam('settlement')) {
      this.onHasten(1, 3, '02');
      this.onHasten(1, 3, '01');
    }

    dispatch({
      type: 'order/queryOrderStagesDetail',
      payload: {
        orderId: getParam('id'),
      },
      callback: res => {
        if (res.responseType === 'SUCCESS') {
          this.setState({
            queryOrderStagesDetail: res.data,
          });
          // const { userOrderInfoDto } = this.props;
          // if(getParam('type') == 5 || getParam('type') == 2 ){
          //   this.setState({
          //     activeTab: getParam('type'),
          //   });
          // }
          // console.log(getParam('type'),'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm', userOrderInfoDto)
          // if(getParam('type') == 2 ) {
          //   this.viewCredit(userOrderInfoDto.uid);
          // }
        }
      },
    });
    // const { userOrderInfoDto } = this.props;
    if (getParam('type') == 5 || getParam('type') == 2) {
      this.setState({
        activeTab: getParam('type'),
      });
    }
    if (getParam('type') == 2) {
      axios(`/hzsx/ope/order/queryOpeUserOrderDetail`, {
        method: 'POST',
        headers: { token: getToken() },
        data: {
          orderId: getParam('id'),
        },
      }).then(res => {
        this.viewCredit(res.data.data.userOrderInfoDto.uid);
      });
    }
  }
  fetchProcessDetail() {
    const orderId = getParam('id');
    OrderService.queryOrderStatusTransfer({
      orderId,
    }).then(res => {
      this.setState({
        processDetail: res || [],
      });
    });
  }

  renderCollectionRecordModal() {
    const { orderVisible } = this.state;
    const { getFieldDecorator } = this.props.form;
    const orderId = getParam('id');

    const handleOk = e => {
      e.preventDefault();
      this.props.form.validateFields(['jg', 'xj'], (err, values) => {
        if (!err) {
          OrderService.orderHasten({ orderId, notes: values.xj, result: values.jg }).then(res => {
            this.onHasten(1, 3, '01');
            this.handleCancel();
          });
        }
      });
    };

    return (
      <Modal
        title="记录催收"
        visible={orderVisible === 'remarks'}
        onOk={handleOk}
        onCancel={this.handleCancel}
        destroyOnClose
      >
        <Form>
          <Form.Item label="结果" {...formItemLayout}>
            {getFieldDecorator('jg', {
              rules: [{ required: true, message: '请选择结果' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择结果">
                <Option value="01">承诺还款</Option>
                <Option value="02">申请延期还款</Option>
                <Option value="03">拒绝还款</Option>
                <Option value="04">电话无人接听</Option>
                <Option value="05">电话拒接</Option>
                <Option value="06">电话关机</Option>
                <Option value="07">电话停机</Option>
                <Option value="08">客户失联</Option>
              </Select>,
            )}
          </Form.Item>
          <Form.Item label="小记" {...formItemLayout}>
            {getFieldDecorator('xj', {
              rules: [{ required: true, message: '请输入小记' }],
            })(<TextArea placeholder="请输入" />)}
          </Form.Item>
        </Form>
      </Modal>
    );
  }

  onRentRenewalDetail = () => {
    const { dispatch } = this.props;
    if (getParam('RentRenewal')) {
      dispatch({
        type: 'order/queryUserReletOrderDetail',
        payload: {
          orderId: getParam('id'),
        },
      });
    } else {
      dispatch({
        type: 'order/queryOpeUserOrderDetail',
        payload: {
          orderId: getParam('id'),
        },
      });
    }
  };

  onQueryOrderRemark = (pageNumber, pageSize, source) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryOrderRemark',
      payload: {
        orderId: getParam('id'),
        pageNumber,
        pageSize,
        source,
      },
    });
  };

  // 新建备注翻页
  onPage = (e = { current: 1 }) => {
    this.setState(
      {
        xcurrent: e.current,
      },
      () => {
        this.onQueryOrderRemark(e.current, 3, '01');
      },
    );
  };

  // 商机备注翻页
  onPageBusiness = (e = { current: 1 }) => {
    this.setState(
      {
        scurrent: e.current,
      },
      () => {
        this.onQueryOrderRemark(e.current, 3, '02');
      },
    );
  };

  // 物流信息
  onClose = () => {
    this.setState({
      drawerVisible: false,
    });
  };

  // 查看物流
  onLogistics = (e, i) => {
    this.setState(
      {
        drawerVisible: true,
        drawerTitle: e,
      },
      () => {
        this.onQueryExpressInfo(i);
      },
    );
  };

  handleOk = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const { dispatch, userOrderInfoDto } = this.props;
        if (this.state.titles === '备注') {
          if (getParam('RentRenewal')) {
            dispatch({
              type: 'order/telephoneAuditOrder',
              payload: {
                orderId: getParam('id'),
                remark: values.beizhu,
              },
              callback: res => {
                this.onQueryOrderRemark(1, 3, '01');
                this.onRentRenewalDetail();
                this.setState({
                  visible: false,
                });
              },
            });
          } else {
            dispatch({
              type: 'order/orderRemark',
              payload: {
                orderId: getParam('id'),
                remark: values.beizhu,
                orderType: userOrderInfoDto.type,
              },
              callback: res => {
                this.onQueryOrderRemark(1, 3, '01');
                this.onRentRenewalDetail();
                this.setState({
                  visible: false,
                });
              },
            });
          }
        } else {
          dispatch({
            type: 'order/opeOrderAddressModify',
            payload: {
              realName: values.realName,
              street: values.street,
              telephone: values.telephone,
              province: values && values.city && values.city[0],
              city: values && values.city && values.city[1],
              area: values && values.city && values.city[2],
              orderId: getParam('id'),
            },
            callback: res => {
              this.onRentRenewalDetail();
              this.setState({
                visible: false,
              });
            },
          });
        }
      }
    });
  };

  onQueryExpressInfo = i => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryExpressInfo',
      payload: {
        expressNo: i.expressNo,
        receiverPhone: i.receiverPhone,
        shortName: i.shortName,
      },
    });
  };

  getExpressList = () => {
    OrderService.selectExpressList().then(res => {
      this.setState({
        deliverOptions: res || [],
      });
    });
  };

  getAuditRecord = () => {
    OrderService.queryOrderAuditRecord({
      orderId: this.state.orderId,
    }).then(res => {
      this.setState({
        auditRecord: res || [],
      });
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false,
      orderVisible: false,
    });
  };

  handleCancels = e => {
    this.setState({
      visibles: false,
      visibles2: false,
      visibles3: false,
      visiblesimg: false,
    });
  };

  onKaiImg = e => {
    this.setState({
      img: e,
      visiblesimg: true,
    });
  };

  showModal = e => {
    this.setState({
      visible: true,
      titles: e,
    });
  };

  settleDia = (type, orderId, userOrderCashId, record) => {
    const { userOrderCashesDto, userViolationRecords } = this.props;
    if (userViolationRecords && userViolationRecords[0]) {
      let radioValue = 'good';
      radioValue = userOrderCashesDto.damagePrice ? 'damage' : radioValue;
      radioValue = userOrderCashesDto.lostPrice ? 'lose' : radioValue;
      this.setState({
        checkValue: true,
        radioValue,
        damageValue: userOrderCashesDto.damagePrice || userOrderCashesDto.lostPrice,
      });
    }
    this.setState({
      orderId,
      userOrderCashId,
      record,
      orderVisible: 'settle',
    });
  };

  showOrderModal = (type, flag) => {
    if (['express', 'deliver'].includes(type)) {
      this.getExpressList();
    }
    if (type === 'settle') {
      this.settleDia();
    }
    if (type === 'audit') {
      this.setState({
        titles: flag ? '审批通过' : '审批拒绝',
      });
    }
    this.setState({
      orderVisible: type,
    });
  };

  onXY = () => {
    // const { dispatch } = this.props;
    // dispatch({
    //   type: 'order/contractReport',
    //   payload: {
    //     orderId: getParam('id'),
    //   },
    // });
    location.href = this.props.contractUrl;
  };

  viewCredit = id => {
    this.props.dispatch({
      type: 'order/getCredit',
      payload: {
        uid: id,
        orderId: getParam('id'),
      },
      callback: res => {
        console.log('res:', JSON.parse(res.data));
        const _data = JSON.parse(res.data);
        if (_data.resp_code === 'SW0000') {
          this.setState({
            redata: _data.resp_data || {},
          });
          return;
        }
        if (res.responseType === 'SUCCESS') {
          if (res.data) {
            if (res.data.reportType === '01') {
              // 旧版
              this.setState(
                {
                  visibles2: !!res.data.siriusRiskReport,
                  creditInfo: res.data.siriusRiskReport || {},
                  comprehensiveSuggest: res.data.comprehensiveSuggest || '',
                },
                () => {
                  // console.log(this.state.creditInfo);
                },
              );
            } else if (res.data.reportType === '02') {
              // 新版
              this.setState(
                {
                  visibles: !!res.data.respData,
                  creditInfo: res.data.respData || {},
                  comprehensiveSuggest: res.data.comprehensiveSuggest || '',
                  nsfLevel: res.data.nsfLevel,
                },
                () => {
                  // console.log(this.state.creditInfo);
                },
              );
            } else if (res.data.reportType === '03') {
              // 新版
              this.setState(
                {
                  visibles3: !!res.data.decisionResult,
                  creditInfo: res.data.decisionResult || {},
                  comprehensiveSuggest: res.data.comprehensiveSuggest || '',
                  nsfLevel: res.data.nsfLevel,
                  antiCheatingLevel: res.data.antiCheatingLevel,
                },
                () => {
                  // console.log(this.state.creditInfo);
                },
              );
            }
          } else {
            this.setState({
              creditEmpty: true,
            });
          }
        } else {
          message.error(res.errorMessage);
        }
      },
    });
  };

  tabChange = key => {
    const { userOrderInfoDto } = this.props;
    if (key === '3') {
      this.getAuditRecord();
    }
    if (key === '6') {
      this.fetchProcessDetail();
    }
    if (key === '2') {
      this.viewCredit(userOrderInfoDto.uid);
    }
    this.setState({
      activeTab: key,
    });
  };

  renderOrderInfoTab() {
    const {
      userOrderInfoDto = {},
      orderAdditionalServicesDto = {},
      orderAddressDto,
      opeRemarkDtoPage,
      businessRemarkDtoPage,
      productInfo,
      rentStart,
      rentDuration,
      unrentTime,
      shopInfoDto = {},
    } = this.props;

    const zengzhiList = this.props.orderAdditionalServicesList || [];

    const orderId = getParam('id');
    return (
      <div>
        <Descriptions>
          <Descriptions.Item label="订单号" span={3}>
            {orderId}
          </Descriptions.Item>
          {this.props.contractUrl ? (
            <Descriptions.Item label="用户租赁协议">
              <a onClick={this.onXY}>《租赁协议》</a>
            </Descriptions.Item>
          ) : null}
        </Descriptions>

        {orderAddressDto ? (
          <>
            <Descriptions
              title={
                <>
                  <CustomCard title="收货人信息" />
                </>
              }
            >
              <Descriptions.Item label="收货人姓名">
                {orderAddressDto && orderAddressDto.realname}
              </Descriptions.Item>
              <Descriptions.Item label="收货人手机号">
                {orderAddressDto && orderAddressDto.telephone}
              </Descriptions.Item>
              <Descriptions.Item label="收货人地址">
                {orderAddressDto && orderAddressDto.provinceStr}
                {orderAddressDto && orderAddressDto.cityStr}
                {orderAddressDto && orderAddressDto.areaStr}
                {orderAddressDto && orderAddressDto.street}
              </Descriptions.Item>
              <Descriptions.Item label="用户备注">{userOrderInfoDto.remark}</Descriptions.Item>
            </Descriptions>
            <Divider />
          </>
        ) : null}

        <Descriptions title={<CustomCard title="商家信息" />}>
          <Descriptions.Item label="商家名称">{shopInfoDto.shopName}</Descriptions.Item>
          <Descriptions.Item label="商家电话" span={2}>
            {shopInfoDto.telephone}
          </Descriptions.Item>
        </Descriptions>
        <Divider />

        <CustomCard title="商品信息" style={{ marginBottom: 20 }} />
        <AntTable
          columns={columnsInformation}
          dataSource={onTableData(productInfo)}
          paginationProps={paginationProps}
        />

        <Descriptions title={<CustomCard title="租用信息" />}>
          <Descriptions.Item label="租用天数">{rentDuration}</Descriptions.Item>
          <Descriptions.Item label="起租时间">{rentStart}</Descriptions.Item>
          <Descriptions.Item label="到期时间">{unrentTime}</Descriptions.Item>
        </Descriptions>
        <Divider />

        <CustomCard title="增值服务" style={{ marginBottom: 20 }} />
        <AntTable
          columns={columnsAddService}
          dataSource={zengzhiList}
          // dataSource={onTableData([orderAdditionalServicesDto])}
          paginationProps={paginationProps}
        />

        <CustomCard title="商家备注" style={{ marginBottom: 20 }} />
        {/* <Button */}
        {/*  type="primary" */}
        {/*  style={{ margin: '20px 0' }} */}
        {/*  onClick={() => this.showOrderModal('remark')} */}
        {/* > */}
        {/*  + 新建备注 */}
        {/* </Button> */}
        <MyPageTable
          onPage={this.onPageBusiness}
          paginationProps={{
            current: this.state.scurrent,
            pageSize: 3,
            total: businessRemarkDtoPage.total,
          }}
          dataSource={onTableData(businessRemarkDtoPage.records)}
          columns={columnsBusiness}
        />
        <Divider />
        <CustomCard title="平台备注" />
        <MyPageTable
          onPage={this.onPage}
          paginationProps={{
            current: this.state.xcurrent,
            pageSize: 3,
            total: opeRemarkDtoPage.total,
          }}
          dataSource={onTableData(opeRemarkDtoPage.records)}
          columns={columns}
        />
      </div>
    );
  }

  renderRiskTab() {
    const riskColumns = [
      {
        title: '综合评分',
        dataIndex: 'userName',
      },
      {
        title: '审批建议',
        dataIndex: 'createTime',
      },
      {
        title: '分值标注说明',
        dataIndex: 'remark',
      },
    ];
    const riskLevelColumns = [
      {
        title: '等级',
        dataIndex: 'userName',
      },
      {
        title: '审批建议',
        dataIndex: 'createTime',
      },
      {
        title: '说明',
        dataIndex: 'remark',
      },
    ];
    const {
      userOrderInfoDto = {},
      orderAddressDto,
      productInfo,
      userOrderCashesDto,
      orderBuyOutDto,
      wlList,
    } = this.props;
    const { drawerVisible, visibles, visibles2, visibles3, creditEmpty } = this.state;
    const { getFieldDecorator } = this.props.form;

    // console.log('orderBuyOutDto:', orderBuyOutDto);
    if (creditEmpty) {
      return '风险报告查询中，请稍后再来查看';
    }
    return (
      <div>
        {visibles ? (
          <CreditDetail
            userOrders={userOrderInfoDto}
            creditInfo={this.state.creditInfo}
            userOrderInfoDto={userOrderInfoDto}
            orderAddressDto={orderAddressDto}
            productInfo={productInfo}
            userOrderCashesDto={userOrderCashesDto}
            comprehensiveSuggest={this.state.comprehensiveSuggest}
            nsfLevel={this.state.nsfLevel}
          />
        ) : null}
        {visibles2 ? (
          <CreditDetailOld
            userOrders={userOrderInfoDto}
            creditInfo={this.state.creditInfo}
            userOrderInfoDto={userOrderInfoDto}
            orderAddressDto={orderAddressDto}
            productInfo={productInfo}
            userOrderCashesDto={userOrderCashesDto}
            comprehensiveSuggest={this.state.comprehensiveSuggest}
          />
        ) : null}
        {visibles3 ? (
          <CreditDetailThree
            userOrders={userOrderInfoDto}
            creditInfo={this.state.creditInfo}
            userOrderInfoDto={userOrderInfoDto}
            orderAddressDto={orderAddressDto}
            productInfo={productInfo}
            userOrderCashesDto={userOrderCashesDto}
            comprehensiveSuggest={this.state.comprehensiveSuggest}
            nsfLevel={this.state.nsfLevel}
            antiCheatingLevel={this.state.antiCheatingLevel}
          />
        ) : null}
      </div>
    );
  }

  renderAuditTab() {
    const { auditRecord = {} } = this.state;

    return (
      <div>
        <Descriptions>
          <Descriptions.Item label="审批时间" span={3}>
            {auditRecord.approveTime}
          </Descriptions.Item>
          <Descriptions.Item label="审批人" span={3}>
            {auditRecord.approveUserName}
          </Descriptions.Item>
          <Descriptions.Item label="审批结果" span={3}>
            {AuditStatus[auditRecord.approveStatus]}
          </Descriptions.Item>
          {auditRecord.approveStatus === '02' && (
            <Descriptions.Item label="拒绝类型" span={3}>
              {AuditReason[auditRecord.refuseType]}
            </Descriptions.Item>
          )}
          <Descriptions.Item label="小记" span={3}>
            {auditRecord.remark}
          </Descriptions.Item>
        </Descriptions>
      </div>
    );
  }

  renderExpressTab() {
    const { receiptExpressInfo, giveBackExpressInfo } = this.props;
    return (
      <div>
        {giveBackExpressInfo ? (
          <>
            <Descriptions title={<CustomCard title="归还物流信息" />}>
              <Descriptions.Item label="发货物流公司">
                {giveBackExpressInfo && giveBackExpressInfo.expressCompany
                  ? giveBackExpressInfo.expressCompany
                  : ''}
              </Descriptions.Item>
              <Descriptions.Item label="发货物流单号">
                {giveBackExpressInfo.expressNo}
              </Descriptions.Item>
              <Descriptions.Item label="归还时间">
                {giveBackExpressInfo.deliveryTime}
              </Descriptions.Item>
            </Descriptions>
            <Button onClick={() => this.onLogistics('归还物流信息', giveBackExpressInfo)}>
              查看物流
            </Button>
            <Divider />
          </>
        ) : null}
        {receiptExpressInfo ? (
          <>
            <Descriptions title={<CustomCard title="发货物流信息" />}>
              <Descriptions.Item label="发货物流公司">
                {receiptExpressInfo && receiptExpressInfo.expressCompany
                  ? receiptExpressInfo.expressCompany
                  : ''}
              </Descriptions.Item>
              <Descriptions.Item label="发货物流单号">
                {receiptExpressInfo.expressNo}
              </Descriptions.Item>
              <Descriptions.Item label="发货时间">
                {receiptExpressInfo.deliveryTime}
              </Descriptions.Item>
            </Descriptions>
            <Button onClick={() => this.onLogistics('发货物流信息', receiptExpressInfo)}>
              查看物流
            </Button>
            <Divider />
          </>
        ) : null}
      </div>
    );
  }

  renderBillTab() {
    const {
      userOrderCashesDto = {},
      orderByStagesDtoList = [],
      orderBuyOutDto = {},
      settlementInfoDto = {},
    } = this.state.queryOrderStagesDetail;

    return (
      <Card bordered={false}>
        {settlementInfoDto ? (
          <>
            <CustomCard title="结算信息" style={{ marginBottom: 20 }} />
            <AntTable
              columns={columnsSettlement}
              dataSource={onTableData([settlementInfoDto])}
              paginationProps={paginationProps}
            />
          </>
        ) : null}

        <CustomCard title="账单信息" style={{ marginBottom: 20 }} />
        <AntTable
          columns={columnsBill}
          dataSource={onTableData([userOrderCashesDto])}
          paginationProps={paginationProps}
        />
        <CustomCard title="分期信息" style={{ marginBottom: 20 }} />
        <AntTable
          columns={columnsByStages}
          dataSource={onTableData(orderByStagesDtoList)}
          paginationProps={paginationProps}
        />
        {orderBuyOutDto.orderId ? (
          <>
            <CustomCard title="买断信息" style={{ marginBottom: 20 }} />
            <AntTable
              columns={orderBuyOutDto.payFlag ? columnsBuyOutYes : columnsBuyOutNo}
              dataSource={onTableData([orderBuyOutDto])}
              paginationProps={paginationProps}
            />
          </>
        ) : null}
      </Card>
    );
  }

  renderProcessTab() {
    const { processDetail = [] } = this.state;
    const { userOrderInfoDto = {} } = this.props;
    return (
      <Card
        className="remove-card-bottom-border"
        title={<CustomCard title="订单进度" />}
        bordered={false}
      >
        <Steps
          direction="vertical"
          progressDot={document.body.clientWidth >= 1025}
          current={processDetail.length}
        >
          {processDetail.map(item => {
            const desc = (
              <div style={{ width: 300 }}>
                <div>{item.operatorName}</div>
                <div>{item.createTime}</div>
              </div>
            );
            return <Step title={item.operate} key={item.operate} description={desc} />;
          })}
        </Steps>
      </Card>
    );
  }

  renderContentTabCard() {
    const { userOrderInfoDto } = this.props;
    const { activeTab, redata } = this.state;
    const { status } = userOrderInfoDto;
    const personal_loan_demand = redata.personal_loan_demand || {};
    const { wx_datad7, wx_datam1, wx_datam3 } = personal_loan_demand;
    const applyQuerySeven = wx_datad7 || [];
    const applyQuerythrity = wx_datam1 || [];
    const applyQueryninety = wx_datam3 || [];
    const applyQuerySevendata = [];
    const applyQuerythritydata = [];
    const applyQueryninetydata = [];
    for (const key in applyQuerySeven) {
      const seven = {};
      seven.day = applyQuerySeven[key];
      applyQuerySevendata.push(seven);
    }
    for (const key in applyQuerythrity) {
      const seven = {};
      seven.day = applyQuerythrity[key];
      applyQuerythritydata.push(seven);
    }
    for (const key in applyQueryninety) {
      const seven = {};
      seven.day = applyQueryninety[key];
      applyQueryninetydata.push(seven);
    }
    const sevenDays = [{ title: '近7天', dataIndex: 'day' }];
    const monthDays = [{ title: '近30天', dataIndex: 'day' }];
    const ninetyDays = [{ title: '近90天', dataIndex: 'day' }];
    const applycolumns = [{ title: '', dataIndex: 'name' }];
    const applyData = apply.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    const sevenData = applyQuerySevendata.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    const monthData = applyQuerythritydata.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    const ninetyData = applyQueryninetydata.map((item, sign) => {
      const newsItem = { ...item };
      const keys = sign + 1;
      newsItem.key = keys;
      return newsItem;
    });
    const signLess = {
      display: 'flex',
      flexDirection: 'column',
      textAlign: 'left',
      fontSize: 14,
      color: '#333',
    };
    const riskSign = (
      <div className={signLess}>
        {redata &&
          redata.hit_risk_tagging &&
          redata.hit_risk_tagging.map((item, sign) => {
            return (
              <span key={sign}>
                {sign + 1}、{item}
              </span>
            );
          })}
      </div>
    );
    const scoreStandard = (
      <div className={signLess}>
        <span>分值在(0-100)之间，得分越高，风险越大:</span>
        <span>(0-30)，建议通过；</span>
        <span>[30-80)，建议审核；</span>
        <span>[80-100)，建议拒绝；</span>
      </div>
    );
    const titleName = {
      first: '消费分期类申请机构数 (个) ',
      second: '网络贷款类申请机构数 (个) ',
      three: '最近一次申请日期',
      four: '距离最近一次申请日期已有 (天) ',
    };
    const fiveTitle = {
      first: '',
      second: '近1个月',
      three: '近3个月',
      four: '近6个月',
      five: '近12个月',
    };
    const fiveTitlerepay = {
      first: '',
      second: '近1个月',
      three: '近3个月',
      four: '近6个月',
    };
    const nameObject = {
      first: '消费分期类放款机构数 (个) ',
      second: '网络贷款类放款机构数 (个) ',
      three: '最近一次放款日期',
      four: '距离最近一次放款日期已有 (天) ',
    };
    const threeName = {
      first: '近1个月',
      second: '近12个月',
      observeNum: '履约次数(次)',
      unobserveNum: '还款异常次数(次)',
    };
    const JFlist = [
      '申请人身份证',
      '配偶身份证',
      '结婚证',
      '户口本',
      '房产证明',
      '车产证明',
      '客户经理与客户合影',
      '营业执照（正）副本原件',
      '租赁合同原件',
    ];
    const YFlist = [
      '申请人身份证',
      '配偶身份证',
      '结婚证',
      '户口本',
      '房产证明',
      '车产证明',
      '客户经理与客户合影',
    ];
    const FFlist = [
      '申请人身份证',
      '配偶身份证',
      '结婚证',
      '户口本',
      '房产证明',
      '车产证明',
      '客户经理与客户合影',
      '最近一年银行流水原件',
    ];
    return (
      <Card bordered={false} style={{ marginTop: 20 }}>
        <Tabs activeKey={activeTab} onChange={this.tabChange}>
          <TabPane tab="订单信息" key="1">
            {this.renderOrderInfoTab()}
          </TabPane>
          {!['02', '01'].includes(status) ? (
            <TabPane tab="风险报告" key="2">
              {/* {this.renderRiskTab()} */}
              <Descriptions column={4} layout="vertical" bordered>
                <Descriptions.Item label="综合评分">
                  <span style={{ fontSize: 20, color: '#333', fontWeight: 'bold' }}>
                    {redata.multiple_score}
                  </span>
                </Descriptions.Item>
                <Descriptions.Item label="审核建议">
                  {redata.multiple_score < 80 ? (
                    <span style={{ color: '#07880E', fontSize: 16 }}>风控通过。</span>
                  ) : null}
                  {redata.multiple_score >= 80 && redata.multiple_score < 90 ? (
                    <span style={{ color: '#e6a23c', fontSize: 16 }}>建议审核，预收客户租金。</span>
                  ) : null}
                  {redata.multiple_score >= 90 && redata.multiple_score <= 95 ? (
                    <span style={{ color: '#ff2a00', fontSize: 16 }}>
                      风控不通过。拒付风险较高，存在较高逾期风险。
                    </span>
                  ) : null}
                </Descriptions.Item>
                <Descriptions.Item label="命中风险标注">{riskSign}</Descriptions.Item>
                <Descriptions.Item label="分值标注说明">{scoreStandard}</Descriptions.Item>
              </Descriptions>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>基本信息</Divider>
              <Descriptions column={2}>
                <Descriptions.Item label="姓名">
                  {redata.base_info && redata.base_info.name}
                </Descriptions.Item>
                <Descriptions.Item label="身份证号">
                  {redata.base_info && redata.base_info.ident_number}
                </Descriptions.Item>
                <Descriptions.Item label="手机号">
                  {redata.base_info && redata.base_info.phone}
                </Descriptions.Item>
                <Descriptions.Item label="年龄">
                  {redata.base_info && redata.base_info.age}
                </Descriptions.Item>
                <Descriptions.Item label="户籍">
                  {redata.base_info && redata.base_info.id_card_city}
                </Descriptions.Item>
                <Descriptions.Item label="号码归属地">
                  {redata.base_info && redata.base_info.mobile_address_city}
                </Descriptions.Item>
              </Descriptions>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>风险名单监测</Divider>
              <Descriptions column={2}>
                <Descriptions.Item label="特殊关注名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.personal_fraud_blacklist === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="归属地位于高风险集中地区">
                  {redata.risk_list_check &&
                  redata.risk_list_check.census_register_hign_risk_area === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="法院失信名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.court_break_faith_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="犯罪通缉名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.crime_manhunt_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="法院执行名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.court_execute_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="助学贷款欠费历史">
                  {redata.risk_list_check &&
                  redata.risk_list_check.student_loan_arrearage_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="信贷逾期名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.credit_overdue_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="高风险关注名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.hign_risk_focus_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="车辆租赁违约名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.car_rental_break_contract_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="法院结案名单">
                  {redata.risk_list_check && redata.risk_list_check.court_case_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="故意违章乘车名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.riding_break_contract_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="欠税名单">
                  {redata.risk_list_check && redata.risk_list_check.owing_taxes_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="欠税公司法人代表名单">
                  {redata.risk_list_check &&
                  redata.risk_list_check.owing_taxes_legal_person_list === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="虚拟号码库">
                  {redata.risk_list_check &&
                  redata.risk_list_check.virtual_number_base === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="通信小号库">
                  {redata.risk_list_check && redata.risk_list_check.small_number_base === '命中' ? (
                    <img
                      src="https://booleandata-open.oss-cn-shanghai.aliyuncs.com/dataValidation%20/shoot.svg"
                      alt="error"
                    />
                  ) : (
                    '未命中'
                  )}
                </Descriptions.Item>
              </Descriptions>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>机构查询记录</Divider>
              <div className={styles.tableHeader}>
                <Table bordered columns={applycolumns} dataSource={applyData} pagination={false} />
                <Table
                  locale={{ emptyText: '暂无记录' }}
                  bordered
                  columns={sevenDays}
                  dataSource={sevenData}
                  pagination={false}
                />
                <Table
                  locale={{ emptyText: '暂无记录' }}
                  bordered
                  columns={monthDays}
                  dataSource={monthData}
                  pagination={false}
                />
                <Table
                  locale={{ emptyText: '暂无记录' }}
                  bordered
                  columns={ninetyDays}
                  dataSource={ninetyData}
                  pagination={false}
                />
              </div>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>历史借贷行为</Divider>
              <div className={styles.historyWrap}>
                <div className={styles.total}>
                  <span style={{ fontWeight: 'bold' }}>近12个月申请机构总数&emsp;(个)：</span>
                  <span>
                    {redata &&
                    redata.personal_loan_s &&
                    redata.personal_loan_s.apply_mechanism_number === '无记录'
                      ? 0
                      : redata &&
                        redata.personal_loan_s &&
                        redata.personal_loan_s.apply_mechanism_number}
                  </span>
                </div>
                <FourItemapply
                  style={{ marginTop: 14 }}
                  title={titleName}
                  data={redata && redata.personal_loan_s}
                />
                <FiveItem
                  style={{ marginTop: 22 }}
                  title={fiveTitle}
                  text="申请次数(次)"
                  data={redata && redata.personal_loan_s}
                />
                <div className={styles.total}>
                  <span style={{ fontWeight: 'bold' }}>近12个月放款机构总数&emsp;(个)：</span>
                  <span>
                    {redata && redata.personal_loan_f && redata.personal_loan_f.lenders === '无记录'
                      ? 0
                      : redata && redata.personal_loan_f && redata.personal_loan_f.lenders}
                  </span>
                </div>
                <FourItem
                  style={{ marginTop: 14 }}
                  title={nameObject}
                  data={redata && redata.personal_loan_f}
                />
                <FiveItemrepay
                  style={{ marginTop: 22 }}
                  title={fiveTitlerepay}
                  text="放款次数(次)"
                  data={redata && redata.personal_loan_f}
                />
                <ThreeItem
                  style={{ marginTop: 22 }}
                  title={threeName}
                  data={redata && redata.personal_loan_f}
                />
              </div>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>历史逾期记录</Divider>
              <Historyoverdue data={redata && redata.personal_overdue_history} />
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>关联风险检测</Divider>
              <Descriptions column={1}>
                <Descriptions.Item label="3个月身份证关联手机号数(个)">
                  {redata &&
                  redata.relevance_risk_check &&
                  redata.relevance_risk_check.ident_to_phone_counts === '无记录'
                    ? 0
                    : redata &&
                      redata.relevance_risk_check &&
                      redata.relevance_risk_check.ident_to_phone_counts}
                </Descriptions.Item>
                <Descriptions.Item label="3个月手机号关联身份证数(个)">
                  {redata &&
                  redata.relevance_risk_check &&
                  redata.relevance_risk_check.phone_to_ident_counts === '无记录'
                    ? 0
                    : redata &&
                      redata.relevance_risk_check &&
                      redata.relevance_risk_check.phone_to_ident_counts}
                </Descriptions.Item>
              </Descriptions>
              <Divider style={{ fontSize: '20px', marginTop: 50 }}>法院风险信息</Divider>
              <CourtriskList data={redata && redata.court_risk_info_list} />
            </TabPane>
          ) : null}
          {!['01', '02', '11'].includes(status) ? (
            <TabPane tab="审批结论" key="3">
              {this.renderAuditTab()}
            </TabPane>
          ) : null}
          {!['01', '02', '04', '11'].includes(status) ? (
            <TabPane tab="物流信息" key="4">
              {this.renderExpressTab()}
            </TabPane>
          ) : null}
          <TabPane tab="账单信息" key="5">
            {this.renderBillTab()}
          </TabPane>
          {getParam('settlement') ? (
            <TabPane tab="催收记录" key="10">
              {this.renderCollectionRecord()}
            </TabPane>
          ) : null}
          <TabPane tab="流程进度" key="6">
            {this.renderProcessTab()}
          </TabPane>
        </Tabs>
      </Card>
    );
  }

  // OrderService
  onHasten = (pageNumber, pageSize, source) => {
    OrderService.queryOrderHasten({ pageNumber, pageSize, source, orderId: getParam('id') }).then(
      res => {
        if (source === '02') {
          this.setState({
            HastenList: res.records,
            HastenTotal: res.total,
          });
        } else {
          this.setState({
            opeHastenList: res.records,
            opeHastenTotal: res.total,
          });
        }
      },
    );
  };

  onHastenBusiness = e => {
    this.setState(
      {
        HastenCurrent: e.current,
      },
      () => {
        this.onHasten(e.current, 3, '02');
      },
    );
  };

  onHastenOpe = e => {
    this.setState(
      {
        opeHastenCurrent: e.current,
      },
      () => {
        this.onHasten(e.current, 3, '01');
      },
    );
  };

  renderCollectionRecord() {
    const { orderVisible } = this.state;
    console.log(orderVisible === 'remarks', 'orderVisibleorderVisible');
    const { getFieldDecorator } = this.props.form;
    return (
      <div>
        <CustomCard title="商家催收" style={{ marginBottom: 20 }} />
        <MyPageTable
          onPage={this.onHastenBusiness}
          columns={BusinessCollection}
          dataSource={onTableData(this.state.HastenList)}
          paginationProps={{
            current: this.state.HastenCurrent,
            pageSize: 3,
            total: this.state.HastenTotal,
          }}
        />
        <CustomCard title="平台催收" style={{ marginBottom: 20 }} />
        <MyPageTable
          onPage={this.onHastenOpe}
          columns={BusinessCollection}
          dataSource={onTableData(this.state.opeHastenList)}
          paginationProps={{
            current: this.state.opeHastenCurrent,
            pageSize: 3,
            total: this.state.opeHastenTotal,
          }}
        />
      </div>
    );
  }

  renderRemarkModal() {
    const { orderVisible } = this.state;
    const { getFieldDecorator } = this.props.form;
    const orderId = getParam('id');
    const handleOk = e => {
      e.preventDefault();
      this.props.form.validateFields(['beizhu'], (err, values) => {
        if (!err) {
          const { dispatch } = this.props;
          dispatch({
            type: 'order/orderRemark',
            payload: {
              orderId,
              remark: values.beizhu,
              orderType: '01',
            },
            callback: res => {
              this.onPage();
              this.handleCancel();
              this.props.form.resetFields();
            },
          });
        }
      });
    };

    return (
      <div>
        <Modal
          title="备注"
          visible={orderVisible === 'remark'}
          onOk={handleOk}
          onCancel={this.handleCancel}
        >
          <Form>
            <Form.Item label="备注内容" {...formItemLayout}>
              {getFieldDecorator('beizhu', {
                rules: [{ required: true, message: '请输入备注' }],
              })(<TextArea placeholder="请输入" />)}
            </Form.Item>
          </Form>
        </Modal>
      </div>
    );
  }

  renderDeliverModal() {
    const { form } = this.props;
    const { orderVisible, deliverOptions } = this.state;
    const { getFieldDecorator } = form;
    const orderId = getParam('id');
    const handleOk = e => {
      e.preventDefault();
      this.props.form.validateFields(['expressId', 'expressNo'], (err, fieldsValue) => {
        if (err) return;
        OrderService.orderDelivery({
          ...fieldsValue,
          orderId,
        }).then(res => {
          this.onRentRenewalDetail();
          this.props.form.resetFields();
          this.handleCancel();
        });
      });
    };

    return (
      <Modal
        destroyOnClose
        title={orderVisible === 'express' ? '修改物流信息' : '快速发货'}
        visible={orderVisible === 'deliver' || orderVisible === 'express'}
        onOk={handleOk}
        width="450px"
        onCancel={this.handleCancel}
      >
        <Form>
          <FormItem>
            {form.getFieldDecorator('expressId', {
              rules: [{ required: true, message: '请选择物流公司' }],
            })(
              <Select style={{ width: '100%' }} placeholder="请选择物流公司">
                {deliverOptions.map(option => {
                  return (
                    <Option key={option.id} value={option.id}>
                      {option.name}
                    </Option>
                  );
                })}
              </Select>,
            )}
          </FormItem>
          <FormItem>
            {form.getFieldDecorator('expressNo', {
              rules: [{ required: true, message: '请输入物流单号' }],
            })(<Input placeholder="请输入物流单号" />)}
          </FormItem>
        </Form>
      </Modal>
    );
  }

  renderCloseModal() {
    const { form } = this.props;
    const { orderVisible, orderId } = this.state;
    const handleOk = e => {
      this.props.form.validateFields(['closeReason'], (err, fieldsValue) => {
        if (err) return;
        OrderService.closeUserOrderAndRefundPrice({
          ...fieldsValue,
          closeType: '07',
          orderId,
        }).then(res => {
          this.onRentRenewalDetail();
          this.props.form.resetFields();
          this.handleCancel();
        });
      });
    };

    return (
      <Modal
        destroyOnClose
        title="关闭订单"
        visible={orderVisible === 'close'}
        onOk={handleOk}
        width="450px"
        onCancel={this.handleCancel}
      >
        <Form>
          {/* <FormItem> */}
          {/*  {form.getFieldDecorator( */}
          {/*    'closeType', */}
          {/*    { */}
          {/*      rules: [ */}
          {/*        {required: true, message: '请选择关单类型'} */}
          {/*      ] */}
          {/*    }, */}
          {/*  )( */}
          {/*    <Radio.Group> */}
          {/*      <Radio value={'06'}>客户要求关单</Radio> */}
          {/*      <Radio value={'07'}>商家风控关单</Radio> */}
          {/*    </Radio.Group>, */}
          {/*  )} */}
          {/* </FormItem> */}
          <FormItem label="小记">
            {form.getFieldDecorator('closeReason', {})(<Input placeholder="请输入关单原因" />)}
          </FormItem>
        </Form>
      </Modal>
    );
  }

  renderSettleModal() {
    const { form, userOrderCashesDto = {} } = this.props;
    const { orderId, orderVisible, radioValue, damageValue } = this.state;

    const onRadioChange = e => {
      this.setState({
        radioValue: e.target.value,
      });
    };

    const handleDamageValue = val => {
      this.setState({
        damageValue: val,
      });
    };

    const handleOk = e => {
      this.props.form.validateFields(['penaltyAmount', 'cancelReason'], (err, fieldsValue) => {
        if (err) return;
        const payload = {
          lossAmount: 0,
          damageAmount: 0,
          penaltyAmount: 0,
          settlementType: radioValue,
          ...fieldsValue,
          orderId,
        };
        if (radioValue === '03') {
          payload.lossAmount = damageValue;
        } else if (radioValue === '02') {
          payload.damageAmount = damageValue;
        }
        OrderService.merchantsIssuedStatements(payload).then(res => {
          this.onRentRenewalDetail();
          this.props.form.resetFields();
          this.handleCancel();
        });
      });
    };

    return (
      <Modal
        title="是否确认结算？"
        zIndex={2000}
        visible={orderVisible === 'settle'}
        onOk={handleOk}
        onCancel={this.handleCancel}
      >
        <div>
          <div>
            <span style={{ marginRight: '20px' }}>宝贝状态</span>
            <Radio.Group onChange={onRadioChange} value={radioValue}>
              <Radio value="01">完好</Radio>
              <Radio value="02">损坏</Radio>
              <Radio value="03">丢失</Radio>
              <Radio value="04">其他</Radio>
            </Radio.Group>
            {radioValue === '02' && (
              <div style={{ display: 'inline-block', marginTop: '20px' }}>
                <span>损坏赔偿金：</span>
                <InputNumber
                  min={0}
                  defaultValue={0}
                  value={damageValue}
                  onChange={handleDamageValue}
                />
                <span>元</span>
              </div>
            )}
            {radioValue === '03' && (
              <div style={{ display: 'inline-block', marginTop: '20px' }}>
                <span>丢失赔偿金：</span>
                <InputNumber
                  min={0}
                  defaultValue={0}
                  value={damageValue}
                  onChange={handleDamageValue}
                />
                <span>元</span>
              </div>
            )}
            {radioValue === '04' && (
              <div style={{ marginTop: '20px' }}>
                <Form.Item labelCol={{ span: 4 }} label="违约金：">
                  {form.getFieldDecorator('penaltyAmount', {
                    initialValue: userOrderCashesDto.penaltyAmount,
                  })(<InputNumber min={0} />)}
                  <span> 元</span>
                </Form.Item>
                <Form.Item labelCol={{ span: 4 }} label="违约原因：">
                  {form.getFieldDecorator('cancelReason', {
                    initialValue: userOrderCashesDto.cancelReason,
                  })(<Input style={{ width: '60%' }} placeholder="请输入违约原因" />)}
                </Form.Item>
              </div>
            )}
          </div>
        </div>
      </Modal>
    );
  }

  renderAddressModal() {
    const {
      userOrderInfoDto = {},
      orderAddressDto,
      dispatch,
      productInfo,
      userOrderCashesDto,
      orderBuyOutDto,
      wlList,
    } = this.props;
    const { orderVisible, orderId } = this.state;
    const { getFieldDecorator } = this.props.form;
    const handleOk = e => {
      this.props.form.validateFields(['realName', 'street', 'city', 'telephone'], (err, values) => {
        if (err) return;
        dispatch({
          type: 'order/opeOrderAddressModify',
          payload: {
            realName: values.realName,
            street: values.street,
            telephone: values.telephone,
            province: values && values.city && values.city[0],
            city: values && values.city && values.city[1],
            area: values && values.city && values.city[2],
            orderId,
          },
          callback: res => {
            this.onRentRenewalDetail();
            this.props.form.resetFields();
            this.handleCancel();
          },
        });
        // OrderService.businessClosePayedOrder({
        //   ...fieldsValue,
        //   orderId,
        // }).then(res => {
        //   this.onRentRenewalDetail()
        //   this.props.form.resetFields();
        //   this.handleCancel();
        // });
      });
    };

    return (
      <Modal
        title="修改收货信息"
        visible={orderVisible === 'address'}
        onOk={handleOk}
        onCancel={this.handleCancel}
      >
        <Form>
          <Form.Item label="所在城市" {...formItemLayout}>
            {getFieldDecorator('city', {
              rules: [
                {
                  required: true,
                  message: '请输入备注',
                },
              ],
              initialValue: [
                orderAddressDto && orderAddressDto.province && orderAddressDto.province.toString(),
                orderAddressDto && orderAddressDto.city && orderAddressDto.city.toString(),
                orderAddressDto && orderAddressDto.area && orderAddressDto.area.toString(),
              ],
            })(
              <Cascader
                options={optionsdata}
                fieldNames={{ label: 'name', value: 'value', children: 'subList' }}
              />,
            )}
          </Form.Item>
          <Form.Item label="收货人姓名" {...formItemLayout}>
            {getFieldDecorator('realName', {
              rules: [{ required: true, message: '请输入备注' }],
              initialValue: orderAddressDto && orderAddressDto.realname,
            })(<Input placeholder="请输入" />)}
          </Form.Item>
          <Form.Item label="收货人手机号" {...formItemLayout}>
            {getFieldDecorator('telephone', {
              rules: [{ required: true, message: '请输入备注' }],
              initialValue: orderAddressDto && orderAddressDto.telephone,
            })(<Input placeholder="请输入" />)}
          </Form.Item>
          <Form.Item label="详细地址" {...formItemLayout}>
            {getFieldDecorator('street', {
              rules: [{ required: true, message: '请输入备注' }],
              initialValue: orderAddressDto && orderAddressDto.street,
            })(<TextArea placeholder="请输入" />)}
          </Form.Item>
        </Form>
      </Modal>
    );
  }

  renderAuditModal() {
    const { form } = this.props;
    const { orderVisible, orderId, titles } = this.state;
    const handleOk = e => {
      this.props.form.validateFields(['refuseType', 'auditRemark'], (err, fieldsValue) => {
        if (err) return;
        OrderService.telephoneAuditOrder({
          ...fieldsValue,
          orderId,
          remark: fieldsValue.auditRemark,
          orderAuditStatus: titles === '审批通过' ? '01' : '02',
        }).then(res => {
          this.onRentRenewalDetail();
          this.props.form.resetFields();
          this.handleCancel();
        });
      });
    };

    return (
      <Modal
        destroyOnClose
        title={titles}
        visible={orderVisible === 'audit'}
        onOk={handleOk}
        width="450px"
        onCancel={this.handleCancel}
      >
        <Form>
          {titles === '审批拒绝' ? (
            <FormItem label="拒绝类型" {...formItemLayout}>
              {form.getFieldDecorator('refuseType', {
                rules: [{ required: true, message: '请选择拒绝类型' }],
              })(
                <Select style={{ width: '100%' }} placeholder="请选择">
                  {Object.keys(AuditReason).map(option => {
                    return (
                      <Option key={option} value={option}>
                        {AuditReason[option]}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </FormItem>
          ) : null}
          <FormItem label="小记" {...formItemLayout}>
            {form.getFieldDecorator('auditRemark', {
              rules: [{ required: true, message: '请输入小记' }],
            })(<Input.TextArea placeholder="请输入小记" />)}
          </FormItem>
        </Form>
      </Modal>
    );
  }

  // 基础信息按钮组
  renderBaseInfoButtons() {
    const { userOrderInfoDto = {} } = this.props;
    const orderId = getParam('id');
    const { auditLabel, status } = userOrderInfoDto;
    return (
      <Fragment>
        {status === '11' || status == '13' || status == '14' ? (
          <Fragment>
            {auditLabel !== '01' ? (
              <Fragment>
                <Button type="primary" onClick={() => this.showOrderModal('audit', true)}>
                  审批通过
                </Button>
                <Button type="primary" onClick={() => this.showOrderModal('audit', false)}>
                  审批拒绝
                </Button>
              </Fragment>
            ) : null}
            <Button type="primary" onClick={() => this.showOrderModal('close')}>
              关闭订单
            </Button>
            <Button type="primary" onClick={() => this.showOrderModal('address')}>
              修改收货信息
            </Button>
          </Fragment>
        ) : null}
        {['01', '02'].includes(status) ? (
          <Button type="primary" onClick={() => this.showOrderModal('address')}>
            修改收货信息
          </Button>
        ) : null}
        {status === '04' ? (
          <Fragment>
            {/* <Button type="primary" onClick={() => this.showOrderModal('deliver')}> */}
            {/*  发货 */}
            {/* </Button> */}
            <Button type="primary" onClick={() => this.showOrderModal('close')}>
              关闭订单
            </Button>
            <Button type="primary" onClick={() => this.showOrderModal('address')}>
              修改收货信息
            </Button>
          </Fragment>
        ) : null}
        {status === '05' || status == '15' ? (
          <Fragment>
            <Button type="primary" onClick={() => this.showOrderModal('close')}>
              关闭订单
            </Button>
            {/* <Button type="primary" onClick={() => this.showOrderModal('express')}> */}
            {/*  修改物流信息 */}
            {/* </Button> */}
          </Fragment>
        ) : null}
        {/* {status === '07' ? ( */}
        {/*  <Button type="primary" onClick={ */}
        {/*    () => this.settleDia('settle', orderId, userOrderInfoDto.orderCashId, userOrderInfoDto) */}
        {/*  }>结算</Button> */}
        {/* ) : null} */}
        {getParam('settlement') ? (
          <Button type="primary" onClick={() => this.showOrderModal('remarks')}>
            记录催收
          </Button>
        ) : null}
        <Button type="primary" onClick={() => this.showOrderModal('remark')}>
          备注
        </Button>
      </Fragment>
    );
  }

  renderBaseInfo() {
    // hisRentingOrderCount, //在途订单
    //   hisFinishOrderCount, //完成订单
    //   hisCloseOrderCount, // 关闭订单
    const {
      userOrderInfoDto = {},
      shopInfoDto = {},
      hisRentingOrderCount,
      hisFinishOrderCount,
      hisCloseOrderCount,
    } = this.props;
    return (
      <Card bordered={false} style={{ marginTop: 20 }}>
        <Descriptions title={<CustomCard title="下单人信息" />}>
          <Descriptions.Item label="姓名">{userOrderInfoDto.userName}</Descriptions.Item>
          <Descriptions.Item label="手机号">{userOrderInfoDto.telephone}</Descriptions.Item>
          <Descriptions.Item label="身份证号">{userOrderInfoDto.idCard}</Descriptions.Item>
          <Descriptions.Item label="年龄">{userOrderInfoDto.age}</Descriptions.Item>
          <Descriptions.Item label="性别">{userOrderInfoDto.gender}</Descriptions.Item>
          <Descriptions.Item label="下单时间">{userOrderInfoDto.createTime}</Descriptions.Item>
          {/* <Descriptions.Item label="在途订单数">
            {userOrderInfoDto.userPayCount > 1 ? (
              <span className="red-status">{userOrderInfoDto.userPayCount}</span>
            ) : (
              userOrderInfoDto.userPayCount
            )}
          </Descriptions.Item> */}
          <Descriptions.Item label="在途订单数">
            <span style={{ color: 'red', fontWeight: '600', fontSize: '16px' }}>
              {hisRentingOrderCount}
            </span>
          </Descriptions.Item>
          <Descriptions.Item label="完结订单数">
            {userOrderInfoDto.userFinishCount}
          </Descriptions.Item>
          <Descriptions.Item label="订单状态">
            {orderStatusMap[userOrderInfoDto.status]}
          </Descriptions.Item>
          {/* <Descriptions.Item label="完成订单">{ hisFinishOrderCount }</Descriptions.Item> */}
          <Descriptions.Item label="关闭订单">{hisCloseOrderCount}</Descriptions.Item>
          <Descriptions.Item label="人脸认证" span={1}>
            {userOrderInfoDto.userFaceCertStatus ? (
              <span className="green-status">已通过</span>
            ) : (
              <span className="red-status">未通过</span>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="身份证照片" span={2}>
            {userOrderInfoDto.idCardBackUrl ? (
              <>
                <img
                  src={userOrderInfoDto.idCardBackUrl}
                  style={{ width: 146, height: 77, marginRight: 20 }}
                  onClick={() => this.onKaiImg(userOrderInfoDto.idCardBackUrl)}
                />
                <img
                  onClick={() => this.onKaiImg(userOrderInfoDto.idCardFrontUrl)}
                  src={userOrderInfoDto.idCardFrontUrl}
                  style={{ width: 146, height: 77 }}
                />
              </>
            ) : (
              <span className="red-status">未上传</span>
            )}
          </Descriptions.Item>
          {/* <Descriptions.Item label="风险分"> */}
          {/*      <span className="primary-color"> */}
          {/*        {userOrderInfoDto.score}分 */}
          {/*       */}
          {/*      </span> */}
          {/* </Descriptions.Item> */}
        </Descriptions>
        {this.renderBaseInfoButtons()}
        <Divider />
      </Card>
    );
  }

  render() {
    const { orderBuyOutDto, wlList } = this.props;
    const { drawerVisible } = this.state;

    return (
      <PageHeaderWrapper title={false}>
        <Spin
          spinning={getParam('RentRenewal') ? this.props.RentRenewalLoading : this.props.loading}
        >
          {this.renderBaseInfo()}
          {this.renderContentTabCard()}
        </Spin>

        {this.renderRemarkModal()}
        {this.renderDeliverModal()}
        {this.renderCloseModal()}
        {this.renderSettleModal()}
        {this.renderAddressModal()}
        {this.renderAuditModal()}
        {this.renderCollectionRecordModal()}
        <Drawer
          width={420}
          title={this.state.drawerTitle || '发货物流信息'}
          placement="right"
          onClose={this.onClose}
          visible={drawerVisible}
        >
          <Timeline>
            {wlList.map((item, idx) => {
              let color = 'blue';
              if (idx === 0) {
                color = 'green';
              }
              return (
                <Timeline.Item
                  style={{ color: idx !== 0 ? '#aaa' : '#333' }}
                  key={idx}
                  color={color}
                >
                  <p>{item.remark}</p>
                  <p>{item.datetime}</p>
                </Timeline.Item>
              );
            })}
          </Timeline>
        </Drawer>
        <Modal
          title="身份证图片"
          visible={this.state.visiblesimg}
          onCancel={this.handleCancels}
          destroyOnClose
          footer={null}
        >
          <img src={this.state.img} alt="alt" style={{ width: '100%' }} />
        </Modal>
      </PageHeaderWrapper>
    );
  }
}
