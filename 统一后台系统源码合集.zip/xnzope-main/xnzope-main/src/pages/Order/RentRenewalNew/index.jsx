import React, { Component } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { Card, Button, Form, Row, Col, Input, Select, DatePicker, Tooltip, Spin } from 'antd';
import MyPageTable from '@/components/MyPageTable';
import { onTableData, getParam } from '@/utils/utils.js';
import CopyToClipboard from '@/components/CopyToClipboard';
import moment from 'moment';
const { Option } = Select;
const { RangePicker } = DatePicker;
const { TextArea } = Input;
import { getTimeDistance } from '@/utils/utils';
import { router } from 'umi';
import OrderService from '@/services/order';
@connect(({ order, loading }) => ({
  ...order,
  loading: loading.effects['order/queryReletOrderByConditionNew'],
}))
@Form.create()
export default class RentRenewalNew extends Component {
  state = {
    current: 1,
    yunTime: getTimeDistance('month'),
  };
  componentDidMount() {
    console.log(this.props, 'props');
    this.onList(1, 10);
    const { dispatch } = this.props;
    dispatch({
      type: 'order/PlateformChannel',
    });
  }
  onList = (pageNumber, pageSize, data = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'order/queryReletOrderByConditionNew',
      payload: {
        pageSize,
        pageNumber,
        ...data,
      },
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      console.log('Received values of form: ', values);
      if (values.createDate && values.createDate.length < 1) {
        values.createTimeStart = '';
        values.createTimeEnd = '';
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
          },
        );
      } else if (values.createDate) {
        values.createTimeStart = moment(values.createDate[0]).format('YYYY-MM-DD HH:mm:ss');
        values.createTimeEnd = moment(values.createDate[1]).format('YYYY-MM-DD HH:mm:ss');
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
          },
        );
      } else {
        this.setState(
          {
            datas: { ...values },
          },
          () => {
            this.onList(1, 10, { ...values });
          },
        );
      }
    });
  };
  //table 页数
  onPage = e => {
    this.setState(
      {
        current: e.current,
      },
      () => {
        this.onList(e.current, 10, this.state.datas);
      },
    );
  };
  onexport = () => {
    const { yunTime } = this.state;
    if (this.props.form.getFieldValue('createDate')) {
      this.props.dispatch({
        type: 'order/exportOpeAllUserOrders',
        payload: {
          createTimeEnd: moment(this.props.form.getFieldValue('createDate')[1]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
          createTimeStart: moment(this.props.form.getFieldValue('createDate')[0]).format(
            'YYYY-MM-DD HH:mm:ss',
          ),
        },
      });
    } else {
      this.props.dispatch({
        type: 'order/exportOpeAllUserOrders',
        payload: {
          createTimeEnd: moment(yunTime[1]).format('YYYY-MM-DD HH:mm:ss'),
          createTimeStart: moment(yunTime[0]).format('YYYY-MM-DD HH:mm:ss'),
        },
      });
    }
  };

  confirm = () => { };
  render() {
    const { ReletList, ReletTotal, loading } = this.props;
    const paginationProps = {
      current: this.state.current,
      pageSize: 10,
      total: ReletTotal,
      showTotal: total => (
        <span style={{ fontSize: '14px' }}>
          <span>共{Math.ceil(total / 10)}页</span>&emsp;
          <span>共{total}条</span>
        </span>
      ),
    };
    let detailsStute = {
      '01': '待支付',
      '02': '支付中',
      '03': '已支付申请关单',
      '04': '待发货',
      '05': '待确认收货',
      '06': '租用中',
      '07': '待结算',
      '08': '结算待支付',
      '09': '订单完成',
      '10': '交易关闭',
    };
    const columns = [
      {
        title: '订单编号',
        dataIndex: 'orderId',
        width: '120px',
        render: orderId => <CopyToClipboard text={orderId} />,
      },
      {
        title: '店铺名称',
        dataIndex: 'shopName',
        width: '10%',
        render: shopName => {
          return (
            <>
              <Tooltip placement="top" title={shopName}>
                <div
                  style={{
                    width: 60,
                  }}
                >
                  {shopName}
                </div>
              </Tooltip>
            </>
          );
        },
      },
      {
        title: '渠道来源',
        width: '120px',
        dataIndex: 'channelName',
      },
      {
        title: '商品名称',
        dataIndex: 'productName',
        width: '200px',
      },
      {
        title: '已支付期数/总期数',
        // dataIndex: 'currentPeriods',
        width: '60px',
        render: e => {
          return (
            <>
              <div
                style={{
                  width: 60,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                }}
              >
                {e.payedPeriods}/{e.totalPeriods}
              </div>
            </>
          );
        },
      },
      {
        title: '总租金',
        render: e => <span>{e.totalRentAmount}</span>,
        width: '100px',
      },
      {
        title: '已付租金',
        render: e => <span>{e.payedRentAmount}</span>,
        width: '100px',
      },
      {
        title: '下单人姓名',
        width: '100px',
        render: e => <span>{e.realName}</span>,
      },
      {
        title: '手机号',
        width: '120px',
        render: e => <span>{e.telephone}</span>,
      },
      {
        title: '起租时间',
        width: '120px',
        render: e => {
          return <>{e.rentStart}</>;
        },
      },
      {
        title: '归还时间',
        width: '120px',
        render: e => {
          return <>{e.unrentTime}</>;
        },
      },
      {
        title: '下单时间',
        dataIndex: 'placeOrderTime',
        width: '120px',
      },
      {
        title: '订单状态',
        dataIndex: 'status',
        width: 80,
        render: status => {
          return <span>{detailsStute[status]}</span>;
        },
      },
      {
        title: '操作',
        width: '80px',
        fixed: 'right',
        render: e => {
          return (
            <div style={{ textAlign: 'center' }}>
              <a
                href={`#/Order/RentRenewal/Details?id=${e.orderId}&RentRenewal=RentRenewal`}
                target="_blank"
              >
                处理
              </a>
            </div>
          );
        },
      },
    ];
    const { getFieldDecorator } = this.props.form;

    return (
      <PageHeaderWrapper title={false}>
        <Card bordered={false} style={{ marginBottom: 20 }}>
          <Form
            {...{
              labelCol: { xs: { span: 24 }, sm: { span: 7 } },
              wrapperCol: { xs: { span: 24 }, sm: { span: 17 } },
            }}
            onSubmit={e => {
              e && e.preventDefault();
              this.handleSubmit();
            }}
          >
            <Row style={{ display: 'flex', flexWrap: 'wrap' }}>
              <Col span={6}>
                <Form.Item label="商品名称">
                  {getFieldDecorator('productName')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入商品名称" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="店铺名称">
                  {getFieldDecorator('shopName')(
                    <Input style={{ minWidth: 200 }} placeholder="请输入店铺名称" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人姓名">
                  {getFieldDecorator('userName')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入下单人姓名" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="下单人手机号">
                  {getFieldDecorator('telephone')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入下单人手机号" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单编号">
                  {getFieldDecorator('orderId')(
                    <Input style={{ minWidth: 200 }} allowClear placeholder="请输入订单编号" />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="创建时间">
                  {getFieldDecorator('createDate')(
                    <RangePicker allowClear />
                  )}
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item label="订单状态">
                  {getFieldDecorator('status')(
                    <Select placeholder="订单状态" allowClear style={{ minWidth: 200 }}>
                      <Option value="01">待支付</Option>
                      <Option value="04">待发货</Option>
                      <Option value="05">待确认收货</Option>
                      <Option value="06">租用中</Option>
                      <Option value="07">待结算</Option>
                      <Option value="08">结算待支付</Option>
                      <Option value="09">订单完成</Option>
                      <Option value="10">交易关闭</Option>
                    </Select>
                  )}
                </Form.Item>
              </Col>
              <div style={{ flex: 1, textAlign: 'right', marginBottom: 20 }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button htmlType="button" onClick={() => { this.props.form.resetFields(); }}>
                  重置
                </Button>
                <Button onClick={this.onexport}>导出</Button>
              </div>
            </Row>
          </Form>
        </Card>
        <Card>
          <Spin spinning={loading}>
            <MyPageTable
              scroll
              onPage={this.onPage}
              paginationProps={paginationProps}
              dataSource={onTableData(ReletList)}
              columns={columns}
            />
          </Spin>
        </Card>
      </PageHeaderWrapper>
    );
  }
}
