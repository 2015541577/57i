import { router } from 'umi';
import * as shopApi from '@/services/order';
import { message } from 'antd';

export default {
  namespace: 'order',
  state: {
    allList: [], //全部列表
    allTotal: 1,
    closeList: [], //关闭列表
    closeTotal: 1,
    conditionList: [], //逾期列表列表
    conditionTotal: 1,
    BuyOutList: [], //买断订单列表
    BuyOutTotal: 1,
    ReletList: [], //查询续租订单
    ReletTotal: 1,
    AuditList: [], //电审
    AuditTotal: 1,
    ApplyTotal: 1,
    ApplyList:[],
    ApplyListType:[],
    ApplyTypeToal:1,
    PlateformList: [], //获取上架渠道集合
    userOrderInfoDto: {}, //订单信息
    shopInfoDto: {}, //商家信息
    orderAddressDto: {}, //收货人信息
    receiptExpressInfo: {}, //发货物流信息
    giveBackExpressInfo: {}, //归还物流信息
    productInfo: [],
    opeRemarkDtoPage: {}, //平台备注
    // OrderRemarkDataTotal: 1,
    businessRemarkDtoPage: {}, //商家备注
    // businessRemarkDtoTotal: 1,
    userOrderCashesDto: [], //账单信息
    orderByStagesDtoList: [], //分期信息
    orderBuyOutDto: [], //买断信息
    wlList: [], //物流信息
    originalOrderDto: [], //原定单详情
    userOrderBuyOutDto: [], //买断信息
    userOrderPurchaseList: [],
    userOrderPurchaseTotal: 1,
    promotion_list: [],     // 推广来源信息
  },
  effects: {
    // 新增前台类目集合控制器
    *GetAddCategoryCollection({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(shopApi.addCategoryCollection, payload);
      if (callback) callback(res);
    },
    // 更新前台类目集合控制器
    *GetModifyCategoryCollection({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(shopApi.modifyCategoryCollection, payload);
      if (callback) callback(res);
    },
    // 获取代扣申请表
    *getShopOrderDeductionApplyLog({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.getShopOrderDeductionApplyLog, payload);

      yield put({
        type: 'ApplyListData',
        payload: response,
      });
    },
    // 完结申请表
     *queryOrderCompleteApplyLog({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOrderCompleteApplyLog, payload);
      yield put({
        type: 'ApplyListType',
        payload: response,
      });
    },
    *getFinalReportList({ payload, callback }, { call, put }) {
      console.log(payload,"666666666666666666666666666666666")
      const response = yield call(shopApi.finalReportList, payload);
      yield put({
        type: 'finalReportData',
        payload: response,
      });
    },
    *queryOpeOrderByConditionList({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOpeOrderByCondition, payload);
      yield put({
        type: 'allListData',
        payload: response,
      });
      if (callback) callback(response);
    },
    *userOrderPurchase({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.userOrderPurchase, payload);

      yield put({
        type: 'userOrderPurchaseData',
        payload: response,
      });
    },
    *queryPendingOrderClosureList({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryPendingOrderClosureList, payload);

      yield put({
        type: 'closeListData',
        payload: response,
      });
    },
    *closeUserOrderAndRefundPrice({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.closeUserOrderAndRefundPrice, payload);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *queryOrderStagesDetail({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOrderStagesDetail, payload);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *queryOpeOverDueOrdersByCondition({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOpeOverDueOrdersByCondition, payload);

      yield put({
        type: 'conditionListData',
        payload: response,
      });
    },
    *queryWaitingGiveBackOrder({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryWaitingGiveBackOrder, payload);

      yield put({
        type: 'waitingGiveBackListData',
        payload: response,
      });
    },
    *queryOpeBuyOutOrdersByCondition({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOpeBuyOutOrdersByCondition, payload);

      yield put({
        type: 'BuyOutListData',
        payload: response,
      });
    },
    *billReport({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.billReport, payload);
      yield put({
        type: 'billReportData',
        payload: response,
      });
    },
    *queryPayOrder({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryPayOrder, payload);
      yield put({
        type: 'queryPayOrderData',
        payload: response,
      });
    },
    *queryCategoryCollectionPage({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryCategoryCollectionPage, payload);
      yield put({
        type: 'queryCategoryCollectionPageData',
        payload: response,
      });
    },
    *queryCategoryCollectionPageByScheme({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryCategoryCollectionPageByScheme, payload);
      yield put({
        type: 'queryCategoryCollectionPageBySchemeData',
        payload: response,
      });
      if(callback && typeof callback === 'function') {
        return callback(response);
      }
    },
    *queryTelephoneAuditOrder({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryTelephoneAuditOrder, payload);

      yield put({
        type: 'AuditListData',
        payload: response,
      });
    },
    *queryReletOrderByCondition({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryReletOrderByCondition, payload);

      yield put({
        type: 'ReletListData',
        payload: response,
      });
    },
    *queryReletOrderByConditionNew({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryReletOrderByConditionNew, payload);

      yield put({
        type: 'ReletListDataNew',
        payload: response,
      });
    },
    *PlateformChannel({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.PlateformChannel, payload);
      yield put({
        type: 'PlateformData',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *guanggao_items({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.guanggao_items, payload);
      yield put({
        type: 'guanggao_data',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *promotion_items({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.promotion_items, payload);
      yield put({
        type: 'promotion_data',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *orderRemark({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.orderRemark, payload);

      message.warning('备注成功～');
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *setUserOrderRate({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.setUserOrderRate, payload);

      message.success('提交成功～');
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *telephoneAuditOrder({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.telephoneAuditOrder, payload);
      message.warning('备注成功～');
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },

    *queryOpeUserOrderDetail({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOpeUserOrderDetail, payload);

      yield put({
        type: 'OpeUserData',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *queryOpeBuyOutOrderDetail({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOpeBuyOutOrderDetail, payload);
      yield put({
        type: 'OpeUserData',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },

    //续租
    *queryUserReletOrderDetail({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryUserReletOrderDetail, payload);
      yield put({
        type: 'OpeUserData',
        payload: response,
      });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *userOrdersPurchase({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.userOrdersPurchase, payload);

      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *purchaseOrder({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.purchaseOrder, payload);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *queryOrderRemark({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryOrderRemark, payload);
      // console.log(payload.source);
      yield put({
        type: 'OrderRemarkData',
        payload: {
          response,
          source: payload.source,
        },
      });
    },
    *queryExpressInfo({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.queryExpressInfo, payload);
      if(callback){
          callback(response)
      }
      yield put({
        type: 'queryInfoList',
        payload: response,
      });
    },
    *picPushExpress({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.picPushExpress, payload);
      if(callback){
          callback(response)
      }
      yield put({
        type: 'queryExpressList',
        payload: response,
      });
    },
    *getPicPushExpressList({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.getPicPushExpressList, payload);
      if(callback){
          callback(response)
      }
      yield put({
        type: 'queryExpressList',
        payload: response,
      });
    },
    *expressInfo({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.expressInfo, payload);
      yield put({
        type: 'queryInfoList',
        payload: response,
      });
    },
    *contractReport({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.contractReport, payload);
      window.open(response.data);
    },
    *selectDistrict({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.selectDistrict, payload);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *opeOrderAddressModify({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.opeOrderAddressModify, payload);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    *exportOpeAllUserOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportOpeAllUserOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },

    *purchaseOrderExport({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.purchaseOrderExport, payload);
      location.href = response.data;
      message.success('导出成功～');
    },

    *exportOpeBuyOutUserOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportOpeBuyOutUserOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    *exportOpeOverDueUserOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportOpeOverDueUserOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    *exportWaitingGiveBack({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportWaitingGiveBack, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    *exportReletOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportReletOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    *exportTelephoneAuditOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportTelephoneAuditOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    *exportCloseRefundOrders({ payload, callback }, { call, put }) {
      const response = yield call(shopApi.exportCloseRefundOrders, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    // 获取信用详情
    *getCredit({ payload, callback }, { put, call }) {
      let res = yield call(shopApi.getSiriusReportRecord, payload);
      if (callback) callback(res);
    },
  },
  reducers: {
    finalReportData(state, { payload }) {
      return {
        ...state,
        allList: payload.data.records,
        allTotal: payload.data.total,
      };
    },
    allListData(state, { payload }) {
      return {
        ...state,
        allList: payload.data.records,
        allTotal: payload.data.total,
      };
    },
    userOrderPurchaseData(state, { payload }) {
      return {
        ...state,
        userOrderPurchaseList: payload.data.records,
        userOrderPurchaseTotal: payload.data.total,
      };
    },
    closeListData(state, { payload }) {
      return {
        ...state,
        closeList: payload.data.records,
        closeTotal: payload.data.total,
      };
    },
    conditionListData(state, { payload }) {
      return {
        ...state,
        conditionList: payload.data.records,
        conditionTotal: payload.data.total,
      };
    },
    waitingGiveBackListData(state, { payload }) {
      return {
        ...state,
        waitingGiveBackList: payload.data.records,
        waitingGiveBackTotal: payload.data.total,
      };
    },
    ApplyListData(state, { payload }) {
      return {
        ...state,
        ApplyList: payload.data.records,
        ApplyTotal: payload.data.total,
      };
    },
    ApplyListType(state,{payload}){
        return {
            ...state,
            ApplyListType:payload.data.records,
             ApplyTypeToal:payload.data.total,

        }
    },
    AuditListData(state, { payload }) {
      return {
        ...state,
        AuditList: payload.data.records,
        AuditTotal: payload.data.total,
      };
    },
    billReportData(state, { payload }) {
      return {
        ...state,
        billReportList: payload.data.records,
        billReportTotal: payload.data.total,
      };
    },
    queryPayOrderData(state, { payload }) {
      return {
        ...state,
        queryPayOrderList: payload.data.records,
        queryPayOrderTotal: payload.data.total,
      };
    },
    queryCategoryCollectionPageData(state, { payload }) {
      return {
        ...state,
        queryCategoryCollectionPageList: payload.data.records,
        queryCategoryCollectionPageTotal: payload.data.total,
      };
    },
    queryCategoryCollectionPageBySchemeData(state, { payload }) {
      return {
        ...state,
        queryCategoryCollectionPageBySchemeList: payload.data.records,
        queryCategoryCollectionPageBySchemeTotal: payload.data.total,
      };
    },
    BuyOutListData(state, { payload }) {
      return {
        ...state,
        BuyOutList: payload.data.records,
        BuyOutTotal: payload.data.total,
      };
    },
    ReletListData(state, { payload }) {
      return {
        ...state,
        ReletList: payload.data.records,
        ReletTotal: payload.data.total,
      };
    },
    ReletListDataNew(state, { payload }) {
      return {
        ...state,
        ReletList: payload.data.records,
        ReletTotal: payload.data.total,
      };
    },
    PlateformData(state, { payload }) {
      return {
        ...state,
        PlateformList: payload.data,
      };
    },
    guanggao_data(state, { payload }) {
      return {
        ...state,
        guanggao_list: payload.data,
      };
    },
    promotion_data(state, { payload }) {
      return {
        ...state,
        promotion_list: payload.data,
      };
    },
    OpeUserData(state, { payload }) {
      // console.log('payload:', payload);
      return {
        ...state,
        ...payload.data,
        productInfo: [payload.data.productInfo],
        // OrderRemarkDataList: payload.data.opeRemarkDtoPage.records,
        // OrderRemarkDataTotal: payload.data.opeRemarkDtoPage.total,
        // businessRemarkDtoList: payload.data.businessRemarkDtoPage.records,
        // businessRemarkDtoTotal: payload.data.businessRemarkDtoPage.total,
        userOrderCashesDto: [payload.data.userOrderCashesDto],
        orderByStagesDtoList: payload.data.orderByStagesDtoList,
        orderBuyOutDto: [payload.data.orderBuyOutDto],
        originalOrderDto: [payload.data.originalOrderDto],
        userOrderBuyOutDto: [payload.data.userOrderBuyOutDto],
      };
    },
    OrderRemarkData(state, { payload }) {
      const { source, response } = payload;
      if (source === '01') {
        return {
          ...state,
          opeRemarkDtoPage: response.data,
        };
      }
      return {
        ...state,
        businessRemarkDtoPage: response.data,
      };
    },
    queryInfoList(state, { payload }) {
      return {
        ...state,
        wlList: payload.data.result.list || [],
      };
    },
    queryExpressList(state, { payload }) {
      return {
        ...state,
        wlList: payload.data.data || [],
      };
    },
  },
};
