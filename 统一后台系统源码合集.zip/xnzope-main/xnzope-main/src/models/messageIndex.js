import * as servicesApi from '@/services/message';
import { message } from 'antd';

export default {
  spacename: 'messageIndex',
  state: {
    list: [],
  },
  effects: {
    // 新增报表模块
    // 用户列表
    // *getUsersList({ payload, callback }, { put, call }) {
    //   console.log(payload,'ssssssssssss')
    //   let res = yield call(servicesApi.getUsersList, payload);
    //   yield put({
    //     type: 'getUsersLists',
    //     payload: res,
    //   });
    //   if (callback) callback(res);
    // },
  *getUsersVlist({ payload, callback }, { put, call }) {
      console.log(payload,'ssssssssssss')
      let res = yield call(servicesApi.getUsersVlist, payload);
      yield put({
        type: 'getUsersLists',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 账户明细列表
    *getGetSettlementLogs({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.getSettlementLogs, payload);
      yield put({
        type: 'getSettlementLogsList',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 对账单导出
    *exprtAccountLogs({ payload, callback }, { call, put }) {
      const response = yield call(servicesApi.exprtAccountLogs, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
     // 人保订单导出导出
    *lifeLnsurance({ payload, callback }, { call, put }) {
      const response = yield call(servicesApi.lifeLnsurance, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
     // 账户明细导出
    *exportAccountDetail({ payload, callback }, { call, put }) {
      const response = yield call(servicesApi.exportAccountDetail, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    // 账户明细导出2
    *exportshopAccountBalance({ payload, callback }, { call, put }) {
      const response = yield call(servicesApi.exportshopAccountBalance, payload);
      location.href = response.data;
      message.success('导出成功～');
    },
    // 提现明细导出功能
    *exportDepositDetail({payload,callback},{call,put}){
        const response =yield call(servicesApi.exportDepositDetail,payload)
        location.href=response.data;
        message.success('导出成功了')
    },
    // 用户导出功能
    *getExportUserDataV({payload,callback},{call,put}){
        const response =yield call(servicesApi.getExportUserDataV,payload)
        location.href=response.data;
        message.success('导出成功了')
    },
    // saas租金对账单导出功能
    *exportOnGetShopAccountLogs({payload,callback},{call,put}){
      const response =yield call(servicesApi.exportOnGetShopAccountLogs,payload)
      location.href=response.data;
      message.success('导出成功了')
    },
    // saas租金对账单导出功能
    *getExportOnGetShopAccountLogsUrlByKey({payload,callback},{call,put}){
      const response =yield call(servicesApi.getExportOnGetShopAccountLogsUrlByKey,payload)
      location.href=response.data;
    //   message.success('导出成功了')
    },
    // 平台对账列表的导出
  *exportOnPlatformStmtLogs({payload,callback},{call,put}){
      const response =yield call(servicesApi.exportOnPlatformStmtLogs,payload)
      location.href=response.data;
      message.success('导出成功了')
    },
    // 结算系统接口
    // 账户明细列表
    *getShopAccountList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.shopAccountList, payload);
      yield put({
        type: 'getAccountList',
        payload: res,
      });
      if (callback) callback(res);
    },
   //平台明细列表
   *getqueryShopAccountList({ payload, callback }, { put, call }) {
    let res = yield call(servicesApi.queryShopAccountList, payload);
         yield put({
          type: 'queryShopAccountList',
          payload: res,
        });
        if (callback) callback(res);
     },

    //账户明细日志
    *getshopAccountDayLogList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.shopAccountDayLogList, payload);
      yield put({
        type: 'getAccountDayLogList',
        payload: res,
      });
      if (callback) callback(res);
    },
      //账户明细日志2
    *shopAccountBalanceLogList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.shopAccountBalanceLogList, payload);
      yield put({
        type: 'getAccountDayLogList',
        payload: res,
      });
      if (callback) callback(res);
    },

    // 添加账户
    *AddEditShopAccount({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.editShopAccount, payload);
      if (callback) callback(res);
    },
    // //删除账户
    *deleteShopAccount({ payload, callback }, { call }) {
      let res = yield call(servicesApi.deleteShopAccount, payload);
      if (callback) callback(res);
    },

    // 新增对账单
    // 添加对账单
    *GetAddShopAccountLog({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.addShopAccountLog, payload);
      if (callback) callback(res);
    },
    // 添加账期
    *addPeriodAccount({payload,callback},{call}){
        let res=yield call(servicesApi.addPeriodAccount,payload);
        if(callback) callback(res);
    },
    // //删除对账单
    *deleteShopAccountLog({ payload, callback }, { call }) {
      let res = yield call(servicesApi.deleteShopAccountLog, payload);
      if (callback) callback(res);
    },
    // 账户明细列表
    *getShopAccountLogs({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.getShopAccountLogs, payload);
      yield put({
        type: 'getShopAccountLists',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 新租金对账单接口 2023.2.13
    *getShopAccountLogsForNew({ payload, callback }, { put, call }) {
      console.log(payload,"mmmmmmmmmmmmmmmmmmmmmmmmm")
      let res = yield call(servicesApi.getShopAccountLogsForNew, payload);
      yield put({
        type: 'getShopAccountLogsForNewList',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 账户明细列表
    *getShopAccountLogsv2({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.getShopAccountLogsv2, payload);
      yield put({
        type: 'getShopAccountLogsv2s',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 添加招募关系列表
    *queryBackstageUserPage({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.queryBackstageUserPage, payload);
      yield put({
        type: 'getCityRelationshipLists',
        payload: res,
      });
      if (callback) callback(res);
    },
    // 添加关系
    *bindShopCityPartner({payload,callback},{call}){
        let res=yield call(servicesApi.bindShopCityPartner,payload);
        if(callback) callback(res);
    },
    // 生成流水
    *GetCreateSettlementAccountLog({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.createSettlementAccountLog, payload);
      if (callback) callback(res);
    },
    // 结算
    *GetSetShopAccountsValue({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.setShopAccountsValue, payload);
      if (callback) callback(res);
    },
    // 审核
    *GetSetShopAccountValue({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.setShopAccountValue, payload);
      if (callback) callback(res);
    },
    // ------------------------
    // //删除广告商
    *deleteAdvertiser({ payload, callback }, { call }) {
      let res = yield call(servicesApi.delete_guanggao, payload);
      if (callback) callback(res);
    },
    // 广告商管理列表
    *getAdvertisingList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.getGuangGaoBusiness_list, payload);
      yield put({
        type: 'advertisingList',
        payload: res,
      });

      if (callback) callback(res);
    },
    // list
    *getList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.queryOpeOrderByCondition, payload);

      yield put({
        type: 'saveList',
        payload: res,
      });

      if (callback) callback(res);
    },
    //添加广告管理新增接口
    *addAdvertisingList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.addGuangGaoBusiness, payload);
      if (callback) callback(res);
    },
    //添加list
    *addList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.saveMessageTemplate, payload);
      if (callback) callback(res);
    },
    // //删除list
    *deleteList({ payload, callback }, { call }) {
      let res = yield call(servicesApi.delMessageTemplate, payload);
      if (callback) callback(res);
    },
    //编辑list
    *updateList({ payload, callback }, { call }) {
      let res = yield call(servicesApi.updateMessageTemplate, payload);
      if (callback) callback(res);
    },
    // //获取上架信息
    // *getChannel({ payload, callback }, { call, put }) {
    //   const response = yield call(servicesApi.getChannel, payload);
    //   if (response.data.code == 1) {
    //     callback && callback(response.data.data);
    //   }
    // },
    //发送短信查询发送数量接口
    *getOrderPhoneQuantity({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.getOrderPhone, payload);
      if (callback) callback(res);
    },
    // 发送短信历史列表
    *querySendLogPageList({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.querySendLogPage, payload);
      yield put({
        type: 'querySendLogList',
        payload: res,
      });

      if (callback) callback(res);
    },
    //发送短信
    *getAddSendLog({ payload, callback }, { put, call }) {
      let res = yield call(servicesApi.addSendLog, payload);
      if (callback) callback(res);
    },

    // 结算系统-saas余额
    *getQueryShopAccountLogs({ payload, callback }, { put, call }) {
      console.log(payload,'ssssssssssss')
      let res = yield call(servicesApi.getQueryShopAccountLogs, payload);
      yield put({
        type: 'getQueryShopAccountLogsList',
        payload: res,
      });
      if (callback) callback(res);
    },
    //sass 查询所需要的一些下拉选信息
    *querySassAccountOfOptionsParam({ payload, callback }, { call, put }) {
      const response = yield call(servicesApi.querySassAccountOfOptionsParam, payload);
      // yield put({
      //   type: 'querySassAccountOfOptionsParamData',
      //   payload: response,
      // });
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
    // saas充值
    *addUpdateSassAccount({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.updateSassAccount, payload);
      if (callback) callback(res);
    },
    // saas二维码充值
    *saasAccountRechargeSubmit({ payload, callback }, { call }) {
      // console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.saasAccountRechargeSubmit, payload);
      if (callback) callback(res);
    },
    // 城市列表查询
    *queryPageCityPartnerAccountLog({ payload, callback }, { call }) {
      console.log(payload,'nnnnnnnnnnnnnn')
      let res = yield call(servicesApi.queryPageCityPartnerAccountLog, payload);
      if (callback) callback(res);
    },
  },
  reducers: {
    saveList(state, { payload }) {
      console.log();
      // let _state = JSON.parse(JSON.stringify(state));
      // _state.list = (payload.data && payload.data.records) || [];
      // return _state;
      return {
        ...state,
        list: payload.data.records,
      };
    },
    getSettlementLogsList(state, { payload }) {
      return {
        ...state,
        list: payload.data.records,
      };
    },
    getAccountList(state, { payload }) {
      return {
        ...state,
        list: payload.data.records,
      };
    },
    getUsersLists(state, { payload }) {
      return {
        ...state,
        list: payload.data.records,
      };
    },
    getShopAccountLogsForNewList(state, { payload }) {
      return {
        ...state,
        list: payload.data.data.records,
      };
    },
    getShopAccountLists(state, { payload }) {
      return {
        ...state,
        list: payload.data.data.records,
      };
    },
    getCityAccountLists(state, { payload }) {
      return {
        ...state,
        list: payload.data.data.records,
      };
    },
    getCityRelationshipLists(state, { payload }) {
      return {
        ...state,
        list: payload.data.records,
      };
    },
    querySendLogList(state, { payload }) {
      // console.log(payload,"mmmmmmmmmmmmmmmmmmmm",state);
      // let _state = JSON.parse(JSON.stringify(state));
      // _state.list = (payload.data && payload.data.records) || [];
      // return _state;
      return {
        ...state,
        list: payload.data.records,
      };
    },
    advertisingList(state, { payload }) {
      // console.log(payload,"mmmmmmmmmmmmmmmmmmmm",state);
      // let _state = JSON.parse(JSON.stringify(state));
      // _state.list = (payload.data && payload.data.records) || [];
      // return _state;
      return {
        ...state,
        list: payload.data.records,
      };
    },
    getQueryShopAccountLogsList(state, { payload }) {
      return {
        ...state,
        lists: payload.data.records,
      };
    },
    querySassAccountOfOptionsParamData(state, { payload }) {
      return {
        ...state,
        querySassAccountOfOptionsParamList: payload.data,
      };
    },
    /* initProps(state, payload) {
      let _state = JSON.parse(JSON.stringify(state));
      _state.list = [];
      return _state;
    }, */
  },
};
