import { router } from 'umi';
import * as reportApi from '@/services/reportForm';

export default {
  namespace: 'report',
  state: { reportList: [], reportTotal: 1 },
  effects: {
    *getReportList({ payload, callback }, { call, put }) {
      console.log(payload, '666666666666666666666666666666666');
      const response = yield call(reportApi.getReportList, payload);
      yield put({
        type: 'ReportData',
        payload: response,
      });
    },
  },
  reducers: {
    ReportData(state, { payload }) {
      return {
        ...state,
        reportList: payload.data.list,
        reportTotal: payload.data.total,
      };
    },
  },
};
