import Request from "../../utils/request";

export const getTopicSpecialPageData = (data) =>
  Request({
    url: "hzsx/special/getTopicSpecialPageData",
    method: "GET",
    data,
  });
export const getDirectSpecialPageData = (data) =>
  Request({
    url: "hzsx/special/getDirectSpecialPageData",
    method: "GET",
    data,
  });
export const userPointInsertUserPoint = (data) =>
  Request({
    url: "hzsx/userPoint/insertUserPoint",
    method: "GET",
    data,
  });
