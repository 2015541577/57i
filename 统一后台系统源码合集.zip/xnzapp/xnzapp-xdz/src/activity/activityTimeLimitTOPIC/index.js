import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, ScrollView, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import "./index.scss";
import Request from "../../utils/request";
import { getGloble, getUid, setUid, getBuyerId } from "../../utils/localStorage";
import * as acTimeLimitTOPICApi from "./service";

@connect(({ productList }) => ({
  ...productList,
  // loading: loading.models.productList,
}))
class ActivityTimeLimitTOPIC extends Component {
  config = {
    navigationBarTitleText: " ",
  };

  state = {
    spike: {},
    labelProductsArr: [],
    activeIndex: 0,
    guangGao_token: null,
  };
  onProcess (e){
    // Taro.switchTab({ url: `/pages/home/index`});
    Taro.navigateTo({ url: e ? e : "/pages/home/index"});
  };
  // 对应 onLoad
	componentWillMount = () => {
    const { id, type, action, channelId, position } = this.$router.params;
    // if (channelId) {
    //   if(getUid()){
    //     acTimeLimitTOPICApi.userPointInsertUserPoint({
    //       uid: getUid(),
    //       action: action || "action",
    //       channelId: channelId || "channelId",
    //       position: position || "position",
    //     });
    //   }else{
    //     // 没有uid时先获取
    //     my.getAuthCode({
    //       scopes: "auth_base",
    //       success: (res) => {
    //         Request({
    //           url: "hzsx/aliPay/user/exemptLogin",
    //           method: "POST",
    //           data: {
    //             authCode: res.authCode,
    //             channelId: getGloble('channelId'),
    //           },
    //         }).then((res2) => {
    //           setUid(res2.data.data.uid);
    //           acTimeLimitTOPICApi.userPointInsertUserPoint({
    //             uid: getUid() || -1,
    //             action: action || "action",
    //             channelId: channelId || "channelId",
    //             position: position || "position",
    //           });
    //         });
    //       },
    //     });
    //   }
    // }
    const JKPD =
      type === "DIRECT"
        ? acTimeLimitTOPICApi.getDirectSpecialPageData
        : acTimeLimitTOPICApi.getTopicSpecialPageData;
    JKPD({
      indexId: id,
    }).then((res) => {
      const spike =
        type === "DIRECT" ? res.data.data.direct || {} : res.data.topic || {};
      my.setNavigationBar({
        title: spike.title || "限时租",
      });
      const labelProductsArr = [];
      for (let key in spike.labelProducts) {
        labelProductsArr.push({
          key,
          val: spike.labelProducts[key],
        });
      }
      this.setState({
        spike,
        labelProductsArr,
      });
    });
  }
  // componentDidMount = () => {}
  //  onShow
	componentDidShow = () => {
    // 获取缓存埋点
    const { gg_id } = (this.$router.params)
    // Taro.removeStorageSync(gg_id);
    if(gg_id != undefined && gg_id != null && gg_id.length>0){
      // 进入条件：从外部进入 有gg_id

      // Taro.removeStorageSync(gg_id);
      
      // 获取历史缓存的gg_id
      const data = Taro.getStorageSync(gg_id);
      if(data != null && data.length>0){
        // 历史缓存中有数据的情况进入
        this.state.guangGao_token = JSON.parse( data);
      }
      
      const obj_current={
        gg_id:gg_id,
        time:new Date()
      }
      Taro.setStorageSync("current_gg_id",JSON.stringify(obj_current));

      if(this.state.guangGao_token == null){
        // 没有历史缓存的情况
        //本地没有用户token和time
        Request({
          url: `hzsx/llxzu/guanggao/add_guanggao_token`,
          method: "GET",
          data:{
            // 此时gg_id是跳转传参
            gg_id:gg_id 
          }
        }).then(res=>{
          const token = res.data.data
          const obj={
            token:token,
            time:new Date()
          }
          // 没有历史缓存 请求接口获取token和time 进行缓存
          Taro.setStorageSync(gg_id,JSON.stringify(obj));
          // 再次获取历史缓存
          const data = Taro.getStorageSync(gg_id);
          if(data != null && data.length>0){
            // 判断如果有token和time给guanggao_token赋值
            this.state.guangGao_token = JSON.parse( data);
          }
        });
      }else{
        // 有历史缓存
        // 如果有
        let that  = this;
        Request({
              url: `/hzsx/llxzu/guanggao/set_guanggao_cont`,
              method: "GET",
              data:{
                user_token: that.state.guangGao_token.token 
              }
        }).then(res=>{
          if(gg_id) {
            if(!res.data.data) {
              Taro.removeStorageSync(gg_id);
              Request({
                url: `hzsx/llxzu/guanggao/add_guanggao_token`,
                method: "GET",
                data:{
                  product_id: product_id ,
                  // 此时gg_id是跳转传参
                  gg_id:gg_id 
                }
              }).then(res=>{
                const token = res.data.data
                const obj={
                  token:token,
                  time:new Date()
                }
                // 没有历史缓存 请求接口获取token和time 进行缓存
                Taro.setStorageSync(gg_id,JSON.stringify(obj));
                // 再次获取历史缓存
                const data = Taro.getStorageSync(gg_id);
                if(data != null && data.length>0){
                  // 判断如果有token和time给guanggao_token赋值
                  that.state.guangGao_token = JSON.parse( data);
                }
              });
            }
          }
        })
      }
      
    }
    
  };

  onShareAppMessage() {
    const { id, type } = this.$router.params;

    return {
      title: type === 'DIRECT' ? "1元起买好物" : "租数码上星动租",
      desc: type === 'DIRECT' ? '限量1元购，超多福利送到家！' : '租啥都有，超划算合集来啦！',
      path: `activity/activityTimeLimitTOPIC/index?id=${id}&type=${type}`,
    };
  }

  toProduct(id) {
    const { type } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${id}&source=02&type=${type}`,
    });
  }
  toProducts(url) {
    Taro.navigateTo({
      url: url,
    });
  }
  onGoToMore = (url) => {
    if (url.indexOf("alipays://") === 0) {
      const index = url.indexOf("appId=");
      const indexPage = url.indexOf("=/");
      const appId = url.substr(index + 6, 16);
      const path = url.substring(indexPage + 1, url.length);
      if (indexPage !== -1) {
        my.navigateToMiniProgram({
          appId,
          path: path,
        });
      } else {
        my.navigateToMiniProgram({
          appId,
        });
      }
    } else {
      // if (url == "/SharingRentFree/sharerent/index") {
      //   this.onShare();
      // } else {
      //   Taro.navigateTo({ url });
      // }
        Taro.navigateTo({ url });
    }
  };

  menuChange(index) {
    this.setState({
      activeIndex: index,
    });
  }

  render() {
    const { spike, labelProductsArr, activeIndex } = this.state;
    const { type } = this.$router.params;
    return (
      <View className="activity-time-limit-topic-page" style={{background:spike.backgroundColor}}>
        <Image mode="aspectFit" src={spike.adPic} className="banner-img" lazyLoad={true} />
        {/* <View className="active-title">
          <View className="title-text">
            {spike.title}
            <Image
              mode="aspectFit"
              className="title-img-l"
              src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/active/title-icon.png"
            />
            <Image
              mode="aspectFit"
              className="title-img-r"
              src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/active/title-icon.png"
            />
          </View>
        </View> */}
        {/* <ScrollView
          scrollX
          scrollWithAnimation
          scrollTop="0"
          className="product-list"
        >
          {!!spike.products &&
            !!spike.products.length &&
            spike.products.map((item, index) => (
              <View
                className="product-item"
                key={item.itemId}
                onClick={() => this.toProduct(item.productId)}
              >
                <View className="product-info">
                  <Image
                    mode="aspectFit"
                    src={item.image}
                    className="product-img"
                  />
                  <View className="product-name">{item.productName}</View>
                </View>
                <View className="product-price">
                  ￥
                  <Text className="price-text">
                    {item.price && item.price.toString().split(".")[0]}.
                  </Text>
                  {(item.price && item.price.toString().split(".")[1]) || "00"}
                  {type === "TOPIC" ? "元/天" : "起"}
                </View>
                <Button className="product-btn">
                  {type === "TOPIC" ? "立即租" : "立即买"}
                </Button>
              </View>
            ))}
        </ScrollView> */}
        <View className="c_commodity">
          {!!spike.topList &&
            !!spike.topList.length &&
            spike.topList.map((item, index) => (
            <View className="c_commodity_list" onClick={() => this.toProducts(item.targetUrl)}>
              <Image
                mode="aspectFit"
                className="c_commodity_img"
                src={item.imgUrl}
                lazyLoad={true}
              />
            </View>
          ))}
        </View>
        <ScrollView
          scrollX
          scrollWithAnimation
          scrollTop="0"
          className="menu-list"
          style={{background:spike.backgroundColor}}
        >
          <View className="menu-list-view" style={{background:spike.navColor}}>
            {!!labelProductsArr &&
              !!labelProductsArr.length &&
              labelProductsArr.map((item, index) => (
                <Text
                  key={item.key}
                  onClick={() => this.menuChange(index)}
                  style={{color: index === activeIndex ? spike.backgroundColor : "#fff",background: index === activeIndex ? spike.buttonColor : ""}}
                  className={
                    "menu-item " +
                    (index === activeIndex ? "menu-item-active" : "")
                  }
                >
                  {item.key}
                  {index === activeIndex ? (
                    <View className="active-line"></View>
                  ) : (
                    ""
                  )}
                </Text>
              ))}
          </View>
        </ScrollView>
        <View className="product-list2">
          {!!labelProductsArr[activeIndex] &&
            labelProductsArr[activeIndex].val.map((item, index) => (
              <View
                className="product-item2"
                key={item.itemId}
                onClick={() => this.toProduct(item.productId)}
              >
                <View className="product-info">
                  <Image
                    mode="aspectFit"
                    src={item.image}
                    className="product-img"
                    lazyLoad={true}
                  />
                  {/* <View className="product-name">{item.productName}</View> */}
                </View>
                <View className="product-name">{item.productName}</View>
                <View className="product-price">
                  ￥
                  <Text className="price-text">
                    {item.price && item.price.toString().split(".")[0]}.
                  </Text>
                  {(item.price && item.price.toString().split(".")[1]) || "00"}
                  {/* {type === "TOPIC" ? "元/天" : "起"} */}
                  {type === "TOPIC" ? "元/天" : "元/天"}
                </View>
                <Button className="product-btn">
                  {/* {type === "TOPIC" ? "立即租" : "立即买"} */}
                  {type === "TOPIC" ? "立即抢租" : "立即抢租"}
                </Button>
              </View>
              // <View
              //   className="c_product-item2"
              //   key={item.itemId}
              //   onClick={() => this.toProduct(item.productId)}
              // >
              //   <Image
              //     mode="aspectFit"
              //     src={item.image}
              //     className="c_product-img"
              //   />
              // </View>
            ))}
        </View>
        {/* <View className="bottom-img">
          <Image
            className="bottom-img1"
            onClick={this.onGoToMore.bind(
              this,
              (spike.bottom && spike.bottom[0] && spike.bottom[0].url) || ""
            )}
            mode="aspectFit"
            src={spike.bottom && spike.bottom[0] && spike.bottom[0].pic}
          />
          <View className="bottom-img2-view">
            <Image
              className="bottom-img2"
              onClick={this.onGoToMore.bind(
                this,
                (spike.bottom && spike.bottom[1] && spike.bottom[1].url) || ""
              )}
              mode="aspectFit"
              src={spike.bottom && spike.bottom[1] && spike.bottom[1].pic}
            />
            <Image
              className="bottom-img3"
              onClick={this.onGoToMore.bind(
                this,
                (spike.bottom && spike.bottom[2] && spike.bottom[2].url) || ""
              )}
              mode="aspectFit"
              src={spike.bottom && spike.bottom[2] && spike.bottom[2].pic}
            />
          </View>
        </View> */}
       <View className="c_bottom-img">
          <Image
            onClick={() => this.onProcess( spike.bottom && spike.bottom[0] && spike.bottom[0].url ? spike.bottom[0].url : "" )}
            className="c_bottom-img1"
            mode="aspectFit"
            lazyLoad={true}
            src={spike.bottom && spike.bottom[0] && spike.bottom[0].pic}
          />
        </View>
      </View>
    );
  }
}

export default ActivityTimeLimitTOPIC;
