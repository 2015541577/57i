import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, ScrollView, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import "./index.scss";
import Request from "../../utils/request";
import { getGloble, getUid, setUid, getBuyerId } from "../../utils/localStorage";
import * as acTimeLimitTOPICApi from "./service";

@connect(({ productList }) => ({
  ...productList,
  // loading: loading.models.productList,
}))
class ActivityTimeLimitTOPIC extends Component {
  config = {
    navigationBarTitleText: "安卓专区",
  };

  state = {
  };
    onGotoProduct = (itemId) => {
        Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}`});
      };
  render() {
    return (
      <View className="anzhuo">
        <View className="anzhuo_top">
          
        </View>
        <View className="anzhuo_huawei">
          <View className="anzhuo_huawei_left">
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e9f13dff90a644de8c9bd8c77927defd.png" className="img" onClick={() => { this.onGotoProduct('1741076055406') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/47fd328270d745f9b661bc4937b9ee81.png" className="img" onClick={() => { this.onGotoProduct('1741072138029') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/24d5ba8f51e545178a898a9b2ecf2086.png" className="img" onClick={() => { this.onGotoProduct('1741071030100') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d7de41cf87594588862d8792b1d45976.png" className="img" onClick={() => { this.onGotoProduct('1741067217783') }}></Image>
            </View>

          </View>
          <View className="anzhuo_huawei_right">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/24187359fd734c95849b596a070c3ab4.png" className="img" onClick={() => { this.onGotoProduct('1741076944534') }}></Image>
          </View>

        </View>
        <View className="anzhuo_xiaom">
          <View className="anzhuo_huawei_left">
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/7c813344a1ea40b9b38b6344c2d29cbd.png" className="img" onClick={() => { this.onGotoProduct('1741145531481') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/2c16b6f7973e4c1ea901d7b1c75675a9.png" className="img" onClick={() => { this.onGotoProduct('1742113322860') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/b83c9fce61944f2c8426163b84af3cda.png" className="img" onClick={() => { this.onGotoProduct('1741156449754') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/5789ab38c7a146ea8b3a75a4504431b6.png" className="img" onClick={() => { this.onGotoProduct('1740987036754') }}></Image>
            </View>

          </View>
          <View className="anzhuo_huawei_right">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1081a3758dda4264a551e68bf26533d9.png" className="img" onClick={() => { this.onGotoProduct('1740985370271') }}></Image>
          </View>

        </View>
        <View className="anzhuo_oppo">
          <View className="anzhuo_huawei_left">
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/eb7637fa27be4cd7912914ad9a04ea90.png" className="img" onClick={() => { this.onGotoProduct('1742114410590') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/5c2b05d8ba2b42d2a729c9af542b6f27.png" className="img" onClick={() => { this.onGotoProduct('1742116437648') }}></Image>            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1b02d27375974c1ea65274164f5bf5c3.png" className="img" onClick={() => { this.onGotoProduct('1741162505845') }}></Image>            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/06bdeeea2fec462f892a5a2ed94db17f.png" className="img" onClick={() => { this.onGotoProduct('1742117002028') }}></Image>            </View>

          </View>
          <View className="anzhuo_huawei_right">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/538f794e8a224f12938bd69a2b412299.png" className="img" onClick={() => { this.onGotoProduct('1740988950969') }}></Image>          </View>

        </View>
        <View className="anzhuo_vive">
          <View className="anzhuo_huawei_left">
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/a4e7cb594bff48118b3d2c6ac0d8cad1.png" className="img" onClick={() => { this.onGotoProduct('1741242582699') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c810bd41160a4a8287c7d4ca898ae77a.png" className="img" onClick={() => { this.onGotoProduct('1741243291725') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/a71b10fa4e2c48e0b8ea501c4b8cefc9.png" className="img" onClick={() => { this.onGotoProduct('1742116956338') }}></Image>
            </View>
            <View className="anzhuo_huawei_left_div">
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6e297d7e816d4072b8982fe1a22f38ed.png" className="img" onClick={() => { this.onGotoProduct('1741232646616') }}></Image>
            </View>

          </View>
          <View className="anzhuo_huawei_right">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/5202f3b4060a4bfc8fdb7acaf0b77e28.png" className="img" onClick={() => { this.onGotoProduct('1741241725379') }}></Image>
          </View>

        </View>
        <View className="anzhuo_btn">

        </View>
      </View>
    );
  }
}

export default ActivityTimeLimitTOPIC;
