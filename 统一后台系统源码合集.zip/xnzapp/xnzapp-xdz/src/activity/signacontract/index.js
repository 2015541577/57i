import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, ScrollView, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import Request from "../../utils/request";
import {
  getGloble,
  getUid,
  setUid,
  getBuyerId,
} from "../../utils/localStorage";
import * as acTimeLimitTOPICApi from "./service";

@connect(({ productList }) => ({
  ...productList,
  // loading: loading.models.productList,
}))
class signacontract extends Component {
  config = {
    navigationBarTitleText: "",
  };

  state = {};
  render() {
    const { link } = this.$router.params;
    console.log(link, "linklinklink");
    return (
      <View>
        <web-view src={link} onMessage="onmessage"></web-view>
      </View>
    );
  }
}

export default signacontract;
