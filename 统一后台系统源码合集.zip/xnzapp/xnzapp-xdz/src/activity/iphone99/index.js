import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, ScrollView, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import "./index.scss";
import Request from "../../utils/request";
import {
  getGloble,
  getUid,
  setUid,
  getBuyerId,
} from "../../utils/localStorage";
import * as acTimeLimitTOPICApi from "./service";

@connect(({ productList }) => ({
  ...productList,
  // loading: loading.models.productList,
}))
class ActivityTimeLimitTOPIC extends Component {
  config = {
    navigationBarTitleText: "玖环优品机",
    titleBarColor:'#FFFFFF',
  };

  state = {};
  onGotoProduct = (itemId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` });
  };
  render() {
    return (
      <View className="iphone99">
        <View className="iphone99_top"></View>
        <View className="iphone99_ip16">
          <View className="iphone99_ip16_top">
            <Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/451413dd8d3f4d648075c6dd109164d4.png" className="img" onClick={() => { this.onGotoProduct('1741766241220') }}></Image>
          </View>
          <View className="iphone99_ip16_btn">
            <View className="iphone99_ip16_btn_div">
               <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/7c60b70796264de6ad94219b1b9e2276.png" className="img" onClick={() => { this.onGotoProduct('1742121521263') }}></Image>
            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/4de17139ec404d7a9f4a36efad5db649.png" className="img" onClick={() => { this.onGotoProduct('1741768014948') }}></Image>

            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/df50290d8aca4ca98ae0cabd2289f761.png" className="img" onClick={() => { this.onGotoProduct('1741768852477') }}></Image>

            </View>

          </View>
        </View>
        <View className="iphone99_ip15">
          <View className="iphone99_ip16_top">
            <Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/32c7640a666d447986048e5de5193436.png" className="img" onClick={() => { this.onGotoProduct('1741763969887') }}></Image>
          </View>
          <View className="iphone99_ip16_btn">
            <View className="iphone99_ip16_btn_div">
               <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/017b931c5d654706beccf7ea599aa746.png" className="img" onClick={() => { this.onGotoProduct('1741761848956') }}></Image>
            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/07dc2e84b6444be993f8f0698cb756ac.png" className="img" onClick={() => { this.onGotoProduct('1741767070307') }}></Image>

            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/4b7f0c685fdc412a8c92fe0a25378769.png" className="img" onClick={() => { this.onGotoProduct('1741764836847') }}></Image>

            </View>

          </View>
        </View>
        <View className="iphone99_ip14">
          <View className="iphone99_ip16_top">
            <Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/98959192678943deb7cb634b63816131.png" className="img" onClick={() => { this.onGotoProduct('1741757811904') }}></Image>
          </View>
          <View className="iphone99_ip16_btn">
            <View className="iphone99_ip16_btn_div">
               <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/a6b552853d294b75986c0bab094798d2.png" className="img" onClick={() => { this.onGotoProduct('1741757056746') }}></Image>
            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/26a7db73eceb4eb5975a047c6e85704b.png" className="img" onClick={() => { this.onGotoProduct('1741756319449') }}></Image>

            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6d8d7bf645dc44d998c9a7d649e8cb1e.png" className="img" onClick={() => { this.onGotoProduct('1741755681246') }}></Image>

            </View>

          </View>
        </View>
        <View className="iphone99_ip13">
          <View className="iphone99_ip16_top">
            <Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/dd50b3a875354caf93b8692cd6464254.png" className="img" onClick={() => { this.onGotoProduct('1742014049206') }}></Image>
          </View>
          <View className="iphone99_ip16_btn">
            <View className="iphone99_ip16_btn_div">
               <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0ad72321635b4f8d94e5f9fd97db6192.png" className="img" onClick={() => { this.onGotoProduct('1741772552261') }}></Image>
            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0196835d1b164e839fa755c1973aa305.png" className="img" onClick={() => { this.onGotoProduct('1741769612906') }}></Image>

            </View>
            <View className="iphone99_ip16_btn_div">
            <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3f31c66575764805b1027dc7104f7e6f.png" className="img" onClick={() => { this.onGotoProduct('1741769920662') }}></Image>

            </View>

          </View>
        </View>
        <View className="iphone99_btn">
          <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e3cbaee3df004a82bc5f5310ec81ef45.png" className="img"></Image>
        </View>
      </View>
    );
  }
}

export default ActivityTimeLimitTOPIC;
