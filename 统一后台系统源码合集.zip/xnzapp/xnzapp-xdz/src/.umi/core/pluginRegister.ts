// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from 'C:/Users/ /Desktop/小程序/alipay/src/app.js';

  plugin.register({
    apply: Plugin_0,
    path: 'C:/Users/ /Desktop/小程序/alipay/src/app.js',
  });

export const __mfsu = 1;
