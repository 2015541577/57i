// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'C:/Users/ /AppData/Roaming/npm/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  // {
  //   "path": "/activityZhongQiu",
  //   "exact": true,
  //   "component": require('@/pages/activityZhongQiu/index.js').default
  // },
  {
    "path": "/addAddress",
    "exact": true,
    "component": require('@/pages/addAddress/index.js').default
  },
  {
    "path": "/address",
    "exact": true,
    "component": require('@/pages/address/index.js').default
  },
  {
    "path": "/authentication",
    "exact": true,
    "component": require('@/pages/authentication/index.js').default
  },
  {
    "path": "/billDetail",
    "exact": true,
    "component": require('@/pages/billDetail/index.js').default
  },
  {
    "path": "/buyOutOrder",
    "exact": true,
    "component": require('@/pages/buyOutOrder/index.js').default
  },
  {
    "path": "/Certificates",
    "exact": true,
    "component": require('@/pages/Certificates/index.js').default
  },
  {
    "path": "/checkSuccess",
    "exact": true,
    "component": require('@/pages/checkSuccess/index.js').default
  },
  {
    "path": "/classify",
    "exact": true,
    "component": require('@/pages/classify/index.js').default
  },
  {
    "path": "/commentOn",
    "exact": true,
    "component": require('@/pages/commentOn/index.js').default
  },
  {
    "path": "/Complaint",
    "exact": true,
    "component": require('@/pages/Complaint/index.js').default
  },
  {
    "path": "/configureActivities",
    "exact": true,
    "component": require('@/pages/configureActivities/index.js').default
  },
  {
    "path": "/confirmOrder",
    "exact": true,
    "component": require('@/pages/confirmOrder/index.js').default
  },
  {
    "path": "/coupon/collector",
    "exact": true,
    "component": require('@/pages/coupon/collector.js').default
  },
  {
    "path": "/coupon",
    "exact": true,
    "component": require('@/pages/coupon/index.js').default
  },
  {
    "path": "/coupon/oldCoupon",
    "exact": true,
    "component": require('@/pages/coupon/oldCoupon.js').default
  },
  {
    "path": "/couponList",
    "exact": true,
    "component": require('@/pages/couponList/index.js').default
  },
  {
    "path": "/deposit",
    "exact": true,
    "component": require('@/pages/deposit/index.js').default
  },
  {
    "path": "/digital",
    "exact": true,
    "component": require('@/pages/digital/index.js').default
  },
  {
    "path": "/express",
    "exact": true,
    "component": require('@/pages/express/index.js').default
  },
  {
    "path": "/FilingComplaint",
    "exact": true,
    "component": require('@/pages/FilingComplaint/index.js').default
  },
  {
    "path": "/FilingType",
    "exact": true,
    "component": require('@/pages/FilingType/index.js').default
  },
  {
    "path": "/home",
    "exact": true,
    "component": require('@/pages/home/index.js').default
  },
  {
    "path": "/mine",
    "exact": true,
    "component": require('@/pages/mine/index.js').default
  },
  {
    "path": "/myCollect",
    "exact": true,
    "component": require('@/pages/myCollect/index.js').default
  },
  {
    "path": "/orderDetail",
    "exact": true,
    "component": require('@/pages/orderDetail/index.js').default
  },
  {
    "path": "/orderList",
    "exact": true,
    "component": require('@/pages/orderList/index.js').default
  },
  {
    "path": "/otherPayment",
    "exact": true,
    "component": require('@/pages/otherPayment/index.js').default
  },
  {
    "path": "/process",
    "exact": true,
    "component": require('@/pages/process/index.js').default
  },
  {
    "path": "/productAssess",
    "exact": true,
    "component": require('@/pages/productAssess/index.js').default
  },
  {
    "path": "/productDetail",
    "exact": true,
    "component": require('@/pages/productDetail/index.js').default
  },
  {
    "path": "/productDetail/wxParseComponent",
    "exact": true,
    "component": require('@/pages/productDetail/wxParseComponent.js').default
  },
  {
    "path": "/productList",
    "exact": true,
    "component": require('@/pages/productList/index.js').default
  },
  {
    "path": "/productShopList",
    "exact": true,
    "component": require('@/pages/productShopList/index.js').default
  },
  {
    "path": "/purchaseDetail",
    "exact": true,
    "component": require('@/pages/purchaseDetail/index.js').default
  },
  {
    "path": "/realName",
    "exact": true,
    "component": require('@/pages/realName/index.js').default
  },
  {
    "path": "/search",
    "exact": true,
    "component": require('@/pages/search/index.js').default
  },
  {
    "path": "/selAddress",
    "exact": true,
    "component": require('@/pages/selAddress/index.js').default
  },
  {
    "path": "/sendBack",
    "exact": true,
    "component": require('@/pages/sendBack/index.js').default
  },
  {
    "path": "/shops",
    "exact": true,
    "component": require('@/pages/shops/index.js').default
  },
  // {
  //   "path": "/shopSettleIn",
  //   "exact": true,
  //   "component": require('@/pages/shopSettleIn/index.js').default
  // },
  {
    "path": "/sign",
    "exact": true,
    "component": require('@/pages/sign/index.js').default
  },
  // {
  //   "path": "/tenants",
  //   "exact": true,
  //   "component": require('@/pages/tenants/index.js').default
  // },
  {
    "path": "/tribeDetail",
    "exact": true,
    "component": require('@/pages/tribeDetail/index.js').default
  },
  {
    "path": "/vip",
    "exact": true,
    "component": require('@/pages/vip/index.js').default
  },
  {
    "path": "/webview/xieyi",
    "exact": true,
    "component": require('@/pages/webview/xieyi.js').default
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
