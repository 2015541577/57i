/**
 * redux数据存储中的全局模块数据
 */
export default {
  namespace: 'global',

  state: {
    queryObj:{}
  },

  effects: {
    *setKeyValue({ payload }, { call, put }) {
      yield put({ type: 'saveKvToStore', payload });
    }
  },

  reducers: {
    saveKvToStore(state, { payload }) {
      const { key, value,queryObj } = payload;
      return {
        ...state,
        [key]: value,
        queryObj
      };
    }
  }
};
