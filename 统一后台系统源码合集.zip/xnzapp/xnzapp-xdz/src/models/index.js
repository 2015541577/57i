import productList from '../pages/productList/model';
import productDetail from '../pages/productDetail/model';
import confirmOrder from '../pages/confirmOrder/model';
import orderDetail from '../pages/orderDetail/model';
import orderDetails from '../pages/orderDetails/model';
import address from '../pages/address/model';
import addAddress from '../pages/addAddress/model';
import shops from '../pages/shops/model';
import classify from '../pages/classify/model';
import home from '../pages/home/model';
import search from '../pages/search/model';
import mine from '../pages/mine/model';
import realName from '../pages/realName/model';
import orderList from '../pages/orderList/model';
import billDetail from '../pages/billDetail/model';
import otherPayment from '../pages/otherPayment/model';
import sendBack from '../pages/sendBack/model';
import coupon from '../pages/coupon/model';
import express from '../pages/express/model'
import certificate from '../pages/Certificates/model'
import deposit from '../pages/deposit/model'
import checkSuccess from '../pages/checkSuccess/model'
import authentication from '../pages/authentication/model'
import agreement from '../pages/webview/model'
import buyout from '../pages/buyOutOrder/model'
import couponList from '../pages/couponList/model'
import productAssess from '../pages/productAssess/model'
import global from "./globalModel";

export default [
  home,
  orderDetail,
  orderDetails,
  productList,
  productDetail,
  confirmOrder,
  address,
  addAddress,
  shops,
  classify,
  search,
  mine,
  realName,
  orderList,
  billDetail,
  sendBack,
  coupon,
  express,
  certificate,
  deposit,
  checkSuccess,
  authentication,
  agreement,
  buyout,
  couponList,
  productAssess,
  global,
]
