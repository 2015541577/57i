import Request from '../../utils/request';
export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const getOrderinformation = (data) => {
  return Request({
    url: `hzsx/api/buyOutOrder/buyOutPage`,
    method: 'POST',
    data
  });
}
export const submitOrder = (data) => {
  return Request({
    url: `hzsx/api/buyOutOrder/buyOutOrderPay`,
    method: 'POST',
    data
  })
} 