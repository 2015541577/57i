import { getOrderinformation, submitOrder } from './service';
import { tradePay } from '../../utils/openApi';
import Taro from '@tarojs/taro';
export default {
    namespace: 'buyout',
    state: {
        data: []
    },
    effects: {
        // 获取订单信息
        *getInformation({ payload, callback }, { call, put }) {
            const res = yield call(getOrderinformation, {orderId: payload});
            if (res.data.responseType == 'SUCCESS') {
                callback(res.data.data);
            }
        },
        // 提交支付订单
        *onPutorder({ payload, callback }, { call, put }) {
            const res = yield call(submitOrder, payload);
            if (res.data.responseType == 'SUCCESS') {
                // 无需支付，为空
                // if(!res.data.data.payUrl){
                //     callback && callback()
                //     return
                // }
                // const payres = yield tradePay('orderStr', res.data.data.payUrl, 'TradeAppPay', res.data.data.serialNo);
               const payres = yield tradePay(
                "tradeNO",
                res.data.data.tradeNo,
                "TradeAppPay",
                res.data.data.serialNo
              );
                if (payres.resultCode == '9000') {
                    callback && callback()
                }
                else {
                    Taro.showToast({
                        title: '支付失败',
                        icon: 'none',
                    });
                }
            }
            else if (res.code == 200) {
                Taro.showToast({
                    title: '买断订单已受理',
                    icon: 'none',
                });
                Taro.redirectTo({
                    url: '/pages/orderList/index?type=all'
                })
            }
            else {
                Taro.showToast({
                    title: '订单不支持买断,请联系客服人员！',
                    icon: 'none',
                });
            }
        }
    },
    reducers: {
    }
};
