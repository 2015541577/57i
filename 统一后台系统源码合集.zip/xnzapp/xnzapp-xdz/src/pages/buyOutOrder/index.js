import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { AtIcon, AtFloatLayout } from 'taro-ui'
import { getGloble,getBuyerId } from '../../utils/localStorage';
import './index.scss';
@connect(({ buyout }) => ({ ...buyout }))
class Buyoutorder extends Component {
    config = {
        navigationBarTitleText: '买断',
    };
    state = {
        inforMation: {},
        showQuanCoupons: false,
        couponId: ''
    };
    onBuyout = () => {
        const { orderId } = this.$router.params;
        const { dispatch } = this.props;
        dispatch({
            type: 'buyout/onPutorder',
            payload: {
                orderId: orderId,
                couponId: this.state.couponId,
                buyerId: getBuyerId(),
                channelId: getGloble('channelId')
            },
            callback: (res) => {
                Taro.redirectTo({
                    url: '/pages/orderList/index?type=all'
                })
            }
        })
    }
    // 点击更多优惠券
    changeCoupon(couponsLen){
        const { sign } = this.$router.params;
        if(sign === '0'){
            return
        }
        if(couponsLen < 1){
            return
        }
        this.setState({ showQuanCoupons: true });
    }
    // 改变优惠券时
    couponChangeClick(defaultCode, code, item){
        if(defaultCode === code){
            return
        }
        const inforMation = {...this.state.inforMation}
        // 不使用优惠券
        if(!code){
            inforMation.needPay = inforMation.endFund
        }else{
            const discountAmount = item.discountAmount
            inforMation.needPay = inforMation.endFund - discountAmount
        }
        inforMation.couponCode = code || ''
        inforMation.couponAmount = item.discountAmount || 0

        this.setState({
            inforMation,
            couponId: code || ''
        })

        this.hideQuanCoupons()
    }
    hideQuanCoupons(){
        this.setState({ showQuanCoupons: false });
    }

    componentDidMount() {
        const { orderId, userOrderBuyOutDto } = this.$router.params;
        const { dispatch } = this.props;

        if(userOrderBuyOutDto){
            // 查看操作
            const userOrderBuyOutData = JSON.parse(userOrderBuyOutDto)
            this.setState({
                inforMation: userOrderBuyOutData
            })
        }else{
            // 买断操作
            dispatch({
                type: 'buyout/getInformation',
                payload: orderId,
                // payload: '12004161631398934612041729',
                callback: (res) => {
                    this.setState({
                        inforMation: res,
                        couponId: res.couponCode || ''
                    })
                }
            })
        }
    }
    render() {
        const { inforMation: { productName, couponAmount, couponReduction, couponCode, orderCouponDtos, paidRent, skuTitle, totalRent, endFund, dueBuyOutAmount, paid, images, deposit, needPay } } = this.state;
        const { sign } = this.$router.params;
        return (
            <View className='tenants-wrap'>
                <View className="tenants-content">
                    <View className="header-product">
                        <View className='headerWrap'>
                            <View>
                                {
                                    !!images ? <Image className='headerImg' src={images} /> : null
                                }
                            </View>
                            <View className='right'>
                                <View className='leftText'>{!!productName ? productName : null}</View>
                                <View className='rightText'>规格：{!!skuTitle ? skuTitle : null}</View>
                            </View>
                        </View>
                        <View className='headerFooter'>总租金：<Text className="price-text">￥{!!totalRent ? totalRent : 0}</Text></View>
                    </View>
                    <View className='fill'></View>
                    <View className="header-price">
                        <View className='buyoutPayment'>
                            <Text>当前买断尾款</Text>
                            <Text className='textbig'>￥{!!endFund ? endFund : 0}</Text>
                        </View>
                        {
                            true
                                ? (
                                    <View className='buyoutPayment'>
                                        <Text>到期买断尾款</Text>
                                        <Text className='textbig'>￥{!!dueBuyOutAmount ? dueBuyOutAmount : 0}</Text>
                                    </View>
                                )
                                : ''
                        }
                        <View className='buyoutPayment' onClick={() => this.changeCoupon(orderCouponDtos.length || 0)}>
                            <Text>优惠券优惠</Text>
                            <Text className='textes text-red'>
                                ￥{sign === '1' ? (!!couponAmount ? couponAmount : 0) : (!!couponReduction ? couponReduction : 0)}
                                {
                                    sign === '1'
                                        ? <AtIcon value='chevron-right' size='18' color='#666' />
                                        : ''
                                }
                            </Text>
                        </View>
                        <View className='buyoutPayment'>
                            <Text className='c-9'>已付租金</Text>
                            <Text className='textes c-9'>￥{sign === '1' ? (!!paid ? paid : 0) : (!!paidRent ? paidRent : 0)}</Text>
                        </View>
                    </View>
                    <View className='fillsize'></View>
                </View>
                {
                    sign === '1'
                        ? <View className='foooterButton'>
                            <View className='footerLeft'>
                                <Text>总计：</Text>
                                <Text className='text'>￥{(!!needPay && needPay > 0) ? needPay : 0}</Text>
                            </View>
                            <Text onClick={this.onBuyout} className='button'>确定买断</Text>
                        </View>
                        : null
                }
                <View className='bill-plan2'>
                    <AtFloatLayout
                        isOpened={this.state.showQuanCoupons}
                        onClose={() => this.hideQuanCoupons()}
                        className='product-float'
                    >
                        {
                            orderCouponDtos && orderCouponDtos.map((item,index) =>
                                <View key={index+'df'} onClick={() => this.couponChangeClick(couponCode, item.code, item)} className="coupon-item">
                                <View>
                                    <Text className="item-left-1">减{item.discountAmount}: </Text>
                                    <Text className="item-left-2">{item.minAmount==0?'无门槛':('满 '+item.minAmount)}减{item.discountAmount}</Text>
                                </View>
                                {
                                    couponCode === item.code
                                    ? <Image mode="aspectFit" className="coupon-icon" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ed2961f6c99f4436a813519dac0afc5a.png" />
                                    : <Image mode="aspectFit" className="coupon-icon" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/f59346069ae8481488a5879d5aa90526.png" />
                                }
                                </View>
                            )
                        }
                        <View className="coupon-item" onClick={() => this.couponChangeClick(couponCode, '', {})}>
                            <View>
                                <Text className="item-left-1">不使用优惠券</Text>
                            </View>
                            {
                                couponCode == ''
                                    ? <Image mode="aspectFit" className="coupon-icon" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/f39e8ad045204cbb9bfed7853af89b3f.png" />
                                    : <Image mode="aspectFit" className="coupon-icon" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d8b342f7ea924c99915e1d08a47c58bd.png" />
                            }
                        </View>
                        <View className="item-close-btn" onClick={() => this.hideQuanCoupons()}>关闭</View>
                    </AtFloatLayout>
                    </View>
            </View>
        )
    }
}

export default Buyoutorder;
