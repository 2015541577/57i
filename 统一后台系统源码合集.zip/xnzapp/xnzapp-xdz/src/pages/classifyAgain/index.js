import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import {
  getGloble,
  getUid
} from '../../utils/localStorage.js';
import Search from '../home/component/search/index';
import Request from "../../utils/request";
import umUpload from "../../utils/umengUploadData";
import { abilityNewPhone, abilitySecondHand } from '../../utils/constant';
import './index.scss';

@connect(({ classify,productList, home, loading }) => ({
  ...home,
  ...classify,
  ...productList,
  loading: loading.models.productList,
}))
class classifyAgain extends Component {
  config = {
    navigationBarTitleText: '分类',
    usingComponents: {
      "popup": "../../npm/mini-antui/es/popup/index"
    },
    titleBarColor: "#AEABCD",
    allowsBounceVertical:"NO",
  };
  activeMenuId = ''; // 当前选中菜单的id
  state = {
    // 是否展开全部
    activeMenuIndex: 0, // 当前选中的menu的index
    currentMenu: null,
    bannerIcon: '',

    // 是否显示筛选项
    showPopup: false,
    oldNewDegreeStatus: null,
    priceSort: null,
    salesSort: null,
    minRentCycleDays: null,
    minPrice: null,
    maxPrice: null,
    logisticsService: null,
    categoryId: null,
    // 是否显示排序筛选页面
    topMenuShow: false,
    // 筛选品牌list
    rightLists: [],
    // 初始化时的类目id
    // initCategoryId: '',
    // 加入页面的渠道，category-类目；search-搜索
    intType: '',
    menuListIndex:0, // 顶部定位index
    scrollTop:100,
    activeMenuIndexTs:null, // 筛选中 暂存坐标
    guangGao_token:null,
  };

  componentDidShow() {
    // const { id,index } = this.$router.params;
    // const obj = {
    //   id:id,
    // };
    // if(id) {
    //   Taro.setStorageSync(`classifyNew_index`, index);
    //   Taro.setStorageSync(`classifyNew_id`, id);
    //   this.activeMenuIndexChange(index, obj);
    //   // this.setState({ activeMenuIndex: index });
    // }else if(Taro.getStorageSync('classifyNew_id')) {
    //   const objs = {
    //     id:Taro.getStorageSync('classifyNew_id'),
    //   };
    //   this.activeMenuIndexChange(Taro.getStorageSync('classifyNew_index'), objs);
    // }
  }
  /**
   * 跳转到商品详情页面
   * @param {*} itemId : 商品ID
   */
   onGotoProduct = (itemId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}`});
  };
  // menu激活项改变
  activeMenuIndexChange(index, item) {
    const { dispatch } = this.props;
    // 获取筛选中分类列表
    if(this.props.rightList[index]) {
      const newQueryInfo = {
        oldNewDegreeStatus: null,// 新旧排序
        priceSort: null,  // 价格排序
        salesSort: null,  // 销量排序
        minRentCycleDays: null, // 起租天使
        minPrice: null, // 最小价格
        maxPrice: null, // 最大价格
        logisticsService: null, // 物流服务
        categoryId: null, // 类目
        // orderBy: null, // 排序规则 asc  desc  升序降序
        // oldNewDegreeStatus: null, // 全新二手 0全新,1二手
        content: null, // 搜索内容
        pageNumber: 1,
        pageSize: 10,
      };
      dispatch({
        type: 'productList/fetchSubCategoryList',
        payload: { categoryId: this.props.rightList[index].parentId },
        callback: (list) => {
          const rightList = []
          list.map((item, index) => {
            if(index % 3 === 0){
              const lastIndex = rightList.length
              rightList[lastIndex] = [item]
            }else{
              const lastIndex = rightList.length - 1
              rightList[lastIndex].push(item)
            }
          })
          this.setState({
            rightLists:rightList,
            activeMenuIndex:index,
            categoryId:item.id,
            // scrollTop:2,
          })
        }
      });
      newQueryInfo.categoryId = item.id;
      this.setDispatch(newQueryInfo);
    }
    // -----------------
    // ------------------------------------------
    // const info = { 
    //   categoryId: item.id,
    //   intType: "category",
    //   pageNumber: 1,
    //   pageSize: 10,
    //   uid: getUid()
    // };
    // dispatch({
    //   type: 'productList/fetchProductList',
    //   payload: { ...info },
    // });
    // this.setState({
    //   activeMenuIndex:index
    // })
  }
  /**
   * 合成请求下一页产品数据接口所需要的参数，发起请求
   * @param {*} queryInfo
   * @param {*} fetchType
   */
   setDispatch(queryInfo, fetchType) {
    // const { dispatch } = this.props;
    // const info = { ...queryInfo };
    // if (fetchType === 'scroll') {
    //   info.pageNumber += 1;
    //   info.fetchType = fetchType;
    //   info.intType = "category";
    //   info.uid= getUid();
    // }
    // info.tabId = this.activeMenuId;
    // dispatch({
    //   type: 'productList/fetchProductList',
    //   payload: { ...info },
    // });
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === 'scroll') {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    info.intType = this.state.intType
    const { useLoc } = this.$router.params;
    if (useLoc === abilityNewPhone || useLoc === abilitySecondHand) {
      info.type = useLoc;
      info.isAbility = true;
    }
    dispatch({
      type: 'productList/fetchProductList',
      payload: { ...info },
    });
  }
  onClickChannel = () => {
    const { total, queryInfo, queryInfo: { pageNumber, pageSize } } = this.props;
    if (pageNumber * pageSize - total >= 0) {
      this.activeMenuIndexChange(this.state.activeMenuIndex + 1, this.props.rightList[this.state.activeMenuIndex + 1])
      this.setState({
        activeMenuIndex: this.state.activeMenuIndex + 1,
        // scrollTop:0,
      })
      if(total >= 10 ){
        setTimeout(() => {
          // 1秒后执行
          this.setState({
            scrollTop:1,
          })
        }, 500);
        setTimeout(() => {
          // 1秒后执行
          this.setState({
            scrollTop:0,
          })
        }, 1000);
      }
    }
    this.setDispatch(queryInfo, 'scroll');
  }
  /**
   * scrollView的下拉加载更多动作
   */
   onScrollToLower = () => {
    const { total, queryInfo, queryInfo: { pageNumber, pageSize } } = this.props;
    const totals=pageNumber * pageSize - total
    // if (totals <=5) {
    //   if(totals >=0 && total >4){
    //   if(this.props.rightList[this.state.activeMenuIndex + 1]) {
    //     this.activeMenuIndexChange(this.state.activeMenuIndex + 1, this.props.rightList[this.state.activeMenuIndex + 1])
    //     this.setState({
    //       activeMenuIndex: this.state.activeMenuIndex + 1,
    //       // scrollTop:0,
    //     })
    //     if(total >= 10 ){
    //       setTimeout(() => {
    //         // 1秒后执行
    //         this.setState({
    //           scrollTop:1,
    //         })
    //       }, 500);
    //       setTimeout(() => {
    //         // 1秒后执行
    //         this.setState({
    //           scrollTop:0,
    //         })
    //       }, 1000);
    //     }
    //   }
    //   Taro.showToast({
    //   title: '更多商品，敬请期待！',
    //   icon: 'none',
    //   duration: 1000,
    //   });
    //   return;
    // }
    this.setDispatch(queryInfo, 'scroll');
  };
  // componentDidMount = () => {
  //  onShow
	componentDidShow = () => {
    // const { id,index,tertiary,tertiaryIndex } = this.$router.params;
    // const { dispatch } = this.props;
    // 获取缓存埋点
    const { gg_id } = (this.$router.params)
    // Taro.removeStorageSync(gg_id);
    if(gg_id != undefined && gg_id != null && gg_id.length>0){
      // 进入条件：从外部进入 有gg_id

      // Taro.removeStorageSync(gg_id);
      
      // 获取历史缓存的gg_id
      const data = Taro.getStorageSync(gg_id);
      if(data != null && data.length>0){
        // 历史缓存中有数据的情况进入
        this.state.guangGao_token = JSON.parse( data);
      }
      
      const obj_current={
        gg_id:gg_id,
        time:new Date()
      }
      Taro.setStorageSync("current_gg_id",JSON.stringify(obj_current));

      if(this.state.guangGao_token == null){
        // 没有历史缓存的情况
        //本地没有用户token和time
        Request({
          url: `hzsx/llxzu/guanggao/add_guanggao_token`,
          method: "GET",
          data:{
            // 此时gg_id是跳转传参
            gg_id:gg_id 
          }
        }).then(res=>{
          const token = res.data.data
          const obj={
            token:token,
            time:new Date()
          }
          // 没有历史缓存 请求接口获取token和time 进行缓存
          Taro.setStorageSync(gg_id,JSON.stringify(obj));
          // 再次获取历史缓存
          const data = Taro.getStorageSync(gg_id);
          if(data != null && data.length>0){
            // 判断如果有token和time给guanggao_token赋值
            this.state.guangGao_token = JSON.parse( data);
          }
        });
      }else{
        // 有历史缓存
        // 如果有
        let that  = this;
        Request({
              url: `/hzsx/llxzu/guanggao/set_guanggao_cont`,
              method: "GET",
              data:{
                user_token: that.state.guangGao_token.token 
              }
        }).then(res=>{
          if(gg_id) {
            if(!res.data.data) {
              Taro.removeStorageSync(gg_id);
              Request({
                url: `hzsx/llxzu/guanggao/add_guanggao_token`,
                method: "GET",
                data:{
                  product_id: product_id ,
                  // 此时gg_id是跳转传参
                  gg_id:gg_id 
                }
              }).then(res=>{
                const token = res.data.data
                const obj={
                  token:token,
                  time:new Date()
                }
                // 没有历史缓存 请求接口获取token和time 进行缓存
                Taro.setStorageSync(gg_id,JSON.stringify(obj));
                // 再次获取历史缓存
                const data = Taro.getStorageSync(gg_id);
                if(data != null && data.length>0){
                  // 判断如果有token和time给guanggao_token赋值
                  that.state.guangGao_token = JSON.parse( data);
                }
              });
            }
          }
        })
      }
      
    }
    
  };
  // 对应 onLoad
	componentWillMount = () => {
    const { id,index,tertiary,tertiaryIndex } = this.$router.params;
    const { dispatch } = this.props;
    const newQueryInfo = {
      oldNewDegreeStatus: null,// 新旧排序
      priceSort: null,  // 价格排序
      salesSort: null,  // 销量排序
      minRentCycleDays: null, // 起租天使
      minPrice: null, // 最小价格
      maxPrice: null, // 最大价格
      logisticsService: null, // 物流服务
      categoryId: null, // 类目
      // orderBy: null, // 排序规则 asc  desc  升序降序
      // oldNewDegreeStatus: null, // 全新二手 0全新,1二手
      content: null, // 搜索内容
      pageNumber: 1,
      pageSize: 10,
    };
    // 老分类接口
    dispatch({
      type: 'classify/fetchCategoryList',
      payload: { categoryId: 0 },
      callback: (secondId, bannerIcon) => {
        let categoryId = secondId;
        if (Number(id)) {
          categoryId = id;
          this.setState({
            menuListIndex:parseInt(index)
          })
        }
        dispatch({
          type: 'classify/fetchCategoryList',
          payload: { categoryId },
          callback:()=>{
            this.setState({
              currentMenu: categoryId,
              bannerIcon,
              intType:"category",
            });
            if(this.props.rightList.length > 0 ) {
              // 获取筛选中分类列表
              dispatch({
                type: 'productList/fetchSubCategoryList',
                payload: { categoryId: tertiary ? tertiary : this.props.rightList[0].parentId },
                callback: (list) => {
                  const rightList = []
                  list.map((item, index) => {
                    if(index % 3 === 0){
                      const lastIndex = rightList.length
                      rightList[lastIndex] = [item]
                    }else{
                      const lastIndex = rightList.length - 1
                      rightList[lastIndex].push(item)
                    }
                  })
                  // 判断是否有下表
                  if(tertiaryIndex) {
                    this.setState({
                      activeMenuIndex:tertiaryIndex
                    })
                  }
                  this.setState({
                    rightLists:rightList,
                    categoryId: tertiary ? tertiary : this.props.rightList[0].id,
                  })
                }
              });
              // -----------------
              newQueryInfo.categoryId = tertiary ? tertiary : this.props.rightList[0].id;
              this.setDispatch(newQueryInfo);
            }
            // 请求第一个商品分类的商品
            // if(this.props.rightList.length > 0 ) {
            //   const info = {
            //     categoryId: this.props.rightList[0].id,
            //     intType: "category",
            //     // pageNumber: 1,
            //     // pageSize: 10,
            //     uid: getUid(),
            //     ...newQueryInfo
            //   };
            //   dispatch({
            //     type: 'productList/fetchProductList',
            //     payload: { ...info },
            //   });
            // }
          }
        });
      },
    });
  }
  handleClickMenu = (id, bannerIcon,index) => {
    const { dispatch } = this.props;
    const { currentMenu } = this.state;
    const newQueryInfo = {
      oldNewDegreeStatus: null,// 新旧排序
      priceSort: null,  // 价格排序
      salesSort: null,  // 销量排序
      minRentCycleDays: null, // 起租天使
      minPrice: null, // 最小价格
      maxPrice: null, // 最大价格
      logisticsService: null, // 物流服务
      categoryId: null, // 类目
      // orderBy: null, // 排序规则 asc  desc  升序降序
      // oldNewDegreeStatus: null, // 全新二手 0全新,1二手
      content: null, // 搜索内容
      pageNumber: 1,
      pageSize: 10,
    };
    if (currentMenu === id) {
      return;
    }
    dispatch({
      type: 'classify/clearRightList',
    });
    this.setState({
      currentMenu: id,
      bannerIcon:bannerIcon,
      menuListIndex:index
    });
    dispatch({
      type: 'classify/fetchCategoryList',
      payload: { categoryId: id },
      callback:()=>{
        this.setState({
          currentMenu: id,
          bannerIcon,
          intType:"category",
        });
        if(this.props.rightList.length > 0 ) {
          // 获取筛选中分类列表
          dispatch({
            type: 'productList/fetchSubCategoryList',
            payload: { categoryId: this.props.rightList[0].parentId },
            callback: (list) => {
              const rightList = []
              list.map((item, index) => {
                if(index % 3 === 0){
                  const lastIndex = rightList.length
                  rightList[lastIndex] = [item]
                }else{
                  const lastIndex = rightList.length - 1
                  rightList[lastIndex].push(item)
                }
              })
              this.setState({
                rightLists:rightList,
                activeMenuIndex:0,
                categoryId:this.props.rightList[0].id
              })
            }
          });
          // -----------------
          newQueryInfo.categoryId = this.props.rightList[0].id;
          this.setDispatch(newQueryInfo);
        }
      }
    });
  }
  handleClickDegree = (type) => {
    const { queryInfo } = this.props;
    const newQueryInfo = { ...queryInfo, pageNumber: 1, pageSize: 10 };

    // 切换排序选项
    if (queryInfo[type] === 0) {
      newQueryInfo[type] = 1
    } else if (queryInfo[type] === 1) {
      newQueryInfo[type] = null
    } else {
      newQueryInfo[type] = 0
    }

    this.setDispatch(newQueryInfo);
  }
  // 点击确定-筛选
  handleFilterOk = () => {
    let { minPrice, maxPrice, minRentCycleDays, logisticsService, categoryId, initCategoryId } = this.state;
    const { queryInfo } = this.props;

    // 没选择类目则用初始类目
    // categoryId = categoryId || initCategoryId
    // const newQueryInfo = { ...queryInfo, minPrice, maxPrice, minRentCycleDays, logisticsService, categoryId: categoryId + '' };
    const newQueryInfo = { ...queryInfo, minPrice, maxPrice, minRentCycleDays, logisticsService, categoryId: categoryId };
    this.setDispatch(newQueryInfo);
    this.setState({ showPopup: false });
    if(this.state.activeMenuIndexTs != null){
      this.setState({
        activeMenuIndex:this.state.activeMenuIndexTs,
        activeMenuIndexTs:null
      })
    }
  }
  handleClickFilter = () => {
    this.setState({ showPopup: true });
  }
  onPopupClose = () => {
    this.setState({ showPopup: false });
  }
  // 点击筛选项
  handleChoicedClick = (val, key,index,index2) => {
    if(key == "categoryId"){
      for (let i = 0; i < this.props.rightList.length; i++) {
        const item = this.props.rightList[i];
        if(item.id == val){
          this.setState({
            activeMenuIndexTs:i
          })
        }
      }
    }
    this.setState({
      [`${key}`]: val
    })
  }
  // 价格区间切换
  priceChage(key, e){
    const val = e.currentTarget.value
    this.setState({
      [`${key}`]: val
    })
  }
  // 点击重置-筛选
  handleFilterCancel = () => {
    this.setState({
      minPrice: null,
      maxPrice: null,
      minRentCycleDays: null,
      logisticsService: null,
      // categoryId: this.state.initCategoryId
      categoryId: this.props.rightList[0].id,
      activeMenuIndexTs:0
    });
  }
  // 跳转去产品列表
  // handleClickRight = (item) => {
  //   let { currentMenu } = this.state;
    
  //   Taro.navigateTo({ 
  //     url: `/pages/productList/index?type=category&catId=${item.id}&catName=${item.name}&currentMenu=${currentMenu}`
  //   });
  // }
  /**
   * 当菜单处于第一个焦点的时候，会显示banner
   * 点击banner触发该方法
   * @param {*} url
   */
  //  onGoToMore = (url) => {
  //   if (url.indexOf('alipays://') === 0) {
  //     redirectToOtherMiniProgram(url);
  //   } else {
  //     if (url == '/SharingRentFree/sharerent/index') {
  //       this.onShare();
  //     } else {
  //       Taro.navigateTo({ url });
  //     }
  //   }
  // };

  // 监听点击tab栏，进行事件上报。这是个页面周期方法，试了下在app.js写无效，得复制到各个tab页面中
  // onTabItemTap(object) {
  //   umUpload.bottomNavClickHandler(object);
  // }
  	/**
	 * 判断数组是否能够用来进行渲染
	 * @param {Array} arr
	 */
	arrIsUseful = (arr) => arr && arr.length


  render() {
    const { rightList, loading, oldNewDegreeList,menuList ,list,queryInfo  } = this.props;
    let { currentMenu, bannerIcon,showPopup, rightLists,scrollTop } = this.state;
    // const { activeMenuIndex } = this.state;
    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='classify-page'>
        <View className='search-view'>
          <Search value='' useLoc="分类页面" />
        </View>
        <View className="classifyNew_main">
          <View className='classifyNew_head'> 
            <ScrollView
              className="classifyNew_head_nav"
              scrollX
              scrollWithAnimation
            >
              {this.arrIsUseful(menuList) &&
              menuList.map((item,index) => (
                <View
                  className="home_img"
                  onClick={this.handleClickMenu.bind(this, item.id, item.bannerIcon, index)}
                >
                  <Image
                    lazyLoad={true}
                    className="nav_img"
                    src={item.icon}
                  />
                  {index === this.state.menuListIndex ? (
                    <View className="nav_title_b">{item.name}</View>
                  ) : (
                    <View className="nav_title_a">{item.name}</View>
                  )}
                </View>
              ))}
            </ScrollView>
          </View>
          <ScrollView className={'products-lists ' + 
              (this.state.getScrollTop
                      ? 'c_getScrollTop'
                      : '')} scrollY scrollWithAnimation  ref="myScrollView">
              {rightList.map((item, index) => (
                <View
                  className={
                    'products-item ' +
                    (index == this.state.activeMenuIndex
                      ? 'products-item-active'
                      : '')
                  }
                  key={'kk' + index}
                  onClick={() => this.activeMenuIndexChange(index, item)}
                >
                  {item.name}
                  {index == this.state.activeMenuIndex ? (
                    <View className="active-line"></View>
                  ) : null}
                </View>
              ))}
            </ScrollView>
            <View className="home-channel">
              {/* <Image className="channel_img"  src="../../images/common/jingpin.png"/> */}
              {/* 筛选功能 */}
              {/* <View className='top-menu' style={{display:this.state.topMenuShow?'flex':'none'}}> */}
              <View className='top-menu'>
                <View className='menu-item' onClick={() => this.handleClickDegree('oldNewDegreeStatus')}>
                  <View>新旧</View>
                  {queryInfo.oldNewDegreeStatus === null && (
                    <View className='default' />
                  )}
                  {queryInfo.oldNewDegreeStatus === 0 && (
                    <View className='new' />
                  )}
                  {queryInfo.oldNewDegreeStatus === 1 && (
                    <View className='old' />
                  )}
                </View>
                <View className='menu-item' onClick={() => this.handleClickDegree('priceSort')}>
                  <View>价格</View>
                  {queryInfo.priceSort === null && (
                    <View className='default' />
                  )}
                  {queryInfo.priceSort === 0 && (
                    <View className='new' />
                  )}
                  {queryInfo.priceSort === 1 && (
                    <View className='old' />
                  )}
                </View>
                <View className='menu-item' onClick={() => this.handleClickDegree('salesSort')}>
                  <View>销量</View>
                  {queryInfo.salesSort === null && (
                    <View className='default' />
                  )}
                  {queryInfo.salesSort === 0 && (
                    <View className='new' />
                  )}
                  {queryInfo.salesSort === 1 && (
                    <View className='old' />
                  )}
                </View>
                <View className='menu-item' onClick={this.handleClickFilter} >
                  <View>筛选</View>
                  <View className={(!!queryInfo.orderBy || !!queryInfo.minRentCycleDays) ? 'filter-action' : 'filter'} />
                </View>
              </View>
              <ScrollView
                className="channel_scroll"
                scrollY
                scrollWithAnimation
                // style={`height: ${scrollHeight}px;`}
                lowerThreshold={10}
                // scrollTop={this.state.scrollTop}
                scrollTop={scrollTop}
                scrollAnimationDuration={400}
                onScrollToLower={this.onScrollToLower}
                // onScroll={this.onScroll}
              >
                {!!list && !!list.length && list.map((product) => (
                  <View className="channel_list"  onClick={this.onGotoProduct.bind(this,product.itemId || product.productId,)}>
                    <Image
                      className="list_img"
                      mode="aspectFit"
                      src={product.image || product.src}
                    />
                    <View className="list_app">
                      <View className="list_text">{ product.title  || product.name }</View>
                      <View className="new-tags">
												{oldNewDegreeList[product.oldNewDegree-1] }
											</View>
                      <View className="list_money">
                      <Text className="box">
                        <Text className="unit">￥</Text>
                        <Text className="unit2">
                          {
                            String(
                              product.price || product.lowestSalePrice || 0
                            ).split(".")[0]
                          }
                        </Text>
                        <Text className="decimal">
                          {String(
                            product.price || product.lowestSalePrice || 0
                          ).split(".")[1]
                            ? `.${
                                String(
                                  product.price || product.lowestSalePrice || 0
                                ).split(".")[1]
                              }`
                            : ""}
                          </Text>
                          <Text className="unit"> /天</Text>
                        </Text>
                        <View className="list_button">立即免押</View>
                      </View>
                    </View>
                  </View>
                ))}
                {/* {!!list && list.length > 5 ? (
                  <View className='channel_bottom'>向上滑动，继续浏览！</View>
                ) : rightList[this.state.activeMenuIndex + 1] ? (
                  <View className='channel_bottoms'>
                    <View className='channel_bottoms_text' onClick={this.onClickChannel}>点击继续浏览！</View>
                  </View>
                ) : null} */}
                 <View className='channel_bottoms'>
                    <View className='channel_bottoms_text' onClick={this.onClickChannel}>点击继续浏览！</View>
                  </View>
                {/* {rightList[this.state.activeMenuIndex + 1] ? (
                  <View className='channel_bottoms'>
                    <View className='channel_bottoms_text' onClick={this.onClickChannel}>点击继续浏览！</View>
                  </View>
                ) : null} */}
              </ScrollView>
            </View>
            {/* 筛选弹框 */}
            <popup show={showPopup} disableScroll={false} position='right' zIndex={999} onClose={this.onPopupClose}>
              <View className='popup-right'>
                <ScrollView 
                  className='filter-info'
                  scrollY
                  scrollWithAnimation
                  scrollTop='0'
                  //style={`height: ${scrollHeight}px;`}
                >
                  <View className='lease-term'>
                    <View>品牌</View>
                    <View className='term-info'>
                      {
                        rightLists && rightLists.length && rightLists.map((item, index) => 
                          <View className='terms' key={"level1"+index}>
                            {
                              item && item.length && item.map((item2, index2) =>
                                <View
                                  key={'level2'+index2}
                                  className={`filter-botton right-margin ${categoryId === item2.id && 'filter-action'}`}
                                  onClick={this.handleChoicedClick.bind(this, item2.id, 'categoryId',index,index2)}
                                >
                                  {item2.name}
                                </View>
                              )
                            }
                          </View>
                        )
                      }
                    </View>
                  </View>
                  <View className='lease-term'>
                    <View>物流服务</View>
                    <View className='term-info'>
                      <View className='terms'>
                        <View
                          className={`filter-botton right-margin ${logisticsService === 'FREE' && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 'FREE', 'logisticsService')}
                        >
                          包邮
                        </View>
                        <View
                          className={`filter-botton left-margin ${logisticsService === 'PAY' && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 'PAY', 'logisticsService')}
                        >
                          到付
                        </View>
                        <View
                          className={`filter-botton left-margin ${logisticsService === 'SELF' && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 'SELF', 'logisticsService')}
                        >
                          自提
                        </View>
                      </View>
                    </View>
                  </View>
                  <View className='lease-term'>
                    <View>最低租期</View>
                    <View className='term-info'>
                      <View className='terms'>
                        <View
                          className={`filter-botton right-margin ${minRentCycleDays === 1 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 1, 'minRentCycleDays')}
                        >
                          1天
                        </View>
                        <View
                          className={`filter-botton right-margin ${minRentCycleDays === 3 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 3, 'minRentCycleDays')}
                        >
                          3天
                        </View>
                        <View
                          className={`filter-botton right-margin ${minRentCycleDays === 7 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 7, 'minRentCycleDays')}
                        >
                          7天
                        </View>
                      </View>
                      <View className='terms'>
                        <View
                          className={`filter-botton left-margin ${minRentCycleDays === 30 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 30, 'minRentCycleDays')}
                        >
                          1个月
                        </View>
                        <View
                          className={`filter-botton right-margin ${minRentCycleDays === 90 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 90, 'minRentCycleDays')}
                        >
                          3个月
                        </View>
                        <View
                          className={`filter-botton left-margin ${minRentCycleDays === 180 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 180, 'minRentCycleDays')}
                        >
                          6个月
                        </View>
                      </View>
                      <View className='terms'>
                        <View
                          className={`filter-botton left-margin ${minRentCycleDays === 365 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 365, 'minRentCycleDays')}
                        >
                          1年
                        </View>
                        <View
                          className={`filter-botton right-margin ${minRentCycleDays === 730 && 'filter-action'}`}
                          onClick={this.handleChoicedClick.bind(this, 730, 'minRentCycleDays')}
                        >
                          2年
                        </View>
                      </View>
                    </View>
                  </View>
                  <View className='lease-term'>
                    <View>价格区间</View>
                    <View className='term-info-price'>
                      <Input type='number' onInput={e => this.priceChage('minPrice', e)} placeholder='最低价'/>
                      <Text> — </Text>
                      <Input type='number' onInput={e => this.priceChage('maxPrice', e)} placeholder='最高价'/>
                    </View>
                  </View>
                </ScrollView>
                <View className='popup-bottom'>
                  <View className='bottom-info' onClick={this.handleFilterCancel}>重置</View>
                  <View className='bottom-info bottom-confirm' onClick={this.handleFilterOk}>确定</View>
                </View>
              </View>
            </popup>
        </View>
      </View>
    )
  }
}

export default classifyAgain;
