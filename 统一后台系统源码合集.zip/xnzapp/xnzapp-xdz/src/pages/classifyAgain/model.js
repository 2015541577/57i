import * as classifyApi from './service';

export default {
  namespace: 'classify',
  state: {
    menuList: [],
    rightList: [],
  },

  effects: {
    // 获取分类列表
    *fetchCategoryList({ payload, callback }, { call, put }) {
      const res = yield call(classifyApi.selectReceptionCategoryList, {...payload, channel:2});
      if (res) {
        yield put({
          type: 'saveList',
          payload: { list: res.data.category, categoryId: payload.categoryId },
        });
        if (callback && res.data && res.data.category && res.data.category.length) {
          callback(res.data.category[0].id, res.data.category[0].bannerIcon);
        }
      }
    },
  },

  reducers: {
    saveList(state, { payload }) {
      let newMenuList = [...state.menuList];
      let newRightList = [...state.rightList];
      // 第一级
      if (payload.categoryId === 0) {
        newMenuList = payload.list;
      } else { // 第二级
        newRightList = payload.list;
      }
      return {
        ...state,
        menuList: newMenuList,
        rightList: newRightList,
      };
    },
    clearRightList(state) {
      return {
        ...state,
        rightList: [],
      };
    },
  },

};
