import Taro, { Component, Fragment } from '@tarojs/taro';
import { View, Input, Icon ,Image} from '@tarojs/components';
import TagPage from '../../../../components/service'
import { getGlobalData } from '../../../../utils/globalVariable'
import search from  '../../../../images/home/search_top.png'
import classfy from  '../../../../images/home/classfy_top.png'
import umUploadHandler from "../../../../utils/umengUploadData";

import './index.scss';

class Search extends Component {
  state = {
    // 弹窗显示
    isTagOpened: false,
  }

  skipToSearch = () => {
    umUploadHandler.searchClick(this.props.useLoc); // 友盟上报 搜索点击 事件
    // 使用navigateTo而非redirectTo，保留页面栈访问记录，避免跳转到搜索页面不出现上一页的返回按钮
    Taro.navigateTo({
      url: `/pages/search/index?useLoc=${this.props.useLoc}`,
    });
    // Taro.redirectTo({
    //   url: '/pages/search/index'
    // });
  }
  onPageScroll(e){
    const { searchScroll} = this.props
    searchScroll(e.scrollTop)
  }

   // 打开弹窗
   handleService = () => {
    this.setState({
      isTagOpened: true
    })
  }
  // 关闭弹窗
  handleClose = () => {
    this.setState({
      isTagOpened: false
    })
  }

  render() {
    const { value } = this.props;
    return (
      <Fragment>
        <View  className='search-com'>
          <View className='search_r' onClick={this.skipToSearch}>
          
             <Icon
              className='search-icon'
              type='search'
              size='16'
              color='#fff'
            />
            <Input
              name='search'
              type='text'
              className='search-input'
              placeholder='搜索宝贝,开启租赁新生活'
              placeholderClass="placeholder_class"
              disabled={true}
              value={value}
            />
          </View>
          {/* <View onClick={this.handleService} className='c_class-img'>
            <Image
              className='class-img'
            />
          </View> */}
        </View>
        <TagPage
          onClose={this.handleClose}
          isOpened={this.state.isTagOpened}
          //44"
          // data={product && product.shop && product.shop.serviceTel}
        />
      </Fragment>
    )
  }
}

export default Search;
