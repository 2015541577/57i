/**
 * 这是商品列表组件
 */

import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, Form } from "@tarojs/components";
import { AtIcon } from "taro-ui";
import "./index.scss";

class Search extends Component {
  handleGotoProduct(itemId) {
    const { onGotoProduct } = this.props;
    onGotoProduct(itemId);
  }

  handleGotoMore(url) {
    const { onGoToMore } = this.props;
    onGoToMore(url);
  }
  render() {
    const { products, tab, oldNewDegreeList } = this.props;

    return (
      <View className="channel">
        <View className="channel-list">
          {!!products &&
            !!products.length &&
            products.map((product) => (
              <View
                key={product.itemId || product.productId}
                className="channel-list-item"
                onClick={this.handleGotoProduct.bind(
                  this,
                  product.itemId || product.productId,
                )}
              >
                <View className="channel-list-item-img">
                  <Image
                    className="channel-list-item-img-box"
                    mode="aspectFit"
                    src={product.image || product.src}
                  />
                </View>
                <View className="channel-list-item-title">
                  <View className="title">
                    <Text className="name">
                      {
                        oldNewDegreeList[product.oldNewDegree - 1] && <Text className="new-tags">{oldNewDegreeList[product.oldNewDegree - 1]}</Text>
                      }
                      <Text className="product-name">{ product.title  || product.name }</Text>
                    </Text>
                  </View>
                  <View className="price">
                    <Text className="box">
                      <Text className="unit">￥</Text>
                      <Text className="unit2">
                        {
                          String(
                            product.price || product.lowestSalePrice || 0
                          ).split(".")[0]
                        }
                      </Text>
                      <Text className="decimal">
                        {String(
                          product.price || product.lowestSalePrice || 0
                        ).split(".")[1]
                          ? `.${
                              String(
                                product.price || product.lowestSalePrice || 0
                              ).split(".")[1]
                            }`
                          : ""}
                      </Text>
                      <Text className="unit"> /天</Text>
                    </Text>
                    {/* <Text className="sellnum">
                      销量 {product.salesVolume || 0}
                    </Text> */}
                  </View>
                </View>
              </View>
            ))}
        </View>
      </View>
    );
  }
}

export default Search;
