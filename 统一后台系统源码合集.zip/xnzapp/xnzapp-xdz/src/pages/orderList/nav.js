import menu from "../mine/menu";
const nas = [
  {
    id: "",
    text: "全部",
  },
  {
    id: 'payment',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3ea7e53762304a20811675625747a25e.png',
    text: '待下单',
    cname: 'WAITING_PAYMENT',
  },
  {
    id: 'deliver',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/94acc9ceb67440769665977effb46609.png',
    text: '待发货',
    cname: 'PENDING_DEAL',
  },
  {
    id: 'receipt',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/229c9d3b892f4e94a093098f3a393300.png',
    text: '待收货',
    cname: 'WAITING_USER_RECEIVE_CONFIRM',
  },
  {
    id: 'rent',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/99028e908a2f49e3830902caac6da40d.png',
    text: '租用中',
    cname: 'RENTING',
  },
  {
    id: 'settle',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/267cb238afa04619a77d0d54424545d5.png',
    text: '待结算',
    cname: 'WAITING_SETTLEMENT_PAYMENT',
  },
  {
    id: 'overdue',
    iconUrl: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6990796fb65a4bbaa797ca78e404de2f.png',
    text: '已逾期',
    cname: 'OVER_DUE',
  },
];
const nav = [...menu];
nav.unshift({
  id: "all",
  text: "全部",
});

export default nav;
