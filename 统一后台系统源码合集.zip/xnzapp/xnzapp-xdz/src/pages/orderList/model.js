import * as orderListApi from "./service";
import { getGloble,getUid } from "../../utils/localStorage";
import * as orderDetailApi from "../orderDetail/service";
import Taro from "@tarojs/taro";
import { tradePay } from "../../utils/openApi";
export default {
  namespace: "orderList",
  state: {
    queryInfo: {
      status: [],
      pageNumber: 1,
      pageSize: 10,
    },
    total: 0,
    list: [],
    sysConfigValue: null,
  },

  effects: {
    // 获取订单列表
    *fetchUserOrderList({ payload }, { call, put }) {
      payload = payload || {};
      payload.channelIdList = [getGloble('channelId')];

      const statusObj = {
        WAITING_PAYMENT: "01",
        PAYING: "02",
        PAYED_USER_APPLY_CLOSE: "03",
        PENDING_DEAL: "04",
        WAITING_USER_RECEIVE_CONFIRM: "05",
        RENTING: "06",
        WAITING_SETTLEMENT: "07",
        WAITING_SETTLEMENT_PAYMENT: "08",
        FINISH: "09",
        CLOSED: "10",
        OVER_DUE: "11",
      };
      if (payload.status && payload.status.length) {
        const status = [];
        payload.status.map((item) => {
          status.push(statusObj[item] || item);
        });
        payload.statusList = status;
      }

      let res = yield call(orderListApi.userOrderList, {
        ...payload,
        uid: getUid(),
      });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        if (payload.fetchType === "scroll") {
          yield put({
            type: "concatOrderList",
            payload: res.data,
          });
        } else {
          yield put({
            type: "saveOrderList",
            payload: { data: res.data, queryInfo: payload },
          });
        }
      }
    },
    // 购买订单
    *userOrdersPurchase({ payload }, { call, put }) {
      let res = yield call(orderListApi.userOrdersPurchase, {
        ...payload,
        uid: getUid(),
      });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        if (payload.fetchType === "scroll") {
          yield put({
            type: "concatOrderList",
            payload: res.data,
          });
        } else {
          yield put({
            type: "saveOrderList",
            payload: { data: res.data, queryInfo: payload },
          });
        }
      }
    },
    // 获取系统信息
    *getSysConfigByKey({ payload }, { call, put }) {
      const res = yield call(orderListApi.getSysConfigByKey, { ...payload });
      if (res) {
        yield put({
          type: "sysConfigValue",
          payload: res.data.sysConfigValue,
        });
      }
    },
    // demo
    *effectsDemo(_, { call, put }) {
      const { status, data } = yield call(orderListApi.demo, {});
      if (status === "ok") {
        yield put({
          type: "save",
          payload: {
            topData: data,
          },
        });
      }
    },
    // 取消订单
    *userCancelOrderSendMsg({ payload, callback }, { call, put }) {
      const res = yield call(orderListApi.userCancelOrderSendMsg, payload);
      if (res) {
        const nextStatus = "10";
        if (res.code === 1) {
          Taro.showToast({
            title: "取消成功",
            icon: "none",
          });
        }
        yield put({
          type: "orderList/setOrderStatus",
          payload: {
            orderId: payload.orderId,
            status: "10",
          },
        });
        if (callback) {
          callback();
        }
      }
    },
    // 取消购买订单
    *userOrdersPurchasecancel({ payload, callback }, { call, put }) {
      const res = yield call(orderListApi.userOrdersPurchasecancel, payload);
      if (res) {
        if (res.data.data) {
          Taro.showToast({
            title: "取消成功",
            icon: "none",
          });
          if (callback) {
            callback();
          }
        } else {
          Taro.showToast({
            title: res.data.data.errorMessage,
            icon: "none",
          });
          if (callback) {
            callback();
          }
        }
      }
    },
    // 购买订单收货
    *userOrdersPurchasereceipt({ payload, callback }, { call, put }) {
      const res = yield call(orderListApi.userOrdersPurchasereceipt, payload);
      if (res) {
        if (res.data.data) {
          Taro.showToast({
            title: "确认成功",
            icon: "none",
          });
          if (callback) {
            callback();
          }
        } else {
          if (callback) {
            callback();
          }
        }
        if (callback) {
          callback();
        }
      }
    },
    // 购买订单-再次支付
    *userOrdersPurchasepayAgain({ payload, callback }, { call }) {
      const api = orderListApi.userOrdersPurchasepayAgain;

      let res = yield call(api, { ...payload });
      res = res.data;
      if (res) {
        try {
          const payres = yield tradePay(
            "tradeNO",
            res.data.payUrl,
            "Freeze",
            res.data.serialNo
          );
          // 支付成功进入订单详情页，失败则进入订单列表页
          let type = "detail";
          if (payres.resultCode !== "9000") {
            payres.memo &&
              Taro.showToast({
                title: payres.memo,
                icon: "none",
              });
            type = "list";
          }
          if (callback) {
            callback(payload.orderId, type);
          }
        } catch (e) {
          Taro.showToast({
            title: "授权失败，请重试或联系客服",
            icon: "none",
          });
        }
      }
    },
    // 获取用户认证信息
    *getCardinformation({ payload, callback }, { call, put }) {
      const res = yield call(orderListApi.selectUserCertification, {
        ...payload,
        uid: getUid(),
      });
      if (res.data.data) {
        callback(res.data.data);
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    sysConfigValue(state, { payload }) {
      return {
        ...state,
        sysConfigValue: payload,
      };
    },
    concatOrderList(state, { payload }) {
      const list = [...state.list];
      return {
        ...state,
        list: list.concat(payload.records || []),
        total: payload.total,
        queryInfo: {
          ...state.queryInfo,
          pageNumber: payload.current,
        },
      };
    },

    saveOrderList(state, { payload }) {
      return {
        ...state,
        list: payload.data ? payload.data.records : [],
        total: payload.data && payload.data.total,
        queryInfo: {
          ...payload.queryInfo,
          pageNumber: payload.data && payload.data.current,
        },
      };
    },

    setOrderStatus(state, { payload }) {
      let newList = [...state.list];
      // 全部订单修改状态，其他订单列表删除
      const index = newList.findIndex(
        (info) => info.orderId === payload.orderId
      );
      if (state.queryInfo.status && state.queryInfo.status.length) {
        newList.splice(index, 1);
      } else {
        newList[index] = { ...newList[index], status: payload.status };
      }
      return {
        ...state,
        list: newList,
      };
    },
  },
};
