import Taro, { Component } from "@tarojs/taro";
import { View, ScrollView, Text, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import {
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
  AtButton,
} from "taro-ui";
import ListItemCopy from "./components/listItemCopy/index";
import ListItem from "./components/listItem/index";

import NoData from "../../components/noData/index";

import OrderService from "service";

import CancelOrder from "../../components/cancelOrder";
import nav from "./nav";
import nas from "./navs";
import "./index.scss";
import { customerServiceTel, orderStatus } from "../../assets/Constant";
import TagPage from "../../components/service";
import umUploadHandler from "../../utils/umengUploadData";

import moment from "moment";
import { getGloble,getUid,getBuyerId, } from "../../utils/localStorage";
import { dateDiff, debounce,getSignUrl,schemeToParams } from "../../utils/utils";
import Request from '../../utils/request';
import { startAPVerify } from "../../utils/openApi";
const esignPlugin = requirePlugin("esign");

@connect(({ orderList, loading,confirmOrder,authentication }) => ({
  ...authentication,
  ...confirmOrder,
  ...orderList,
  loading: loading.models.orderList,
}))
class Orderlist extends Component {
  config = {
    navigationBarTitleText: "全部订单",
    usingComponents: {
      modal: "../../npm/mini-antui/es/modal/index",
      popover: "../../npm/mini-antui/es/popover/index",
      "popover-item": "../../npm/mini-antui/es/popover/popover-item/index",
    },
    // 下拉刷新配置
      enablePullDownRefresh: true,
      backgroundTextStyle: "dark",
      onReachBottomDistance: 50,
  };
  onPullDownRefresh() {
    console.log('下拉刷新')
    setTimeout(() => {
      // 停止下拉刷新
      Taro.stopPullDownRefresh()
    }, 1000)
}

onReachBottom() {
    console.log('触底事件，做上拉加载')
}

  needCancelOrder = {}; // 需要被取消的订单对象

  state = {
    type: "all",
    display: "block", // none -> 没数据隐藏
    cancelOrderDisplay: false,
    receiveDoodsDisplay: false,
    showServicePhone: false,
    canCel: false,
    examineStatus: null,
    stageBillModal: false,
    statusCance: null,
    isTagOpened: false,
    position: "bottomLeft",
    cancelOrderList: [
      {
        value: "想要重新下单",
      },
      {
        value: "商品价格较贵",
      },
      {
        value: "等待时机较长",
      },
      {
        value: "是想了解流程",
      },
      {
        value: "不想要了",
      },
    ],
    showMask: true,
    isCard: false,
    isCards: false,
    show: false,
    dinText: "租赁订单",
    arrow: "rotate(0deg)",
    showOnPayment:false, //选择支付方式弹框 预授权&蚂蚁代扣
    payment_id:1,
    showHint:false, //信用评估中弹窗
    newCountDownStr:null, //倒计时
    showRemind:false, //提示弹窗
    newOrderId:null, //储存订单号
    faceAuthStatus:null, // 储存的订单人脸状态 001 未实名 002 实名中 003 已实名
  };
  // 获取倒计时
  newCountDown = () => {
    console.log("进入倒计时！！！")
    let seconds = 8; // 设定倒计时秒数
    const timer = setInterval(() => {
      this.setState({ newCountDownStr: seconds });
      console.log(seconds); // 输出剩余秒数
      seconds--; // 剩余秒数减少1
      if (seconds < 0) { // 如果剩余秒数小于0，清除定时器
        clearInterval(timer);
        console.log("倒计时结束！");
      }
    }, 1000); // 设置定时器每秒执行一次
  };
  componentWillMount =() =>{

    /*
    OrderService.selectUserCertification({

    });
    */

  };

  componentDidShow = () => {
    const { type, typess } = this.$router.params;
    const currentMenu = nav.find((info) => info.id === type);
    let status = null;
    if (currentMenu) {
      status = [currentMenu.cname];
      if (currentMenu.id === "settle") {
        status = [
          "WAITING_SETTLEMENT",
          "WAITING_CONFIRM_SETTLEMENT",
          "WAITING_SETTLEMENT_PAYMENT",
        ];
      }
      if (currentMenu.id === "overdue") {
        status = ["OVER_DUE", "ORDER_VERDUE"];
      }
      if (currentMenu.id === "deliver" || currentMenu.id === "all") {
        const { dispatch } = this.props;
        dispatch({
          type: "orderList/getSysConfigByKey",
          payload: {
            configKey: "USER_CANCEL_ORDER:HOUR",
          },
        });
      }
    }

    if (typess === "购买订单") {
      this.setState({
        dinText: typess,
      });
    }
    this.setState({ type });
    const { queryInfo, dispatch } = this.props;

    const info = { ...queryInfo, pageNumber: 1 };
    if (type === "all") {
      delete info.status;
      delete info.statusList;
    } else {
      info.status = status;
    }
    const is = {
      pageNumber: 1,
      pageSize: 10,
      state: "",
    };
    if (this.state.dinText === "购买订单" || typess === "购买订单") {
      this.setDispatchs(is);
    } else {
      this.setDispatch(info);
    }
    this.onCardinformation();
    this.onCardinformations();
    // 通过插件js接口获取签署状态
    const {
      code,
      message,
    } = esignPlugin.getSignStatusInfo();
    console.log('code1111111', code)
    console.log('message222222222', message)
  };
  onCardinformations = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'orderList/getCardinformation',
      callback: (res) => {
        if (!res) {
          return;
        }
        if (res.id  > 0 && !!res.idCard && !!res.uid && !!res.userName && !!res.telephone) {
          this.setState({
            isCards: true,
          });
        }
      },
    });
  };
  onCardinformation = () => {
    const { dispatch } = this.props;
    // let myDate = new Date();
    // let tiems = myDate.toLocaleDateString();
    // let reg = new RegExp("/", "");
    // let a = tiems.replace(reg, "");
    // let b = a.replace(reg, "");
    let b = moment().format("YYYYMMDD");

    dispatch({
      type: "orderList/getCardinformation",
      callback: (res) => {
        if (!res) {
          return;
        }
        if (!!res.idCardBackUrl && !!res.idCardFrontUrl && b < res.limitDate) {
          this.setState({
            isCard: true,
          });
        }
      },
    });
  };

  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === "scroll") {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    // 逾期订单多一个参数
    if (
      (info.statusList && info.statusList.includes("11")) ||
      (info.status && info.status.includes("OVER_DUE"))
    ) {
      info.overDueQueryFlag = true;
    } else {
      info.overDueQueryFlag = false;
    }

    dispatch({
      type: "orderList/fetchUserOrderList",
      payload: { ...info },
    });
  }

  setDispatchs(queryInfo, fetchType) {
    const { dispatch } = this.props;

    const info = { ...queryInfo };
    if (fetchType === "scroll") {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    dispatch({
      type: "orderList/userOrdersPurchase",
      payload: { ...info },
    });
  }

  switchTab = (item) => {
    this.setState({ type: item.id });
    let status = [item.cname];
    if (item.id === "settle") {
      status = [
        "WAITING_SETTLEMENT",
        "WAITING_CONFIRM_SETTLEMENT",
        "WAITING_SETTLEMENT_PAYMENT",
      ];
    }
    if (item.id === "overdue") {
      status = ["OVER_DUE", "ORDER_VERDUE"];
    }
    if (item.id === "deliver") {
      const { dispatch } = this.props;
      dispatch({
        type: "orderList/getSysConfigByKey",
        payload: {
          configKey: "USER_CANCEL_ORDER:HOUR",
        },
      });
    }
    const info = {
      status,
      pageNumber: 1,
      pageSize: 10,
    };
    const infos = {
      state: "",
      pageNumber: 1,
      pageSize: 10,
    };
    if (item.id === "all") {
      delete info.status;
    }
    this.setDispatch(info);
  };

  switchTabs = (item) => {
    this.setState({ type: item.id });
    let status = [item.cname];
    if (item.id === "settle") {
      status = [
        "WAITING_SETTLEMENT",
        "WAITING_CONFIRM_SETTLEMENT",
        "WAITING_SETTLEMENT_PAYMENT",
      ];
    }
    if (item.id === "overdue") {
      status = ["OVER_DUE", "ORDER_VERDUE"];
    }
    if (item.id === "deliver") {
      const { dispatch } = this.props;
      dispatch({
        type: "orderList/getSysConfigByKey",
        payload: {
          configKey: "USER_CANCEL_ORDER:HOUR",
        },
      });
    }
    const info = {
      status,
      pageNumber: 1,
      pageSize: 10,
    };
    const infos = {
      state: item.cname,
      pageNumber: 1,
      pageSize: 10,
    };

    this.setDispatchs(infos);
  };

  onScrollToLower = () => {
    const {
      total,
      queryInfo,
      queryInfo: { pageNumber, pageSize },
    } = this.props;
    if (pageNumber * pageSize - total >= 0) {
      Taro.showToast({
        title: "没有更多订单了",
        icon: "none",
        duration: 1000,
      });
      return;
    }
    if (this.state.dinText === "购买订单") {
      this.setDispatchs(queryInfo, "scroll");
    } else {
      this.setDispatch(queryInfo, "scroll");
    }
  };

  onClickItem = (order) => {
    Taro.navigateTo({
      url: `/pages/orderDetail/index?orderId=${order.orderId}&type=${order.typeText}&imgUrl=${order.imgUrl}&productName=${order.productName}&skuTitle=${order.skuTitle}`,
    });
  };

  onClickPurchaseDetail = (order) => {
    Taro.navigateTo({
      url: `/pages/purchaseDetail/index?orderId=${order.orderId}`,
    });
  };

  onClickCancelOrder = (order, data) => {
    this.needCancelOrder = data;
    if (order.examineStatus === 0) {
      this.setState({
        cancelOrderDisplay: true,
        clickedOrderId: order.orderId,
        clickedOrderStatus: order.status,
        examineStatus: order.examineStatus,
        statusCance: order.statusCancel,
      });
    } else {
      this.setState({
        clickedOrderId: order.orderId,
        clickedOrderStatus: order.status,
        canCel: true,
      });
    }
  };
  // 接受去签约
  onClickSignAContract = (order, data) => {
    console.log(order,"11111111111111111111111",data)
    // this.setState({
    //   showOnPayment: true,
    //   newOrderId:order.orderId,
    // })
    //进入芝麻代扣流程
    this.newCountDown();
    this.setState({
      showHint:true,
    })
    Request({
      url:'hzsx/api/appZuLinPingTai/zuLinPingTaiUserSgnMainFlow',
      method:'POST',
      data:{
        channelIdOfReq:'006',
        orderIdOfReq:order.orderId,
        uidOfReq:getUid(),
      } 
    }).then(res=>{
      if(res.data.responseType == "SUCCESS") {
        // 【contractSign=合同签署，withholdSign=代扣签署】
        // 当signType=contractSign合同签署时，就是签署合同用这个zuLinPingTaiContractSignLinkOfRes返回签署合同
        //     当signType=withholdSign代扣签署时，就是签署合同用以下返回签署合同
        // private String myZuLinPingTai_signStr;
        // private String myZuLinPingTai_tenantId_res;
        // private String myZuLinPingTai_merchantId_res;
        // private String myZuLinPingTai_orderId_res;
        if(res.data.data.signType == 'contractSign'){
          if(res.data.data.zuLinPingTaiContractSignLinkOfRes){
            my.navigateTo({
              // url: 'plugin://esign/esign?env=${env}&flowId=${flowId}&signerId=${signerId}&skipResult=${skipResult}&skipGuide=${skipGuide}',
              url: res.data.data.zuLinPingTaiContractSignLinkOfRes,
            })
            this.setState({
              showHint:false,
              // showRemind:true,
              // longUrl:res.data.data.zuLinPingTaiContractSignLinkOfRes,
            })
          }else {
            // 请求失败 跳转到订单列表
            this.setState({
              showHint:false,
            })
            Taro.showToast({
              title: "正在处理，请稍后再次点击！",
              icon: "none",
            });
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          }
        }
        if(res.data.data.signType == 'withholdSign') {
          my.navigateToMiniProgram({
            appId:"2021001152620480", // 区块链合同真实appId
            path:"pages/tripartite/index", // 支付宝商家跳转区块链合同代扣签署地址（真实路径
            query:{
            signStr:res.data.data.myZuLinPingTai_signStr,// 签署代扣必要的字符串参数
            tenantId:res.data.data.myZuLinPingTai_tenantId_res,
            merchantId:res.data.data.myZuLinPingTai_merchantId_res,
            orderId:res.data.data.myZuLinPingTai_orderId_res,
            redirectUrl:'alipays://platformapi/startapp?appId=2021004124697663&page=pages/orderList/index?type=all', // 代扣签署成功/失败回跳地址，示例 alipays://platformapi/startapp?appId=2021004108689505&page=pages/home/index，appId 和 page 需要根据实际情况调整真实数值
          }, // 需要携带的必要参数
          success: () => {
          },
          fail: () => {
          },
          });
        }
      }else {
        // 请求失败 跳转到订单列表
        this.setState({
          showHint:false,
        })
        setTimeout(() => {
          Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
        }, 1000)
        if (res.errorMessage) {
          Taro.showToast({
            title: res.errorMessage,
            icon: "none",
          });
        }
      }
    })
  };
  // 接收选择免押方案
  onClickPayment = (order, data) => {
    this.setState({
      showOnPayment: true,
      newOrderId:order.orderId,
      faceAuthStatus:order.faceAuthStatus
    })
  };
  handleModalOk = (value) => {
    if (!value) {
      Taro.showToast({
        title: "请选择取消原因",
        icon: "none",
      });
      return;
    }

    const {
      clickedOrderId,
      clickedOrderStatus,
      examineStatus,
      statusCance,
      dinText,
    } = this.state;
    const { dispatch } = this.props;

    if (dinText === "购买订单") {
      dispatch({
        type: "orderList/userOrdersPurchasecancel",
        payload: {
          cancelReason: value,
          orderId: clickedOrderId,
        },
        callback: (res) => {
          this.setDispatchs({
            pageNumber: 1,
            pageSize: 10,
            state: "",
          });
        },
      });
    } else if (examineStatus === 0 && statusCance === "PENDING_DEAL") {
      dispatch({
        type: "orderList/userCancelOrderSendMsg",
        payload: {
          cancelReason: value,
          orderId: clickedOrderId,
        },
      });
    } else {
      dispatch({
        type: "orderDetail/userCancelOrder",
        // payload: {
        //   cancelReason: value,
        //   orderId: clickedOrderId,
        //   status: clickedOrderStatus,
        // },
        payload: {
          reson: value,
          order_id: clickedOrderId,
          status: "14",
        },
        callback: () => {
          umUploadHandler.cancelOrder(this.needCancelOrder);
        },
      });
    }
    this.setState({ cancelOrderDisplay: false });
  };

  handleModalCancel = () => {
    this.setState({ cancelOrderDisplay: false });
  };

  onClickBillDetail = (order) => {
    const { dispatch } = this.props;
    dispatch({
      type: "billDetail/saveProduct",
      payload: order,
    });
    Taro.navigateTo({
      url: `/pages/billDetail/index?orderId=${order.orderId}`,
    });
  };

  onClickFrezzAgain = (order) => {
    if (order.type === 3) {
      Taro.navigateTo({ url: `/pages/buyout/index?orderId=${order.orderId}` });
    } else if (order.type === 2) {
      Taro.navigateTo({ url: `/pages/renewal/index?orderId=${order.orderId}` });
    } else {
      Taro.navigateTo({
        url: `/pages/orderDetail/index?orderId=${order.orderId}&type=${order.status}&imgUrl=${order.images[0].src}&productName=${order.productName}&skuTitle=${order.skuTitle}`,
      });
    }
  };
  coCliszhifu = (e) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderList/userOrdersPurchasepayAgain",
      payload: { orderId: e },
      callback: (res) => {
        this.setDispatchs({
          pageNumber: 1,
          pageSize: 10,
          state: "",
        });
      },
    });
  };
  onClickReceiveGoods = (orderId, orderStatus) => {
    this.setState({
      receiveDoodsDisplay: true,
      clickedOrderId: orderId,
      clickedOrderStatus: orderStatus,
    });
  };

  onClickSendBack = (order) => {
    const { dispatch } = this.props;
    const product = {
      ...order,
    };
    const userOrders = {
      orderId: order.orderId,
    };
    dispatch({
      type: "sendBack/saveProductAndOrder",
      payload: { product, userOrders },
    });
    Taro.navigateTo({ url: `/pages/sendBack/index?orderId=${order.orderId}` });
  };

  handleCancalGoods = () => {
    this.setState({ receiveDoodsDisplay: false });
  };

  handleOkGoods = () => {
    const { clickedOrderId, dinText } = this.state;
    const { dispatch } = this.props;
    if (dinText !== "购买订单") {
      dispatch({
        type: "orderDetail/userConfirmReceipt",
        payload: { orderId: clickedOrderId },
      });
    } else {
      dispatch({
        type: "orderList/userOrdersPurchasereceipt",
        payload: { orderId: clickedOrderId },
        callback: (res) => {
          this.setDispatchs({
            pageNumber: 1,
            pageSize: 10,
            state: "",
          });
        },
      });
    }

    this.setState({ receiveDoodsDisplay: false, clickedOrderId: null });
  };

  connectServices = (val) => {
    const { serviceTel } = this.state;
    let num = String(val);
    if (val === "business") {
      my.makePhoneCall({ number: serviceTel });
    } else {
      my.makePhoneCall({ number: num });
    }
  };
  onClosePhoneModal = () => {
    this.setState({ showServicePhone: false });
  };
  oncanCelModal = () => {
    this.setState({
      canCel: false,
    });
  };

  handleService = (val) => {
    this.setState({
      serviceTel: val.business,
      isTagOpened: true,
    });
  };
  handleClose = () => {
    this.setState({
      isTagOpened: false,
    });
  };
  onPushIdcard = () => {
    Taro.navigateTo({ url: `/pages/Certificates/index?idcard=1` });
  };
  onMaskClick = () => {
    this.setState({
      show: false,
      arrow: "rotate(0deg)",
    });
  };
  onShowPopoverTap = () => {
    this.setState({
      show: true,
      showMask: true,
      arrow: "rotate(180deg)",
    });
  };
  onOrder = (e) => {
    const is = {
      pageNumber: 1,
      pageSize: 10,
      state: "",
    };
    const iss = {
      pageNumber: 1,
      pageSize: 10,
    };
    this.setState(
      {
        dinText: e,
        show: false,
        showMask: false,
        arrow: "rotate(0deg)",
      },
      () => {
        if (e === "租赁订单") {
          this.setDispatch(iss);
        } else {
          this.setDispatchs(is);
        }
      }
    );
  };
  onCKAll = () => {
    const { queryInfo, dispatch } = this.props;

    const info = { ...queryInfo, pageNumber: 1 };
    
    this.setDispatch(info);
  };
  onFaceFinsh = (order) => {
    const { dispatch } = this.props;
    dispatch({
      type: "confirmOrder/faceRecognition",
      payload: {
        orderId: order.orderId,
        uid:getUid()
      },
      callback: (data) => {
        startAPVerify(
          {
            certifyId: data.certifyId,
            url: data.faceUrl,
          },
          function(verifyResult) {
            // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
            if (verifyResult.resultStatus === "9000") {
              // 验证成功，接入方在此处处理后续的业务逻辑
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId: data.certifyId,
                  bizId:data.bizId,
                },
                callback: (res) => {
                   Request({
                            url:"hzsx/api/order/hasOrderUsing",
                            method:'GET',
                            data:{
                              uid:getUid(),
                              channelId:getGloble('channelId'),
                            }
                          }).then(res=>{
                            if(res.data.data===true){
                              my.call('verifyIdentity', {
                                action: 'getEnvData', 
                              }, function (result) {
                                console.log(result.actionResult);
                                const actionResult = result.actionResult
                                if(actionResult){
                                  Request({
                                    url:'hzsx/api/components/riskRuning',
                                    method:'POST',
                                    data:{
                                      uid:getUid(),
                                      channelId:getGloble('channelId'),
                                      orderId: order.orderId,
                                      bizRequestParams:actionResult,
                                      userId:getBuyerId(),
                                    }
                                  }).then(res=>{
                                    const verifyId = res.data.data.verifyId;
                                    const bizId = res.data.data.bizId;
                                    my.call('verifyIdentity', {
                                      verifyId: verifyId,
                                      user_id:getBuyerId(),
                                    }, function (result) {
                                      Request({
                                        url:'hzsx/api/components/runingReceive',
                                        method:'POST',
                                        data:{
                                          bizId,
                                          code:result.code,
                                        }
                                      }).then(res=>{
                                      })
                                    });
                                  })
                                }
                              });
                            }
                          })
                  const { queryInfo, dispatch } = this.props;

                  const info = { ...queryInfo, pageNumber: 1 };
                  if (type === "all") {
                    delete info.status;
                    delete info.statusList;
                  } else {
                    info.status = status;
                  }
                  this.setDispatch(info);
                },
              });
            } else {
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                  passed: false,
                  bizId:data.bizId,
                },
                callback: (res) => {},
              });
            }
            // 用户主动取消认证
            if (verifyResult.resultStatus === "6001") {
              // 可做下 toast 弱提示m
              Taro.showToast({
                title: "取消认证成功",
              });
            }
            if (verifyResult.result) {
            }
            // 其他结果状态码判断和处理 ...
          }
        );
      },
    });
  };
  // 取消选择支付方式 预授权&&蚂蚁代扣
  onClosePayment = () => {
    setTimeout(() => {
      Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
    }, 1000)
  }
  // 选择支付方式提交
  submitPayment = () => {
    const { dispatch } = this.props;
    const then = this;
    console.log(this.state.payment_id ,'this.state.payment_id ',this.state.faceAuthStatus);
    this.setState({
      showOnPayment:false,
    })
    // 进入预授权流程
    if( this.state.faceAuthStatus == "01" || this.state.faceAuthStatus == "02" ) {
      console.log("进入人脸！！！！！！！！！！！！！！！！！",then.state.newOrderId)
      dispatch({
        type: "confirmOrder/faceRecognition",
        payload: {
          orderId: this.state.newOrderId,
          uid:getUid()
        },
        callback: (data) => {
          console.log(data,"sssssssssssssssssssssssssss")
          startAPVerify(
            {
              certifyId: data.certifyId,
              url: data.faceUrl,
            },
            function (verifyResult) {
              console.log(verifyResult.result,"看下这是什么参数！！！！！！！！！！",verifyResult,then.state.payment_id)
              // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
              if (verifyResult.resultStatus === '9000') {
                // 验证成功，接入方在此处处理后续的业务逻辑
                if (
                  verifyResult.result &&
                  verifyResult.result.certifyId
                ) {
                  // 验证成功，接入方在此处处理后续的业务逻辑
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId: verifyResult.result && verifyResult.result.certifyId,
                      bizId:data.bizId,
                    },
                  });
                }
                // 人脸请求成功之后，进行是走预授权还是走代扣判断 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<===================================================
                // 进入预授权流程
                if(then.state.payment_id == 1) {
                  dispatch({
                    type: "orderDetail/userFrezzAgain",
                    payload: {
                      orderId: then.state.newOrderId,
                    },callback: (e) => {
                      dispatch({
                        type: "orderList/fetchUserOrderList",
                        payload: {
                          overDueQueryFlag: false,
                          pageNumber: 1,
                          pageSize: 10,
                        },
                      });
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                    }
                  });
                }else {
                  // 生成代扣订单
                  Request({
                    url:`hzsx/api/appZuLinPingTai/antZuLinPingTaiOrderComfirm?orderId=${this.state.newOrderId}&channel=006`,
                    method:'POST',
                    data:{
                      // channel:'067',
                      // orderId:then.state.newOrderId,
                      // orderId:"031OI202304277521072469482250240",
                    }
                  }).then(res=>{
                    console.log(res,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
                    if(res.data.responseType == "SUCCESS") {
                      Taro.showToast({
                        title: "操作成功，请等待商家审核！",
                      });
                      //跳转下单成功
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                    }else {
                      // 请求失败 跳转到订单列表
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                      if (res.errorMessage) {
                        Taro.showToast({
                          title: res.errorMessage,
                          icon: "none",
                        });
                      }
                    }
                  })
                }
              } else {
                if (
                    verifyResult.result &&
                    verifyResult.result.certifyId
                ) {
                  // Request({
                  //   url: `hzsx/api/components/faceAuthInitAsync`,
                  //   method: "GET",
                  //   data: {
                  //     certifyId: verifyResult.result && verifyResult.result.certifyId,
                  //   }
                  // }).then(res => {
                  //   console.log("请求成功")
                  // });
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId:
                        verifyResult.result && verifyResult.result.certifyId,
                        bizId:data.bizId,
                    },
                  });
                }
              }
              // 用户主动取消认证-
              if (verifyResult.resultStatus === '6001') {
                then.setState({
                  showOnPayment:true,
                })
                Taro.showToast({
                  title: '取消认证成功！',
                });
                //取消认证直接返回上一页 预授权时 再调人脸 
                return;
              }
              if (verifyResult.result) {
                // Taro.redirectTo({ url: `/pages/checkSuccess/index?orderId=${orderId}&type=1` });
              }
            },
          );
        },
      });
    }else {
      // 进入预授权流程
      if(this.state.payment_id == 1) {
        // dispatch({
        //   type: "orderDetail/userFrezzAgain",
        //   payload: {
        //     orderId: this.state.newOrderId,
        //   },
        // });
        dispatch({
          type: "orderDetail/userFrezzAgain",
          payload: {
            orderId: this.state.newOrderId,
          },
          callback:res=>{
            dispatch({
              type: "orderList/fetchUserOrderList",
              payload: {
                overDueQueryFlag: false,
                pageNumber: 1,
                pageSize: 10,
              },
            });
          }
        });
      }else {
        // 生成代扣订单
        Request({
          url:`hzsx/api/appZuLinPingTai/antZuLinPingTaiOrderComfirm?orderId=${this.state.newOrderId}&channel=006`,
          method:'POST',
          data:{
            // channel:'067',
            // orderId:then.state.newOrderId,
            // orderId:"031OI202304277521072469482250240",
          }
        }).then(res=>{
          console.log(res,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
          if(res.data.responseType == "SUCCESS") {
            Taro.showToast({
              title: "操作成功，请等待商家审核！",
            });
            //跳转下单成功
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          }else {
            // 请求失败 跳转到订单列表
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
            if (res.errorMessage) {
              Taro.showToast({
                title: res.errorMessage,
                icon: "none",
              });
            }
          }
        })
      }
    }
  }
  // 芝麻代扣跳转方法
  submitRemind = () => {
    if(this.state.longUrl) {
      console.log(this.state.longUrl,"llllllllllllllllll")
      let finalSignUrl; // 最终需要跳转的签署地址
      //  小程序签署地址（设置签署平台ALIPAY时）
      // const alipaySignUrl = 'alipays://platformapi/startapp?appId=2021001152620480&page=pages/signH5/index&query=signUrl%3Dhttps%253A%252F%252Ftsign.cloud.alipay.com%252Fweb%252FhandMultifileSign%253Ftimestamp%253D1682314757165%2526flowId%253Da5a216b79ed844029e4de14477422f65%2526accountId%253DNGLDDEPSconsumerUid274817hid0d%2526sign%253Dfa64731ae19b01213a9b41f4697a3f04fd58e4a0e092fa9b4b9f683e6e915df8';
      // if 生成的签署地址为小程序版本，需要按照以下进行处理 **/
      finalSignUrl = getSignUrl(this.state.longUrl);
      
      /* 他方小程序跳转至区块链合同小程序 */
      my.navigateToMiniProgram({
        appId: '2021001152620480', // 非示例，真实小程序appId
        path:`pages/signH5/index?signUrl=${finalSignUrl}`, // 非示例，真实小程序签署页面地址
        success: (res) => {
          this.setState({
            showRemind:false
          })
          console.log(JSON.stringify(res),"芝麻代扣合同签署成功！！！！！！")
          // setTimeout(() => {
          //   Taro.redirectTo({
          //     url: `/pages/checkSuccess/index?orderId=${this.state.newOrderId}&type=1`,
          //   });
          // }, 400)
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
          }, 1000)
        },
        fail: (res) => {
          this.setState({
            showRemind:false
          })
          console.log(JSON.stringify(res),"芝麻代扣合同签署失败。。。。。。")
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
          }, 1000)
        }
      });
    }else {
      Taro.showToast({
        title: "请返回列表！",
        icon: "none",
      });
    }
  }
  handleChangePayment = (e) =>{
    console.log(e,"jjjjjjjjjjjjjjjjjjj")
    this.setState({
      payment_id:e.detail.value
    })
  }
  render() {
    const {
      type,
      display,
      cancelOrderDisplay,
      receiveDoodsDisplay,
      showServicePhone,
      serviceTel,
      cancelOrderList,
      canCel,
      stageBillModal,
      isTagOpened,
      isCard,
      isCards,
      showMask,
      position,
      show,
      dinText,
      arrow,
      showOnPayment,payment_id,showHint,
      newCountDownStr,
      showRemind,
    } = this.state;
    const { list, loading, sysConfigValue } = this.props;

    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = 43;
    if (systemInfo.model.indexOf("iPhone X") > -1) {
      fixedHeight = fixedHeight + 30;
    }
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;
    let obj = null;
    if (sysConfigValue) {
      obj = {
        sysConfigValue: sysConfigValue,
      };
    }
    //
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    return (
      <View className="order-list">
        <popover
          position={position}
          show={show}
          showMask={showMask}
          onMaskClick={this.onMaskClick}
          className="order-list-button"
        >
          <View onClick={this.onShowPopoverTap} style={{ marginRight: "10px" }}>
            <View
              type="secondary"
              className="order-list-button"
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                className="order-list-sj"
                style={{
                  transform: arrow,
                }}
              ></Text>
              {dinText}
            </View>
          </View>
          <View slot="items">
            <popover-item onItemClick={() => this.onOrder("租赁订单")}>
              <text style={dinText === "租赁订单" ? { color: "#C43737" } : {}}>
                租赁订单
              </text>
            </popover-item>
            <popover-item onItemClick={() => this.onOrder("购买订单")}>
              <text style={dinText === "购买订单" ? { color: "#C43737" } : {}}>
                购买订单
              </text>
            </popover-item>
          </View>
        </popover>
        <ScrollView
          scrollIntoView={type}
          className="order-list-nav"
          scrollWithAnimation
          scrollX
        >
          {dinText !== "购买订单"
            ? nav.map((item) => {
                return (
                  <View
                    onClick={this.switchTab.bind(this, item)}
                    key={item.id}
                    id={item.id}
                    className="order-list-nav-container"
                  >
                    <Text
                      className={`text ${type === item.id && "text-active"}`}
                    >
                      {item.text}
                    </Text>
                    {type === item.id && (
                      <View className="border-bottom"></View>
                    )}
                  </View>
                );
              })
            : nas.map((item) => {
                return (
                  <View
                    onClick={this.switchTabs.bind(this, item)}
                    key={item.id}
                    id={item.id}
                    className="order-list-nav-container"
                  >
                    <Text
                      className={`text ${type === item.id && "text-active"}`}
                    >
                      {item.text}
                    </Text>
                    {type === item.id && (
                      <View className="border-bottom"></View>
                    )}
                  </View>
                );
              })}
        </ScrollView>
        <View className="order-content">
          {isCards ? null : this.state.dinText === "租赁订单" ? (
            <View className="idCord_wrap">
                <View className="order-image"></View>
              <View className="left">上传身份证照片才能发货哦！</View>
              <View onClick={this.onPushIdcard}>去上传 {`>`}</View>
            </View>
          ) : null}
          {this.state.dinText === "租赁订单" ? (
            <View>
              {!list.length ? (
                <NoData type="order" display={display} />
              ) : (
                <ScrollView
                  scrollY
                  scrollWithAnimation
                  scrollTop="0"
                  style={`height: ${scrollHeight}px;`}
                  onScrollToLower={this.onScrollToLower}
                >
                  {!!list &&
                    !!list.length &&
                    list.map((data, index) => (
                      <ListItem
                        key={data.orderId + Math.random()}
                        data={{ ...data, ...obj }}
                        index={index}
                        type={type}
                        sysConfigValue={sysConfigValue}
                        onClickPayment={this.onClickPayment}
                        onClickSignAContract={this.onClickSignAContract}
                        onClickItem={this.onClickItem}
                        onClickCancelOrder={this.onClickCancelOrder}
                        onClickBillDetail={this.onClickBillDetail}
                        onClickFrezzAgain={this.onClickFrezzAgain}
                        onClickReceiveGoods={this.onClickReceiveGoods}
                        onClickSendBack={this.onClickSendBack}
                        onClickService={this.handleService}
                        onCKAll={this.onCKAll}
                        isCards={isCards}
                      />
                    ))}
                </ScrollView>
              )}
            </View>
          ) : null}
          {this.state.dinText === "租赁订单" ? null : (
            <View>
              {!list.length ? (
                <NoData type="order" display={display} />
              ) : (
                <ScrollView
                  scrollY
                  scrollWithAnimation
                  scrollTop="0"
                  style={`height: ${scrollHeight}px;`}
                  onScrollToLower={this.onScrollToLower}
                >
                  {list &&
                    !!list.length &&
                    list.map((data, index) => (
                      <ListItemCopy
                        key={data.orderId + Math.random()}
                        data={{ ...data, ...obj }}
                        index={index}
                        type={type}
                        sysConfigValue={sysConfigValue}
                        onClickPayment={this.onClickPayment}
                        onClickSignAContract={this.onClickSignAContract}
                        onClickItem={this.onClickPurchaseDetail}
                        onClickCancelOrder={this.onClickCancelOrder}
                        onClickBillDetail={this.onClickBillDetail}
                        onClickFrezzAgain={this.onClickFrezzAgain}
                        onClickReceiveGoods={this.onClickReceiveGoods}
                        onClickSendBack={this.onClickSendBack}
                        onClickService={this.handleService}
                        coCliszhifu={this.coCliszhifu}
                      />
                    ))}
                </ScrollView>
              )}
            </View>
          )}
        </View>
        <CancelOrder
          display={cancelOrderDisplay}
          onCancal={this.handleModalCancel}
          onOk={this.handleModalOk}
          cancelOrderList={cancelOrderList}
        />
        <AtModal isOpened={receiveDoodsDisplay}>
          <AtModalHeader>确认收货？</AtModalHeader>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>确认已收到商品</View>
          </AtModalContent>
          <AtModalAction className="modailAction">
            <Button onClick={this.handleCancalGoods}>取消</Button>
            <Button className="conform" onClick={this.handleOkGoods}>
              确定
            </Button>
          </AtModalAction>
        </AtModal>
        <modal
          show={showServicePhone}
          showClose={false}
          onModalClick={this.onClosePhoneModal}
          onModalClose={this.onClosePhoneModal}
        >
          <View slot="header">联系客服</View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            商家客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectServices.bind(this, "business")}
            >
              {serviceTel}
            </Text>
          </View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            平台客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectServices.bind(this, customerServiceTel)}
            >
              {customerServiceTel}
            </Text>
          </View>
          <View style={{ textAlign: "left", paddingLeft: "15px" }}>
            工作时间：<Text style={{ color: "#777" }}>10:30 - 19:30</Text>
          </View>
          <View slot="footer">取消拨打</View>
        </modal>
        <modal
          show={canCel}
          onModalClick={this.oncanCelModal}
          onModalClose={this.oncanCelModal}
          advice={true}
        >
          <View className="cancel-modal">
            <View slot="header" className="header">
              温馨提示·
            </View>
            <View className="content">
              退款处理中，预计24小时内操作完成，请耐心等待；
              如需加急处理，可联系客服：
              <Text
                style={{ color: "#51A0F9" }}
                onClick={this.connectServices.bind(this, customerServiceTel)}
              >
                {customerServiceTel}
              </Text>
            </View>
          </View>
        </modal>
        <TagPage
          onClose={this.handleClose}
          isOpened={isTagOpened}
          data={serviceTel}
        />
        {/* 下面是申请代扣代码 */}
        {/* 选择支付方式弹框 预授权&蚂蚁代扣 */}
        <AtModal isOpened={showOnPayment}  onClose={this.onClosePayment} closeOnClickOverlay={false} className="payment">
          <View className='payment_main'>
            <RadioGroup className='radioGroup' onChange={this.handleChangePayment}>
              <View className='payment_main_top'>
                <View className='payment_main_top_up'>
                  <Image
                    className="up_img"
                    mode="scaleToFill"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/43322ab49f0b4b5590576fabd8ffae29.png"
                  />
                  <View className='radioText'>芝麻信用免押金</View>
                  <Image
                    className="up_img_t"
                    mode="scaleToFill"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/bb3e08939ccd410eb956833c39ac085a.png"
                  />
                </View>
                <View className='payment_main_top_down'>凭芝麻信用最高可全免</View>
                <Radio value={1} className='radio' checked />
              </View>
              {/* <View className='payment_main_buttom'>
                <View className='payment_main_buttom_up'>
                  <Image
                    className="up_img"
                    mode="scaleToFill"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/85359e11547c4888a488d6cd74ece728.png"
                  />
                  <View className='radioText'>快速<View className='radioText_mian'>免押</View></View>
                </View>
                  <View className='payment_main_buttom_down'>快速免押，无需押金~</View>
                <Radio value={2} className='radio'/>
              </View> */}
            </RadioGroup>

          </View>
          <AtModalAction className="payment_button"><Button className='payment_button_a' onClick={this.onClosePayment}>取消</Button> <Button className='payment_button_b' onClick={debounce(this.submitPayment, 2000)}>确定</Button> </AtModalAction>
        </AtModal>
        {/* 信用评估中弹窗 */}
        <AtModal isOpened={showHint} closeOnClickOverlay={false} className="hint">
          <View className='hint_main'>
            <Image
              className="hint_img"
              mode="scaleToFill"
              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c2b318a91c92448db72bd2a657f204c6.gif"
              />
              <View className='hintText'>信用评估中</View>
              <View className='hintText_a'>
                剩余 <View className='hint_time'>{newCountDownStr}</View> s
              </View>
          </View>
        </AtModal>
        {/* 提示信息弹窗 */}
        <AtModal isOpened={showRemind} closeOnClickOverlay={false} className="remind">
          <AtModalHeader className="remind_head">温馨提示</AtModalHeader>
          <View className='remind_main'>
            <View className='remindText'>
            即将前往支付宝智能合同小程序签署合同，签署合同完成请点击右上角关闭按钮，返回星动租查看订单审核进度！
            </View>
            <View className='remind_img'>
              <Image
                className="remind_img_a"
                mode="scaleToFill"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3204ed970d8c462a9df08602516ebdc4.png"
                />
            </View>
          </View>
          <AtModalAction><Button onClick={debounce(this.submitRemind, 2000)}>确定</Button></AtModalAction>
        </AtModal>
      </View>
    );
  }
}

export default Orderlist;
