import Request from "../../utils/request";

export const demo = (data) => {
  return Request({
    url: "路径",
    method: "POST",
    data,
  });
};

export const userOrderList = (data) =>
  Request({
    url: "hzsx/api/order/userOrderList",
    method: "POST",
    data,
  });
export const userOrdersPurchase = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/page",
    method: "POST",
    data,
  });

export const getSysConfigByKey = (data) =>
  Request({
    url: "hzsx/api/sysConfig/getSysConfigByKey",
    method: "GET",
    data,
  });
export const userCancelOrderSendMsg = (data) =>
  Request({
    url: "hzsx/api/order/userCancelOrderSendMsg",
    method: "POST",
    data,
  });
export const selectUserCertification = (data) =>
  Request({
    url: "hzsx/userCertification/getByUid",
    method: "GET",
    data,
  });
export const userOrdersPurchasecancel = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/cancel",
    method: "POST",
    data,
  });
export const userOrdersPurchasepayAgain = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/payAgain",
    method: "POST",
    data,
  });
export const userOrdersPurchasereceipt = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/receipt",
    method: "POST",
    data,
  });
