import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, Button } from "@tarojs/components";
import { orderStatus } from "../../../../assets/Constant";
import { formatDate, transdate } from "../../../../utils/utils";
import {
  AtIcon,
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
} from "taro-ui";
import "./index.scss";
import { connect } from "@tarojs/redux";
import { startAPVerify } from "../../../../utils/openApi";
import { getServicePhone, getGloble,getBuyerId,getUid } from "../../../../utils/localStorage";
import Request from "../../../../utils/request";
@connect(({ confirmOrder, authentication }) => ({
  ...confirmOrder,
  ...authentication,
}))
class listItemCopy extends Component {
  config = {
    usingComponents: {
      popover: "/npm/mini-antui/es/popover/index",
      "popover-item": "/npm/mini-antui/es/popover/popover-item/index",
    },
  };
  state = {
    position: "bottomLeft",
    show: false,
    show2: false,
    showMask: true,
    modifySettlementDisplay: false,
    showServicePhone: false,
    statusObj: {
      "01": {
        text: "待支付",
        color: "#C43737",
      },
      "02": {
        text: "待发货", //"支付中",
        color: "#C43737",
      },
      "03": {
        text: "申请关单",
        color: "#333333",
      },
      "04": {
        text: "待发货",
        color: "#333333",
      },
      "05": {
        text: "待收货",
        color: "#F8A544",
      },
      "06": {
        text: "租用中",
        color: "#C43737",
      },
      "07": {
        text: "待结算",
        color: "#333333",
      },
      "08": {
        text: "结算中",
        color: "#333333",
      },
      "09": {
        text: "已完成",
        color: "#C43737",
      },
      "10": {
        text: "已关闭",
        color: "#333333",
      },
      "11": {
        text: "已逾期",
        color: "#C43737",
      },
    },
  };
  handleClickItem = (order) => {
    let obj = {
      orderId: order.orderId,
      type: order.type,
      refundStatus: order.refundStatus ? order.refundStatus : null,
      typeText: order.status,
      imgUrl: order.mainImageUrl,
      productName: order.productName,
      skuTitle: order.skuId,
    };
    const { onClickItem } = this.props;
    onClickItem(obj);
  };
  // 去评论
  toComment(data) {
    Taro.navigateTo({
      url:
        "/pages/commentOn/index?orderId=" +
        data.orderId +
        "&from=orderList" +
        "&type=type",
    });
  }
  handleClickCancelOrder = (order) => {
    let obj = {
      orderId: order.orderId,
      status: order.status,
      examineStatus: 0, //order.examineStatus,
      statusCancel: order.status,
    };
    const { onClickCancelOrder, data } = this.props;
    onClickCancelOrder(obj, data);
  };

  handleClickBillDetail = (order) => {
    const { onClickBillDetail } = this.props;
    onClickBillDetail(order);
  };

  handleClickFrezzAgain = (order) => {
    const { onClickFrezzAgain } = this.props;
    onClickFrezzAgain(order);
  };

  handleClickReceiveGoods = (orderId) => {
    const { onClickReceiveGoods } = this.props;
    onClickReceiveGoods(orderId);
  };

  handleClickSendBack = () => {
    const { onClickSendBack, data } = this.props;
    onClickSendBack(data);
  };
  buyoutClick = () => {
    const { onClickSendBack, data } = this.props;
    Taro.navigateTo({
      url: `/pages/buyOutOrder/index?orderId=${data.orderId}&sign=1`,
    });
  };

  handleClickExpress = (order) => {
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${order}&type="购买"`,
    });
  };
  onClickReturn(expressId, expressNo) {
    //const { orderId } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/express/index?expressId=${expressId}&expressNo=${expressNo}`,
    });
  }
  handleCancelModifySettlement = () => {
    this.setState({ modifySettlementDisplay: false });
  };
  handleOkModifySettlement = (orderId) => {
    const { dispatch } = this.props;

    dispatch({
      type: "orderDetail/userApplicationForAmendmentOfSettlementForm",
      payload: { orderId },
    });
    this.setState({ modifySettlementDisplay: false });
  };
  onMaskClick = () => {
    this.setState({
      show: false,
    });
  };
  onShowPopoverTap = () => {
    this.setState({
      show: true,
    });
  };
  onMaskClick2 = () => {
    this.setState({
      show2: false,
    });
  };
  onShowPopoverTap2 = () => {
    this.setState({
      show2: true,
    });
  };
  connectService = (val) => {
    const { data } = this.props;
    let obj = {
      business: data.serviceTel,
    };

    const { onClickService } = this.props;
    onClickService(obj);
  };
  // 续租
  buyAgain(productId, type, skuId, orderId) {
    // type:buyAgain(再次下单)，continue（续租）
    Taro.navigateTo({
      url:
        "/pages/productDetail/index?itemId=" +
        productId +
        "&buyType=" +
        type +
        "&skuId=" +
        skuId +
        "&orderId=" +
        orderId,
    });
  }
  onFaceFinsh = (order) => {
    const { dispatch } = this.props;
    dispatch({
      type: "confirmOrder/faceRecognition",
      payload: {
        orderId: order.orderId,
        uid:getUid(),
      },
      callback: (data) => {
        startAPVerify(
          {
            certifyId: data.certifyId,
            url: data.faceUrl,
          },
          function(verifyResult) {
            // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
            if (verifyResult.resultStatus === "9000") {
              // 验证成功，接入方在此处处理后续的业务逻辑
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                },
                callback: () => {},
              });
            } else {
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                  passed: false,
                },
              });
            }
            // 用户主动取消认证
            if (verifyResult.resultStatus === "6001") {
              // 可做下 toast 弱提示m
              Taro.showToast({
                title: "取消认证成功",
              });
            }
            if (verifyResult.result) {
            }
            // 其他结果状态码判断和处理 ...
          }
        );
      },
    });
  };

  // 修改地址
  changeAddress(data) {
    Taro.navigateTo({
      url:
        "/pages/address/index?orderId=" +
        data.orderId +
        "&pages=orderList&type2=" +
        (this.props.type || "all") +
        "&typess=购买",
    });
  }

  onClickConfirmSettlement = (orderId, waitTotalPay) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/confirmOrderSettlement",
      payload: {
        orderId,
        amount: waitTotalPay,
        channelId: getGloble('channelId'),
      },
    });
  };

  onClickFrezzAgain = (order) => {
    const { dispatch } = this.props;
    this.props.coCliszhifu(order.orderId);
  };

  onClickModifySettlement = () => {
    this.setState({ modifySettlementDisplay: true });
  };
  onClickFrezzT = (e) => {
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${e.productId}&source=02&type=DIRECT`,
    });
  };
  render() {
    const { data, type, index } = this.props;
    const {
      position,
      show,
      showMask,
      statusObj,
      modifySettlementDisplay,
    } = this.state;
    // const letTime =
    //   data.createTime &&
    //   formatDate(new Date(data.createTimeStr), "yyyy-MM-dd hh:mm");
    const newTime = formatDate(new Date(), "yyyy-MM-dd hh:mm");
    // let dueTime =
    //   transdate(letTime) +
    //   data.sysConfigValue * 60 * 60 * 1000 -
    //   transdate(newTime);
    // let dueTimeMs = dueTime / 1000;
    const idCord =
      type == "payment" ||
      data.faceAuthStatus == "03" ||
      data.status == "WAITING_PAYMENT" ? null : (
        <View
          className="btnCord idcord"
          onClick={this.onFaceFinsh.bind(this, data)}
        >
          刷脸认证
        </View>
      );
    const states = {
      WAITING_FOR_PAY: "待支付",
      CANCEL: "已取消",
      WAITING_FOR_DELIVERY: "待发货",
      WAITING_RECEIVE: "待收货",
      FINISH: "已完成",
    };
    const statesCorol = {
      WAITING_FOR_PAY: "#C43737",
      CANCEL: "#333333",
      WAITING_FOR_DELIVERY: "#F8A544",
      WAITING_RECEIVE: "#333333",
      FINISH: "#333333",
    };
    const star = {
      WAITING_FOR_DELIVERY: "64vw",
      WAITING_FOR_PAY: "48vw",
      WAITING_RECEIVE: "48vw",
      FINISH: "48vw",
      CANCEL: "48vw",
    };
    return (
      <View className="list-item" key={data.orderId + Math.random()}>
        <View className="list-item-header">
          <View className="top">
            <Text className="text">{data.createTime}</Text>
          </View>
          <View className="top">
            <Text
              className="text text-status"
              style={{
                color: statesCorol[data.state],
              }}
            >
              {states[data.state]}
            </Text>
          </View>
        </View>
        <View className="list-item-content">
          <View
            className="list-item-content-info"
            onClick={this.handleClickItem.bind(this, data)}
          >
            <Image className="img" mode="aspectFit" src={data.productImage} />
            <View className="list-item-content-info-box">
              <View className="title-info">
                <View className="title name">
                  {data.productName}
                  {data.orderType && data.orderType === "03" ? (
                    <Image
                      className="continue-order"
                      mode="aspectFit"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/7ed84bb0df1249fb9fb34b9cbf71de31.png"
                    />
                  ) : (
                    ""
                  )}
                </View>
                <View className="device-type ">规格：{data.skuInfo}</View>
                <View className="price name">
                  合计：<Text className="price-num">¥{data.totalAmount}</Text>
                </View>
              </View>
            </View>
          </View>

          <View className="list-item-content-btn">
            {data.state === "WAITING_FOR_PAY" ? (
              <popover
                className="popover"
                position={position}
                show={show}
                showMask={false}
                onMaskClick={this.onMaskClick}
              >
                <View
                  onClick={this.onShowPopoverTap}
                  style={{ marginRight: star[data.state] }}
                >
                  <Image
                    mode="aspectFit"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/912eae1d5dab4275918d94231ace2490.png"
                    style={{ width: "25px", height: "25px" }}
                  />
                </View>
                <View slot="items">
                  <popover-item onItemClick={this.connectService}>
                    <text>联系客服</text>
                  </popover-item>
                  <popover-item
                    onItemClick={() => this.handleClickCancelOrder(data)}
                  >
                    <text>取消订单</text>
                  </popover-item>
                </View>
              </popover>
            ) : null}
            {data.state === "WAITING_FOR_DELIVERY" ? (
              <View>
                <Button
                  className="btn"
                  onClick={() =>
                    Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                  }
                >
                  投诉
                </Button>
                <Button className="btn" onClick={this.connectService}>
                  客服热线
                </Button>
                <Button
                  className="btn"
                  onClick={() => this.handleClickCancelOrder(data)}
                >
                  取消订单
                </Button>
                <Button
                  className="btn"
                  onClick={() => this.changeAddress(data)}
                >
                  修改地址
                </Button>
              </View>
            ) : null}
            {data.state === "WAITING_FOR_PAY" ? (
              <Button className="btn" onClick={() => this.changeAddress(data)}>
                修改地址
              </Button>
            ) : null}
            {data.state === "WAITING_FOR_PAY" && (
              <Button
                className="btn careful"
                onClick={() => this.onClickFrezzAgain(data)}
              >
                去支付
              </Button>
            )}
            {data.state === "CANCEL" ? (
              <View>
                <Button
                  className="btn"
                  onClick={this.connectService}
                  style={{
                    marginRight: "54vw",
                  }}
                >
                  客服热线
                </Button>

                <Button
                  className="btn careful"
                  onClick={() => this.onClickFrezzT(data)}
                >
                  再次下单
                </Button>
              </View>
            ) : null}
            {data.state === "FINISH" ? (
              <View>
                <Button
                  className="btn"
                  onClick={() =>
                    Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                  }
                >
                  投诉
                </Button>
                <Button
                  className="btn"
                  onClick={this.connectService}
                  // style={{
                  //   marginRight: !data.hasEvaluation ? "42vw" : "54vw",
                  // }}
                >
                  客服热线
                </Button>

                <Button
                  className="btn careful"
                  onClick={() => this.onClickFrezzT(data)}
                >
                  再次下单
                </Button>
                {!data.hasEvaluation ? (
                  <Button className="btn" onClick={() => this.toComment(data)}>
                    评论
                  </Button>
                ) : null}
              </View>
            ) : null}

            {data.state === "WAITING_RECEIVE" ? (
              <View>
                <Button
                  className="btn"
                  onClick={() =>
                    Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                  }
                >
                  投诉
                </Button>
                <Button
                  className="btn"
                  onClick={this.connectService}
                  style={{
                    marginRight: "25vw",
                  }}
                >
                  客服热线
                </Button>
                <Button
                  className="btn"
                  onClick={this.handleClickExpress.bind(this, data.orderId)}
                >
                  查询物流
                </Button>
                <Button
                  className="btn careful"
                  onClick={this.handleClickReceiveGoods.bind(
                    this,
                    data.orderId
                  )}
                >
                  确认收货
                </Button>
              </View>
            ) : null}
          </View>

          {(data.status === "04" || data.status === "02") && (
            <View>
              <View className="list-item-content-btn">
                {/* {dueTimeMs > 0 ? <View></View> : null} */}
                <Button className="btn" onClick={this.connectService}>
                  联系客服
                </Button>
                {data.status === "04" ? (
                  <Button
                    className="btn"
                    onClick={this.handleClickCancelOrder.bind(this, data)}
                  >
                    取消订单
                  </Button>
                ) : (
                  ""
                )}
                <Button
                  className="btn careful"
                  onClick={this.handleClickBillDetail.bind(this, data)}
                >
                  支付账单
                </Button>
                {idCord}
              </View>
            </View>
          )}
          {data.status === "05" && (
            <View className="list-item-content-btn">
              <Button
                className="btn"
                onClick={this.handleClickExpress.bind(this, data.orderId)}
              >
                查询物流
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              <Button
                className="btn careful"
                onClick={this.handleClickReceiveGoods.bind(this, data.orderId)}
              >
                确认收货
              </Button>
              {idCord}
            </View>
          )}
          {data.status === "06" && (
            <View className="list-item-content-btn">
              <popover
                className="popover"
                position={position}
                show={show2}
                showMask={showMask}
                onMaskClick={this.onMaskClick2}
              >
                <View
                  onClick={this.onShowPopoverTap2}
                  style={{ marginRight: "10px" }}
                >
                  <Image
                    mode="aspectFit"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/912eae1d5dab4275918d94231ace2490.png"
                    style={{ width: "25px", height: "25px" }}
                  />
                </View>
                <View slot="items">
                  <popover-item onItemClick={this.connectService}>
                    <text>联系客服</text>
                  </popover-item>
                  <popover-item
                    onItemClick={() => this.handleClickBillDetail(data)}
                  >
                    <text>支付账单</text>
                  </popover-item>
                </View>
              </popover>
              {!data.evaluationStatus && (
                <Button className="btn" onClick={() => this.toComment(data)}>
                  评论
                </Button>
              )}
              {data.buyOutSupport == 1 ? (
                <Button className="btn" onClick={this.buyoutClick}>
                  买断
                </Button>
              ) : null}
              {
                // <Button className='btn' onClick={() => this.buyAgain(data.productId, 'continue', data.skuId, data.orderId)}>续租</Button>
              }
              <Button className="btn" onClick={this.handleClickSendBack}>
                归还
              </Button>
              {idCord}
            </View>
          )}
          {data.status === "09" && (
            <View className="list-item-content-btn">
              <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                账单详情
              </Button>
              <Button
                className="btn"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
              {!data.evaluationStatus && (
                <Button className="btn" onClick={() => this.toComment(data)}>
                  评论
                </Button>
              )}
              {idCord}
            </View>
          )}
          {data.status === "11" && (
            <View className="list-item-content-btn">
              <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {idCord}
            </View>
          )}
          {data.status === "07" && (
            <View className="list-item-content-btn">
              <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              <Button
                className="btn"
                onClick={() =>
                  this.onClickReturn(data.unrentExpressId, data.unrentExpressNo)
                }
              >
                归还状态
              </Button>
              {idCord}
            </View>
          )}
          {data.status === "08" && (
            <View className="list-item-content-btn">
              <Button className="btn" onClick={this.connectService}>
                联系客服
              </Button>
              <Button className="btn" onClick={this.onClickModifySettlement}>
                申请修改
              </Button>
              <Button
                className="btn"
                onClick={this.onClickConfirmSettlement.bind(
                  this,
                  data.orderId,
                  data.settlementRent
                )}
              >
                确认并支付
              </Button>
              {idCord}
            </View>
          )}
        </View>
        <AtModal isOpened={modifySettlementDisplay}>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>
              是否申请商家修改结算单？
            </View>
          </AtModalContent>
          <AtModalAction>
            <Button onClick={this.handleCancelModifySettlement}>再想想</Button>
            <Button
              onClick={this.handleOkModifySettlement.bind(this, data.orderId)}
            >
              确认申请
            </Button>
          </AtModalAction>
        </AtModal>
      </View>
    );
  }
}

export default listItemCopy;
