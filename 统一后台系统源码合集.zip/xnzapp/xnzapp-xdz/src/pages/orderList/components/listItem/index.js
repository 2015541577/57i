import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, Button ,Block} from "@tarojs/components";
import { orderStatus } from "../../../../assets/Constant";
import { formatDate, transdate, leftTimerMS_C } from "../../../../utils/utils";
import {
  AtIcon,
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
} from "taro-ui";
import "./index.scss";
import { connect } from "@tarojs/redux";
import { startAPVerify } from "../../../../utils/openApi";
import { getGlobalData , 
  getUserName,
  getTelephone,
  setTelephone,} from "../../../../utils/globalVariable";
import { getGloble,getUid,getBuyerId, } from "../../../../utils/localStorage";
import Request from '../../../../utils/request';
@connect(({ confirmOrder, authentication }) => ({
  ...confirmOrder,
  ...authentication,
}))
class ListItem extends Component {
  config = {
    usingComponents: {
      popover: "/npm/mini-antui/es/popover/index",
      "popover-item": "/npm/mini-antui/es/popover/popover-item/index",
    },
  };
  state = {
    position: "bottomLeft",
    countDownStr:null,
    show: false,
    show2: false,
    showMask: true,
     modifySettlementDisplay: false,
    showServicePhone: false,
    idCard:false,
    statusObj: {
      "01": {
        text: "待下单",
        color: "#C43737",
      },
      "02": {
        text: "待发货", //"支付中",
        color: "#C43737",
      },
      "03": {
        text: "申请关单",
        color: "#333333",
      },
      "04": {
        text: "待发货",
        color: "#333333",
      },
      "05": {
        text: "待收货",
        color: "#F8A544",
      },
      "06": {
        text: "租用中",
        color: "#C43737",
      },
      "07": {
        text: "待结算",
        color: "#333333",
      },
      "08": {
        text: "结算中",
        color: "#333333",
      },
      "09": {
        text: "已完成",
        color: "#C43737",
      },
      "10": {
        text: "已关闭",
        color: "#333333",
      },
      "11": {
        text: "待发货",
        color: "#333333",
      },
      "13": {
        text: "待发货",
        color: "#333333",
      },
      "14": {
        text: "申请取消中",
        color: "#C43737",
      },
    },
  };
  // 获取倒计时
  countDown = () => {
    const {
      data: { createTime, status },
      dispatch,
    } = this.props;
    if (!createTime) {
      setTimeout(this.countDown, 1000);
    } else {
      const cdStr = leftTimerMS_C(createTime.replace(/-/g, "/"));
      if (status === "01" && cdStr) {
        setTimeout(this.countDown, 1000);
        this.setState({ countDownStr: cdStr });
      } else {
      }
    }
  };
  handleClickItem = (order) => {
    let obj = {
      orderId: order.orderId,
      type: order.type,
      refundStatus: order.refundStatus ? order.refundStatus : null,
      typeText: order.status,
      imgUrl: order.mainImageUrl,
      productName: order.productName,
      skuTitle: order.skuId,
    };
    const { onClickItem } = this.props;
    onClickItem(obj);
  };
  // 去评论
  toComment(data) {
    Taro.navigateTo({
      url: "/pages/commentOn/index?orderId=" + data.orderId + "&from=orderList",
    });
  }
  // 去签约
  onClickSign  = (order) => {
    console.log(order,"kkkkkkkkkkkkkkk")
    let obj = {
      orderId: order.orderId,
      status: order.status,
      examineStatus: 0, //order.examineStatus,
      statusCancel: order.status,
    };
    const { onClickSignAContract, data } = this.props;
    onClickSignAContract(obj, data);
  };
  // 芝麻代扣的子传父方法
  handleClickPayment = (order) => {
    console.log(order,"kkkkkkkkkkkkkkk")
    let obj = {
      orderId: order.orderId,
      status: order.status,
      examineStatus: 0, //order.examineStatus,
      statusCancel: order.status,
      faceAuthStatus: order.faceAuthStatus
    };
    const { onClickPayment, data } = this.props;
    onClickPayment(obj, data);
  };
  handleClickCancelOrder = (order) => {
    let obj = {
      orderId: order.orderId,
      status: order.status,
      examineStatus: 0, //order.examineStatus,
      statusCancel: order.status,
    };
    const { onClickCancelOrder, data } = this.props;
    onClickCancelOrder(obj, data);
  };

  handleClickBillDetail = (order) => {
    const { onClickBillDetail } = this.props;
    onClickBillDetail(order);
  };

  handleClickFrezzAgain = (order) => {
    const { onClickFrezzAgain } = this.props;
    onClickFrezzAgain(order);
  };
  onlink = (data) => {
    console.log(data,'=========');
    Taro.redirectTo({url:`/activity/signacontract/index?link=${data.contractLink}`})
  }

  handleClickReceiveGoods = (orderId) => {
    const { onClickReceiveGoods } = this.props;
    onClickReceiveGoods(orderId);
  };

  handleClickSendBack = () => {
    const { onClickSendBack, data } = this.props;
    onClickSendBack(data);
  };
  buyoutClick = () => {
    const { onClickSendBack, data } = this.props;
    Taro.navigateTo({
      url: `/pages/buyOutOrder/index?orderId=${data.orderId}&sign=1`,
    });
  };

  handleClickExpress = (order) => {
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${order}`,
    });
  };
  onClickReturn(expressId, expressNo) {
    //const { orderId } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/express/index?expressId=${expressId}&expressNo=${expressNo}`,
    });
  }
  handleCancelModifySettlement = () => {
    this.setState({ modifySettlementDisplay: false });
  };
  handleOkModifySettlement = (orderId) => {
    const { dispatch } = this.props;

    dispatch({
      type: "orderDetail/userApplicationForAmendmentOfSettlementForm",
      payload: { orderId },
    });
    this.setState({ modifySettlementDisplay: false });
  };
  onMaskClick = () => {
    this.setState({
      show: false,
    });
  };
  onShowPopoverTap = () => {
    this.setState({
      show: true,
    });
  };
  onMaskClick2 = () => {
    this.setState({
      show2: false,
    });
  };
  onShowPopoverTap2 = () => {
    this.setState({
      show2: true,
    });
  };
  connectService = (val) => {
    const { data } = this.props;
    let obj = {
      business: data.serviceTel,
    };

    const { onClickService } = this.props;
    onClickService(obj);
  };
  // 续租
  buyAgain(productId, type, skuId, orderId) {
  
    Taro.navigateTo({
      url:
        "/pages/productDetail/index?itemId=" +
        productId +
        "&buyType=" +
        type +
        "&skuId=" +
        skuId +
        "&orderId=" +
        orderId,
    });
  }
  onNameFinsh=()=>{
      
    Taro.navigateTo({ url: `/pages/Certificates/index?idcard=1` });

    // this.setState({
    // idCard:true
    // })
      
  }
  onFaceFinsh = (order) => {
    const { dispatch, onCKAll } = this.props;
    dispatch({
      type: "confirmOrder/faceRecognition",
      payload: {
        orderId: order.orderId,
        uid:getUid(),
      },
      callback: (data) => {
        startAPVerify(
          {
            certifyId: data.certifyId,
            url: data.faceUrl,
          },
          function(verifyResult) {
            // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
            if (verifyResult.resultStatus === "9000") {
              // 验证成功，接入方在此处处理后续的业务逻辑
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId: data.certifyId,
                  bizId:data.bizId,
                },
                callback: (res) => {
                   Request({
                            url:"hzsx/api/order/hasOrderUsing",
                            method:'GET',
                            data:{
                              uid:getUid(),
                              channelId:getGloble('channelId'),
                            }
                          }).then(res=>{
                            if(res.data.data===true){
                              my.call('verifyIdentity', {
                                action: 'getEnvData', 
                              }, function (result) {
                                console.log(result.actionResult);
                                const actionResult = result.actionResult
                                if(actionResult){
                                  Request({
                                    url:'hzsx/api/components/riskRuning',
                                    method:'POST',
                                    data:{
                                      uid:getUid(),
                                      channelId:getGloble('channelId'),
                                      orderId: order.orderId,
                                      bizRequestParams:actionResult,
                                      userId:getBuyerId(),
                                    }
                                  }).then(res=>{
                                    const verifyId = res.data.data.verifyId;
                                    const bizId = res.data.data.bizId;
                                    my.call('verifyIdentity', {
                                      verifyId: verifyId,
                                      user_id:getBuyerId(),
                                    }, function (result) {
                                      Request({
                                        url:'hzsx/api/components/runingReceive',
                                        method:'POST',
                                        data:{
                                          bizId,
                                          code:result.code,
                                        }
                                      }).then(res=>{
                                            console.log('这里的是订单列表中的刷脸认证')
                                      })
                                    });
                                  })
                                }
                              });
                            }
                          })
                  dispatch({
                    type: "orderList/fetchUserOrderList",
                    payload: {
                      overDueQueryFlag: false,
                      pageNumber: 1,
                      pageSize: 10,
                    },
                  });
                },
              });
            } else {
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                  passed: false,
                  bizId:data.bizId,
                },
                callback: (res) => {
                  dispatch({
                    type: "orderList/fetchUserOrderList",
                    payload: {
                      overDueQueryFlag: false,
                      pageNumber: 1,
                      pageSize: 10,
                    },
                  });
                },
              });
            }
            // 用户主动取消认证
            if (verifyResult.resultStatus === "6001") {
              // 可做下 toast 弱提示m
              Taro.showToast({
                title: "取消认证成功",
              });
            }
            if (verifyResult.result) {
            }
            // 其他结果状态码判断和处理 ...
          }
        );
      },
    });
  };

  // 修改地址
  changeAddress(data) {
    Taro.navigateTo({
      url:
        "/pages/address/index?orderId=" +
        data.orderId +
        "&pages=orderList&type2=" +
        (this.props.type || "all"),
    });
  }

  onClickConfirmSettlement = (orderId, waitTotalPay) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/confirmOrderSettlement",
      payload: {
        orderId,
        amount: waitTotalPay,
        channelId: getGloble('channelId'),
      },
    });
  };

  onClickFrezzAgain = (order) => {
    const { dispatch } = this.props;
    console.log(order,'orderorderorder');
    if (order.type === 2) {
      dispatch({
        type: "orderDetail/payReletAgain",
        payload: {
          orderId: order.orderId,
        },
      });
    } else if (order.type === 3) {
      dispatch({
        type: "orderDetail/payBuyOutAgain",
        payload: {
          orderId: order.orderId,
        },
      });
    } else {
      //这里是走预授权的方法
      this.handleClickPayment(order)
      // dispatch({
      //   type: "orderDetail/userFrezzAgain",
      //   payload: {
      //     orderId: order.orderId,
      //   },
      //   callback:res=>{
      //     dispatch({
      //       type: "orderList/fetchUserOrderList",
      //       payload: {
      //         overDueQueryFlag: false,
      //         pageNumber: 1,
      //         pageSize: 10,
      //       },
      //     });
      //   }
      // });
    }
  };

  onClickModifySettlement = () => {
    this.setState({ modifySettlementDisplay: true });
  };
// componentDidShow(){
//     this.onCardinformation()
// }
  
  componentDidMount(){
      // this.onCardinformation()
  };
  goodsOrderId=(id)=>{
     Taro.navigateTo({
      url: `/pages/orderDetails/index?orderId=${id}`,
    });
  }
   //发起共证
  notarization = (data) =>{
    console.log(data,'发起公证数据');
     my.setClipboard({
      text: data.weiXinHttpUrl, // 剪贴板数据
      success: (res) => {
        my.alert({
          content: '复制成功请于5分钟之内到浏览器复制打开'
        });
      },
    });
  }
  onClickFrezzAgainss = (order) => {
    Request({
      url:'hzsx/api/appZuLinPingTai/antZuLinPingTaiUserContractSignQueryConfirm',
      method:'POST',
      data:{
        channelIdOfReq:'006',
        orderIdOfReq:order.orderId,
      } 
    }).then(res=>{
      console.log(res,"ppppppppppppppp")
      if(res.data.responseType == "SUCCESS") {
        my.navigateToMiniProgram({
          appId:"2021001152620480", // 区块链合同真实appId
          path:"pages/tripartite/index", // 支付宝商家跳转区块链合同代扣签署地址（真实路径
          query:{
          signStr:res.data.data.myZuLinPingTai_signStr,// 签署代扣必要的字符串参数
          tenantId:res.data.data.myZuLinPingTai_tenantId_res,
          merchantId:res.data.data.myZuLinPingTai_merchantId_res,
          orderId:res.data.data.myZuLinPingTai_orderId_res,
          redirectUrl:'alipays://platformapi/startapp?appId=2021004124697663&page=pages/orderList/index?type=all', // 代扣签署成功/失败回跳地址，示例 alipays://platformapi/startapp?appId=2021004108689505&page=pages/home/index，appId 和 page 需要根据实际情况调整真实数值
        }, // 需要携带的必要参数
        success: () => {
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
          }, 1000)
        },
        fail: () => {
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
          }, 1000)
        },
        });

      }else {
        Taro.showToast({
          title: "签署失败，请稍后再次点击！",
          icon: "none",
        });
        setTimeout(() => {
          Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
        }, 1000)
      }
    })
  }
  render() {
    const { data, type, index,isCards } = this.props;
    const {
      position,
      show,
      showMask,
      statusObj,
      countDownStr,
      modifySettlementDisplay
    } = this.state;
    
    // 待支付倒计时
    if (data.status === "01" && !countDownStr) {
      this.countDown();
    }
    const letTime =
      data.createTime &&
      formatDate(new Date(data.createTimeStr), "yyyy-MM-dd hh:mm");
    const newTime = formatDate(new Date(), "yyyy-MM-dd hh:mm");
    let dueTime =
      transdate(letTime) +
      data.sysConfigValue * 60 * 60 * 1000 -
      transdate(newTime);
    let dueTimeMs = dueTime / 1000;
    const idCord =
      type == "payment" ||
      data.faceAuthStatus == "03" ||
      data.status == "WAITING_PAYMENT" ? null : (
        <View
          className="btnCord idcord"
          onClick={this.onFaceFinsh.bind(this, data)}
        >
          刷脸认证
        </View>
      );
      const idCard= isCards ? null : (  
     <View
      className="btnCord idcord"
          onClick={this.onNameFinsh}
        >
          实名认证
        </View>);
        
    const { userState } = this.$router.params;

    return (
      <View className="list-item" key={data.orderId + Math.random()}>
        <View className="list-item-header">
          <View className="top">
            <Text className="text">{data.createTime}</Text>
            {countDownStr ? (
              <Text className="text">{countDownStr}后关闭订单</Text>
            ) : (
              ""
            )}
          </View>
          <View className="top">
            <Text
              className="text text-status"
              style={{
                color:
                  (statusObj &&
                    statusObj[data.status] &&
                    statusObj[data.status].color) ||
                  "#333",
              }}
            >
              {statusObj[data.status].text}
            </Text>
          </View>
        </View>
        <View className="list-item-content">
          <View
            className="list-item-content-info"
            onClick={this.handleClickItem.bind(this, data)}
          >
            <Image className="img" mode="aspectFit" src={data.mainImageUrl} />
            <View className="list-item-content-info-box">
              <View className="title-info">
                <View className="title name">
                  {data.productName}
                  {data.orderType && data.orderType === "03" ? (
                    <Image
                      className="continue-order"
                      mode="aspectFit"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/7c0718bbc5604477a807b84a86c016d3.png"
                    />
                  ) : (
                    ""
                  )}
                </View>
                <View className="device-type ">规格：{data.skuTitle}</View>
                <View className="price name">
                  总租金：<Text className="price-num">¥{data.totalRent}</Text>
                </View>
              </View>
            </View>
          </View>
          <View className="list-item-content-zx">
            <View className="list-item-content-zx-btn">
         {data.orderGoodsDtoList && data.orderGoodsDtoList.length ?(
           <Block>
             {
               data.orderGoodsDtoList.map(item=>(
                   <Button
                     key={item.id}
                    className={'btn '+(item.status=='01' ? 'buyAgain':'')}
                    onClick={() => this.goodsOrderId(item.goodsOrderId)}
                  >
                    {item.serviceName}
                  </Button>
               ))
              }
           </Block>
         ) : ''}
         </View>
          </View>
          {data.status === "01" && (
            <View className="list-item-content-btn">
              <popover
                className="popover"
                position={position}
                show={show}
                showMask={showMask}
                onMaskClick={this.onMaskClick}
              >
                <View
                  onClick={this.onShowPopoverTap}
                  style={{ marginRight: "10px" }}
                >
                  <Image
                    mode="aspectFit"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ddfa73fd9d814cd186fbdb521b11ad33.png"
                    style={{ width: "25px", height: "25px" }}
                  />
                </View>
                <View slot="items">
                  <popover-item onItemClick={this.connectService}>
                    <text>联系客服</text>
                  </popover-item>
                </View>
              </popover>

              {/* <Button
                className="btn"
                onClick={this.handleClickCancelOrder.bind(this, data)}
              >
                申请取消
              </Button> */}
              <Button className="btn" onClick={() => this.changeAddress(data)}>
                修改地址
              </Button>
              <Button
                className="btn careful"
                onClick={this.onClickFrezzAgain.bind(this, data)}
              >
                去下单
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
            
            </View>
          )}
          {(data.status === "04" || data.status === "02"  || data.status === "11" || data.status === "13") && (
            <View>
              <View className="list-item-content-btn">
                 {
                    data.fuHongLinkResp != null?(
                    <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                    ):''
                  }
                <Button
                  className="btn"
                  onClick={() =>
                    // Taro.navigateTo({ url: "/pages/FilingComplaint/index" })
                    Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                  }
                >
                  投诉
                </Button>
                <Button className="btn" onClick={this.connectService}>
                  联系客服
                </Button>
                {/* {data.status === "04" || data.status === "11" || data.status === "13" ? ( */}
                {data.status === "13" ? (

                  <Button
                    className="btn"
                    onClick={this.handleClickCancelOrder.bind(this, data)}
                  >
                    申请取消
                  </Button>
                ) : (
                  ""
                )}
                {/*     
                // 代扣方式：1是普通预授权方式；2蚂蚁链合同代扣
                    withholdType  数字类型   2确定时蚂蚁链合同代扣 其他不是
                        // 用户是签署完成：1未签署完成，2已签署完成。2则说明用户已经盖章，归档了
                    userIsSigned 数字类型  2确定 说明用户已经盖章  其他不是 */}
                {data.status === "04" && ((data.withholdType===7&&data.userIsSigned == 3)||((data.withholdType !== 2 && data.withholdType !== 4 && data.withholdType !== 7) || ((data.withholdType !== 7)&&(data.userIsSigned == 2))) ) ? (
                  <Button
                    className="btn careful"
                    onClick={this.handleClickBillDetail.bind(this, data)}
                  >
                    支付账单
                  </Button>
                ) : (
                  ""
                )}
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
                {/* {data.isCanSignAntchainContract === 2 ? (
                  <Button
                    className="btn careful"
                    onClick={this.onClickSign.bind(this, data)}
                  >
                    去签约
                  </Button>
                ) : (
                  ""
                )} */}
                {data.isCanSignAntchainContract === 3 ? (
                  <Button
                    className="btn careful"
                    onClick={this.onClickFrezzAgainss.bind(this, data)}
                  >
                    代扣签约
                  </Button>
                ) : (
                  ""
                )}
                {idCord}
                {idCard}

              </View>
            </View>
          )}
          {data.status === "05" && (
            <View className="list-item-content-btn">
             {
                  data.fuHongLinkResp != null?(
                  <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                  ):''
                }
              <Button
                className="btn"
                onClick={() =>
                  Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                }
              >
                投诉
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickExpress.bind(this, data.orderId)}
              >
                查询物流
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              <Button
                className="btn careful"
                onClick={this.handleClickReceiveGoods.bind(this, data.orderId)}
              >
                确认收货
              </Button>
              {idCord}
              {idCard}

            </View>
          )}
          {data.status === "06" && (
            <View className="list-item-content-btn">
              <popover
                className="popover"
                position={position}
                show={show2}
                showMask={showMask}
                onMaskClick={this.onMaskClick2}
              >
                <View
                  onClick={this.onShowPopoverTap2}
                  style={{ marginRight: "10px" }}
                >
                  <Image
                    mode="aspectFit"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ddfa73fd9d814cd186fbdb521b11ad33.png"
                    style={{ width: "25px", height: "25px" }}
                  />
                </View>

                <View slot="items">
                  <popover-item onItemClick={this.connectService}>
                    <text>联系客服</text>
                  </popover-item>
                  <popover-item
                    onItemClick={() =>
                      Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                    }
                  >
                    <text>投诉</text>
                  </popover-item>
                     {!data.evaluationStatus &&(  <popover-item 
                      onItemClick={() => this.toComment(data)}
                  >
                    <text>评论</text>
                  </popover-item>)}
                </View>
              </popover>
                 <Button
                className="btn buyAgain"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
              {/* <Button
                className="btn"
                onClick={() => this.handleClickBillDetail(data)}
              >
                账单
              </Button> */}
            
              {data.buyOutSupport == 1 ? (
                <Button className="btn" onClick={this.buyoutClick}>
                  买断
                </Button>
              ) : null}
              <Button
                className="btn careful"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
              <Button className="btn" onClick={this.handleClickSendBack}>
                归还
              </Button>
              {idCord}
     
            </View>
          )}
          {data.status === "09" && (
            <View className="list-item-content-btn">
             {
                data.fuHongLinkResp != null?(
                <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                ):''
              }
              <Button
                className="btn"
                onClick={() =>
                  Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                }
              >
                投诉
              </Button>
              {/* <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button> */}
              {/* <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                账单详情
              </Button> */}
                {
                data.fuHongLinkResp != null?(
                <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                ):''
              }
              <Button
                className="btn buyAgain"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
              <Button
                className="btn careful"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
              {/* {!data.evaluationStatus && (
                <Button className="btn" onClick={() => this.toComment(data)}>
                  评论
                </Button>
              )} */}
              {idCord}
           

            </View>
          )}
          {data.status === "11" && (
            <View className="list-item-content-btn">
              <Button
                className="btn"
                onClick={() =>
                  Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                }
              >
                投诉
              </Button>
              <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button>
              {/* <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button> */}
              {idCord}
              {idCard}

            </View>
          )}
          {data.status === "07" && (
            <View className="list-item-content-btn">
             {
                data.fuHongLinkResp != null?(
                <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                ):''
              }
              <Button
                className="btn"
                onClick={() =>
                  Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                }
              >
                投诉
              </Button>
              <Button
                className="btn"
                onClick={this.connectService.bind(this, data)}
              >
                联系客服
              </Button>
                <Button
                className="btn buyAgain"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
              <Button
                className="btn"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
              <Button
                className="btn"
                onClick={() =>
                  this.onClickReturn(data.unrentExpressId, data.unrentExpressNo)
                }
              >
                归还状态
              </Button>
              {idCord}
              {idCard}

            </View>
          )}
          {/* {(data.status === "04") && (
            <View className="list-item-content-btn">
              <Button
                className="btn careful"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {idCord}
            </View>
          )} */}
            {(data.status === "10") && (
            <View className="list-item-content-btn">
              {
                data.fuHongLinkResp != null?(
                <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                ):''
              }
                <Button
                className="btn buyAgain"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
            </View>
          )}
          {data.status === "08" && (
            <View className="list-item-content-btn">
                {
                data.fuHongLinkResp != null?(
                <Button className="btn" onClick={()=>this.notarization(data.fuHongLinkResp)}>协议公证</Button>
                ):''
              }
              <Button
                className="btn"
                onClick={() =>
                  Taro.navigateTo({ url: `/pages/FilingComplaint/index?orderId=${data.orderId}` })
                }
              >
                投诉
              </Button>
              <Button className="btn" onClick={this.connectService}>
                联系客服
              </Button>
              <Button className="btn" onClick={this.onClickModifySettlement}>
                申请修改
              </Button>
                <Button
                className="btn buyAgain"
                onClick={() => this.buyAgain(data.productId, "buyAgain")}
              >
                再次下单
              </Button>
              <Button
                className="btn careful"
                onClick={this.handleClickBillDetail.bind(this, data)}
              >
                支付账单
              </Button>
              {
                data.contractLink ?
                <Button
                className="btn careful"
                onClick={this.onlink.bind(this, data)}
              >
                去签约
                  </Button>
                  :""
              }
              <Button
                className="btn"
                onClick={this.onClickConfirmSettlement.bind(
                  this,
                  data.orderId,
                  data.settlementRent
                )}
              >
                确认并支付
              </Button>
              {idCord}
              {idCard}
            </View>
          )}
        </View>
        <AtModal isOpened={modifySettlementDisplay}>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>
              是否申请商家修改结算单？
            </View>
          </AtModalContent>
          <AtModalAction>
            <Button onClick={this.handleCancelModifySettlement}>再想想</Button>
            <Button
              onClick={this.handleOkModifySettlement.bind(this, data.orderId)}
            >
              确认申请
            </Button>
          </AtModalAction>
        </AtModal>
      </View>
    );
  }
}

export default ListItem;
