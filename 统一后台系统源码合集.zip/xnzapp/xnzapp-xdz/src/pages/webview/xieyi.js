import Taro, { Component } from "@tarojs/taro";
import { connect } from "@tarojs/redux";
import { getUid, getGloble } from "../../utils/localStorage";
import "./index.scss";
import { timeDate } from "../../utils/utils";

@connect(({ agreement, confirmOrder }) => ({ ...agreement, ...confirmOrder }))
class Ment extends Component {
  config = {
    navigationBarTitleText: "租赁协议",
  };
  state = {
    loading: true,
    name: "迪丽热巴·迪",
    Relationship: [],
    firstData: [],
    secondData: [],
    threeData: [],
    eightData: [],
    nineData: [],
    tenData: [],
    twelveData: [],
    thirteenData: [],
    sixteen: [],
    seventeen: [],
    privacyheader: [],
    colectioninformation: [],
    footer: [],
    isUmbner: false,
    agreementData: {},
  };
  componentDidMount = () => {
    const { dispatch } = this.props;
    const { detail, orderId, signNumber, productId } = this.$router.params;
    if (productId) {
      dispatch({
        type: "agreement/agreementNoorder",
        payload: {
          productId: productId,
          uid: getUid(),
        },
        callback: (res) => {
          this.setState({
            agreementData: res.data,
          });
        },
      });
    }
    if (orderId) {
      dispatch({
        type: "agreement/agreementNoorder",
        payload: {
          orderId: orderId,
        },
        callback: (res) => {
          this.setState({
            agreementData: res.data,
          });
        },
      });
    }

    let {
      Relationship,
      firstData,
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      privacyheader,
      colectioninformation,
      footer,
    } = require("./data.js");
    this.setState({
      Relationship,
      firstData,
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      privacyheader,
      colectioninformation,
      footer,
    });
  };
  render() {
    let { dataess, information } = this.props;

    const {
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      agreementData,
    } = this.state;

    let fontWeight = {
      fontWeight: "bold",
    };
    const { detail, adressInformation, type } = this.$router.params;
    const adress = adressInformation && JSON.parse(adressInformation);
    dataess = dataess || {}; // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading()
    return (
      <View className="webview-page">
        <View className="header">租赁服务协议</View>
        <View className="text-size" style={fontWeight}>
          甲方（商家）：{agreementData.shopName}
        </View>
        <View className="text-size">甲方地址：{agreementData.shopAddress}</View>
        <View className="text-size">法人（负责人）：{agreementData.shopLegalName}</View>
        <View className="text-size" style={{ marginTop: "20px" ,fontWeight:'700'}}>
          乙方（租户,以下尊称“您”）：{agreementData.userName}
        </View>
        <View className="text-size">乙方身份证号：{agreementData.idNo}</View>
        <View  className="text-size">
          乙方地址：{agreementData.reciveAddress}
        </View>
        <View className="text-size">
          乙方电话：{agreementData.telephone}
        </View>
        <View  className="text-size">
          电子邮箱：{agreementData.email}
        </View>
        {/* <View className="text-size">
          乙方租用产品：{agreementData.productName}
        </View> */}
        <View className="text-size" style={{ marginTop: "20px",fontWeight:'700' }}>
          丙方（平台）：{agreementData.platformName}
        </View>
        <View className="text-size">
          丙方地址：{agreementData.platformAddress}
        </View>
        <View  className="text-size">法人（负责人）：{agreementData.platformLegalName}</View>
        <View className="lock-text">甲乙丙三方关系说明：</View>
        <View className="lock-text">
          【甲方】系指通过平台进驻成为租赁商的商家，自愿签署《租赁服务协议》，且已阅览并同意本协议所有条款，认可本协议的法律效力。
        </View>
        <View className="lock-text">
          【乙方】系指通过平台自愿下单租用甲方产品的租户。
        </View>
        <View className="lock-text">
          【丙方】系指星动租平台（本协议简称“平台”），即由西安鑫盛智达网络科技有限公司为甲乙双方提供技术和服务支持的在线交易平
          台，其只负责为本协议项下的租赁服务提供网络交易平台、系统支
          持及信息技术支持等服务，星动租平台与平台商家系独立的法律
          主体/民事主体，不承担您与平台商家之间因本次租赁服务而产生的
          任何责任。
        </View>

        <View className="sign-title">特别提醒：</View>
        <View
          className="lock-text"
          style={{
            fontWeight: "bold",
           
          }}
        >
        1、在此特别提示您阅读本协议的各个条款，尤其是以粗体及下划线
        标示的条款，包括第[一]条关于设备、第[二]条租金与押金、第
        [三]条关于订单取消、租期计算和提前返还、第[六]条订单审核、
        第[十二]条失信客户处理(包含失信认定、失信处置、租转售条款
        等)、第[十五]条争议解决条款、第[十六]条证据保全(区块链存
        证)、第[十七]条通知和送达条款及附件一《个人信息查询授权书》
        等可能限制或影响您责任的相应条款。如您通过点击确认、勾选同
        意等方式在平台或其他客户端确认本协议，或通过电子签名的方式
        签署本协议，即视为您已阅读并同意本协议所有条款，且并对本协
        议条款的含义及相应的法律后果已全部通晓并充分理解，同意接受
        本协议的约束。
        </View>
        <View
           className="lock-text"
          style={{
            fontWeight: "bold",
          }}
         >
          2、乙方确认并承诺:乙方已明确知晓乙方登陆星动租平台前已同
          意授权星动租平台获取乙方的支付宝账号信息，使用该支付宝账
          号在星动租平台进行的任意行为均视为乙方本人的行为(包括但不
          限于签署本协议、申请免押等行为)，乙方对上述行为承担一切责任
          及法律后果。
        </View>
        <View  className="lock-text"
          style={{
            fontWeight: "bold",
          }}>
        3、如果您不同意本协议的任意内容，或者无法准确理解本协议相
          关条款，请不要进行后续操作。如您对本协议有任何疑问，请与平
          台官方客服进行咨询，星动租客服将竭诚为您服务并作出解释。
        </View>
        <View  className="lock-text"
          style={{
            fontWeight: "bold",
          }}>
         4、本协议签署地默认为平台所在地，即陕西省西安市未央区。因本合同
          履行过程中引起的或与本合同相关的任何争议，任何一方均可向甲
          方所在地人民法院或丙方所在地人民法院提起诉讼。
        </View>

        <View className="sign-title">第一条 关于设备</View>
        <View className="lock-text" style={fontWeight}>1.1 租赁订单的设备详细信息如下</View>
        <View className="text-size" style={fontWeight}>订单编号：{agreementData.orderId}</View>
        <View className="text-size" style={fontWeight}>收货人：{agreementData.userName}</View>
        <View className="text-size" style={fontWeight}>联系电话：{agreementData.telephone}</View>
        <View className="text-size" style={fontWeight}>
          送达地址：{agreementData.reciveAddress || adress &&`${adress.street}`}
        </View>
        <View className="text-size" style={fontWeight}>
          电子邮箱：{agreementData.email}
        </View>
        <View className="text-size" style={fontWeight}>设备名称：{agreementData.productName}</View>
        <View className="text-size" style={fontWeight}>
          套餐名称：{agreementData.skuTitle}
        </View>
        <View className="text-size" style={fontWeight}>
          {/* 商品详情：（附表格） */}
          {/* 规格颜色：{agreementData.skuTitle || type === "DIRECT"
            ? information.skuInfo
            : information.skuDto &&
              !!information.skuDto.specAll &&
              information.skuDto.specAll
                .map((val) => val.platformSpecValue)
              .join(",")} */}
          {/* 规格颜色：{agreementData.skuTitle} */}
        </View>
        {/* <View className="text-table" style={fontWeight}>
           <View className="text-tables">
             <Text className="text-tablesText">品牌</Text>
             <Text className="text">11</Text>
             <Text></Text>
           </View>
           <View className="text-tables">
             <Text className="text-tablesText">品牌</Text>
             <Text className="text">11</Text>
           </View>
           <View className="text-tables">
             <Text className="text-tablesText">品牌</Text>
             <Text className="text">11</Text>
           </View>
           <View className="text-tables">
             <Text className="text-tablesText">品牌</Text>
             <Text className="text">11</Text>
           </View>
           <View className="text-tables">
             <Text className="text-tablesText">品牌</Text>
             <Text className="text">11</Text>
           </View>
        </View> */}
        <View className="text-size" style={fontWeight}>设备数量：1台</View>
        <View className="text-size" style={fontWeight}>租期：{ agreementData && agreementData.totalDays ? agreementData.totalDays : 0 }天（{agreementData.totalPeriod || information.orderPricesDto.totalPeriods}期）</View>
        <View className="text-size" style={fontWeight}>
          总租金：
          {/* {agreementData.totalRent || type === "DIRECT"
                    ? information.totalAmount
                    : information.orderPricesDto.rentPrice} */}
          {agreementData.totalRent}
          元
        </View>
        <View className="text-size" style={fontWeight}>
          租金单价：{agreementData.originalRent || information.orderPricesDto && information.orderPricesDto.firstPeriodsRentPrice}
          元/期
        </View>
        {/* <View className="text-size" style={fontWeight}>
          商品押金：{agreementData.totalDeposit}
        </View>
        <View className="text-size" style={fontWeight}>
          已付押金(已冻结):{agreementData.deposit}
        </View> */}
        {/* <View className="text-size">销售价：{agreementData.salePrice || information.salePrice}</View> */}
        
        <View className="text-size" style={fontWeight}>
          买断价：{agreementData.finalBuyOutPrice} 元
        </View>
         <View className="text-size" style={{textIndent:'2em',fontWeight:'700'}}>
          若上述信息与甲方或星动租（丙方）运营后台订单详情页记
          载内容不一致，以甲方或星动租运营后台订单详情页记载的内容
          为准。其他信息，以下单页面为准
        </View>
        <View className="text-size">
         1.2 乙方在下单租用设备前应当向甲方及丙方提供自己的真实姓名
          和身份证号码，同时还应当提供准确的邮寄送达地址及联系方式
          （包括但不限于手机号码、微信号、邮箱等）。 乙方提供的身份证
          住址与邮寄送达地址不一致的，以乙方下单时或发货时确认的邮寄
          送达地址为乙方确认的收货地址。在租赁期限内，乙方住址及联系
          方式变更时应及时通知甲方和丙方，否则，由此电话信息失联、租
          赁设备无法送达、丢失等损失均由乙方承担。
        </View>
        <View className="text-size">
          1.3 乙方在租用设备过程中，需爱护设备，确保设备完好；未经甲
          方同意，不得私自拆卸、私自升级系统或软件服务。
        </View>
        <View className="text-size">
            1.4 甲方提供的租赁服务仅含硬件部分，不含软件；若乙方需预装
          软件，乙方可在发货前将软件提供给甲方，由甲方协助安装；或在
          乙方收到设备后由甲方远程协助安装。若涉及软件版权纠纷由乙方
          自行承担责任。
        </View>
        <View className="text-size">
           1.5 设备运费承担以商品详情页（交易快照）中的约定为准。
        </View>
        <View className="sign-title">
          1.6 特别说明:
        </View>
        <View  className="text-size" style={fontWeight}>
          (1)平台的商品或服务信息随时都有可能发生变动，平台当中文字表
          述、图片效果可能被实时修改和调整，对于此类变化和调整，甲方
          可能将不作特别通知。平台展示的标的物规格参数、功能说明、零
          部件信息、库存、限购数量等商品信息将尽可能准确、详细并与实
          际产品信息相匹配，但由于网站上商品信息的数量极其庞大，且受
          互联网技术发展水平(如缓存延时等)、产品批次和生产供应实时变
          化等因素的限制，不排除部分信息会存在滞后或差错的可能性。乙
          方确认:对此情形您表示知悉并理解，并同意不追究甲方及丙方的相
          关责任。
        </View>
        <View className="text-size" style={fontWeight}>
          (2)甲方对商品进行明码标价，但乙方应当了解并同意，甲方的商品
          价格信息随时都有可能发生变动，因此商品成交价格须以乙方您提
          交订单结算时的价格为准。同时，尽管甲方会尽最大努力确保本网
          站商品价格的准确性，但仍然可能出现部分商品标价错误的情形，
          对于明显错误标价的商品，甲方保留不予确认或取消相应订单的权
          利。
        </View>
        <View className="sign-title">第二条 租金和押金</View>
        {/* {secondData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })} */}
        <View className="text-size">
             2.1 产品租金及押金由甲方自主确定，乙方在下单时，由丙方代收相应租金、押金。 
        </View>
        <View className="text-size" style={fontWeight}>
           2.2 丙方根据乙方信用资质授予免押金范围，乙方租赁设备所需押金在免押金范围内的，不需要支付押金；超出部分，应支付押金。甲乙双方未确认发货前，丙方有权依据其自身风险控制系统输出结果决定变更免押金的范围，但须经过甲乙双方同意订单才生效。 
        </View>
        <View className="text-size" >
          2.3 租赁期限届满，乙方根据下单选择需要归还设备的，乙方应及时将设备归还甲方。甲方在收到设备后经检测确认无损坏后，并且乙方在甲方处无任何未结清款项的情况下， 应当在 3 个工作日通知退还押金，如遇节假日则顺延。
        </View>
          <View className="text-size" style={fontWeight}>
           2.4 乙方在租赁期限届满后未及时归还设备的，甲方有权继续按协议约定收取相应租金，乙方每逾期一日应按应付未付款金额0.05%的标准向甲方支付违约金;若乙方逾期归还设备超过15天的，甲方可直接向丙方申请扣除乙方全部押金。
        </View>
        <View className="text-size" style={fontWeight}>
          2.5 甲方产品租金收取方式分两种:一期及多期。发货前乙方至少需支付一期租金。丙方在下一个交租日(交租日为账单中的预计扣款日)自动从乙方绑定账户中扣除下一期租金。乙方应保证在租金付款日账户中有足够金额，以免造成租金支付逾期。
        </View>
        <View className="text-size" style={fontWeight}>
          2.6 乙方应当按时足额支付租金，否则，甲方可直接向丙方申请扣除乙方部分或全部押金，用以抵扣逾期租金或本协议第12.4条约定的买断款。
        </View>
        <View className="text-size" style={fontWeight}>
          2.7 租赁期间设备正常折旧而导致设备无法使用或使用故障、设备自然产生的硬件故障由甲方负责更换，因软件问题导致的使用故障由甲方协助解决。
        </View>
        <View className="text-size" >
          2.8 因人为损坏，拆解，划痕等问题导致维修的，乙方应承担配件成本和维修费用，若乙方拒绝支付配件成本和维修费用，甲方有权向丙方申请划扣乙方部分或全部押金来抵扣相应费用;同时，甲方应向丙方举证，证明设备确为乙方所损坏及设备的损失价值。维修期间算入乙方的租赁期间，乙方须继续支付租金。如设备无法修复、修复价格远远超过设备本身价值或设备丢失的，乙方应当按本协议12.4条的约定向甲方买断该设备。
        </View>
        <View className="text-size" >
           2.9 设备使用过程中因软件造成设备不能使用的问题不包含在租赁服务中，但可要求甲方尽力协助解决。
        </View>
        <View className="sign-title">
          第三条 关于订单取消、租期计算和提前归还
        </View>
        {threeData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })}
         <View className="text-size" style={fontWeight}>
        3.3  除非甲方设备介绍页面约定可随借随还，否则乙方不能提前返还。乙方擅自提前返还设备，乙方实际租期计算至甲方签收设备之日止，乙方须按照实际租期支付租金，来回运费均由乙方承担，且应按以下标准向甲方支付违约金。
         </View>
          <View className="text-size" style={fontWeight}>
             3.3.1 二手设备赔付标准如下:
          </View>
          <View className="text-size" style={fontWeight}>
              （1）总租期在 6 个月(不含 6 个月)以上，乙方须支付 1 个月租金作为违约金;
          </View>
           <View className="text-size" style={fontWeight}>
               (2)总租期在 3 个月(不含 3 个月)-6 个月以内(含 6 个月)的，乙方须支付 15 天租金作为违约金;
          </View>
           <View className="text-size" style={fontWeight}>
               (3)总租期在 3 个月以内(含 3 个月)的，乙方须支付 7 天租金作为违约金。
          </View>
           <View className="text-size" style={fontWeight}>
             3.3.2 全新设备赔付标准:
          </View>
           <View className="text-size" style={fontWeight}>
                “固定租期”租赁方式的订单，乙方须待租赁期满后才能退还;若乙方提前退还设备，甲方将收取剩余租赁期租金的 30%作为服务费。
          </View>
          <View className="text-size" style={fontWeight}>
            3.3.3 定制产品赔付标准:
          </View>
           <View className="text-size" style={fontWeight}>
                乙方定制的产品，乙方须待租赁期满后才能退还;若乙方提前退还设备，甲方将收取剩余租赁期租金的 30%作为服务费。
          </View>
            <View className="text-size" style={fontWeight}>
                3.3.4 如上述违约金/服务费不足以补偿甲方的全部损失，不足部分由乙方承担。
          </View>
        
        <View className="sign-title">第四条 续租</View>
        <View className="lock-text">
        4.1  租赁期限届满后，乙方需要续租的，可以申请续租即在“我的订单”找到待归还的设备，点击续租按钮，乙方继续按原租赁协议约定的标准支付租金，无需另行支付押金。
        </View>
          <View className="lock-text">
        4.2 订单续租后，如未生成新订单，则本合同有效期按照续租租期延展，如生成新订单号，则三方重新签署《租赁服务协议》。
        </View>
          <View className="lock-text" style={fontWeight}>
        4.3 租赁期限届满 7 个自然日后，若乙方未进行归还、买断、续租等任一操作，甲方及丙方可自行开启自动续租，乙方需按照本合同约定的租金标准向甲方支付租金。
        </View>
        <View className="sign-title">第五条 支付方式</View>
        <View className="lock-text">
          5.1 丙方提供支付宝、信用卡、芝麻信用授权等支付方式。
        </View>
        <View className="sign-title">第六条 订单审核</View>
        <View className="lock-text" style={fontWeight}>
         6.1 订单支付成功后，丙方对乙方订单信息进行评估，若经评估判定乙方风险系数较高，甲方有权让乙方补交押金或补信用授权或取消(关闭)订单，如甲方要求乙方补交押金或担保物，乙方未补的，订单将直接关闭，已经支付的款项原路退还乙方。如甲方及丙方识别到乙方为未成年人，可直接关闭订单，已经支付的款项原路退还乙方。
        </View>
        <View className="lock-text"  style={fontWeight}>
          6.2 在订单审核过程中，若丙方依据自身风险控制系统判定乙方风险系数较高时，甲方或丙方在征得乙方同意的前提下，可向乙方预收一期或多期租金(具体扣款期数由甲方或由甲方授权丙方与乙方进行协商，预收租金详见账单列表);租金成功扣除后，若乙方对预收租金金额、对应的预收期数等有异议的，应在 1 个工作日内向丙方提出，逾期未提出则视为乙方对预收租金的认可。
        </View>
        <View className="lock-text" style={fontWeight}>
           6.3 若乙方订单信息与星动租逾期订单中的下单人、支付宝 ID、下单账号及收货联系电话中的一项或多项信息一致，则星动租可暂时冻结此订单(如订单已支付租金或存在冻结押金，则该部分款项将暂时冻结)，直至乙方处理完全部逾期订单或已提供充足证据证明上述逾期订单与其并无任何关联，方可申请解冻订单。
        </View>
        <View className="lock-text" style={fontWeight}>
          6.4 若乙方订单信息与星动租逾期订单中的下单人、支付宝 ID、下单账号及收货联系电话其中一项或多项信息一致，星动租可拒绝为乙方提供租赁服务。
        </View>
        <View className="sign-title">第七条 发票开取</View>
        <View className="lock-text">
          7.1 发票由甲方提供，开取发票必须符合税法的规定。乙方需开取发票的，开票前需主动联系甲方，然后在下单时一并填写开票所需详细资料。开票内容为“租赁服务费”，类型为增值税普通发票或增值税专用票，乙方可在下单页面标注所需的发票类型。 
        </View>
        <View className="lock-text">
        7.2 乙方需开具发票的，应下单成功且收到租赁手机后向甲方申请开具，如需纸质发票，可自行前往甲方领取或要求甲方邮寄，邮寄费用由乙方承担。
        </View>
        <View className="lock-text">
         7.3 发票开具后，如因乙方原因取消订单，乙方应归还发票原件并承担甲方由此支出的税费，同时须按本协议约定承担违约责任。
        </View>
        <View className="sign-title">第八条 甲方的权利与义务</View>
        {eightData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })}
        <View className="text-size" style={fontWeight}>
            8.6  当乙方逾期不缴纳租金时，甲方有权停止为乙方提供租后服务、收回租赁设备或按协议第12.3条、第12.4条的约定要求乙方承担相应的违约责任。
        </View>
         <View className="text-size" style={fontWeight}>
            8.7  对于非甲方生产的租赁商品，乙方在使用过程中造成人身损害、财产损失的，除非证明甲方对于商品造成的损害事故有故意或重大过失，否则甲方不承担任何责任。
        </View>
         <View className="text-size" style={fontWeight}>
           8.8 如乙方所租赁的设备商品详情页中有标注[逾期停机提醒]，则甲方授权丙方在租赁设备中安装停机管理程序并通过停机管理程序对乙方进行履约情况管理，丙方的管理措施详见本协议第9.6条。
        </View>
         <View className="text-size" style={fontWeight}>
           8.9 甲方有权将本协议中出租人的全部权利以及本协议项下甲方对乙方的全部权利义务转移给第三方享有并行使。乙方确认，因履行本协议所产生的纠纷，第三方有权基于甲方的授权，通过本协议约定的方式解决纠纷；乙方同意甲方与第三方的转让协议中对管辖权的重新约定。
        </View>
        <View className="sign-title">第九条 乙方权利与义务</View>
        {nineData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })}

        <View className="text-size" style={fontWeight}>
           9.6 如乙方所租赁的设备商品详情页中有标注「逾期停机提醒]，则乙方所租赁的设备已安装停机管理程序(甲方及丙方仅能通过设备IMEI码对设备进行履约管控，无法通过此停机管理程序非法收集乙方的任何隐私信息)，并由星动租进行履约情况管理，当乙方出现违约行为(如逾期支付租金、逾期归还设备等)，星动租将远程停用乙方所租赁的设备，在此过程中，可能会对网络数据和WLAN链接产生消耗。设备停机及停机恢复规则如下:
        </View>
        <View className="text-size" style={fontWeight}>
           (1)乙方应在签收设备后48小时内激活设备，否则星动租可对租赁设备进行远程停机处理，星动租在进行停机处理前将提前与乙方进行沟通；
        </View>
        <View className="text-size" style={fontWeight}>
            (2)乙方逾期后，星动租将通过短信、电话等一种或多种方式告知乙方须及时履约;当乙方恶意逾期，星动租将对租赁设备进行远程停机处理，设备将处于完全无法使用状态，直至乙方履约完毕后，方可申请恢复使用;
        </View> 
          <View className="text-size" style={fontWeight}>
           (3)租赁设备被远程停用后，用户端无法激活该设备，须待乙方缴足欠款后方可被星动租远程激活，故乙方缴足欠款后，请及时联系甲方或星动租，申请重新激活租赁设备，星动租将在收到乙方申请后核实乙方是否已履约，如乙方已履约则激活设备，如乙方并未完全履约则不激活;
        </View>
        <View className="text-size" style={fontWeight}>
          (4)租赁期间乙方不得自行卸载停机管理程序，若乙方已买断租赁设备，星动租将远程移除停机管理程序，保证乙方拥有设备完整的所有权。
        </View>
          <View className="text-size" style={fontWeight}>
            9.7 乙方使用租赁设备时应遵守相关法律、法规，不得利用租赁设备从事违法犯罪活动，不得利用租赁设备侵害他人合法权益;因乙方违规使用租赁设备所产生的一切法律纠纷及法律责任由乙方自行解决、承担;因乙方原因导致租赁设备被监管部门查封、冻结、扣押的，乙方仍需按照合同约定缴纳租金，合同期满后乙方无法按照约定归还设备的,乙方须向甲方支付买断款买断租赁设备。
        </View>
        <View className="text-size" style={fontWeight}>
            9.8 如乙方归还设备时选择“顺丰上门取件”服务，乙方授权星动租在本订单绑定的支付账号中划扣“顺丰上门取件”服务包含的所有费用(包含运输费用、保价费用等)，“顺丰上门取件”服务费以顺丰出具的账单为准。
        </View>
         <View className="text-size" style={fontWeight}>
          9.9 乙方同意丙方将其在星动租平台上的租赁次数、履约情况等告知甲方;甲方取得上述信息后仅能用于本次租赁审核，不得做其他用途。
        </View>
        <View className="sign-title">第十条 丙方权利与义务</View>
        {tenData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })}
        <View className="text-size" style={fontWeight}>
           10.5 丙方有权在由于甲方原因(例如甲方设备缺货、乙方所在地址不在甲方服务范围内、甲方对订单审核结果不接受等)导致订单无法发货或无效、订单退回至丙方或丙方可以根据实际情况需要等情形，在同等订单条件下(设备型号、配置、租期、租金、押金、买断款等均相同)，可向乙方另行指定设备供应方，并重新签定《租赁服务协议》。
        </View>
        <View className="sign-title">第十一条 关于信息保护</View>
        <View className="text-size">
          11.1 退租时，为保障乙方的隐私及信息安全，乙方须自行妥善处理保存在租赁设备上的数据信息。
        </View>
        <View className="text-size">
          11.2 设备退还后，甲方将抹除设备上所有电子数据，将设备还原至出租前的初始状态，甲方无义务保留设备中的相关信息。同时，甲方承诺不会将乙方留存在设备上的信息向第三人泄露。
        </View>
        <View className="sign-title">第十二条 失信客户的处理</View>
        <View className="text-size" style={fontWeight}>
          12.1 以下情况之一的，乙方将被认定为失信客户:
        </View>
        <View className="text-size" style={fontWeight}>
          (1) 逾期7个自然日不支付设备租金或逾期后不缴纳逾期违约金的;
        </View>
        <View className="text-size" style={fontWeight}>
          (2) 租赁期满，但拒不归还设备;
        </View>
        <View className="text-size" style={fontWeight}>
          (3) 归还的设备严重损坏，但拒不偿付维修费用的。
        </View>
        <View className="text-size" style={fontWeight}>
          12.2 对于被列入失信客户名单的乙方，甲方及丙方有权利采取包括但不限于以下的措施:
        </View>
        <View className="text-size" style={fontWeight}>(1)将乙方及相应负责人个人信息在星动租平台及网站公布;</View>
        <View className="text-size" style={fontWeight}>(2)有权将违约信息反馈给依法设立的机构(包括但不限于芝麻信用管理有限公司)，乙方应了解上述违约信息可能影响乙方在相关机构处的信用状况，并可能影响其申请或办理相关服务;</View>
        <View className="text-size" style={fontWeight}>
          (3) 向公安机关报案;
        </View>
        <View className="text-size" style={fontWeight}>
          (4) 向法院起诉;
        </View>
        <View className="text-size" style={fontWeight}>
         (5) 通过法院调解平台对乙方进行催收；
        </View>
        <View className="text-size" style={fontWeight}>
          (6) 通过发送短信、拨打电话、邮寄函件、委托第三方进行上门取回设备等形式对乙方进行催缴;
        </View>
        <View className="text-size" style={fontWeight}>
          (7) 向支付宝公司申请冻结乙方名下的支付宝账户。
        </View>
        <View className="text-size" style={fontWeight}>
          12.3 乙方同意在下列任一情形发生时，甲方和乙方之间的租赁服务关系自动转为买卖关系。乙方同意无条件支付买断款买断本协议租赁设备:
        </View>
        <View className="text-size" style={fontWeight}>
          (1)因乙方原因导致租赁设备在租赁期间遗失、灭失、报废、实质性损坏.自行更换设备主体部分等，使得租赁设备无法归还甲方;
        </View>
        <View className="text-size" style={fontWeight}>
          (2)因乙方原因导致设备在租赁期间遭到的损坏程度超过免赔范围，且乙方拒绝支付相应维修费用;
        </View>
        <View className="text-size" style={fontWeight}>
          (3)租赁期限届满后，乙方未归还设备且未申请续租超过7个自然日;
        </View>
        <View className="text-size" style={fontWeight}>
         (4)租赁期间乙方逾期支付租金超过15个自然日;
        </View>
        <View className="text-size" style={fontWeight}>
         (5)乙方失联超过15个自然日，甲方或丙方通过乙方留存在甲方或丙方处的所有联系方式都无法与乙方取得联系;
        </View>
        <View className="text-size" style={fontWeight}>
         (6)乙方租赁物退还时，经甲方检测，乙方未注销、解除该租赁物中账户密码，乙方在甲方提示后7个自然日内未及时注销、解除该账号密码，且乙方未按甲方要求的赔偿金额进行赔付的。 
        </View>
        <View className="text-size" style={fontWeight}>
          12.4 在乙方失信的情况下，自乙方收到甲方或丙方的书面通知之日起十五日内应当向甲方或通过星动租平台(丙方)支付买断款。买断款的计算方法如下:
        </View>
        <View className="text-size" style={fontWeight}>
           (1)乙方下单商品支持买断或甲乙双方通过系统的“买断申请”达成买断约定:买断款=买断价-已付租金；
        </View>
        <View className="text-size" style={fontWeight}>
          (2)乙方下单商品不支持买断，且双方未通过系统的“买断申请”达成买断约定:若商品押金高于总租金，买断款=商品押金-已付租金;若总租金高于商品押金，买断款=总租金-已付租金;
        </View>
        <View className="text-size" style={fontWeight}>
          (3)如上述买断款不足以弥补甲方损失的，不足部分仍由乙方承担;
        </View>
        <View className='text-size' style={fontWeight}>
          12.5本协议签订后，乙方逾期支付租金或者买断款等任一笔款项的，每逾期一日应按应付未付款金额0.05%的标准向甲方支付违约金至全部款项清偿完毕之日止。
        </View>
        <View className="text-size" style={fontWeight}>
          “买断价”、“总租金”、“商品押金”“已付押金”详见本协议第1.1条;“已付租金”详见甲方和丙方运营后台的账单列表或乙方(用户端)的账单详情。
        </View>
        <View className="sign-title">第十三条 隐私政策及信息保护</View>
        <View  className="text-size">
            13.1 本协议所指的“隐私”包括《电信和互联网用户个人信息保护规定》第4条规定的用户个人信息的内容以及未来不时制定或修订的法律法规中明确规定的隐私应包括的内容。
        </View>
        {twelveData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two" style={fontWeight}>
              {item.text}
            </View>
          );
        })}
        <View className="text-size">
           13.5 丙方可以向乙方注册的电子邮箱、手机号码发送服务所必要的商业信息。
        </View>
        <View className="text-size">
           13.6 乙方在租赁期间未支付月租金导致逾期的，则触发相关担保公司代偿并上报不良信息至金融信用信息基础数据库，连续三期账单逾期或累计六期账单逾期，则要求乙方整笔结清，若乙方无法结清或继续逾期，则立即触发相关担保公司代偿，并上报不良信息至金融信用信息基础数据库。
        </View>
        <View className="sign-title">第十四条 协议终止</View>
        {thirteenData.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })}
        <View className="sign-title">第十五条 争议处理</View>
        <View className="lock-text">
          15.1 本协议履行过程中发生争议的，应友好协商解决，协商不成的，任何一方可向甲方所在地法院或丙方所在地人民法院提起诉讼。守约方为实现债权所产生的案件费用（包括但不限于案件受理费、保全费、公告费、律师费、差旅费）等一切费用均由违约方承担。
        </View>
        <View className="sign-title">第十六条 证据保存</View>
        <View className="lock-text" style={fontWeight}>
          16.1 本协议为电子协议，在甲方、乙方确认后，通过（爱签）电子签约平台完成电子签名和三方存档。本协议即成立并依约生效，视为双方已经充分阅读并同意内容，双方均应依照本协议严格履行约定的义务。双方对于签署的本协议不存在任何质疑，不对本协议的效力提出任何异议。
        </View>
        <View className="lock-text" style={fontWeight}>
          16.2 丙方及本次电签服务提供方浙江爱签数字科技有限公司（爱签），有权将甲乙双方的个人/机构身份信息、证件复印件或扫描件及签约合同信息相应传输至电子商务认证授权机构(CA,CertificateAuthority)或公证处，由CA以出具电子签名认证证书之目的或公证处以出具公证文件之目的使用并保存，且前述信息至少保存至电子签名认证证书失效后或相关电子数据(包括但不限于签约合同电子数据)产生后5年，并且该等信息不因终止使用平台的服务而停止保存。
        </View>
        <View className="lock-text" >
         16.3 本协议有效期自乙方下单并依约支付租金之日起至甲方收回设备检测合格且结清所有租金等费用之日止。
        </View>
        <View className="lock-text">
         16.4 乙方下单网页页面、甲方发货单、交易快照、设备签收回执等均是本协议附件，与本协议有同等法律效力。若记载内容存在冲突，以丙方运营后台记载的信息为准。
        </View>
        <View className="sign-title">第十七条 通知及送达</View>
        {/* {sixteen.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })} */}
        <View className="text-size" style={fontWeight}>
          17.1 本合同履行过程中，甲方或丙方向乙方发送的书面通知，以邮寄送达的，按照乙方填写的送达地址或乙方的注册地址、户籍地址为准(乙方为自然人时)。自书面通知交邮后的第三个自然日视为送达。书面通知的形式还包括但不限于甲方或丙方采用平台公告、平台站内信息、APP弹窗推送、发送电子邮件、手机短信、电话、钉钉、微信等现代化电子通讯方式，在采用上述电子方式进行书面通知的情况下发送当日即视为送达。
        </View>
        <View className="text-size">
          17.2 甲方或丙方有权决定以前述任何一种或几种形式书面通知乙方。甲方以多种方式向乙方发送通知的，通知送达时间以最先送达的为准。
        </View>
        <View className="text-size" style={fontWeight}>
          17.3 甲乙双方一致同意，对于本合同引起的任何纠纷，甲乙双方任一方在司法程序中均同意司法机关(包括但不限于人民法院)采用包括但不限于电子邮件、手机短信、电话、钉钉、微信、QQ等现代化电子通讯方式送达法律文书（包含但不限于诉状、传票、通知、裁定、判决、调解书等诉讼法律文书）。
        </View>
        <View className="text-size" style={fontWeight}>
          17.4 甲乙双方指定接收法律文书的手机号码、电子邮箱、邮寄送达地址默认为甲方、乙方在丙方平台注册及下单时所填写的电话号码、电子邮箱和邮寄送达地址。
        </View>
        <View className="text-size" style={fontWeight}>
          17.5 甲乙双方确认上述电子送达方式、邮寄送达地址适用于各个司法阶段，如调解阶段、一审、二审、再审、执行以及督促程序等。
        </View>
        <View className="text-size">
             17.6 如果甲乙双方上述送达地址有变更，本人应当及时告知丙方和司法机关变更后的送达地址。
        </View>
         <View className="text-size" style={fontWeight}>
            17.7 甲方和乙方承诺，已完全阅读所有条款，并保证上述送达地址是准确的、有效的;如果提供的送达地址不准确，或不及时告知变更后的地址，使法律文书无法送达或未及时送达，由甲方和乙方自行承担由此产生的一切法律后果。
        </View>
         <View className="text-size" style={fontWeight}>
         17.8 若发生纠纷(包括但不限于未按期缴交租金、租赁到期产品退回后发现严重破损，影响再次租赁等)，为保证依法依约提起诉讼主张权利的诉讼文书及时、准确送达给乙方本人(本公司)。乙方确认的送达地址、系本人(本公司)真实意思表示。本人(本公司)确认的上述地址不真实、不准确(包括但不限于地名变更、地址被拆迁、确认的地址中无人签收文书等情形)，导致人民法院的相关文书未能实际由本人(本公司)签收，视同本人(本公司)已收到人民法院寄送的相关文书。邮件退回之日，视为送达之日。
        </View>
        <View className="text-size" style={{fontWeight:'700',textIndent:'2em'}}>
          本人(本公司)承诺如变更上述送达地址的，将在5个工作日内书面或邮件通知更改送达地址;若因本人(本公司)未及时书面通知和更改确认书，导致人民法院的相关文书未能实际由本人(本公司)签收，将视同本人(本公司)已收到甲方或者人民法院寄送的相关文书。邮件退回之日，视为送达之日。本人(本公司)对人民法院寄送的相关文书，将诚实收取;若人民法院按上述地址寄送相关文书，本人(本公司)或本人(本公司)负责签收邮件的人员拒绝签收的，或其他不可抗力的任何原因导致相关文书退回的，将视同本人(本公司)已收到人民法院寄送的相关文书。邮件退回之日，视同送达之日。
        </View>
         <View className="text-size" style={{fontWeight:'700',textIndent:'2em'}}>
           乙方本人(本公司)同意司法机关按照本协议附件二《法律文书送达地址确认书》的约定向乙方送达法律文书。
        </View>
         <View className="sign-title">
            第十八条 其他
        </View>
        <View className="text-size">
             18.1 本合同未尽事宜或任一方认为需要变更协议条款的，均可与对方协商签署相关补充协议;但补充协议中的条款仅能约束补充协议的签署方，未在补充协议上签字的一方，不适用该补充协议约定的条款。
        </View>
         <View className="text-size">
             18.2 若本协议部分内容被认定无效，不影响其他部分效力，其他部分仍然有效，各方须继续履行。
        </View>
        {/* <View className="sign-title">第十九条 保险约定</View> */}
        {/* {seventeen.map((item, index) => {
          return (
            <View key={index} className="lock-text-two">
              {item.text}
            </View>
          );
        })} */}
        {/* <View className="text-size">
            19.1 甲方和乙方达成本协议，可由丙方代甲方购买区块链保险，用于承保本次交易所涉设备的财产权益。
        </View>
        <View className="text-size">
            19.2 当乙方逾期缴纳租金或发生其他违约情况，甲方依法维权并取得相关司法机关法律文书之日起，丙方可代甲方向保险公司申请理赔，赔偿款由丙方代收，再结算至甲方。
        </View> */}
        <View className="lock-text" style={fontWeight}>
            [以下无正文]
        </View>
        {/* <View className='sign-title'>第十八条 </View> */}
        {/* <View className='lock-text'>本协议有效期自乙方下单并依约支付租金日起至甲方收回商品检测合格且乙方结清所有租 金等费用之日止。</View> */}
        {/* <View className='sign-title'>第十九条 </View> */}
        {/* <View className='lock-text'>本协议为电子协议，在甲方、乙方、丙方确认后，甲方、乙方、丙方均完成存档，丙方作为协议存储方。</View> */}
         <View className="text-size-two">甲方：</View>
        <View className="text-size-two">甲方代表（签字）：{agreementData.shopName}</View>
        {/* <View className='text-size-two'>甲方代表（签字）：{dataess.businessLpName}</View> */}
        <View className="text-size-two">
          签约日期：{agreementData.createTime}
        </View>
         <View className="text-size-two">乙方：</View>
        <View className="text-size-two">乙方代表（签字）：{agreementData.userName}</View>
        <View className="text-size-two">
        签约日期：{agreementData.createTime}
        </View>
         <View className="text-size-two">丙方：</View>
        <View className="text-size-two">
          丙方代表（签字）：{agreementData.platformName}
        </View>
        <View className="text-size-two">
         签约日期：{agreementData.createTime}
        </View>
        {/* <View className='people-wrap'>
          <View className='text-size-two'>乙方代表（签字）：{dataess.userName}</View>
          <View className='text-size-two'>签约日期：{!(detail && dataess && dataess.rentStart) ? timeDate() : (dataess && dataess.rentStart)}</View>
          <View>
            {
              !!dataess ?
                <View>
                  {
                    userStamp.length > 4 ?
                      <View className='content-big'>
                        {
                          userStamp.map((item, index) => {
                            return (
                              <Text key={index}>
                                {item}
                              </Text>
                            )
                          })
                        }
                      </View>
                      :
                      <View className='content'>
                        {
                          userStamp.map((item, index) => {
                            return (
                              <Text key={index}>
                                {item}
                              </Text>
                            )
                          })
                        }
                      </View>
                  }
                  {
                    userStamp.length == 6 ?
                      <View className='content-six'>
                        {
                          userStamp.map((item, index) => {
                            return (
                              <Text key={index}>
                                {item}
                              </Text>
                            )
                          })
                        }
                      </View>
                      : null
                  }
                </View>
                : null
            }
          </View>
        </View>
        <View className='company-wrap'>
          <View className='text-size-two'>丙方：合肥众享万物信息科技有限公司</View>
          <View className='text-size-two'>丙方（签字）：李瑞</View>
          <View className='text-size-two'>签约日期：{!(detail && dataess && dataess.rentStart) ? timeDate() : (dataess && dataess.rentStart)}</View>
          <Image className='img-scss' src={`https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/${getGloble('companyYZ')}`} />
        </View> */}
        <View className="sign-title"  style={{marginTop:'200px'}}>
          附件一:
        </View>
        <View style={{margin:'0 auto',textAlign:'center' ,fontWeight:'700'}}>
          个人信息查询授权书
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
          [特别提示]本授权书以数字电文形式签订，在签订授权书之前，请申请人务必仔细阅读本授权书的全部条款，关注您在授权书中的权利和义务。
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
          授权人(即申请人)本人同意并不可撤销地授权星动租平台及甲方，在本次租赁过程中(自租赁申请至租赁终止)，基于约定用途:包括但不限于租赁审核、租后管理、担保或依法或经有权部门要求等，有权通过第三方服务机构(包括但不限于中国人民信用中心等第三方权威信用机构、第三方服务机构及其关联公司以及第三方数据机构等)对申请人提交的个人信息进行核实，有权通过前述第三方服务机构采集申请人的运营商信息、借贷信息、消费信息、财务信息等个人信息(包括可能对本人产生负面影响的不良信息)用于为申请人提供风控、租赁、租后管理等租赁相关服务。申请人已被明确告知提供上述信息可能会给本人带来经济、声誉损失等不利后果，但本人仍然同意授权查询主体通过第三方服务机构采集相关信息。星动租平台及甲方其中一方在获取上述申请人信息后，申请人授权该方将该信息告知另一方。
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
             授权人本人同意并不可撤销地授权星动租平台及甲方向第三方服务机构提供个人信息及借贷信息(含办理业务时产生的不良信息)以判断、识别业务风险及提升自身服务质量;且授权人本人同意并不可撤销地授权第三方服务机构依据法律法规就授权范围内对上述本人信息进行采集、获取、存储、处理、提供、传输、披露。
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
           授权人本人同意并授权甲方及丙方将本人个人信息及履约情况提供给包括但不限于金融信用信息基础数据库、中国人民银行批准成立的信用机构、政府公共信用信息平台、银行、非银行金融机构、电信运营商、信用公司、甲方及丙方的关联公司及合作机构等，以供有关单位、部门及个人查询和使用。
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
            授权人本人承诺本授权效力具有独立性，不因其他合同的任何条款无效而无效。
        </View>
         <View className="text-size" style={{textIndent:'2em'}}>
            授权人本人已知悉本授权书所有内容的意义及由此产生的法律效力，自愿作出上述授权，本授权申明是授权人本人真实的意思表示，本人同意承担由此带来的一切法律后果。
        </View>
        <View className="text-size" style={{textIndent:'2em'}}>
            特此授权!
        </View>
        <View className="sign-title"  style={{marginTop:'200px'}}>
          附件二:
        </View>
        <View style={{margin:'0 auto',textAlign:'center' ,fontWeight:'700'}}>
         《法律文书送达地址确认书》
        </View>
        <View className="text-size" >
          1. 本人同意对于因《租赁服务协议》引起的任何纠纷，本人声明司法机关(包括但不限于人民法院)可以手机短信或电子邮件等现代通讯方式或邮寄方式向本人送达法律文书(包括但不限于诉讼文书)。
        </View>
        <View className="text-size" >
          2. 本人指定接收法律文书的手机号码或电子邮箱为协议签约时在星动租平台注册账号所使用的手机号码或电子邮箱，司法机关以前述码址发出法律文书即视为送达。 
        </View>
        <View className="text-size" >
           3. 本人指定邮寄地址为本人的户籍地址或本人在星动租平台留存的本人通讯地址、收件地址或住址。
        </View>
        <View className="text-size" >
           4. 本人同意司法机关可以采取以上一种或多种送达方式向本人送达法律文书 ，司法机关采取多种方式向本人送达法律文书，送达时间以上述送达方式中最先送达的为准。
        </View>
        <View className="text-size" >
            5. 本人确认的上述送达方式适用于各个司法阶段，包括但不限于调解阶段、一审、二审、 再审、执行以及督促程序。
        </View>
         <View className="text-size" >
           6. 若本人送达地址有变更，本人应当及时告知星动租平台或司法机关变更后的送达地址。
        </View>
        <View className="text-size" >
           7. 督促程序中，若本人任意提出异议进而使纠纷进入诉讼程序，在法院最终判决本人承担责任的情况下，因此产生的所有费用(包括但不限于律师费、支付令申请费和诉讼费)，均由本人承担。
        </View>
        <View className="text-size">
            8.本人已阅读本确认书所有条款，并保证送达地址是准确、有效的;如果提供的送达地址不确切，或不及时告知变更后的地址，使法律文书无法送达或未及时送达，本人自行承担由此可能产生的法律后果。
        </View>
      </View>
    );
  }
}

export default Ment;
