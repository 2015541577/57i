import Taro from '@tarojs/taro'
import { agreementInformationPlaceorder } from './service'
export default {
    namespace: 'agreement',
    state: {
        dataess: null,
        userStamp:[]
    },
    effects: {
        // 协议
        * agreementNoorder({ payload, callback }, { call, put }) {
            let response = yield call(agreementInformationPlaceorder, payload);     
            if (response.data.responseType === "SUCCESS") {
                if(callback){
                    callback(response.data);
                }
                
            }
        },
    },
    reducers: {
        information(state, { payload }) {
            return {
                ...state,
                dataess: payload,
                userStamp:[...payload.userStamp]
            }
        }
    }
}