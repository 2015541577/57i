import Taro, { Component } from "@tarojs/taro";
import { connect } from "@tarojs/redux";
import { getUid, getGloble } from "../../utils/localStorage";
import "./index.scss";
import { timeDate } from "../../utils/utils";

@connect(({ agreement, confirmOrder }) => ({ ...agreement, ...confirmOrder }))
class Credit extends Component {
  config = {
    navigationBarTitleText: "个人信用信息查询及提供授权书",
  };
  state = {
    loading: true,
    name: "迪丽热巴·迪",
    Relationship: [],
    firstData: [],
    secondData: [],
    threeData: [],
    eightData: [],
    nineData: [],
    tenData: [],
    twelveData: [],
    thirteenData: [],
    sixteen: [],
    seventeen: [],
    privacyheader: [],
    colectioninformation: [],
    footer: [],
    isUmbner: false,
    agreementData: {},
  };
  componentDidMount = () => {
    const { dispatch } = this.props;
    const { detail, orderId, signNumber, productId } = this.$router.params;
    if (productId) {
      dispatch({
        type: "agreement/agreementNoorder",
        payload: {
          productId: productId,
          uid: getUid(),
        },
        callback: (res) => {
          this.setState({
            agreementData: res.data,
          });
        },
      });
    }
    if (orderId) {
      dispatch({
        type: "agreement/agreementNoorder",
        payload: {
          orderId: orderId,
        },
        callback: (res) => {
          this.setState({
            agreementData: res.data,
          });
        },
      });
    }

    let {
      Relationship,
      firstData,
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      privacyheader,
      colectioninformation,
      footer,
    } = require("./data.js");
    this.setState({
      Relationship,
      firstData,
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      privacyheader,
      colectioninformation,
      footer,
    });
  };
  render() {
    let { dataess, information } = this.props;

    const {
      secondData,
      threeData,
      eightData,
      nineData,
      tenData,
      twelveData,
      thirteenData,
      sixteen,
      seventeen,
      agreementData,
    } = this.state;

    let fontWeight = {
      fontWeight: "bold",
    };
    const { detail, adressInformation, type } = this.$router.params;
    const adress = adressInformation && JSON.parse(adressInformation);
    dataess = dataess || {}; // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading()
    return (
      <View className="webview-page">
          <View className="header">金融信用信息基础数据库</View>
        <View className="header">个人征信信息查询及报送授权书</View>
        <View className="text-size">
           重要提示：
        </View>
        <View className="text-size" style={{fontWeight:'700',textIndent:'2em'}}>
        为了维护您的权益，请在签署本授权书前，仔细阅读本授权书各条款（特别是黑体字条款），关注您在授权书中的权利、义务。
        我司将严格按照授权范围查询和使用您的征信信息，并依法承担超出授权范围查询的相应责任。如有任何疑问，请向我司工作人员咨询。
          {/* 兹有本人 {agreementData.userName}（称“授权人”）在此不可撤销地授权贵公司及下属分支机构（“被授权人”）根据本授权书查询和提供授权人的信息。 */}
        </View>
        <View className="text-size">
            致：咸阳华瑞融资担保有限公司
        </View>
        <View className="text-size">
          本人因向贵司申请办理金融业务，为使贵司能够对本人信用作出合理评估和风险监控，本人不可撤销地授权咸阳华瑞融资担保有限公司：
        </View>
        
        <View className="sign-title">一、办理以下涉及到本人的业务时，可向中国人民银行金融信用信息基础数据库或其他依法设立的征信机构查询、留存、提供使用本人包括信用报告在内的相关信用信息，用途如下：</View>
        <View className="text-size">
           1．审批、受理、办理本人或本人配偶贷款的担保资格；
        </View>
        <View className="text-size"  style={{textIndent:'2em'}}>
          2．在该业务存续期间监控本人或本人配偶（如有）的信用变化，进行保后服务和管理；
        </View>
        <View className="text-size">
         3．处理本人征信异议；
        </View>
        <View className="text-size">
          4. 其他本人向贵司申请或办理的业务。
        </View>
     
        <View className="sign-title"> 二、同意你公司按照国家相关规定采集本人与本次业务相关的个人信息及合同信息（包括还款信息、合同违约等不良信息），并可向中国人民银行金融信用信息基础数据库或其他依法设立的征信机构报送以上信息。</View>
 

        <View className="sign-title">三、同意你公司在本人发生逾期情况时，按照中国人民银行规定进行本人不良征信信息的上报。</View>

        <View className="sign-title"> 四、本人已知悉如在本授权书下因你公司报送本人信息引起征信异议，本人可于工作日9:00至18:00拨打你公司的客服电话：400-6886370 进行进行咨询或异议申诉。</View>

        <View className="text-size">  五、本授权书是本人向咸阳华瑞融资担保有限公司做出的单方承诺，效力具有独立性。
          如本授权书内容与相关业务的合同条款不一致的，无论相关合同在本授权书之前或之后签署均应以本授权书内容为准，但相关合同条款明确约定是针对本授权书内容所做修订的除外。
          </View> 

          <View className="text-size">  六、授权期限自本授权书出具日起，至本人在你公司该笔业务结清之日止。 </View> 
          <View className="text-size"> 七、若本人申请业务未获批准或终止，均同意你司继续保存本授权书、个人信用报告等资料。</View> 

          <View className="text-size">  八、本人同意你司向该笔业务相关部门提供并使用本人征信信息。 </View> 
          <View className="text-size"> 九、若本人与被授权人发生任何纠纷或争议，首先应友好协商解决；协商不成的，本人同意将纠纷或争议提交本授权书签订地（即陕西省咸阳市）有管辖权的人民法院裁决。</View> 


        <View className="text-size" style={{fontWeight:'700',textIndent:'2em'}}>
         授权人声明：
        </View>
        <View className="text-size" style={{fontWeight:'700',textIndent:'2em'}}>
        本人已知悉并同意上述条款（特别是黑体字条款）。本授权书由本人点击确认、电子签章或其他类似方式确认同意后即生效，为本人真实意思表达。本人同意承担由此带来的一切法律后果。
        </View>
        {/* ----------------------------- */}
        <View className="text-size-two">授权人：{agreementData.userName}</View>
        {/* <View className="text-size-two">身份证件类型：身份证</View> */}
        <View className="text-size-two">证件号码：{agreementData.idNo}</View>
        {/* <View className='text-size-two'>甲方代表（签字）：{dataess.businessLpName}</View> */}
        <View className="text-size-two">
          授权日期：{agreementData.createTime} 
        </View>
      </View>
    );
  }
}

export default Credit;
