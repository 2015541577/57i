import Request from '../../utils/request'
export const demo = (data) => {
    return Request({
        url: '路径',
        method: 'POST',
        data,
    });
};
export const agreementInformationPlaceorder = (data) => {
    return Request({
        url: '/hzsx/api/order/userOrderAgreementV2',
        method: 'POST',
        data
    })
}