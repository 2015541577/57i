import * as realNameApi from './service';
import {  getPhoneNumberFn, getAuthCode,getCard } from '../../utils/openApi'
import { getGlobalData } from '../../utils/globalVariable'
import Taro from '@tarojs/taro'
import { getGloble, setUid, setBuyerId, setNickName, setUserName, setTelephone, getUid, setAvatar } from '../../utils/localStorage';
import umUploadHandler from "../../utils/umengUploadData";

export default {
  namespace: 'realName',
  state: {
    codeTime: null,
    codeKey: null,
    telephone: null,
  },

  effects: {
    // 发送验证码
    * sendSmsCode({ payload, callback }, { call, put }) {
      payload = payload || {}
      payload.channelId = getGloble('channelId')
      const res = yield call(realNameApi.sendSmsCode, payload);
      if (res) {
        yield put({
          type: 'saveSmsCode',
          payload: res.data,
        });
      }
      callback(res);
    },
    // 获取手机号
    * getPhoneNumber({ callback }, { call, put, select }) {
      let ginseng = yield select(state => {
        return state.mine.alipayUserInfoNewDTO
      })
      let res = null;
      let resCode = null;
      try {
        res = yield getPhoneNumberFn();
        resCode = yield getAuthCode();
      } catch (e) {
        console.log(res,"kkkkkkkkkkkkk")
        Taro.showToast({
          title: '授权失败，请重试',
          icon: 'none',
        });
        const errorMessage = e && e.errorMessage;
        // umUploadHandler.loginFailed(`调用getPhoneNumber方法时发生错误：${errorMessage}`);
      }
      if (!!res) {
        // 通过支付宝 授权获取手机号 所返回的数据是加密数据，在调用下面这个API去获取到 解密之后的数据
        let exeRes = yield call(realNameApi.decrypt, { content: res, type: 1 });
        exeRes = JSON.parse(exeRes.data.data)
        if (exeRes.code !== '40003') {
          ginseng.telephone = exeRes.mobile;
          ginseng.channelId = getGloble('channelId')
          ginseng.authCode = resCode.authCode;
          let userData = yield call(realNameApi.exemptLoginNew, { ...ginseng }); // 这是租物租的登录接口
          // let resCodes = yield getAuthCode();
          // 创建会员卡
          // let ress  = getCard({uid : userData.data.data.uid,code:resCodes.authCode})
          userData = userData.data
          if (userData && userData.data) {
            yield put({
              type: 'saveUser',
              payload: userData.data,
            });
            yield put({
              type: 'phone',
              payload: exeRes.mobile,
            });
            if (callback) {
              callback();
            }
            const uid = userData && userData.data && userData.data.uid; // 获取到用户的uid
            // umUploadHandler.loginSuccess(uid); // 使用友盟上报成功登录的事件
          } else {
            // umUploadHandler.loginFailed(`登录时调用exemptLogin接口发生错误，状态码为${userData && userData.errorCode}，错误描述信息为${userData && userData.errorMessage}`);
          }
        } else {
          // umUploadHandler.loginFailed(`getPhoneNumberNumber方法返回为：${exeRes.code}-${exeRes.subMsg}`);
        }
      }
    },
    // 用户认证信息
    * userCertificationAuth({ payload, callback }, { call, put }) {
      const res = yield call(realNameApi.userCertificationAuth, payload);
      if(res.data.errorMessage){
        Taro.showToast({
          title: res.data.errorMessage,
          icon: 'none'
        })
        callback(1);
        return
      }

      if(res.data.data && res.data.data && res.data.data.uid){
        setUid(res.data.data.uid);
      }

      if (res.data) {
        yield put({
          type: 'confirmOrder/setOrderRealState',
          payload: 1,
        });
        yield put({
          type: 'mine/setIsCertified',
          payload: 'T',
        });
        callback();
        if(res.data.msg){
          Taro.showToast({
            title: res.data.msg,
            icon: 'none'
          })
        }
      }
    },
    // 用户认证信息2  实名前置功能
    * userCertificationAuthTwo({ payload, callback }, { call, put }) {
      const res = yield call(realNameApi.userCertificationAuthTwo, payload);
      if(res.data.errorMessage){
        Taro.showToast({
          title: res.data.errorMessage,
          icon: 'none'
        })
        callback(1);
        return
      }

      if(res.data.data && res.data.data && res.data.data.uid){
        setUid(res.data.data.uid);
      }

      if (res.data) {
        yield put({
          type: 'confirmOrder/setOrderRealState',
          payload: 1,
        });
        yield put({
          type: 'mine/setIsCertified',
          payload: 'T',
        });
        callback();
        if(res.data.msg){
          Taro.showToast({
            title: res.data.msg,
            icon: 'none'
          })
        }
      }
    },
    // demo
    * effectsDemo(_, { call, put }) {
      const { status, data } = yield call(realNameApi.demo, {});
      if (status === 'ok') {
        yield put({
          type: 'save',
          payload: {
            topData: data,
          }
        });
      }
    },
  },

  reducers: {
    saveUser(state, { payload }) {
      setAvatar(payload.avatar),
      setUserName(payload.userName);
      setNickName(payload.nickName);
      setTelephone(payload.telephone);
      setUid(payload.uid);
      setBuyerId(payload.thirdId);
      return { ...state, ...payload };
    },
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    phone(state, { payload }) {
      Taro.setStorageSync('userPhone', payload);
      return {
        ...state,
        telephone: payload
      };
    },
    saveSmsCode(state, { payload }) {
      return {
        ...state,
        codeKey: payload.code_key,
        codeTime: payload.code_time,
      };
    },
  },
};
