import Taro, { Component } from '@tarojs/taro';
import { View, Input, Image, Form, Button } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { baseUrl } from '../../config/index';
import { getUid, getTelephone, getUserName, setTelephone } from '../../utils/localStorage'
import './index.scss';

@connect(({ realName, loading }) => ({
  ...realName,
  loading: loading.models.realName,
}))

class Realname extends Component {
  config = {
    navigationBarTitleText: '实名认证',
    usingComponents: {
      "am-icon": "../../npm/mini-antui/es/am-icon/index",
    }
  };

  state = {
    // validateImage: `${baseUrl}hzsx/aliPay/user/certification/validateCode?uid=${getUid()}`,
    mobile: null,
    validateCode: null,
    count: 0,
    checked:true,
    codeKey2: '',
    codeTime2: ''
  }

  componentDidMount = () => {

  };

  showToast(title) {
    Taro.showToast({
      title,
      icon: 'none',
      mask: true,
    });
  }

  reloadValidate = () => {
    this.setState({ validateImage: `${baseUrl}hzsx/aliPay/user/certification/validateCode?uid=${getUid()}&t=${new Date().getTime()}` });
  }

  handleValidateCode = (e) => {
    this.setState({ validateCode: e.detail.value });
  }

  handleMobile = (e) => {
    this.setState({ mobile: e.detail.value });
  }

  submitSmsCode = () => {
    const { dispatch ,telephone} = this.props
    const { mobile, validateCode } = this.state;
    const newMob = mobile || getTelephone() || telephone;
    if (!newMob) {
      this.showToast('手机号不能为空');
      return;
    }
    dispatch({
      type: 'realName/sendSmsCode',
      payload: {
        mobile: newMob,
        type: 'realName',
        uid: getUid(),
        channel:6
      },
      callback: (res) => {
        this.reloadValidate();
        if (res && res.data.responseType === 'SUCCESS') {
          let count = 59;
          this.setState({ count });
          this.interval = setInterval(() => {
            count -= 1;
            this.setState({ count });
            if (count === 0) {
              clearInterval(this.interval);
            }
          }, 1000);
          this.showToast('验证码已发送，5分钟内有效');
          this.setState({
            codeKey2: res.data.data.codeKey,
            codeTime2: res.data.data.codeTime,
          })
        } else {
          this.showToast('图形验证码输入错误，请重新输入');
        }
      },
    });
  }

  formSubmit = (e) => {
    const { userName, idcard, mobile, smsCode } = e.detail.value;
    const { dispatch, codeTime, codeKey ,telephone} = this.props;
    const { checked } = this.state
    if(!checked){
      this.showToast('请同意左下方的协议');
      return;
    }
    if (!userName  ) {
      this.showToast('请输入姓名');
      return;
    }
    if (!idcard || idcard.length !== 18) {
      this.showToast('请输入18位身份证号码');
      return;
    }
    if(!getTelephone()){
      if ((!mobile && !telephone ) || mobile.length !== 11) {
        this.showToast('请输入正确的手机号');
        return;
      }
      //if (!smsCode && !telephone) {
      if (!smsCode) {
        this.showToast('请输入短信验证码');
        return
      }
    }

    dispatch({
      type: 'realName/userCertificationAuth',
      payload: {
        codeKey: this.state.codeKey2,
        codeTime: this.state.codeTime2,
        userName, idCard:idcard, telephone:mobile?mobile:telephone, smsCode,channel:6,
        uid: getUid(),
      },
      callback: () => {
        Taro.navigateBack();
      },
    });
  }
  onChangeMent = (e) => {
    const {  checked } = this.state
    this.setState({
      checked:!checked
    })
  }

  onGetAuthorizePhone = () => {
    const  { dispatch } = this.props
    dispatch({
      type:'realName/getPhoneNumber'
    })
  }
  gotoProtocol = () => {
    Taro.navigateTo({ url: '/pages/webview/xieyi?signNumber=1' });
  }
  render() {
    const { loading ,telephone} = this.props;
    const { validateImage, count ,checked} = this.state;
    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <Form report-submit='true' onSubmit={this.formSubmit}>
        <View className='realName-page'>
          <View className='content'>
            <View className='content-line'></View>
            <View className='content-item'>
              <View>姓名</View>
              {getUserName()?
                (
                  <Input className='content-item-input'  placeholder='请输入姓名' disabled value={getUserName()} name='userName' />
                )
                :
                (
                  <Input className='content-item-input'  placeholder='请输入姓名'  name='userName' />
                )
              }
            </View>
            <View className='content-item'>
              <View>身份证</View>
              <Input className='content-item-input' placeholder='请输入18位身份证号' name='idcard' />
            </View>
            <View className='content-line'></View>
            {!getTelephone() && !telephone?
              (
              <View className='content-item'>
                <View>手机号</View>
                <Input className='content-item-input' placeholder='请输入手机号' value={telephone} name='mobile' onInput={this.handleMobile} />
              </View>
              )
              :
              (
                <View className='content-item'>
                  <View>已绑定手机号</View>
                  <Input className='content-item-input' placeholder='请输入手机号' value={getTelephone()?getTelephone():telephone} name='mobile' disabled />
                </View>
              )
            }
            {
              true ?
              (
                  <View>
                    <View className='content-item' style={{ borderBottom: 0 }}>
                      <View>短信验证码</View>
                      <View className='content-item-inner' style={{ flexGrow: 1 }}>
                        <Input
                          className='content-item-inner-input'
                          placeholder='请输入短信验证码'
                          name='smsCode'
                        />
                        {count ? (
                            <View className='content-item-inner-small'>{count}S</View>
                          ) :
                          (
                            <View className='content-item-inner-small' onClick={this.submitSmsCode}>短信验证</View>
                          )}
                      </View>
                    </View>
                 </View>
                )
                :
                null
            }
            <View className='content-line'></View>
          </View>
          <View className='xieyi' >
            <View  className="libs">
              <View onClick={this.onChangeMent}>
                { checked === true ? (
                  <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/9584d93495b74ae19dfc448be16e304f.png' />
                ):(
                  <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/15d6a09986b846c0a07ad3c8fbd0804b.png' />
                )}
              </View>
              {/* <View  onClick={this.gotoProtocol} className="checkbox-text">同意<Text className='text'>《租赁服务协议》</Text></View> */}
            </View>
          </View>
          <Button className={checked ?'bottom-button':'bottom-button disabled'} formType='submit'>提交</Button>
        </View>
      </Form>
    )
  }
}

export default Realname;
