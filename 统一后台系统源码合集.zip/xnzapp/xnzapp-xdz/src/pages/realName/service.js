import Request from '../../utils/request';
import {getGlobalData} from '../../utils/globalVariable'
import { getGloble } from '../../utils/localStorage';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const validateCode = () =>
  Request({
    url: 'hzsx/aliPay/user/certification/validateCode',
    method: 'GET',
  });

export const sendSmsCode = data =>
  Request({
    url: 'hzsx/userCertification/sendSmsCode',
    method: 'GET',
    data,
  });

export const userCertificationAuth = data =>
  Request({
    url: 'hzsx/userCertification/userCertificationAuth',
    method: 'POST',
    data,
  });
// 实名前置 
export const userCertificationAuthTwo = data =>
  Request({
    url: 'hzsx/userCertification/userCertificationAuthTwo',
    method: 'POST',
    data,
});
export const decrypt = data => {
  return new Promise((res, rej) => {
    data = data || {}
    data.channelId = getGloble('channelId')
    Request({
      url: 'hzsx/api/components/decrypt',
      method: 'GET',
      test: 'decrypt',
      data,
    }).then(data => {
      res(data)
    }).catch(data => {
      rej(data)
    });
  })
}

export const exemptLoginNew = data =>
  Request({
    url: 'hzsx/aliPay/user/exemptLogin',
    method: 'POST',
    data,
  });
