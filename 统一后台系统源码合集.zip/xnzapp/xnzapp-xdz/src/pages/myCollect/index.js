import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, ScrollView } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import NoData from '../../components/noData/index'
import * as myCollect from './service';
import './index.scss';
import { getUid } from '../../utils/localStorage';

@connect(({ couponList, loading }) => ({
  loading: loading.models.couponList,
}))
class MyCollect extends Component {
  config = {
    navigationBarTitleText: '我的收藏',
    // usingComponents: {
    //   "point-asset": "plugin://myPlugin/point-asset"
    // }
  };

  state = {
    list: []
  }
  componentDidMount = () => {
    myCollect.getProductCollection({
      uid: getUid()
    }).then(res => {
      this.setState({
        list: res.data.data || []
      })
    })
  };

  gotoProduct(productId){
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${productId}` });
  }


  onScrollToLower = () => {
  };

  render() {
    const { list, loading } = this.state;
    const oldNewDegreeList = ['全新', '99新', '95新', '9成新', '8成新', '7成新','98新','85成新','准新']
    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = 0;
    if (systemInfo.model.indexOf('iPhone X') > -1) {
      fixedHeight = fixedHeight + 30;
    }
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='my-collect-page'>
        {/* <point-asset templateId="SI20210824000002988751"/> */}
        <ScrollView
          scrollY
          scrollWithAnimation
          scrollTop='0'
          className='collect-area'
          style={`height: ${scrollHeight}px;`}
          onScrollToLower={this.onScrollToLower}
        >
          {!!list && !!list.length && list.map(info => {
            return (
              <View className='item' key={info.productId} onClick={() => this.gotoProduct(info.productId)}>
                <Image className="item-img" mode='aspectFit' src={info.image} />
                <View className="item-text">
                  <View className="item-name">{info.name}</View>
                  <View className="item-params">￥{info.minPrice}元/天 | {oldNewDegreeList[info.oldNewDegree]}</View>
                </View>
              </View>
            )
          }
          )}
          {
            !list || !list.length
              ? (
                <NoData type='collect' display={'block'} />
              )
              : ''
          }
        </ScrollView>
      </View>
    )
  }
}

export default MyCollect;
