import * as productListApi from './service';

export default {
  namespace: 'couponList',
  state: {
  },

  effects: {

  },

  reducers: {

  },
};
