import Request from '../../utils/request';

export const listRechargeDepositRecordsByUid = data => Request({
  url: 'hzsx/aliPay/user/userRechargeDepositRecord/listRechargeDepositRecordsByUid',
  method: 'GET',
  data,
});
