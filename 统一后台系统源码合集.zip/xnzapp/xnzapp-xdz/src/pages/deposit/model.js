import Taro from '@tarojs/taro';
import * as rechargeApi from './service'
import { getUid,getGloble } from '../../utils/localStorage'
import { getGlobalData } from '../../utils/globalVariable'

export default {
  namespace: 'deposit',
  state: {

  },

  effects: {
    // 获取用户账单列表
    * listRechargeDepositRecordsByUid({ payload ,callback}, { call, put }) {
      payload = payload || {}
      payload.channelId = getGloble('channelId')

      const res = yield call(rechargeApi.listRechargeDepositRecordsByUid, { ...payload, uid: getUid() });

      if(res){
        yield put({
          type: 'info',
          payload: res.data,
        });
        if(callback){
          callback(res)
        }
      }
    },
  },
  reducers: {
    info (state, { payload }){
      return {
        ...state,
        info:payload,
      };
    },
  },

};
