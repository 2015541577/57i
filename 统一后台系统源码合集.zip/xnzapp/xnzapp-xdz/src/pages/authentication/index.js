import Taro, { Component } from '@tarojs/taro'
import { View, Swiper, SwiperItem, Image, Form, Button } from '@tarojs/components'
import { connect } from '@tarojs/redux'
import { formatName, forIdCard } from '../../utils/utils'
import { getGloble } from '../../utils/localStorage'
import { getGlobalData } from '../../utils/globalVariable'
import './index.scss';
import { startAPVerify } from '../../utils/openApi'
@connect(({ mine, members, authentication, loading }) => ({
  ...authentication,
  ...mine,
  ...members,
  loading: loading.models.authentication,
}))

class RedCollect extends Component {
  config = {
    navigationBarTitleText: '身份信息',
  };
  state = {
    animationData: {}
  }

  componentDidMount = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'authentication/selectUserCertification',
    })
  };

  skipOtherPage = (id) => {
    const { dispatch } = this.props
    if (id === 'face') {
      dispatch({
        type: 'authentication/getAilFaceAuthCertifyUrl',
        callback: (data) => {
          startAPVerify({
            certifyId: data.certifyId, url: data.faceUrl
          }, function (verifyResult) {
            // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
            if (verifyResult.resultStatus === '9000') {
              // 验证成功，接入方在此处处理后续的业务逻辑
              // ...
              dispatch({
                type: 'authentication/aliFaceAuthSync',
                payload: {
                  certifyId: data.certifyId,
                  passed: true
                },
                callback: () => {
                  dispatch({
                    type: 'authentication/selectUserCertification',
                  })
                }
              })
            }else{
              dispatch({
                type: 'authentication/aliFaceAuthSync',
                payload: {
                  certifyId: data.certifyId,
                  passed: false
                }
              })
            }
            // 用户主动取消认证
            if (verifyResult.resultStatus === '6001') {
              // 可做下 toast 弱提示m
              Taro.showToast({
                title: '取消认证成功'
              })
            }
            if (verifyResult.result) {
              const errorCode = verifyResult.result.errorCode ? verifyResult.result.errorCode : null;
              if (errorCode) {
                my.alert(errorCode)
              }
            }
            // 其他结果状态码判断和处理 ...
          });
        }
      })
    }
    else {
      Taro.navigateTo({
        url: `/pages/${id}/index`
      })
    }
  }

  render() {
    const { loading, membersLoading, isCertified, avatar, idCardPhotoStatus, info } = this.props;
    let statusType
    if (info && info.idCard && info.idCardFrontUrl && info.idCardBackUrl && info.faceUrl) {
      statusType = 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/420634f53ae44c7485c83c6291f06b89.png'
    }
    else if (info && info.idCard && ((info.idCardFrontUrl && info.idCardBackUrl) || info.faceUrl)) {
      statusType = 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/48548c39eb90464691db5393f505c9ff.png'
    }
    else if (info && info.idCard) {
      statusType = 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/8f685e5ec0b24d2a8ae0ace25733a471.png'
    }
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='authentication-container'>
        <View className='header'>
          <View className='header-avatar'>
            <Image className='img' src={avatar} />
          </View>
          <View className='header-con'>
            <View className='header-con-info'>
              <View className='status'>
                {info && info.idCard ?
                  (
                    <View>
                      实名认证成功
                    </View>
                  )
                  :
                  (
                    <View>
                      请完成实名认证
                    </View>
                  )
                }
              </View>
              <View className='name'>
                {info && info.userName && formatName(info.userName.toString())}
              </View>
              <View className='idcard'>
                {info && info.idCard && forIdCard(info.idCard.toString())}
              </View>
            </View>
            <View className='header-con-progress'>
              <Image className='img' src={statusType} />
            </View>
          </View>
        </View>
        <View className='content'>
          <View className='content-title'>
            安全设置
          </View>
          <View className='content-con'>
            {/*1*/}
            <View className='content-con-item'>
              <View className='content-con-item-left'>
                <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/da1c819d65544e81a3fe2ed47e3b27cf.png' />
              </View>
              <View className='content-con-item-right'>
                <View className='title'>
                  <View>
                    实名认证
                  </View>
                  <View className='dec'>
                    必填内容 以免影响下单
                  </View>
                </View>
                {info && info.idCard ?
                  (
                    <View className='img '>
                      <Image className='btn suc' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6bf6ae02fc6148df980d47c90a419cf6.png' />
                    </View>
                  )
                  :
                  (
                    <View className='img' onClick={this.skipOtherPage.bind(this, 'realName')}>
                      <Image className='btn' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/4cb687820fa34263b7d2f82dd4da0377.png' />
                    </View>
                  )
                }
              </View>
            </View>
           {/*2*/}
            <View className='content-con-item'>
              <View className='content-con-item-left'>
                <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/cb7c3f92bb8f4602ad28249edface7a7.png' />
              </View>
              <View className='content-con-item-right'>
                <View className='title'>
                  <View>
                    身份证认证
                  </View>
                  <View className='dec'>
                    认证通过 提高下单通过率
                  </View>
                </View>
                {info && info.idCardFrontUrl && info.idCardBackUrl ?
                  (
                    <View className='img'>
                      <Image className='img suc' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ba1d2c945a5f446b81ec9d7b980797cd.png' />
                    </View>
                  )
                  :
                  (
                    <View className='img' onClick={this.skipOtherPage.bind(this, 'Certificates')}>
                      <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/9564a87391984e35b40357d5aee7be86.png' />
                    </View>
                  )

                }
              </View>
            </View>
            {/*3*/}
            <View className='content-con-item'>
              <View className='content-con-item-left'>
                <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/01e7a3246db14fc4934c4be905fb66c9.png' />
              </View>
              <View className='content-con-item-right'>
                <View className='title'>
                  <View>
                    刷脸认证
                  </View>
                  <View className='dec'>
                    认证通过 提高下单通过率
                  </View>
                </View>
                {info && info.faceUrl ?
                  (
                    <View className='img'>
                      <Image className='img suc' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e243e01618f449df9ed9916249753e4b.png' />
                    </View>
                  )
                  :
                  (
                    <View className='img' onClick={this.skipOtherPage.bind(this, 'face')}>
                      <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1103df69fea3400091aaf73052801194.png' />
                    </View>
                  )
                }
              </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

export default RedCollect
