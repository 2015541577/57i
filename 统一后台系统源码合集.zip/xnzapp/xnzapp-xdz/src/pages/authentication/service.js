import Request from '../../utils/request';



export const generateBizId = data => Request({
  url: 'hzsx/aliPay/user/certification/generateBizId',
  method: 'GET',
  data,
});
export const aliFaceCertification = data => Request({
  url: 'hzsx/aliPay/user/certification/aliFaceCertification',
  method: 'POST',
  data,
});
//1
export const getAilFaceAuthCertifyUrl = data => Request({
  url: 'hzsx/aliPay/user/certification/getAilFaceAuthCertifyUrl',
  method: 'GET',
  data,
});
//2
export const aliFaceAuthSync = data => Request({
  url: 'hzsx/api/components/faceAuthInitAsync',
  method: 'GET',
  data,
});
//3
export const selectUserCertification = data => Request({
  url: 'hzsx/userCertification/getByUid',
  method: 'GET',
  data,
});