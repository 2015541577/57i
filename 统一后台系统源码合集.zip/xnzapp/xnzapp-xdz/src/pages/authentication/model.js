import Taro from '@tarojs/taro';
import { getUid } from '../../utils/localStorage'
import * as authenticationApi from './service'

export default {
  namespace: 'authentication',
  state: {
    info:{},
    bizId:null
  },

  effects: {
    // 获取用户认证状态
    * selectUserCertification({ payload ,callback}, { call, put }) {
      const res = yield call(authenticationApi.selectUserCertification, { ...payload, uid: getUid() });
      if (res.data.data) {
        yield put({
          type: 'confirmOrder/setOrderNameState',
          payload: res.data.data.userName,
        });
        yield put({
          type:'save',
          payload:{
            info:res.data.data
          }
        })
        if(callback){
          callback(res.data)
        }
      }
    },
    /* * generateBizId({ payload ,callback}, { call, put }) {
      const res = yield call(authenticationApi.generateBizId, { ...payload, uid: getUid() });
      if (res) {
        if(callback){
          callback(res.data)
        }
      }
    }, */
    // 获取面部认证使用的url
    * getAilFaceAuthCertifyUrl({ payload ,callback}, { call, put }) {
      const res = yield call(authenticationApi.getAilFaceAuthCertifyUrl, { ...payload, uid: getUid() });
      if (res) {
        if(callback){
          callback(res.data)
        }
      }
    },
    // 面部认证
    * aliFaceAuthSync({ payload ,callback}, { call, put }) {
      const res = yield call(authenticationApi.aliFaceAuthSync, { ...payload});
      if (res) {
        if(callback){
          callback(res.data)
        }
      }
    },
    /* * aliFaceCertification({ payload ,callback}, { call, put }) {
      const res = yield call(authenticationApi.aliFaceCertification, { ...payload, uid: getUid() });
      if (res) {
        if(res.msg){
          Taro.showToast({
            title:res.msg,
            icon:'none'
          })
        }
        if(callback){
          callback(res)
        }
      }
    }, */
  },

  reducers: {
    save (state, { payload }){
      return {
        ...state,
        ...payload
      };
    },
  },
};
