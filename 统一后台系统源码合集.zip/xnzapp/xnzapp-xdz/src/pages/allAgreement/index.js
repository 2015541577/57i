import Taro ,{Component} from '@tarojs/taro'
import {View} from '@tarojs/components'
import { AtList, AtListItem } from "taro-ui"
import { connect } from '@tarojs/redux';
@connect(({ confirmOrder, loading, authentication,addAddress ,address,realName}) => ({
  confirmOrder,
  authentication,
  ...addAddress,
  ...address,
  loading: loading.models.confirmOrder,
  realName,
}))
class Agreement extends Component {
  config = {
      navigationBarTitleText:'协议及相关'
  }
  gotoProtocol = () => {
      Taro.navigateTo({
          url:`/pages/webview/xieyi`
      })
    // const { dispatch, confirmOrder } = this.props;
    // const { defaultUserAddress } = confirmOrder;
    // const addressData = JSON.stringify(defaultUserAddress);
    // const { type } = this.$router.params;
    // Taro.navigateTo({
    //   url: `/pages/webview/xieyi?productId=${Taro.getStorageSync(
    //       'productID',
    //   )}&adressInformation=${addressData}&type=${type}`,
    // });
  };
  gotoAuthorization = () => {
    Taro.navigateTo({
        url:`/pages/webview/credit`
    })
  };

  //   数字协议的弹框
    digitalCertificate=()=>{
        Taro.navigateTo({
            url:`/pages/digital/index`
        })
    }

    // 担保协议的逻辑
    guarantee = () =>{
        Taro.navigateTo({
            url:`/pages/guarantee/index`,
        })
    }

    service = ()=>{
        Taro.navigateTo ({
            url:'/pages/service/index',
        })
    }

    userAnth = () =>{
        Taro.navigateTo({
            url:'/pages/userAnth/index',
        })
    }

    Privacy = ()=>{
        // .js
        my.downloadFile({
        // 示例 url，并非真实存在
            url: 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/b0687729a3884c66bd410fb8ebfbb17e.pdf',
            success({ apFilePath }) {
                my.hideLoading();
                my.openDocument({
                filePath: apFilePath,
                fileType: 'pdf',
                success: (res) => {
                    console.log('open document success')
                    }
                })
                }
            })
      }
          // 个人征信授权书
    personAnth = () =>{
       my.downloadFile({
        // 示例 url，并非真实存在
            url: 'https://llxz.oss-cn-shanghai.aliyuncs.com/ae797447-a09e-4598-b110-bbb824ff1056.pdf',
            success({ apFilePath }) {
                my.hideLoading();
                my.openDocument({
                filePath: apFilePath,
                fileType: 'pdf',
                success: (res) => {
                    console.log('open document success')
                    }
                })
                }
            })
    }
     // 融资租赁合同授权书
    financeLease = () =>{
       my.downloadFile({
        // 示例 url，并非真实存在
            url: 'https://llxz.oss-cn-shanghai.aliyuncs.com/305c7dfa-f483-4eb4-a583-74260dc21f58.pdf',
            success({ apFilePath }) {
                my.hideLoading();
                my.openDocument({
                filePath: apFilePath,
                fileType: 'pdf',
                success: (res) => {
                    console.log('open document success')
                    }
                })
                }
            })
    }
       // 委托担保合同
    EntrustedGuarantee = () =>{
       my.downloadFile({
        // 示例 url，并非真实存在
            url: 'https://llxz.oss-cn-shanghai.aliyuncs.com/eb916d18-d10d-4d0f-a554-8cf1d901ea4b.pdf',
            success({ apFilePath }) {
                my.hideLoading();
                my.openDocument({
                filePath: apFilePath,
                fileType: 'pdf',
                success: (res) => {
                    console.log('open document success')
                    }
                })
                }
            })
    }
    useraAuth =() =>{
       my.downloadFile({
        // 示例 url，并非真实存在
            url: 'https://llxz.oss-cn-shanghai.aliyuncs.com/8ca8aa3c-13ae-4070-af29-efb5f9b7caca.pdf',
            success({ apFilePath }) {
                my.hideLoading();
                my.openDocument({
                filePath: apFilePath,
                fileType: 'pdf',
                success: (res) => {
                    console.log('open document success')
                    }
                })
                }
            })
    }
    render () {
        return (
            <View>
                <AtList>
                <AtListItem title='租赁服务协议'  arrow='right' onClick={this.gotoProtocol} />
                <AtListItem title='担保协议'  arrow='right' onClick={this.guarantee} />
                {/* <AtListItem title='个人信用查询授权书'  arrow='right' onClick={this.gotoAuthorization} /> */}
                {/* <AtListItem title='信用授权协议' arrow='right' onClick={this.digitalCertificate}/> */}
                <AtListItem title='服务协议' arrow='right' onClick={this.service} />
                {/* <AtListItem title="授权协议" arrow='right' onClick={this.userAnth} /> */}
                <AtListItem title="隐私协议" arrow='right' onClick={this.Privacy} />
                <AtListItem title="个人征信授权书" arrow='right' onClick = {this.personAnth}/>
                <AtListItem title="融资租赁合同授权书" arrow='right' onClick = {this.financeLease}/>
                <AtListItem title="委托担保合同" arrow='right' onClick = {this.EntrustedGuarantee}/>
                <AtListItem title="用户授权书" arrow='right' onClick = {this.useraAuth}/>
                </AtList>
            </View>
        )
    }
}

export default Agreement 