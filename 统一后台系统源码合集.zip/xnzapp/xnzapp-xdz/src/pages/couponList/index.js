import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, ScrollView } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import './index.scss';

@connect(({ couponList, loading }) => ({
  ...couponList,
  loading: loading.models.couponList,
}))
class couponList extends Component {
  config = {
    navigationBarTitleText: '可用商品',
  };

  state = {}
  componentDidMount = () => {
    const { shopId } = this.$router.params;
    const { dispatch } = this.props;
    const newQueryInfo = {
      minRentCycleDays: 0, // 起租天数
      pageNumber: 1,
      pageSize: 10,
      templateId: shopId
    };
    this.setDispatch(newQueryInfo);
  };

  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === 'scroll') {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    dispatch({
      type: 'couponList/fetchProductList',
      payload: { ...info },
    });
  }

  onScrollToLower = () => {
    const { total, queryInfo, queryInfo: { pageNumber, pageSize } } = this.props;
    if (pageNumber * pageSize - total >= 0) {
      Taro.showToast({
        title: '没有更多商品了',
        icon: 'none',
      });
      return;
    }
    this.setDispatch(queryInfo, 'scroll');
  };

  handleDetailClick = (id) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${id}` });
    
  }
  toHome =()=>{
      Taro.switchTab({url:'/pages/home/index'})
  }
  render() {
    const { list, loading } = this.props;
    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = 27;
    if (systemInfo.model.indexOf('iPhone X') > -1) {
      fixedHeight = fixedHeight + 30;
    }
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='productList-page'>
        <ScrollView
          scrollY
          scrollWithAnimation
          scrollTop='0'
          className={list&&list.length?'products-area':''}
          style={`height: ${scrollHeight}px;`}
          onScrollToLower={this.onScrollToLower}
        >
            {!!list &&list.length ?(  !!list && !!list.length && list.map(info => {
            return (
              <View className='itme' key={info.id} onClick={this.handleDetailClick.bind(this, info.productId)}>
                <Image className='img' mode='aspectFit' src={info.image} />
                <View className='info'>
                  <View className='title'>{info.name}</View>
                  <View className='price-rent'>
                    <View className='price-info'>
                      <Text className='unit'>￥</Text>
                      <Text className='decimal'>{info.minPrice}</Text>
                      <Text className='unit'> /天</Text>
                    </View>
                    <View className='rent-info'>{info.minRentCycle}天起租</View>
                  </View>
                </View>
              </View>
            )
          }
          )):(
              <View className="blankness" >
              <View  className="blankness_image" ><Image  className="blankness_img"  src="http://img.llxzu.com/image/blanknesss.png"  /> </View>
              <View className="blankness_tet" >该优惠已抢空啦...</View>
              <View  className="blankness_btn" onClick={this.toHome}>去首页了解更多优惠</View>
              </View>
          )}
        </ScrollView>
      </View>
    )
  }
}

export default couponList;
