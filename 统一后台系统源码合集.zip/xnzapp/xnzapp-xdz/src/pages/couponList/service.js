import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const selectCategoryProduct = data => Request({
  url: 'hzsx/aliPay/category/selectCategoryProduct',
  method: 'POST',
  data,
  contentType: 'application/json',
});


export const productSearch = data => Request({
  url: 'hzsx/aliPay/couponCenter/getCouponProduct',
  method: "get",
  contentType: 'application/json',
  data,
});