import Taro,{Component,Fragment} from '@tarojs/taro';
import {View,Image,ScrollView,Button,Block} from '@tarojs/components';
import {leftTimers,leftTimerMS_C} from '../../utils/utils';
import {getUid,getTelephone} from '../../utils/localStorage';
import Request from '../../utils/request';
// import {AtModal} from 'taro-ui';
// import {AtToast} from 'taro-ui';
import './index.scss';
import { connect } from '@tarojs/redux';
@connect(({ realName  }) => ({
  ...realName,
}))
class Midyear extends Component {
    config = {
        navigationBarTitleText:'严选',
        titleBarColor:'#1D2E3B',
        allowsBounceVertical:"NO",
        usingComponents:{
            modal: "../../npm/mini-antui/es/modal/index",
        }
    }

 state={
     photographyIndex:1,
     homeIndex:1,
     gameIndex:1,
     miaoIndex:1,
     currentIndex:1,
     photographyIndexs:1,
     homeIndexs:1,
     gameIndexs:1,
     miaoIndexs:1,
     currentIndexs:1,
     pageShow:false,
     countDownStr:null,
     slideShowDtoList:[],
     lableProductDtoList:[],
     lableDto:[],
     openStringentSelectDto:{},
     shopList:[],
     bagColor:'#ffff',
     navColor:'',
     bgColor:'',
     bigIcon:'',
     smallIcon:'',
     indexs:'',
     productDtoList:[],
     waist:'',
     spike: {},
     activeIndex: 0,
 }
componentDidShow =()=>{
    // Request({
    //     url:'hzsx/aliPay/couponCenter/getUserCouponStatus',
    //     method:'POST',
    //     data:{
    //         packageId:'10062',
    //         uid:getUid(),
    //     }
    // }).then((res)=>{
    //     if(res.data.data==false){
    //         this.setState({
    //             pageShow:true,
    //         })
    //     }else {
    //         this.setState({
    //             pageShow:false,
    //         })
    //     }
    // })
    // this.countDown()
    Request({
        url:'hzsx/aliPay/product/getStringentSelectDto',
        method:'GET',
         
    }).then(res=>{
        this.setState({
            slideShowDtoList:res.data.data.slideShowDtoList,
            bagColor:res.data.data.openStringentSelectDto.bagColor,
            navColor:res.data.data.openStringentSelectDto.navColor,
            bigIcon:res.data.data.openStringentSelectDto.bigIcon,
            smallIcon:res.data.data.openStringentSelectDto.smallIcon,
            waist:res.data.data.openStringentSelectDto&&res.data.data.openStringentSelectDto.waist?res.data.data.openStringentSelectDto.waist:'',
            productDtoList:res.data.data.todayProduct && res.data.data.todayProduct.productDtoList ? res.data.data.todayProduct.productDtoList : [] ,
            waist:res.data.data.openStringentSelectDto.waist,
            productDtoList:res.data.data.todayProduct.productDtoList,
            lableProductDtoList:res.data.data.lableProductDtoList,
            bgColor:res.data.data.bgColor,
        })
    })
    this.countDown()
}
// 倒计时
// 到23年6/30号失效
 countDown = () => {
  const createTime='2099-06-30 23:59:59'
    if (!createTime) {
      setTimeout(this.countDown, 1000);
    } else {
      const cdStr = leftTimerMS_C(createTime.replace(/-/g, "/"));
        setTimeout(this.countDown, 1000);
        this.setState({ countDownStr: cdStr });
    }
  };

  //  onOkPageModal (e){
  //   const { dispatch } = this.props;
  //   my.getSetting({
  //     success: (res) => {
  //       const phoneNumber = res.authSetting.phoneNumber;
  //       if (!!getUid() && !!Taro.getStorageSync('userPhone') && phoneNumber) {
  //       Request({
  //                 url: "hzsx/aliPay/couponCenter/bindCouponPackage",
  //                 method: "POST",
  //                 data: {
  //                   packageId:e,
  //                   uid:getUid(),
  //                   phone: getTelephone(),
  //                 },
  //               }).then((res) => {
  //                 if(res.data.responseType == "SUCCESS") {
  //                   Taro.showToast({
  //                     title: '领取成功!',
  //                     icon: 'success'
  //                   });
  //                   this.setState({
  //                       pageShow:false,
  //                   })
  //                 }else {
  //                   if (res.errorMessage) {
  //                     Taro.showToast({
  //                       title: res.errorMessage,
  //                       icon: "none",
  //                     });
  //                   }
  //                   this.setState({
  //                    pageShow:false,
                     
  //                })
  //                 }
  //               });
  //       } else {
  //         // 未授权
  //         dispatch({
  //           type: 'realName/getPhoneNumber',
  //           callback: () => {
  //               Request({
  //                 url: "hzsx/aliPay/couponCenter/bindCouponPackage",
  //                 method: "POST",
  //                 data: {
  //                   packageId:e,
  //                   uid:getUid(),
  //                   phone: getTelephone(),
  //                 },
  //               }).then((res) => {
  //                 if(res.data.responseType == "SUCCESS") {
  //                   Taro.showToast({
  //                     title: '领取成功!',
  //                     icon: 'success'
  //                   });
  //                   this.setState({
  //                       pageShow:false,
  //                   })
  //                 }else {
  //                   if (res.errorMessage) {
  //                     Taro.showToast({
  //                       title: res.errorMessage,
  //                       icon: "none",
  //                     });
  //                   }
  //                   this.setState({
  //                    pageShow:false,
  //                })
  //                 }
  //               });
  //           },
  //         });
  //       }
  //     },
  //   });
  // };
// 热租爆款
 onChangePre =(e)=>{
    const length= e.target.dataset.length
    // const index=e.target.dataset.index
      if(e.detail.current==length-1){
          this.setState({
              currentIndex:0,
          })
      }else {
          this.setState({
              currentIndex:e.detail.current+1,
          })
      }

 }
onChangephotog =(e)=>{
    const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              photographyIndex:0,
          })
      }else {
          this.setState({
            photographyIndex:e.detail.current+1,
          })
      }
}
onChangehomeIndex =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              homeIndex:0,
          })
      }else {
          this.setState({
            homeIndex:e.detail.current+1,
          })
      }
}
onChangegameIndex =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              gameIndex:0,
          })
      }else {
          this.setState({
            gameIndex:e.detail.current+1,
          })
      }
}
onChangemiaoIndex =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              miaoIndex:0,
          })
      }else {
          this.setState({
            miaoIndex:e.detail.current+1,
          })
      }
}
 onChangePres =(e)=>{
    const length= e.target.dataset.length
    // const index=e.target.dataset.index
      if(e.detail.current==length-1){
          this.setState({
              currentIndexs:0,
          })
      }else {
          this.setState({
              currentIndexs:e.detail.current+1,
          })
      }

 }
onChangephotogs =(e)=>{
    const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              photographyIndexs:0,
          })
      }else {
          this.setState({
            photographyIndexs:e.detail.current+1,
          })
      }
}
onChangehomeIndexs =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              homeIndexs:0,
          })
      }else {
          this.setState({
            homeIndexs:e.detail.current+1,
          })
      }
}
onChangegameIndexs =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              gameIndexs:0,
          })
      }else {
          this.setState({
            gameIndexs:e.detail.current+1,
          })
      }
}
onChangemiaoIndexs =(e) =>{
   const length= e.target.dataset.length
      if(e.detail.current == length-1 ){
          this.setState({
              miaoIndexs:0,
          })
      }else {
          this.setState({
            miaoIndexs:e.detail.current+1,
          })
      }
}
//  关闭弹框
onPageClose = ()=>{
    this.setState({
        pageShow:false,
    })
}
/**
	 * 判断数组是否能够用来进行渲染
	 * @param {Array} arr
	 */
 arrIsUseful = (arr) => arr && arr.length

toGoproduct =(itemId)=>{
    Taro.navigateTo({ url: `${itemId}`});
}
onGotoProduct = (itemId) => {
		Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` })
}
menuChange(index) {
    this.setState({
      activeIndex: index,
    });
  }
  /**
	 * 跳转到商品详情页面
	 * @param {*} itemId : 商品ID
	 */
   toProduct(id) {
    const { type } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${id}&source=02&type=${type}`,
    });
  }
    onGotoClassify = (value,index) => {
		Taro.navigateTo({ url: `/pages/productList/index?type=search&content=${value}&useLoc=${this.$router.params.useLoc}` });
	}
    
 render(){
     const {
        bannerList,
            bagColor,
            bgColor,
            navColor,
            bigIcon,
            smallIcon, 
            slideShowDtoList,
            lableProductDtoList,
            lableDto,
            currentIndex,
            photographyIndex,
            pageShow,
             homeIndex,
             gameIndex,
             miaoIndex,
            photographyIndexs,
            homeIndexs,
            gameIndexs,
            miaoIndexs,
            currentIndexs,
            waterbanner,
            productDtoList,
            waist,
            products,
            spike, activeIndex,
            countDownStr} =this.state
     return (
         <View  className="pagesView"  style={{backgroundColor:bagColor}} >
             {/* 头部区域 */}
             <View className="pagesHeader">
                 <Image  lazyLoad={true} src={bigIcon} className="headerImg" /> 
              {/* 今日补贴 */}
              {
                 !!productDtoList &&!!productDtoList.length>0?(
                  <View className="todayProduct"> 
                    <View className="todayTop">
                      今日秒杀补贴价 
                      {countDownStr? (
                                <Text className="todayTime" >
                                    本期 {countDownStr} 后结束
                                </Text>
                            ):'活动已结束'}
                    </View>
                    <View className="classify_commodity">
                        <ScrollView
                          className="classify_commodity_ScrollView"
                          scrollX
                          scrollWithAnimation
                        >
                          {
                            !!productDtoList &&!!productDtoList.length?(
                              <Block>
                                  {productDtoList.map((items, indexS) => (
                                      <View
                                        key={ items.id }
                                        className="new_main_f"
                                        onClick={this.onGotoProduct.bind(
                                          this,
                                          items.itemId ||
                                            items.productId
                                        )}
                                      >
                                        <View className="new_main_f_img">
                                          <Image
                                            lazyLoad={true}
                                            className="new_main_f_box"
                                            mode="aspectFit"
                                            src={items.src}
                                          />
                                        </View>
                                        <View className="new_main_f_title">
                                          <View className="title">
                                            <Text className="name">
                                              <View className="product-name">
                                                {	items.productName}
                                              </View>
                                            </Text>
                                          </View>
                                          <View className="price">
                                            <Text className="box">
                                              <Text className="unit">
                                                ￥
                                              </Text>
                                              <Text className="unit2">
                                                  {
                                                    String(
                                                      items.sale || 0
                                                    ).split(".")[0]
                                                  }
                                              </Text>
                                              <Text className="decimal">
                                                .
                                                  {
                                                    String(
                                                      items.sale || 0
                                                    ).split(".")[1]
                                                  }
                                              </Text>
                                              <Text className="unit">
                                                {' '}
                                                /天
                                              </Text>
                                            </Text>
                                          </View>
                                        </View>
                                      </View>
                                    ))}
                              </Block>
                            ):''
                          }
                        
                        </ScrollView>
                      </View>
                  </View>
                ):''
              }
             </View>
             {/* 下面的热租爆款 */}
             {
                
              slideShowDtoList.map((item,index)=>(
                index==0 ? (
                  <Block>
                     {
                         item.openSlideShowDtoList.type==1 ?(
                        <Block>
                          <View className="pagesHot">
                              <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                          </View>
                              <swiper 
                                  circular
                                  className="swipers"
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  previousMargin="-155px"
                                  nextMargin="80px"
                                  display-multiple-items="{{2}}"
                                  data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  indicator-dots
                                  indicator-active-color="#ffff"
                                  onChange={this.onChangePre}
                                  >
                                  {
                                      item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            key={items.id}
                                            className="itemd"
                                          >
                                              <View className="item_img">
                                                <Image 
                                                  lazyLoad={true}
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  className={'imgs '+(currentIndex==indexs ? 'actives':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                          </swiper-item>
                                      ))
                                  }
                              </swiper>
                        </Block>
                      ):(
                          <Block>
                                <View className="youxi">
                                  <View className="youxi_img">
                                    <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                    <swiper
                                      className="game"
                                      circular
                                      autoplay="{{true}}"
                                      interval="{{3000}}"
                                      indicator-dots
                                      indicator-color="#ffff"
                                      indicator-active-color="#fffff"
                                        data-index={index}
                                      data-length={item.openSlideShowConfigurationDtoList.length}
                                      display-multiple-items="{{3}}"
                                      onChange={this.onChangePre}
                                    >
                                      {
                                        item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            className="swiper-item" 
                                            key={items.id}
                                          >
                                            <View className="tems">
                                              <View className="item">
                                                <Image 
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  lazyLoad={true}
                                                  className={'img '+(currentIndex==indexs ? 'active':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                            </View>
                                          </swiper-item>
                                        ))
                                      }
                                    </swiper>
                                  </View>
                              </View>
                          </Block>
                      )
                     }
                  </Block>
                ):
                index== 1 ? (
                  <Block>
                    {
                      item.openSlideShowDtoList.type==1 ?(
                        <Block>
                          <View className="pagesHot">
                              <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                          </View>
                              <swiper 
                                  circular
                                  className="swipers"
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  previousMargin="-155px"
                                  nextMargin="80px"
                                  display-multiple-items="{{2}}"
                                  data-index={index}
                                    data-length={item.openSlideShowConfigurationDtoList.length}
                                  indicator-dots
                                  indicator-active-color="#ffff"
                                  onChange={this.onChangephotog}
                                  >
                                  {
                                      item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            key={items.id}
                                            className="itemd"
                                          >
                                              <View className="item_img">
                                                <Image 
                                                  lazyLoad={true}
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  className={'imgs '+(photographyIndex==indexs ? 'actives':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                          </swiper-item>
                                      ))
                                  }
                              </swiper>
                        </Block>
                      ):(
                          <Block>
                                <View className="youxi">
                                  <View className="youxi_img">
                                    <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                    <swiper
                                      className="game"
                                      circular
                                      autoplay="{{true}}"
                                      interval="{{3000}}"
                                      indicator-dots
                                      indicator-color="#ffff"
                                      indicator-active-color="#fffff"
                                        data-index={index}
                                      data-length={item.openSlideShowConfigurationDtoList.length}
                                      display-multiple-items="{{3}}"
                                      onChange={this.onChangephotog}
                                    >
                                      {
                                        item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            className="swiper-item" 
                                            key={items.id}
                                          >
                                            <View className="tems">
                                                <Image 
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  lazyLoad={true}
                                                  className={'img '+(photographyIndex==indexs ? 'active':'')}
                                                  src={items.icon}
                                                />
                                            </View>
                                          </swiper-item>
                                        ))
                                      }
                                    </swiper>
                                  </View>
                              </View>
                          </Block>
                      )
                    }
                  </Block>
                ):
                index== 2 ?
                 (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                               previousMargin="-155px"
                               nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangehomeIndex}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(homeIndex==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangehomeIndex}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(homeIndex==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ):index== 3 ? (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                               previousMargin="-155px"
                               nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangegameIndex}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(gameIndex==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangegameIndex}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(gameIndex==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ):index== 4 ? (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                                previousMargin="-155px"
                                nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangemiaoIndex}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(miaoIndex==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangemiaoIndex}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(miaoIndex==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ): index== 5 ? (
                  <Block>
                     {
                         item.openSlideShowDtoList.type==1 ?(
                        <Block>
                          <View className="pagesHot">
                              <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                          </View>
                              <swiper 
                                  circular
                                  className="swipers"
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  previousMargin="-155px"
                                  nextMargin="80px"
                                  display-multiple-items="{{2}}"
                                  data-index={index}
                                    data-length={item.openSlideShowConfigurationDtoList.length}
                                  indicator-dots
                                  indicator-active-color="#ffff"
                                  onChange={this.onChangePres}
                                  >
                                  {
                                      item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            key={items.id}
                                            className="itemd"
                                          >
                                              <View className="item_img">
                                                <Image 
                                                  lazyLoad={true}
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  className={'imgs '+(currentIndexs==indexs ? 'actives':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                          </swiper-item>
                                      ))
                                  }
                              </swiper>
                        </Block>
                      ):(
                          <Block>
                                <View className="youxi">
                                  <View className="youxi_img">
                                    <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                    <swiper
                                      className="game"
                                      circular
                                      autoplay="{{true}}"
                                      interval="{{3000}}"
                                      indicator-dots
                                      indicator-color="#ffff"
                                      indicator-active-color="#fffff"
                                        data-index={index}
                                      data-length={item.openSlideShowConfigurationDtoList.length}
                                      display-multiple-items="{{3}}"
                                      onChange={this.onChangePres}
                                    >
                                      {
                                        item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            className="swiper-item" 
                                            key={items.id}
                                          >
                                            <View className="tems">
                                              <View className="item">
                                                <Image 
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  lazyLoad={true}
                                                  className={'img '+(currentIndexs==indexs ? 'active':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                            </View>
                                          </swiper-item>
                                        ))
                                      }
                                    </swiper>
                                  </View>
                              </View>
                          </Block>
                      )
                     }
                  </Block>
                ):index== 6 ? (
                  <Block>
                    {
                      item.openSlideShowDtoList.type==1 ?(
                        <Block>
                          <View className="pagesHot">
                              <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                          </View>
                              <swiper 
                                  circular
                                  className="swipers"
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  previousMargin="-155px"
                                  nextMargin="80px"
                                  display-multiple-items="{{2}}"
                                  data-index={index}
                                    data-length={item.openSlideShowConfigurationDtoList.length}
                                  indicator-dots
                                  indicator-active-color="#ffff"
                                  onChange={this.onChangephotogs}
                                  >
                                  {
                                      item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            key={items.id}
                                            className="itemd"
                                          >
                                              <View className="item_img">
                                                <Image 
                                                  lazyLoad={true}
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  className={'imgs '+(photographyIndexs==indexs ? 'actives':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                          </swiper-item>
                                      ))
                                  }
                              </swiper>
                        </Block>
                      ):(
                          <Block>
                                <View className="youxi">
                                  <View className="youxi_img">
                                    <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                    <swiper
                                      className="game"
                                      circular
                                      autoplay="{{true}}"
                                      interval="{{3000}}"
                                      indicator-dots
                                      indicator-color="#ffff"
                                      indicator-active-color="#fffff"
                                        data-index={index}
                                      data-length={item.openSlideShowConfigurationDtoList.length}
                                      display-multiple-items="{{3}}"
                                      onChange={this.onChangephotogs}
                                    >
                                      {
                                        item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                          <swiper-item 
                                            className="swiper-item" 
                                            key={items.id}
                                          >
                                            <View className="tems">
                                              <View className="item">
                                                <Image 
                                                  onClick={()=>this.toGoproduct(items.address)}
                                                  lazyLoad={true}
                                                  className={'img '+(photographyIndexs==indexs ? 'active':'')}
                                                  src={items.icon}
                                                />
                                              </View>
                                            </View>
                                          </swiper-item>
                                        ))
                                      }
                                    </swiper>
                                  </View>
                              </View>
                          </Block>
                      )
                    }
                  </Block>
                ):index== 7 ? (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                               previousMargin="-155px"
                               nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangehomeIndexs}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(homeIndexs==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangehomeIndexs}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(homeIndexs==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ):index== 8 ? (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                               previousMargin="-155px"
                               nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangegameIndexs}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(gameIndexs==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangegameIndexs}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(gameIndexs==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ):index== 9 ? (
                   <Block>
                     {
                        item.openSlideShowDtoList.type==1 ?(
                     <Block>
                       <View className="pagesHot">
                           <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                       </View>
                           <swiper 
                               circular
                               className="swipers"
                               autoplay="{{true}}"
                               interval="{{3000}}"
                               previousMargin="-155px"
                               nextMargin="80px"
                               display-multiple-items="{{2}}"
                               data-index={index}
                                data-length={item.openSlideShowConfigurationDtoList.length}
                               indicator-dots
                               indicator-active-color="#ffff"
                               onChange={this.onChangemiaoIndexs}
                              >
                               {
                                   item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                       <swiper-item 
                                         key={items.id}
                                         className="itemd"
                                       >
                                           <View className="item_img">
                                             <Image 
                                               lazyLoad={true}
                                               onClick={()=>this.toGoproduct(items.address)}
                                               className={'imgs '+(miaoIndexs==indexs ? 'actives':'')}
                                               src={items.icon}
                                             />
                                           </View>
                                       </swiper-item>
                                   ))
                               }
                           </swiper>
                     </Block>
                      ):(
                      <Block>
                            <View className="youxi">
                              <View className="youxi_img">
                                <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                                <swiper
                                  className="game"
                                  circular
                                  autoplay="{{true}}"
                                  interval="{{3000}}"
                                  indicator-dots
                                  indicator-color="#ffff"
                                  indicator-active-color="#fffff"
                                    data-index={index}
                                  data-length={item.openSlideShowConfigurationDtoList.length}
                                  display-multiple-items="{{3}}"
                                  onAnimationEnd={this.onChangemiaoIndexs}
                                >
                                  {
                                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                                      <swiper-item 
                                        className="swiper-item" 
                                        key={items.id}
                                      >
                                        <View className="tems">
                                          <View className="item">
                                            <Image 
                                              onClick={()=>this.toGoproduct(items.address)}
                                              lazyLoad={true}
                                              className={'img '+(miaoIndexs==indexs ? 'active':'')}
                                              src={items.icon}
                                            />
                                          </View>
                                        </View>
                                      </swiper-item>
                                    ))
                                  }
                                </swiper>
                              </View>
                          </View>
                      </Block>
                      )
                     }
                  </Block>
                ):
                ''
                // 此方法表面上是正常的 但是当在滑动时就会错乱  上面的方法比较笨 暂时解决页面滑动问题。
                //  item.openSlideShowDtoList.type==1 ?(
                //      <Block>
                //        <View className="pagesHot">
                //            <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="hot_img" />
                //        </View>
                //            <swiper 
                //                circular
                //                className="swipers"
                //                autoplay="{{true}}"
                //                interval="{{3000}}"
                //                previousMargin="-105px"
                //                nextMargin="105px"
                //                display-multiple-items="{{2}}"
                //                data-index={index}
                //                 data-length={item.openSlideShowConfigurationDtoList.length}
                //                indicator-dots
                //                indicator-active-color="#ffff"
                //                onAnimationEnd={this.onChangePre}
                //               >
                //                {
                //                    item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                //                        <swiper-item 
                //                          key={items.id}
                //                          className="itemd"
                //                        >
                //                            <View className="item_img">
                //                              <Image 
                //                                lazyLoad={true}
                //                                onClick={()=>this.toGoproduct(items.address)}
                //                                className={'imgs '+(currentIndex==indexs ? 'actives':'')}
                //                                src={items.icon}
                //                              />
                //                            </View>
                //                        </swiper-item>
                //                    ))
                //                }
                //            </swiper>
                //      </Block>
                //   ):(
                //       <Block>
                //             <View className="youxi">
                //                <View className="youxi_img">
                //                  <Image  lazyLoad={true} src={item.openSlideShowDtoList.moduleIcon} className="game_img" />
                //                  <swiper
                //                    className="game"
                //                    circular
                //                    autoplay="{{true}}"
                //                    interval="{{3000}}"
                //                    indicator-dots
                //                    indicator-color="#ffff"
                //                    indicator-active-color="#fffff"
                //                     data-index={index}
                //                    data-length={item.openSlideShowConfigurationDtoList.length}
                //                    display-multiple-items="{{3}}"
                //                    onAnimationEnd={this.onChangephotog}
                //                  >
                //                    {
                //                      item.openSlideShowConfigurationDtoList.map((items,indexs)=>(
                //                        <swiper-item 
                //                          className="swiper-item" 
                //                          key={items.id}
                //                        >
                //                          <View className="tems">
                //                            <View className="item">
                //                              <Image 
                //                                onClick={()=>this.toGoproduct(items.address)}
                //                                lazyLoad={true}
                //                                className={'img '+(photographyIndex==indexs ? 'active':'')}
                //                                src={items.icon}
                //                              />
                //                            </View>
                //                          </View>
                //                        </swiper-item>
                //                      ))
                //                    }
                //                  </swiper>
                //                </View>
                //            </View>
                //       </Block>
                //   )

                 )
              )
             }
                {/* 腰封图片 */}
                {/* <View className="home-share">
                  <swiper circular>
                      {this.arrIsUseful(loinBanner) &&
                          loinBanner.map((banner) => (
                              <swiper-item key={banner.id}>
                                  <View
                                      className="item"
                                      onClick={this.skip.bind(
                                          this,
                                          banner
                                      )}
                                  >
                                      <Image
                                          lazyLoad={true}
                                          className="item-img"
                                          src={banner.imgSrc}
                                      />
                                  </View>
                              </swiper-item>
                      ))}
                  </swiper> 
						 </View> */}
             {/* 腰封 */}
             {
                  !!waist && waist!='' ?(
                      <View className="yaof">
                          <Image src={waist} className="yaof-img"/>
                    </View>
                  ):''
                }
             {/* 标签  商品 */}
            <ScrollView
            scrollX
            scrollWithAnimation
            scrollTop="0"
            className="menu-list"
            style={{background:navColor,padding: "0 12px 0 24px",}}
            >
          <View className="menu-list-view" style={{background:navColor}}>
            {!!lableProductDtoList &&
              !!lableProductDtoList.length &&
              lableProductDtoList.map((item, index) => (
                <Text
                  key={item.lableDto.id}
                  onClick={() => this.menuChange(index)}
                  style={{color: index === activeIndex ? navColor : "",background: index === activeIndex ? bgColor : ""}}
                  className={
                    "menu-item " +
                    (index === activeIndex ? "menu-item-active" : "")
                  }
                >
                  {item.lableDto.lableName}
                  {index === activeIndex ? (
                    <View className="active-line"></View>
                  ) : (
                    ""
                  )}
                </Text>
              ))}
          </View>
            </ScrollView>
          <View className="product-list2">
          {!!lableProductDtoList[activeIndex] &&
            lableProductDtoList[activeIndex].productDtoList.map((item, index) => (
              <View
                className="product-item2"
                key={item.itemId}
                onClick={() => this.toProduct(item.productId)}
              >
                <View className="product-info">
                <Image
                    className="product-img"
                    mode="aspectFit"
                    lazyLoad={true}
                    src={item.src}
                    />
                </View>
                <View className="product-name">{item.productName}</View>
                <View className="product-price">
                  ￥
                  <Text className="price-text">
                    {item.sale && item.sale.toString().split(".")[0]}.
                  </Text>
                  {(item.sale && item.sale.toString().split(".")[1]) || "00"}
                  {type === "TOPIC" ? "元/天" : "元/天"}
                </View>
                <Button className="product-btn" >
                  {type === "TOPIC" ? "立即抢租" : "立即抢租"}
                </Button>
              </View>
            ))}
          </View>
                {/* 尾部的图片说明 */}
                <View className="footer">
                    <Image  lazyLoad={true} src={smallIcon} className="footer_img" />
                </View>
         </View>
     )
 }
}

export default Midyear;