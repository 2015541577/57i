import Taro, { Component } from "@tarojs/taro";
import { View, Image } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import "./index.scss";
import * as checkSuccessApi from "./service";
import Channel from "../home/component/channel/index";
import { startAPVerify } from "../../utils/openApi";
import umUploadHandler from "../../utils/umengUploadData";
import { getGloble, getBuyerId, getUid, getAvatar, setUid, getTelephone } from '../../utils/localStorage';
import Request from '../../utils/request';
@connect(({ checkSuccess, loading, confirmOrder, authentication }) => ({
  ...checkSuccess,
  ...confirmOrder,
  ...authentication,
  loading: loading.models.checkSuccess,
}))
class RedCollect extends Component {
  config = {
    navigationBarTitleText: "下单成功",
  };
  state = {
    recommendproductsList: [],
    lists: [],
    amount: 0,
  };
  componentDidMount = () => {
    const { dispatch } = this.props;
    const { orderId, type } = this.$router.params;
    if (type == "DIRECT") {
      checkSuccessApi.getOrderBySuccessrecommend({ orderId }).then((item) => {
        this.setState({
          amount: item.data.data.amount,
          lists: item.data.data.recommend,
        });
      });
    } else {
      dispatch({
        type: "checkSuccess/getOrderBySuccess",
        payload: { orderId },
        callback: (data) => {
          dispatch({
            type: "productDetail/recommendproducts",
            payload: { productId: data.productId, shopId: data.shopId },
            callback: (list) => {
              this.setState({
                recommendproductsList: list,
              });
            },
          });
          umUploadHandler.successPayMoney(data);
        },
      });
    }
   
  };

  // 跳转至产品
  onGotoProduct = (itemId) => {
    const { type } = this.$router.params;
    if (type === "DIRECT") {
      Taro.navigateTo({
        url: `/pages/productDetail/index?itemId=${itemId}&source=02&type=DIRECT`,
      });
    } else {
      Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` });
    }
  };

  goOrderDetail = () => {
    const { type } = this.$router.params;
    if (type === "DIRECT") {
      Taro.navigateTo({ url: "/pages/orderList/index?typess=购买订单" });
    } else {
      Taro.redirectTo({
        url: `/pages/orderList/index?type=all`,
      });
    }
  };
  goHome = () => {
    Taro.switchTab({ url: "/pages/home/index" });
  };
  onFinsh = () => {
    const { idAuthStatus, faceAuthStatus, dispatch } = this.props;
    const { orderId } = this.$router.params;
    if (faceAuthStatus != "03") {
      dispatch({
        type: "confirmOrder/faceRecognition",
        payload: {
          orderId: orderId,
          uid:getUid()
        },
        callback: (data) => {
          startAPVerify(
            {
              certifyId: data.certifyId,
              url: data.faceUrl,
            },
            function(verifyResult) {

              // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
              if (verifyResult.resultStatus === "9000") {
                // 验证成功，接入方在此处处理后续的业务逻辑
                if (verifyResult.result && verifyResult.result.certifyId) {
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId: data.certifyId,
                      bizId:data.bizId,
                    },
                  });
                }
                   Request({
                            url:"hzsx/api/order/hasOrderUsing",
                            method:'GET',
                            data:{
                              uid:getUid(),
                              channelId:getGloble('channelId'),
                            }
                          }).then(res=>{
                            if(res.data.data===true){
                              my.call('verifyIdentity', {
                                action: 'getEnvData', 
                              }, function (result) {
                                const actionResult = result.actionResult
                                if(actionResult){
                                  Request({
                                    url:'hzsx/api/components/riskRuning',
                                    method:'POST',
                                    data:{
                                      uid:getUid(),
                                      channelId:getGloble('channelId'),
                                      orderId: orderId,
                                      bizRequestParams:actionResult,
                                      userId:getBuyerId(),
                                    }
                                  }).then(res=>{
                                    const verifyId = res.data.data.verifyId;
                                    const bizId = res.data.data.bizId;
                                    my.call('verifyIdentity', {
                                      verifyId: verifyId,
                                      user_id:getBuyerId(),
                                    }, function (result) {
                                      Request({
                                        url:'hzsx/api/components/runingReceive',
                                        method:'POST',
                                        data:{
                                          bizId,
                                          code:result.code,
                                        }
                                      }).then(res=>{
                                      })
                                    });
                                  })
                                }
                              });
                            }
                          })
              } else {
                if (verifyResult.result && verifyResult.result.certifyId) {
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId:data.certifyId,
                      passed: false,
                      bizId:data.bizId,
                    },
                  });
                }
              }
              // 用户主动取消认证
              if (verifyResult.resultStatus === "6001") {
                // 可做下 toast 弱提示m
                Taro.showToast({
                  title: "取消认证成功",
                });
              }
              if (verifyResult.result) {
              }
              // 其他结果状态码判断和处理 ...

              Taro.redirectTo({
                url: `/pages/orderList/index?type=all`,
              });
            }
          );
        },
      });
    } else if (!idAuthStatus) {
      Taro.navigateTo({ url: "/pages/Certificates/index" });
    }
  };
  render() {
    const {
      loading,
      firstRent,
      creditFreeze,
      firstPeriodsPrice,
      orderDeposit,
      realFreeze,
      restBuyOutPrice,
      restRent,
      status,
      totalPeriods,
      total,
      payRent,
      totalRent,
      faceAuthStatus,
      idAuthStatus,
    } = this.props;
    const { type } = this.$router.params;
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    return (
      <View className="container-suc">
        <View className="top2">
          <Image
            className="img"
            src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d7a45f00d397482cb6f8852c017767ef.png"
          />
          <View className="success-text">下单成功</View>
          <View className="success-tips">
            审核通过后商家将在24小时内发货，请耐心等待～ 
          </View>
          {/* {type === "DIRECT" ? (
            <View className="success-total">￥{this.state.amount}</View>
          ) : (
            <View className="success-total">￥{firstPeriodsPrice}</View>
          )} */}

          {idAuthStatus && faceAuthStatus == "03" ? (
            ""
          ) : type === "DIRECT" ? null : (
            <View className="need-face">
              <Text>需要完成人脸及身份证认证才能发货哦～</Text>
              <Text onClick={this.onFinsh} className="top_right">
                去认证{">"}
              </Text>
            </View>
          )}
          <View className="footer">
            <View className="item home" onClick={this.goHome}>
              返回首页
            </View>
            <View className="item order" onClick={this.goOrderDetail}>
              查看订单
            </View>
          </View>
        </View>
        <View className="up-content">
          <Channel
            formType="submit"
            products={this.state.lists}
            onGotoProduct={this.onGotoProduct}
          />
        </View>
      </View>
    );
  }
}

export default RedCollect;
