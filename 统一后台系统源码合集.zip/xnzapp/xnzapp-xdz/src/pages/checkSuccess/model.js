import Taro from '@tarojs/taro';
import * as checkSuccessApi from './service'
import { getUid } from '../../utils/localStorage'

export default {
  namespace: 'checkSuccess',
  state: {
  },

  effects: {
    // 获取订单是否成功信息
    * getOrderBySuccess({ payload ,callback}, { call, put }) {
      let res = yield call(checkSuccessApi.getOrderBySuccess, { ...payload });
      res = res.data
      if(res){
       yield put({
         type: 'saveOrder',
         payload: res.data,
       });

       callback && callback(res.data)
     }
    },
  },

  reducers: {
    saveOrder(state, { payload }) {
      return { ...state, ...payload };
    },
  },
};
