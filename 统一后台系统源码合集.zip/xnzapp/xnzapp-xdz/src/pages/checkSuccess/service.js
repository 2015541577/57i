import Request from "../../utils/request";

export const getOrderBySuccess = (data) =>
  Request({
    url: "hzsx/api/order/queryOrderSuccessInfo",
    method: "GET",
    data,
  });

export const getOrderBySuccessrecommend = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/recommend",
    method: "GET",
    data,
  });
