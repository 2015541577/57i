import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Image,
  Text,
  ScrollView,
  Button,
  Checkbox,
} from "@tarojs/components";
import { connect } from "@tarojs/redux";
import "./index.scss";
@connect(({}) => ({}))
class FilingType extends Component {
  config = {
    navigationBarTitleText: "提交投诉",
    usingComponents: {},
  };

  render() {
    return (
      <View className="FilingType">
        <View className="content">
          <Image
            src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/9b91178758614afebf4072af8f874594.png"
            className="imgs"
          ></Image>
          <View className="cheng">提交成功</View>
          <View className="xtitle">
            请您保持联系方式通畅，我们会及时为您处理
          </View>
        </View>
        <View className="footer">
          <Button
            className="footer_button"
            onClick={() => Taro.switchTab({ url: "/pages/mine/index" })}
          >
            返回
          </Button>
        </View>
      </View>
    );
  }
}

export default FilingType;
