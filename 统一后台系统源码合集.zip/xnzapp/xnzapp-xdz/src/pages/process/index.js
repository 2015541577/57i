import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Button,
  Image,
} from "@tarojs/components";
import "./index.scss";
import { connect } from '@tarojs/redux';

@connect(({ billDetail, loading }) => ({
  ...billDetail,
  loading: loading.models.billDetail,
}))
class process extends Component {
  config = {
    navigationBarTitleText: "租赁流程",
  };

  state = {
    data:[],
  };

  
  onProcess = () => {
    Taro.switchTab({ url: `/pages/home/index`});
  };

  componentDidMount() {
 
  }
  render() {

    return (
        <View className="app_v">
          <Image
            onClick={this.onProcess}
            className="app_img"
            src="http://img.llxzu.com/activity/process_img.png"
          />
          {/* <Image
            onClick={this.onProcess}
            className="app_img"
            src="../../images/common/process_img.png"
          /> */}
        </View>
    );
  }
}

export default process;
