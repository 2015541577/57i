import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Button,
  Image,
  ScrollView,
} from "@tarojs/components";
import "./index.scss";
import { tradePay,getCard,getAuthCode } from "../../utils/openApi";
import { connect } from '@tarojs/redux';
import * as billDetailApi from "./service";
import Request from "../../utils/request";
import Channel from '../home/component/channel/index';
import {
  getGloble,
  getUid,
} from '../../utils/localStorage.js';

@connect(({ home, loading }) => ({
  ...home,
  loading: loading.models.billDetail,
}))
class sign extends Component {
  config = {
    navigationBarTitleText: "会员中心",
    titleBarColor:"#302F2E",
    usingComponents: {
      "point-asset": "plugin://myPlugin/point-asset"
    }
  };

  state = {
    data:[],
    show: my.canIUse('life-follow'),
    list:[],
    pageNum:1,
    tabId:'',
    successVip:false,
    c_avatar:Taro.getStorageSync(`alipay-h5-x--avatar`),
    c_nickName:Taro.getStorageSync(`alipay-h5-x--nickName`),
    c_userPhone:Taro.getStorageSync(`userPhone`),
  };

   componentDidMount() {
    const { dispatch } = this.props;
    const that =this
    // Request({
    //   url: "hzsx/aliPay/user/getAliMemberInfo",
    //   method: "GET",
    //   data: {
    //     uid:getUid(),
    //   },
    // }).then((res) => {
    //   this.setState({
    //     successVip: res.data.data.success,
    //     tabId:res.data.data.id,
    //   },()=>{
    //     dispatch({
    //       type: 'home/getIndexTabAndProduct',
    //       payload: { pageNum: 1, pageSize: 10, tabId: this.state.tabId },
    //       callback: (res) => {
    //         that.setState({
    //           list:res,
    //         })
    //       }
    //     });
    //   });
    // });
    this.getSuccess()
    
  }
  getSuccess=()=>{
      Request({
      url: "hzsx/aliPay/user/getAliMemberInfo",
      method: "GET",
      data: {
        uid:getUid(),
      },
    }).then((res) => {
      this.setState({
        successVip: res.data.data.success,
        tabId:res.data.data.id,
      },()=>{
       this.getProduct()
      });
    });
  }
  getProduct=()=>{
    const {dispatch} = this.props
     dispatch({
          type: 'home/getIndexTabAndProduct',
          payload: { pageNum: 1, pageSize: 10, tabId: this.state.tabId },
          callback: (res) => {
            this.setState({
              list:res,
            })
          }
        });
  }
  // 会员开卡
  goTicket() {
    Taro.navigateTo({ url: '/pages/coupon/collector' })
  };

   onOpenCard(){
     const that = this
      Request({
          url: "hzsx/aliPay/user/getCardTemplate",
          method: "GET",
          data: {
            channelId: getGloble('channelId'),
          },
        }).then((res) => {
          var plugin = requirePlugin("alipassToolKit") // 引用名称需与 app.json 中定义名称相同
          let params = {
            cardParams:{//开卡入参，
                templateId:res.data.data.templateId, // 开卡的卡模板ID
                templateAppId:res.data.data.appId, // 卡模板ID 所关联的 AppId
                outString:'',//商户自定义透传信息
                pageType:'full',//可选，默认是 half，其他参数 full
              },  
            callback: ress=> {
              that.getSuccess()
            }
          }
          plugin.openCard(params);// 接口参数说明如下
        });
  };
  onGotoProduct = (itemId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}`});
  };
  /**
     * 当菜单处于第一个焦点的时候，会显示banner
     * 点击banner触发该方法
     * @param {*} url
     */
  // onGoToMore = (url) => {
  //   if (url.indexOf('alipays://') === 0) {
  //     redirectToOtherMiniProgram(url);
  //   } else {
  //     if (url == '/SharingRentFree/sharerent/index') {
  //       this.onShare();
  //     } else {
  //       Taro.navigateTo({ url });
  //     }
  //   }
  // };
  /**
   * 处理分享所需要完成的逻辑
   * 当前触发分享的方式 是 通过 点击分享类型的banner
   */
  //  onShare() {
  //   if (this.uid) {
  //     Taro.navigateTo({ url: '/SharingRentFree/sharerent/index' });
  //   } else {
  //     Taro.showToast({
  //       title: '请先去授权~~',
  //       icon: 'none',
  //       duration: 1000,
  //     });
  //   }
  // }
 
  /**
   * scrollView的下拉加载更多动作
   */
   onScrollToLower = () => {
    const {
      //total,
      queryInfo,
      queryInfo: { pageNum, pageSize },
    } = this.props;
    if (pageNum * pageSize - this.props.total >= 0) {
      Taro.showToast({
        title: '更多商品，敬请期待！',
        icon: 'none',
        duration: 1000,
      });
      return;
    }
    this.setDispatch(queryInfo, 'scroll');
  };
  /**
   * 合成请求下一页产品数据接口所需要的参数，发起请求
   * @param {*} queryInfo
   * @param {*} fetchType
   */
   setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === 'scroll') {
      info.pageNum += 1;
      info.fetchType = fetchType;
      info.type = 0;
    }
    info.tabId = this.state.tabId ;
    dispatch({
      type: 'home/getIndexTabAndProduct',
      payload: { ...info},
    });
  }
  handleGotoProduct(itemId) {
    this.onGotoProduct(itemId);
  };
  goFen(){
    Taro.reLaunch({ url: `/pages/classifyAgain/index`})
  };
  render() {
    const {
      bannerList,
      specialIndexs,
      oldNewDegreeList,
      loinBanner, // 豆腐块banner下面的轮播banner
      loading,
      waterbanner, // 文字slogan下面的豆腐块banner
      products,
      tabList,
      total,
      queryInfo: { pageNum, pageSize },
    } = this.props;
    const { list , successVip, c_avatar, c_nickName, c_userPhone } = this.state;
    return (
        <View className="c_page">
          <View className="c_head">
            {successVip ? (
               <View className="c_head_img_a"  onClick={() => this.onOpenCard()} >
                 <Image
                    className="c_head_profile"
                    src={c_avatar}
                  />
                <View className="c_head_name">{c_nickName}</View>
                <View className="c_head_phone">手机号：{c_userPhone}</View>
               </View>
            ) : (
              <View className="c_head_img" onClick={() => this.onOpenCard()}>

              </View>
            )}
          </View>
          <View className="c_list_title">
            <View className="c_list_title_a">特权1</View>
            <View className="c_list_title_b">会员专享优惠券</View>
          </View>
          {/* --------------------------- */}
          <View className="c_ticket">
            <View className="c_ticket_list" onClick={() => this.goTicket()} >
              <View className="c_ticket_text_a">iPhone 13系列</View>
              <View className="c_ticket_text_b">0元租</View>
              <View className="c_ticket_text_c">去领取</View>
            </View>
            <View className="c_ticket_list" onClick={() => this.goTicket()}>
              <View className="c_ticket_text_a">国产之光</View>
              <View className="c_ticket_text_b">优惠大礼包</View>
              <View className="c_ticket_text_c">去领取</View>
            </View>
            <View className="c_ticket_list" onClick={() => this.goTicket()}>
              <View className="c_ticket_text_a">苹果系列</View>
              <View className="c_ticket_text_b">优惠大礼包</View>
              <View className="c_ticket_text_c">去领取</View>
            </View>
          </View>
          {/* --------------------------- */}
          <View className="c_list_title">
            <View className="c_list_title_a">特权2</View>
            <View className="c_list_title_b">领集分宝</View>
          </View>
          <point-asset templateId="SI20211011000003031994" />
          <View className="c_vip4">
            <Image
                className="vip4"
                src="http://img.llxzu.com/activity/vip4.png"
              />
          </View>
          {/** 产品列表显示 */}
          <View className="home-channel">
            <View className="home_title">
              <View className="home_title_a">会员福利租</View>
              <View className="home_title_b">| 会员专享 为你省钱</View>
              <View className="home_title_c" onClick={() => this.goFen()}>{"更多 >"}</View>
            </View>
            <ScrollView
              className="c_products"
              scrollY
              scrollWithAnimation
              lowerThreshold={60}
              onScrollToLower={this.onScrollToLower}
            >
              {!!products &&
                !!products.length &&
                products.map((product) => (
                  <View
                    key={product.itemId || product.productId}
                    className="channel-list-item"
                    onClick={this.handleGotoProduct.bind(
                      this,
                      product.itemId || product.productId,
                    )}
                  >
                    <View className="channel-list-item-img">
                      <Image
                        className="channel-list-item-img-box"
                        mode="aspectFit"
                        src={product.image || product.src}
                      />
                    </View>
                    <View className="channel-list-item-title">
                      <View className="title">
                        <Text className="name">
                          {
                            oldNewDegreeList[product.oldNewDegree - 1] && <Text className="new-tags">{oldNewDegreeList[product.oldNewDegree - 1]}</Text>
                          }
                          <Text className="product-name">{ product.title  || product.name }</Text>
                        </Text>
                      </View>
                      <View className="price">
                        <Text className="box">
                          <Text className="unit">￥</Text>
                          <Text className="unit2">
                            {
                              String(
                                product.price || product.lowestSalePrice || 0
                              ).split(".")[0]
                            }
                          </Text>
                          <Text className="decimal">
                            {String(
                              product.price || product.lowestSalePrice || 0
                            ).split(".")[1]
                              ? `.${
                                  String(
                                    product.price || product.lowestSalePrice || 0
                                  ).split(".")[1]
                                }`
                              : ""}
                          </Text>
                          <Text className="unit"> /天</Text>
                        </Text>
                        {/* <Text className="sellnum">
                          销量 {product.salesVolume || 0}
                        </Text> */}
                      </View>
                    </View>
                  </View>
                ))}
            </ScrollView>
          </View>
          {/* <View class="action">
            <Button type="ghost" class="btn-integration" onClick={() => this.onOpenCard()}>领取会员卡</Button>
          </View> */}
        </View>
    );
  }
}

export default sign;
