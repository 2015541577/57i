import Request from "../../utils/request";

export const demo = (data) => {
  return Request({
    url: "路径",
    method: "POST",
    data,
  });
};

export const selectUserOrderDetail = (data) =>
  Request({
    url: "hzsx/api/makeOrder/userMakeOrderInfo",
    method: "POST",
    data,
  });
 export const userPayMakeOrder = (data) =>
  Request({
    url: "hzsx/api/makeOrder/userPayMakeOrder",
    method: "POST",
    data,
  });