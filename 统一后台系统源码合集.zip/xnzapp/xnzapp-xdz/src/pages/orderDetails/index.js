import Taro, { Component, Fragment } from "@tarojs/taro";
import { View, Text, Image, Button, Input } from "@tarojs/components";
import {AtModal ,AtModalHeader,AtModalContent,AtModalAction} from 'taro-ui';
import { connect } from "@tarojs/redux";
import {
  formatDate,
  leftTimer,
  leftTimerMS_C,
  transdate,
  addDate,
} from "../../utils/utils";
//import { orderStatus } from '../../assets/Constant';
import CancelOrder from "../../components/cancelOrder";
import "./index.scss";
// import { getBuyerId, getUid, getAvatar } from '../../utils/localStorage';
import { getServicePhone, getGloble, getUid } from "../../utils/localStorage";
import TagPage from "../../components/service";
import { startAPVerify } from "../../utils/openApi";
import umUploadHandler from "../../utils/umengUploadData";
import Request from '../../utils/request';
@connect(({ orderDetails, loading}) => ({
  ...orderDetails,
  loading: loading.models.orderDetails,
}))
class Orderdetails extends Component {
  config = {
    navigationBarTitleText: "质选服务详情页",
    usingComponents: {
      "am-icon": "../../npm/mini-antui/es/am-icon/index",
      modal: '../../npm/mini-antui/es/modal/index',
    },
  };

  state = {
    pricesDtoList: {},
    orderGoodsServiceDto:[],
    serviceContent:'',
    serveiceShow:false,
  };

  componentDidShow = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetails/selectUserOrderDetail",
      payload: { orderId },
      callback: (res) => {
          this.setState({
            pricesDtoList:res.data,
            orderGoodsServiceDto:res.data.orderGoodsServiceDto,
          })
      },
    });
  };

toServiceAdd=(data)=>{
  const { dispatch } = this.props;
    dispatch({
      type: "orderDetails/userPayMakeOrder",
      payload: {
        orderId:data.orderId,
        amount: data.orderPaymentAmount,
        channelId: getGloble('channelId'),
      },
      callback:res=>{
          Taro.navigateBack({ url: '/pages/orderList/index' });
      }
    });
  }
  toShow =(content)=>{
    my.navigateTo({
        url:`/pages/serviceAdd/index?content=${content}`
      })
      // this.setState({
      //   serveiceShow:true,
      //   serviceContent:content
      // })
  }
  handleCloseService=()=>{
    this.setState({
      serveiceShow:false,
    })
  }
  render() {
    const {
          pricesDtoList,
          orderGoodsServiceDto,
          serviceContent,
          serveiceShow,
    } = this.state;
  
    return (
        <View className="orderDetail-page">
          <View className="content-area">
            <View className="goods-area">
              <View className="goods-info">
                <Image
                    lazyLoad={true}
                    className="img"
                    onClick={this.goProductDetails.bind(
                        this,
                        pricesDtoList.productId
                    )}
                    mode="aspectFit"
                    src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/131816eb5c5346ceb2841fccc4c65e38.png'
                />
                <View className="goods">
                  <View className="title">
                    {!!pricesDtoList.serviceName
                        ? pricesDtoList.serviceName
                        : null}
                  </View>
                  <View className="title">
                  
                    {!!pricesDtoList && pricesDtoList.productName}
                  </View>
                </View>
              </View>
            </View>
            <View className="order-info">
              <View className="order-info-title margin-bottom-30">订单信息</View>
              <View className="gray-info margin-bottom-30">
                <View className="left-text">订单编号</View>
                <View className="right-text">{pricesDtoList.orderId}</View>
              </View>
               <View className="gray-info margin-bottom-30">
                <View className="left-text">绑定订单</View>
                <View className="right-text">{pricesDtoList.originalOrderId}</View>
              </View>
            
              {
                !!orderGoodsServiceDto &&
                  !!orderGoodsServiceDto.length&&
                   orderGoodsServiceDto.map((data,index)=>(
                       <View className="gray-info margin-bottom-30" key={data.id}>
                        <View className="left-text">{data.goodsName}</View>
                        <View className="right-text">{data.servicePrice}</View>
                      </View>
                   ))
              }
               <View className="gray-info margin-bottom-30">
                <View className="left-text">服务说明</View>
                <View className="right-text" style={{width:'70px',height:'24px',color:'#fff',textAlign:'center', backgroundColor:'#5476F0',lineHeight:'24px'}} onClick={()=>this.toShow(pricesDtoList.serviceContent)}>点击查看</View>
               </View>
                <View className="gray-info margin-bottom-30">
                <View className="left-text">总价</View>
                <View className="right-text">{pricesDtoList.orderPaymentAmount}</View>
               </View>
                <View className="gray-info margin-bottom-30">
                <View className="left-text">下单时间</View>
                <View className="right-text">{pricesDtoList.createTime}</View>
              </View>
              <View className="gray-info margin-bottom-30">
                <View className="left-text">支付时间</View>
                <View className="right-text">{pricesDtoList.childPayTime}</View>
              </View>
            </View>
          </View>
            {pricesDtoList.status === "01" && (
              <View className="end-banner" onClick={() => this.toServiceAdd(pricesDtoList)}>
                <View className="button-bar">
                  确认支付
                </View>
              </View>
          )}
            {/* {pricesDtoList.status === "10" && (
              <View className="end-banner">
                <View className="button-bar" >
                  交易关闭
                </View>
              </View>
          )}
            {pricesDtoList.status === "09" && (
              <View className="end-banner">
                <View className="button-bar" >
                  已完成
                </View>
              </View>
          )} */}
           {/* 质选服务的弹框 */}
           <AtModal  onClose={ this.handleCloseService } isOpened={serveiceShow}>
                <AtModalHeader >服务说明</AtModalHeader>
                <AtModalContent  >
                   <View style={{textAlign:'center',wordBreak:'break-word'}}>
                     {serviceContent}
                  </View>
                </AtModalContent>
                <AtModalAction> <Button onClick={this.handleCloseService}>关闭</Button> </AtModalAction>
          </AtModal>
        </View>
    );
  }
}

export default Orderdetails;
