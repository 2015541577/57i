import Taro from "@tarojs/taro";
import * as orderDetailApi from "./service";
import { tradePay } from "../../utils/openApi";
import { getGloble, getBuyerId, getUid } from "../../utils/localStorage";
import * as orderListApi from "../orderList/service";

export default {
  namespace: "orderDetails",
  state: {
    userOrderCashesDto: {},
    orderProductDetailDto: {},
    orderAddressDto: {},
    userOrdersDto: {},
    shopDto: {},
  },

  effects: {
    // 获取用户订单详情
    *selectUserOrderDetail({ payload, callback }, { call, put }) {
      let res = yield call(orderDetailApi.selectUserOrderDetail, payload);
      res = res.data;
      if (res) {
        yield put({
          type: "saveOrder",
          payload: res.data,
        });
        if (callback && typeof callback === "function") {
          callback(res);
        }
      }
    },
       // 结算单确认支付
    *userPayMakeOrder({ payload ,callback}, { call, put }) {
      let res = yield call(orderDetailApi.userPayMakeOrder, {
        ...payload,
        buyerId: getBuyerId(),
      });
      res = res.data;
      if (res && res.responseType === "SUCCESS") {
        try {
          const payres = yield tradePay(
            "tradeNO",
            res.data.tradeNo,
            "TradeAppPay",
            res.data.serialNo
          );
          if (payres.resultCode !== "9000") {
            Taro.showToast({
              title: "支付失败",
              icon: "none",
            });
            return;
          }
          // if(res) callback(res)
          // const nextStatus = "09";
          // yield put({
          //   type: "setOrderStatus",
          //   payload: nextStatus,
          // });
          // yield put({
          //   type: "orderList/setOrderStatus",
          //   payload: {
          //     orderId: payload.orderId,
          //     status: "09",
          //   },
          // });
        } catch (e) {
          //  if(res) callback(res)
          Taro.showToast({
            title: "支付失败，请重试或联系客服",
            icon: "none",
          });
        }
         if(res) callback(res)
      } else {
        if (res) {
          res.msg &&
            Taro.showToast({
              title: res.msg,
              icon: "none",
            });
          // const nextStatus = "09";
          // yield put({
          //   type: "setOrderStatus",
          //   payload: nextStatus,
          // });
        }
      }
    },
  },

  reducers: {
    saveOrder(state, { payload }) {
      // return { ...state, ...payload };
      return payload;
    },
  },
};
