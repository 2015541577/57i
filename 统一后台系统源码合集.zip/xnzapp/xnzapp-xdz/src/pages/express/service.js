import Request from "../../utils/request";

export const userGetExpressByorderId = (data) =>
  Request({
    url: "hzsx/api/order/userGetExpressByOrderId",
    method: "GET",
    data,
  });

export const queryExpressInfo = (data) =>
  Request({
    url: "hzsx/api/components/queryExpressInfo",
    method: "GET",
    data,
  });
export const userOrdersPurchase = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/expressInfo",
    method: "GET",
    data,
  });
