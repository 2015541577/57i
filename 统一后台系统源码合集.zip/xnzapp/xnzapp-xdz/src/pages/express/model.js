import * as ExpressApi from "./service";
import { getUid } from "../../utils/localStorage";

export default {
  namespace: "express",
  state: {
    details: {},
    list: {},
  },

  effects: {
    // 根据订单id获取物流信息
    *userGetExpressByorderId({ payload }, { call, put }) {
      let res = yield call(ExpressApi.userGetExpressByorderId, { ...payload });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        yield put({
          type: "expressDetails",
          payload: res.data || {},
        });
      }
    },
    // 根据物流单获取物流信息
    *queryExpressInfo({ payload }, { call, put }) {
      let res = yield call(ExpressApi.queryExpressInfo, { ...payload });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        yield put({
          type: "expressDetails",
          payload: res.data || {},
        });
      }
    },
    // 根据订单id获取物流信息
    *userOrdersPurchase({ payload }, { call, put }) {
      let res = yield call(ExpressApi.userOrdersPurchase, { ...payload });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        yield put({
          type: "expressDetails",
          payload: res.data || {},
        });
      }
    },
  },

  reducers: {
    expressDetails(state, { payload }) {
      return {
        ...state,
        details: payload,
      };
    },
  },
};
