import Taro, { Component } from "@tarojs/taro";
import { View, Text, Image, ScrollView } from "@tarojs/components";
import NoData from "../../components/noData";
// import { formatStrDate } from '../../../utils/utils'
import { connect } from "@tarojs/redux";
import "./index.scss";

@connect(({ express, loading }) => ({
  ...express,
  loading: loading.models.express,
}))
class Express extends Component {
  config = {
    navigationBarTitleText: "物流详情",
  };
  state = {
    display: "block", // none -> 没数据隐藏
  };
  componentDidMount = () => {
    const { dispatch } = this.props;

    if (this.$router.params.type) {
      dispatch({
        type: "express/userOrdersPurchase",
        payload: {
          orderId: this.$router.params.orderId,
        },
      });
    } else if (this.$router.params.orderId) {
      dispatch({
        type: "express/userGetExpressByorderId",
        payload: {
          orderId: this.$router.params.orderId,
        },
      });
    } else {
      dispatch({
        type: "express/queryExpressInfo",
        payload: {
          expressId: this.$router.params.expressId,
          expressNo: this.$router.params.expressNo,
          orderId: this.$router.params.orderId,
        },
      });
    }
  };

  render() {
    const { loading, details } = this.props;
    const { display } = this.state;
    let list = null;
    if (details.result && details.result.list) {
      list = details.result.list.reverse();
    }
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    return (
      <View className="container_express">
        <View className="express-content">
          <View className="title">
            配送快递 ：<Text>{details.result.company}</Text>
          </View>
          {list && !!list ? (
            list.map((item) => (
              <View className="item">
                <View className="item-img">
                  <Image className="img" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/4c3f679ccba24182a74fa35f8c3c8d57.png" />
                </View>
                <View className="item-text">
                  <View className="remark">{item.remark}</View>
                  <View className="time">{item.datetime}</View>
                </View>
                <View className="line"></View>
              </View>
            ))
          ) : (
            <View>
              <NoData className="no-express" type="express" display={display} />
            </View>
          )}
        </View>
      </View>
    );
  }
}

export default Express;
