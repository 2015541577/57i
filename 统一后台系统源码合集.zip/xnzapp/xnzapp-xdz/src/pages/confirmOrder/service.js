import Request from "../../utils/request";

export const demo = (data) => {
  return Request({
    url: "路径",
    method: "POST",
    data,
  });
};



export const userConfirmOrder = (data) =>
  Request({
    url: "hzsx/api/order/confirm",
    method: "POST",
    data,
    contentType: "application/json",
    test: "userConfirmOrder",
  });
export const userOrdersPurchase = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/confirm",
    method: "POST",
    data,
    contentType: "application/json",
  });
export const userOrderReletConfirm = (data) =>
  Request({
    url: "hzsx/api/orderRelet/userOrderReletConfirm",
    method: "POST",
    data,
    contentType: "application/json",
  });

export const exemptLogin = (data) =>
  Request({
    url: "hzsx/aliPay/user/exemptLogin",
    method: "GET",
    data,
  });

export const userSubmitOrder = (data) =>
  Request({
    url: "hzsx/api/order/userSubmitOrder",
    method: "POST",
    data,
    contentType: "application/json",
    test: "userSubmitOrder",
  });
export const userOrdersPurchasesubmit = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/submit",
    method: "POST",
    data,
    contentType: "application/json",
  });

export const userOrderReletSubmit = (data) =>
  Request({
    url: "hzsx/api/orderRelet/userOrderReletSubmit",
    method: "POST",
    data,
    contentType: "application/json",
  });

export const userAlipayTradePay = (data) =>
  Request({
    url: "hzsx/api/order/userAlipayTradePay",
    method: "GET",
    data,
  });
  // /hzsx/api/sysConfig/getConfirmData?key=bah8y9rhf1x9
  //下单获取结果
  export const getConfirmData = (data) =>
  Request({
    url: "hzsx/api/sysConfig/getConfirmData",
    method: "GET",
    data,
  });
export const trailOrderByStage = (data) =>
  Request({
    url: "hzsx/api/order/trailOrderByStage",
    method: "POST",
    data,
  });

//人脸识别
export const faceAlipayUrl = (data) => {
  return Request({
    url: "hzsx/api/components/identityAuthFaceV2",
    method: "POST",
    data,
  });
};

// 复制authentication中接口
export const aliFaceAuthSync = data => Request({
  url: 'hzsx/api/components/faceAuthInitAsync',
  method: 'GET',
  data,
});