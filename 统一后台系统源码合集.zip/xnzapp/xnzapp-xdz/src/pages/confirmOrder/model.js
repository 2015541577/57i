import Taro from "@tarojs/taro";
import * as confirmOrderApi from "./service";
import { tradePay,startAPVerify } from "../../utils/openApi";
import { getUid, setBuyerId } from "../../utils/localStorage";
import Request from "../../utils/request";

export default {
  namespace: "confirmOrder",
  state: {
    information: [],
    defaultUserAddress: {},
    orderByStagesDtoList:[]
  },

  effects: {
    // 用户提交订单（租赁订单）
    *userConfirmOrder({ payload, callback }, { call, put }) {
      const api =
        payload.buyType === "continue"
          ? confirmOrderApi.userOrderReletConfirm
          : confirmOrderApi.userConfirmOrder;
    
      let res = yield call(api, { ...payload, uid: getUid() });
      res = res.data;
      if (res && res.responseType === "SUCCESS") {
        yield put({
          type: "saveOrder",
          payload: res.data,
        });
        if (payload.buyType === "continue") {
          Taro.setStorageSync("productID", res.data.detailDto.productId);
        } else {
          Taro.setStorageSync("productID", res.data.product.productId);
        }

        if (callback) {
          setTimeout(() => {
            callback(res.data);
          }, 0);
        }
      }
    },
    *getConfirmData({ payload, callback }, { call, put }) {
      let res = yield call(confirmOrderApi.getConfirmData, {...payload});
      res = res.data;
      if (res && res.responseType === "SUCCESS") {
        yield put({
          type: "saveOrder",
          payload: res.data,
        });
       

        if (callback) {
          setTimeout(() => {
            callback(res.data);
          }, 0);
        }
      }
    },
    // 订单支付（购买订单）
    *userOrdersPurchase({ payload, callback }, { call, put }) {
      const api =
        payload.buyType === "continue"
          ? confirmOrderApi.userOrderReletConfirm
          : confirmOrderApi.userOrdersPurchase;
      let res = yield call(api, { ...payload, uid: getUid() });
      res = res.data;
      if (res && res.responseType === "SUCCESS") {
        yield put({
          type: "saveOrders",
          payload: res.data,
        });
        // Taro.setStorageSync("productID", res.data.product.productId);
        if (callback) {
          setTimeout(() => {
            callback(res.data);
          }, 0);
        }
      }
    },
    // 修改优惠券
    *couponChange({ payload, callback }, { call, put }) {
      if (!payload.couponId) {
        delete payload.couponId;
      }

      let res = yield call(confirmOrderApi.trailOrderByStage, {
        ...payload,
        uid: getUid(),
      });
      res = res.data;

      if (res) {
        const code = payload.couponId || "";
        yield put({
          type: "saveCouponCode",
          payload: {
            item: payload.item,
            orderPricesDto: res.data,
          },
        });

        callback && callback();
      }
    },
    // 用户提交-支付订单（租赁订单）
    *userSubmitOrder({ payload, callback }, { call }) {
      if (payload.buyType === "continue") {
        payload.num = 1;
      }
      const api =
        payload.buyType === "continue"
          ? confirmOrderApi.userOrderReletSubmit
          : confirmOrderApi.userSubmitOrder;
      const reqParam = { ...payload, uid: getUid() };
      if (payload.isMiaosha === 'true' || payload.isMiaosha === true) { // 是秒杀商品
        reqParam.source = '02';
      }
      delete reqParam.isMiaosha;
      if (reqParam.sourceValue === 'undefined' || reqParam.sourceValue === 'null') delete reqParam.sourceValue;
      let res = yield call(api, reqParam);
      res = res.data;
      // isFaceAuth为true则进行人脸识别 如果为false则直接进行预授权 
      // if (res.data) {
      //       setTimeout(() => {
      //             Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
      //           }, 1000)
      // }
      if(res && res.data && res.data.isFaceAuth) {
        const faceAlipayData = { orderId: res.data.orderId,uid:getUid()};
        const res_c = res;
        const ress = yield call(confirmOrderApi.faceAlipayUrl, faceAlipayData);
        console.log(ress,'=================');
        if (ress.data.responseType === "SUCCESS") {
          // callback(ress.data.data);
          startAPVerify(
            {
              certifyId: ress.data.data.certifyId,
              url: ress.data.data.faceUrl,
              bizId:ress.data.data.bizId,
            },
            function (verifyResult) {
              // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
              if (verifyResult.resultStatus === '9000') {
                  // 人脸成功进行预授权
                // Taro.navigateBack()
                if (res_c && res_c.data && res_c.data.freezeUrl) {
                  // 蚂蚁代扣流程
                  // if (callback) {
                  //   callback(res_c.data.orderId, "list", res_c.data.isAuth);
                  // }
                  // ------------------------------
                  const obj = {
                    success: (data) => {
                      let type = "detail";
                      if (data.resultCode !== "9000") {
                        data.memo &&
                        Taro.showToast({
                          title: data.memo,
                          icon: "none",
                        });
                        type = "list";
                      }
                      if (callback) {
                        callback(res_c.data.orderId, type,res_c.data.isAuth);
                        // callback(payload.orderId, type);
                      }
                    },
                    fail: (data) => {
                      let types = "detail";
                      if (data.resultCode !== "9000") {
                        data.memo &&
                        Taro.showToast({
                          title: data.memo,
                          icon: "none",
                        });
                        types = "list";
                      }
                      if (callback) {
                        callback(res_c.data.orderId, types ,res_c.data.isAuth);
                        // callback(payload.orderId, type);
                      }
                    },
                  };
                  obj["orderStr"] = res_c.data.freezeUrl;
                  my.tradePay(obj);
                }else{
                  // if (callback) {
                  //   callback(payload.orderId, "detail");
                  // }
                  // if (callback) {
                  //   callback(payload.orderId, "detail",res.data.isAuth);
                  // }
                  // if (callback) {
                  //   callback(res_c.data.orderId, "list", res_c.data.isAuth);
                  // }
                  Taro.showToast({
                      title:res_c.errorMessage,
                      icon:'none',
                  })
                }
                // 验证成功，接入方在此处处理后续的业务逻辑
                if (
                    verifyResult.result &&
                    verifyResult.result.certifyId
                ) {
                  // --------------
                  Request({
                    url: `hzsx/api/components/faceAuthInitAsync`,
                    method: "GET",
                    data: {
                      certifyId: ress.data.data.certifyId,
                      bizId:ress.data.data.bizId,
                    }
                  }).then(res => {
                    console.log("请求成功")
                  });
                  // if (res) {
                  //   if(callback){
                  //     callback(res.data)
                  //   }
                  // }
                  // -------------------------------------
                  // dispatch({
                  //   type: 'authentication/aliFaceAuthSync',
                  //   payload: {
                  //     certifyId:data.certifyId,
                  //   },
                  // });
                }
              } else {
                if (
                    verifyResult.result &&
                    verifyResult.result.certifyId
                ) {
                  Request({
                    url: `hzsx/api/components/faceAuthInitAsync`,
                    method: "GET",
                    data: {
                      certifyId: ress.data.data.certifyId,
                      bizId:ress.data.data.bizId,
                    }
                  }).then(res => {
                    console.log("请求成功")
                  });
                  // dispatch({
                  //   type: 'authentication/aliFaceAuthSync',
                  //   payload: {
                  //     certifyId:data.certifyId,
                  //         passed: false,
                  //   },
                  // });
                }
              }
              // 用户主动取消认证-
              if (verifyResult.resultStatus === '6001') {
                // 可做下 toast 弱提示m
                if (callback) {
                  callback(res_c.data.orderId, "detail",res_c.data.isAuth,1);
                  // callback(payload.orderId, type);
                }
                Taro.showToast({
                  title: '取消认证成功',
                });
                //取消认证直接返回上一页 预授权时 再调人脸 
                // Taro.navigateBack()
                return;
                //  Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
              }
              if (verifyResult.result) {
                // Taro.redirectTo({ url: `/pages/checkSuccess/index?orderId=${orderId}&type=1` });
              }
            },
          );
        }
      }else {
        const res_a = res;
        console.log(res,";lllllllllllllllllllll")
        // 芝麻代扣流程
        // if (callback) {
        //   callback(res_a.data.orderId, "list" ,res_a.data.isAuth);
        // }
        if (res_a && res_a.data && res_a.data.freezeUrl) {
          const obj = {
            success: (data) => {
              let type = "detail";
              if (data.resultCode !== "9000") {
                data.memo &&
                Taro.showToast({
                  title: data.memo,
                  icon: "none",
                });
                type = "list";
              }
              if (callback) {
                callback(res_a.data.orderId, type,res_a.data.isAuth);
                // callback(payload.orderId, type);
              }
            },
            fail: (data) => {
              console.log(data,"打印失败回调")
              let types = "detail";
              if (data.resultCode !== "9000") {
                data.memo &&
                Taro.showToast({
                  title: data.memo,
                  icon: "none",
                });
                types = "list";
              }
              if (callback) {
                callback(res_a.data.orderId, types ,res_a.data.isAuth);
                // callback(payload.orderId, type);
              }
            },
          };
          obj["orderStr"] = res_a.data.freezeUrl;
          my.tradePay(obj);
        }else{
          // if (callback) {
          //   callback(res_a.data.orderId, "detail",res.data.isAuth);
          // }
          // if (callback) {
          //   callback(payload.orderId, "detail");
          // }
          Taro.showToast({
              title:res_a.errorMessage,
              icon:'none',
          })
        }
      }
    },
    // 用户提交-支付订单（购买订单）
    *userOrdersPurchasesubmit({ payload, callback }, { call }) {
      const api = confirmOrderApi.userOrdersPurchasesubmit;

      let res = yield call(api, { ...payload, uid: getUid() });
      res = res.data;
      if (res) {
        try {
          const payres = yield tradePay(
            "tradeNO",
            res.data.payUrl,
            "Freeze",
            res.data.serialNo,
            "types"
          );
          // 支付成功进入订单详情页，失败则进入订单列表页
          let type = "detail";
          if (payres.resultCode !== "9000") {
            Taro.showToast({
              title: "支付失败",
              icon: "none",
            });
            type = "list";
            Taro.navigateTo({ url: "/pages/orderList/index?typess=购买订单" });
          } else {
            if (callback) callback(payres);
          }
        } catch (e) {
          Taro.showToast({
            title: "授权失败，请重试或联系客服",
            icon: "none",
          });
        }
      }
    },
    //人脸识别
    *faceRecognition({ payload, callback }, { call }) {
      const res = yield call(confirmOrderApi.faceAlipayUrl, payload);
      if (res.data.responseType === "SUCCESS") {
        callback(res.data.data);
      }
    },
  },

  reducers: {
    saveOrder(state, { payload }) {
      payload.defaultUserAddress =
        state.defaultUserAddress && state.defaultUserAddress.realname
          ? state.defaultUserAddress
          : payload.defaultUserAddress;
          
      return { ...state, ...payload, information: payload,orderByStagesDtoList:payload.orderPricesDto.orderByStagesDtoList };
    },
    saveOrders(state, { payload }) {
      payload.defaultUserAddress =
        state.defaultUserAddress && state.defaultUserAddress.realname
          ? state.defaultUserAddress
          : payload.defaultUserAddress;
          
      return { ...state, ...payload, information: payload };
    },
    saveCouponCode(state, { payload }) {
      state.defaultCouponDto = payload.item;
      state.orderPricesDto = payload.orderPricesDto;
      return { ...state, ...payload, information: payload };
    },

    setOrderRealState(state, { payload }) {
      return {
        ...state,
        realNameStatus: payload,
      };
    },

    setDefaultUserAddress(state, { payload }) {
      state.defaultUserAddress = payload;
      return {
        ...state,
        defaultUserAddress: payload,
      };
    },
  },
};
