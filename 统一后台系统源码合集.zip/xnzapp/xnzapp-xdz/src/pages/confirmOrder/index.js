import Taro, { Component } from '@tarojs/taro';
import { View, Text, Image, Input, ScrollView, Button, Form, Block } from '@tarojs/components';
import { AtFloatLayout, AtIcon, AtMessage, AtModal, AtModalHeader, AtModalContent, AtModalAction } from 'taro-ui';
import { connect } from '@tarojs/redux';
import './index.scss';
import {
  getUid,
  getGloble,
  getActivityCode,
  getshareCode,
  getTelephone,
  getBuyerId,
} from '../../utils/localStorage';
import { startAPVerify, getOpenUserInfo } from '../../utils/openApi';
import { isSeckillProduct, miaoShaIndexId } from '../../utils/constant';
import umUploadHandler from '../../utils/umengUploadData';
import addressList from '../../assets/address.json';
import citys from '../../assets/citys.json';
import moment from "moment";
import Request from "../../utils/request";
import { throttles,getSignUrl,debounce } from '../../utils/utils';
import listItemCopy from '../orderList/components/listItemCopy';


// 秒杀只处理了租赁商品，目前需求就是这样1
@connect(({ orderDetail, confirmOrder, loading, authentication, addAddress, address, realName }) => ({
  ...orderDetail,
  confirmOrder,
  authentication,
  ...addAddress,
  ...address,
  loading: loading.models.confirmOrder,
  realName,
}))
class Confirmorder extends Component {
  config = {
    navigationBarTitleText: '确认订单',
    // titleBarColor:'#52BEFF',
    usingComponents: {
      notice: '../../npm/mini-antui/es/notice/index',
      steps: '../../npm/mini-antui/es/steps/index',
      "am-icon": "../../npm/mini-antui/es/am-icon/index",
    },
  };

  state = {
    message: null,
    attestationName: null,
    attestationId: null,
    isshow: true,
    marquee: { loop: true, leading: 2000, trailing: 100, fps: 18 },
    checkedBtn: 0,
    showCoupons: false,
    showQuanCoupons: false,
    showAddress: false,
    isshowModal: false,
    isShowBtn: false,
    isEditBtn: false,
    gg_token: null,
    // freightType对照
    freightTypeObj: {
      FREE: '包邮',
      PAY: '到付',
      SELF: '自提',
    },

    isCard: true,
    riskResultDescDate: '',
    antiCheatingLevel: '',
    currentAddress: [],
    isAddressDefault: 0,
    stopDisabled: false,
    //------------------- 
    LastAddress:{},
    showOnPayment:false, //选择支付方式弹框 预授权&蚂蚁代扣
    payment_id:1,
    showHint:false, //信用评估中弹窗
    countDownStr:null, //倒计时
    showRemind:false, //提示弹窗
    showOnPaymentOrderId:null, // 暂存订单号
  };

  /**
   * 加载前执行方法
   */
  componentWillMount = () => {
    const { confirmOrder } = this.props
    confirmOrder.defaultUserAddress = ''
    const {
      data,
      additionalServiceIds,
      hbPeriodNum,
      skuId,
      type,
      token,
    } = this.$router.params;
    if (token != undefined && token != null && token.length > 0) {
      this.state.gg_token = token;
    }

    if (data) {
      this.props.dispatch({
        type: 'confirmOrder/getConfirmData',
        payload: {
          key: data,
        },
      });
    } else if (type === 'DIRECT' && skuId) {
      let objs = {
        uid: getUid(),
        additionalServiceIds: JSON.parse(additionalServiceIds),
        hbPeriodNum: JSON.parse(hbPeriodNum),
        skuId,
      };
      this.props.dispatch({
        type: 'confirmOrder/userOrdersPurchase',
        payload: objs,
      });
    }
  };

//   componentDidMount() {
//       this.LastAddress()
//   }
  /**
   * 加载完成后执行
   */
  componentDidShow() {
    const { dispatch, confirmOrder } = this.props;
    const { buyType, originalOrderId, type, data } = this.$router.params;
    let saveServer = [];
    let appId = my.getAppIdSync().appId
    if (
      confirmOrder.additionalServicesDtoList &&
      confirmOrder.additionalServicesDtoList.length
    ) {
      saveServer = confirmOrder.additionalServicesDtoList.map((ser) => ser.id);
    }
    const obj = {
      originalPrice:
        confirmOrder.orderPricesDto && confirmOrder.orderPricesDto.skuPrice,
      price:
        confirmOrder.orderPricesDto && confirmOrder.orderPricesDto.skuPrice,
      productName: confirmOrder.product && confirmOrder.product.name,
      skuId: confirmOrder.skuDto && confirmOrder.skuDto.skuId,
      productId: confirmOrder.product && confirmOrder.product.productId,
      duration: confirmOrder.duration,
      start: confirmOrder.start,
      end: confirmOrder.end,
      estimateStart: confirmOrder.estimateStart,
      estimateEnd: confirmOrder.estimateEnd,
      num: confirmOrder.num,
      originalOrderId,
      additionalServicesIds: [],
      logisticId: '',
      uid: getUid(),
      logisticForm: '1',
      from: '1',
      buyType,
    };
    this.onCardinformation();
    my.ap.nsf({
      pid: '2088941062409490',
      appId: appId,
      bizContext: {
        risk_type: 'riskinfo_nsf_common',
        pid: '2088941062409490',
        user_id: getBuyerId(),
        mobile_no: Taro.getStorageSync('userPhone') || getTelephone(),
        cert_no: 'null',
        lbs: 'null',
        sales_amount: 'null',
      },
      success: (e) => {
        let riskResultDesc = JSON.parse(e.riskResultDesc);
        let riskResultDescDate = Object.keys(riskResultDesc);
        this.setState({
          riskResultDescDate: riskResultDescDate[0],
        });

      },
      fail: (err) => {
      }
    });
    my.ap.preventCheat({
      pid: '2088941062409490',
      appId: appId,
      bizContext: {
        service: 'marketing',
        risk_type: 'riskinfo_anticheat_common',
        pid: '2088941062409490',
        mobile_no: Taro.getStorageSync('userPhone') || getTelephone(),
      },
      success: (e) => {
        let riskResultDesc = JSON.parse(e.riskResultDesc);
        let riskResultDescDate = Object.keys(riskResultDesc);
        this.setState({
          antiCheatingLevel: riskResultDescDate[0],
        });
      },
      fail(e) {
      }
    });
    if (type === 'DIRECT' || buyType === 'continue') {
      return;
    } else {
      if (Taro.getStorageSync(`isShow`) == 1) {
        dispatch({
          type: 'confirmOrder/userConfirmOrder',
          payload: obj,
          callback: () => { },
        });
      }
    }

    const { defaultUserAddress } = confirmOrder;
    // confirmOrder.defaultUserAddress=''
    this.LastAddress()
  }



  onCardinformation = () => {
    const { dispatch } = this.props;
    let b = moment().format("YYYYMMDD")
    dispatch({
      type: 'orderList/getCardinformation',
      callback: (res) => {
        if (!res) {
          return;
        }
        // 老实名认证判断
        // if (res.id  > 0 && !!res.uid && !!res.userName && !!res.telephone) {
        //   this.setState({
        //     isCard: true,
        //   });
        // }
        if (res.id > 0 && !!res.uid && !!res.userName && !!res.telephone) {
          this.setState({
            isCard: true,
          });
        }else {
          this.setState({
            isCard: false,
          });
        }
      },
    });
  };

  gotoRealName = () => {
    Taro.navigateTo({ url: '/pages/realName/index' });
  };
  // 这里的跳转地址需要修改下
  //   gotoAddress = () => {

  //     Taro.navigateTo({ url: '/pages/address/index?type=select' });
  //   };
  alipayAddress = () => {

    const { dispatch } = this.props;
    my.getAddress({
      success: (res) => {
        const obj = res.result;
        if (res.result) {
          dispatch({
            type: "address/saveZhifubaoAddress",
            payload: {
              areaStr: obj.area,
              cityStr: obj.city,
              isDefault: 0,
              provinceStr: obj.prov,
              realname: obj.fullname,
              street: obj.address,
              telephone: obj.mobilePhone,
            },
            callback: (resa) => {
              dispatch({
                type: "address/getUserAllAddressList",
                callback: (ress) => {
                  let data=[]
                  if(resa.data.data){
                     data = ress[ress.length - 1]
                  }else{
                    data = []
                  }
                  dispatch({
                    type: 'confirmOrder/setDefaultUserAddress',
                    payload: {
                      areaStr: data.areaStr,
                      cityStr: data.cityStr,
                      isDefault: 0,
                      provinceStr: data.provinceStr,
                      realname: data.realname,
                      street: data.street,
                      telephone: data.telephone,
                      id: data.id,
                    },
                  });
                  this.setState({
                    isShowBtn: true,
                  })
                }
              });
              this.LastAddress()
            },
          });
        }
      },
      fail: (res) => {
        this.setState({
          showAddress: true,
        })
      }
    });
  };
  //   点击地址 出现回显弹框 来修改地址
  openModal = (id) => {
    const { dispatch, list, addressInfo } = this.props
    //  const {currentAddress}=this.state
    //  const areaStr=currentAddress[0].name
    //  const cityStr=currentAddress[1].name
    //  const provinceStr=currentAddress[2].name

    this.setState({
      showAddress: true,
    })
    // dispatch({
    //     type:'addAddress/changeAddress',
    //     payload:{
    //         id:list[list.length-1].id,
    //         isDefault:1,
    //          realname:list[list.length-1].realname,
    //        areaStr:list[list.length-1].areaStr,
    //         cityStr:list[list.length-1].cityStr,
    //         provinceStr:list[list.length-1].provinceStr,
    //         street:list[list.length-1].street,
    //         telephone:list[list.length-1].telephone,
    //     }
    // })
  }
  //  下单默认地址
  LastAddress =() => {
    const {
        skuId,
        token,
      } = this.$router.params;
      if (token != undefined && token != null && token.length > 0) {
        this.state.gg_token = token;
      }
      this.props.dispatch({
          type: 'address/getLastUserAddressList',
          payload: {
            uid: getUid(),
            skuId,
          },
          callback: (ress) => {
              this.setState({
                LastAddress:ress,
                isShowBtn:true,
            })
          },
        });
  } 
  gotoProtocol = () => {
    const { dispatch, confirmOrder } = this.props;

    const { defaultUserAddress } = confirmOrder;
    const addressData = JSON.stringify(defaultUserAddress);
    const { type } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/webview/xieyi?productId=${Taro.getStorageSync(
        'productID',
      )}&adressInformation=${addressData}&type=${type}`,
    });
  };
  //   数字协议的弹框
  digitalCertificate = () => {
    Taro.navigateTo({
      url: `/pages/digital/index`
    })
  }
  // 所有的协议的跳转页面
  allAgreement = () => {
    Taro.navigateTo({
      url: `/pages/allAgreement/index`,
    })
  }
  onMessageInput = (e) => {
    this.setState({ message: e.detail.value });
  };
  onAttestationName = (e) => {
    this.setState({ attestationName: e.detail.value });
    // if(this.state.attestationId) {
    //   my.getPhoneNumber({
    //     success: (res) => {
    //       let encryptedData = res.response; // 支付宝所返回的加密数据
    //       this.sucHandler(encryptedData);
    //     },
    //     fail: () => {
    //       Taro.showToast({
    //         title: "授权失败",
    //         icon: "none",
    //         duration: 2000,
    //       });
    //     },
    //   });
    // }
  };
  onAttestationId = (e) => {
    this.setState({ attestationId: e.detail.value });
    // my.getPhoneNumber({
    //   success: (res) => {
    //     let encryptedData = res.response; // 支付宝所返回的加密数据
    //     this.sucHandler(encryptedData);
    //   },
    //   fail: () => {
    //     Taro.showToast({
    //       title: "授权失败",
    //       icon: "none",
    //       duration: 2000,
    //     });
    //   },
    // });
  };
  onGetPhone = (e) => {
    if (this.state.attestationId && this.state.attestationName) {
      my.getPhoneNumber({
        success: (res) => {
          let encryptedData = res.response; // 支付宝所返回的加密数据
          this.sucHandler(encryptedData);
          this.submitOrder;
        },
        fail: () => {
          Taro.showToast({
            title: "授权失败",
            icon: "none",
            duration: 2000,
          });
        },
      });
    } else {
      Taro.showToast({
        title: '请正确输入身份信息！',
      });
    }
  };
  /**
   * 解码授权信息，从中提取手机号码
   * @param encryString
   */
  sucHandler = (encryString) => {
    const reqParams = {
      url: "hzsx/api/components/decrypt",
      method: "GET",
      data: { content: encryString },
    };
    Request(reqParams).then((res) => {
      let _data = JSON.parse(res.data.data);
      this.formSubmits(_data.mobile);
    });
  };
  /**
   * 提交用户信息
   * @param phone
   */
  formSubmits = (phone) => {
    this.props.dispatch({
      type: "realName/userCertificationAuth",
      payload: {
        userName: this.state.attestationName, // 姓名
        idCard: this.state.attestationId, // 身份证号
        telephone: phone, // 手机号
        // smsCode,
        channel: 6,
        uid: getUid(),
      },
      callback: () => {
        this.setState({
          isCard: true
        })
        Taro.showToast({
          title: '实名成功!',
          icon: 'success'
        });
        // Taro.navigateBack();
      },
    });
  };
  ddOrder = () => {
    this.setState({ isshow: false });
  };

  submitOrders = () => {
    const { dispatch, confirmOrder } = this.props;
    const { buyType, originalOrderId } = this.$router.params;
    let additional =
      confirmOrder.additionalServicesDtoList &&
        confirmOrder.additionalServicesDtoList.length
        ? [confirmOrder.additionalServicesDtoList[0].id]
        : [];
    dispatch({
      type: 'confirmOrder/userOrdersPurchasesubmit',
      payload: {
        uid: getUid(),
        remark: this.state.message,
        originalOrderId,
        additionalServiceIds: additional,
        hbPeriodNum: confirmOrder.hbPeriodAmountDto
          ? confirmOrder.hbPeriodAmountDto.hbPeriodNum
          : '',
        skuId: confirmOrder.skuId,
        addressId: confirmOrder.defaultUserAddress
          ? confirmOrder.defaultUserAddress.id
          : '',
      },
      callback: (e) => {
        const da = JSON.parse(e.result);
        const dat = da.alipay_trade_app_pay_response.out_trade_no;
        setTimeout(() => {
          Taro.redirectTo({
            url: `/pages/checkSuccess/index?orderId=${dat}&type=DIRECT`,
          });
        }, 200);
      },
    });
  };

  submitOrder = () => {
    const { dispatch, confirmOrder } = this.props;
    const { buyType, originalOrderId, [isSeckillProduct]: isMiaosha, [miaoShaIndexId]: sourceValue, originPrice } = this.$router.params;
    let saveServer = [];
    umUploadHandler.submitOrderHandler(this.props.confirmOrder); // 使用友盟上报创建订单事件
    if (
      confirmOrder.additionalServicesDtoList &&
      confirmOrder.additionalServicesDtoList.length
    ) {
      saveServer = confirmOrder.additionalServicesDtoList.map((ser) => ser.id);
    }
    const { message, checked } = this.state;
    if (!checked) {
      // this.setState({
      //   stopDisabled: false,
      // })
      Taro.showToast({
        title: '请阅读左下方协议并同意',
        icon: 'none',
      });
      return;
    }
    if (!this.state.isCard) {
      Taro.showToast({
        title: '请完成实名认证',
        icon: 'none',
      });
      return;
    }
    const LastAdd = this.state.LastAddress
    if (!confirmOrder.defaultUserAddress && LastAdd == '') {
      // 这里不是跳转到默认地址 而是跳转到支付宝的地址
      //  Taro.navigateTo({ url: '/pages/address/index?type=select' });
      const { dispatch } = this.props;
      my.getAddress({
        success: (res) => {
          const obj = res.result;
          if (res.result) {
            dispatch({
              type: "address/saveZhifubaoAddress",
              payload: {
                areaStr: obj.area,
                cityStr: obj.city,
                isDefault: 0,
                provinceStr: obj.prov,
                realname: obj.fullname,
                street: obj.address,
                telephone: obj.mobilePhone,
              },
              callback: () => {
                dispatch({
                  type: "address/getUserAllAddressList",

                  callback: (ress) => {
                    const data = ress[ress.length - 1]
                    dispatch({
                      type: 'confirmOrder/setDefaultUserAddress',
                      payload: {
                        areaStr: data.areaStr,
                        cityStr: data.cityStr,
                        isDefault: 0,
                        provinceStr: data.provinceStr,
                        realname: data.realname,
                        street: data.street,
                        telephone: data.telephone,
                        id: data.id,
                      },
                    });
                  }
                })

              },
            });
          }
        },
        fail: (res) => {
          this.setState({
            showAddress: true,
          })
        }
      });
      this.setState({
        stopDisabled: false,
      })
    }
    // 有默认地址走这里
    if (LastAdd != '') {
        const { dispatch } = this.props;
          const data = this.state.LastAddress
          dispatch({
            type: 'confirmOrder/setDefaultUserAddress',
            payload: {
              areaStr: data.areaStr,
              cityStr: data.cityStr,
              isDefault: 0,
              provinceStr: data.provinceStr,
              realname: data.realname,
              street: data.street,
              telephone: data.telephone,
              id: data.id,
            },
          });
      this.setState({
        stopDisabled: false,
      })
    }
    if (
      this.state.isCard &&
      // this.state.riskResultDescDate &&
      (buyType === 'continue' ||
        (buyType !== 'continue' && confirmOrder.defaultUserAddress))
    ) {
      dispatch({
        type: 'confirmOrder/userSubmitOrder',
        payload: {
          buyType,
          originalOrderId,
          orderId: confirmOrder.orderId,
          repairOrderCofigsIds: confirmOrder.repairOrderCofigsIds || [],
          addressId: confirmOrder.defaultUserAddress
            ? confirmOrder.defaultUserAddress.id
            : '',
          originalPrice: isMiaosha === true || isMiaosha === 'true' ? originPrice :
            confirmOrder.orderPricesDto && confirmOrder.orderPricesDto.skuPrice,
          price:
            confirmOrder.orderPricesDto && confirmOrder.orderPricesDto.skuPrice,
          productId:
            buyType === 'continue'
              ? confirmOrder.detailDto.productId
              : confirmOrder.product.productId,
          start: confirmOrder.start,
          end: confirmOrder.end,
          duration: confirmOrder.duration,
          logisticForm: '01',
          num: confirmOrder.num,
          skuId:
            buyType === 'continue'
              ? confirmOrder.detailDto.skuId
              : confirmOrder.skuDto.skuId,

          from: confirmOrder.from,
          monthRentAmount: confirmOrder.orderPricesDto.originalMonthRentPrice,
          deposit: confirmOrder.orderPricesDto.depositAmount,
          couponIdList:
            confirmOrder.defaultCouponDto && confirmOrder.defaultCouponDto.code
              ? [confirmOrder.defaultCouponDto.code]
              : null,
          rentAmount: confirmOrder.orderPricesDto.rentPrice,
          installmentCount: confirmOrder.orderPricesDto.totalPeriods,
          localAddress: confirmOrder.localAddress,
          client: 1,
          logisticType: 0,
          creditAmount: 0,
          additionalServicesIds: [],
          remark: message,
          channelId: getGloble('channelId'),
          activityNo: getActivityCode(),
          shareCode: getshareCode(),
          nsfLevel: this.state.riskResultDescDate,
          antiCheatingLevel: this.state.antiCheatingLevel,
          isMiaosha,
          sourceValue,
        },
        // callback: (orderId, type) => {
          callback: (orderId, type, isAuth,newOrderId) => {
            if(newOrderId == 1) {
              confirmOrder.orderId = orderId;
              this.setState({
                stopDisabled: false,
              })
              // 进行下单统计
              const data = Taro.getStorageSync("current_gg_id");
              if (data != undefined && data != null && data.length > 0) {
                let obj = JSON.parse(data);
                const user_token = Taro.getStorageSync(obj.gg_id);
                let objs = {}
                if (user_token !== "") {
                  objs = JSON.parse(user_token);
                } else {
                  objs = {
                    token: ""
                  }
                }
                Request({
                  url: `hzsx/llxzu/guanggao/add_guanggao_order`,
                  method: "GET",
                  data: {
                    order_id: orderId,
                    // 此时gg_id是跳转传参
                    user_token: objs.token
                  }
                }).then(res => {
                  Taro.atMessage({
                    'message': '传输成功',
                    'type': type,
                    'duration': 1000
                  })
                });
              }
            }else {
              confirmOrder.orderId = orderId;
              this.setState({
                stopDisabled: false,
              })
              const data = Taro.getStorageSync("current_gg_id");
              if (data != undefined && data != null && data.length > 0) {
                let obj = JSON.parse(data);
                const user_token = Taro.getStorageSync(obj.gg_id);
                let objs = {}
                if (user_token !== "") {
                  objs = JSON.parse(user_token);
                } else {
                  objs = {
                    token: ""
                  }
                }
                Request({
                  url: `hzsx/llxzu/guanggao/add_guanggao_order`,
                  method: "GET",
                  data: {
                    order_id: orderId,
                    // 此时gg_id是跳转传参
                    user_token: objs.token
                  }
                }).then(res => {
                  Taro.atMessage({
                    'message': '传输成功',
                    'type': type,
                    'duration': 1000
                  })
                });
              }
              // let user_token = this.state.gg_token;
              if (type === 'detail') {
                Request({
                  url: "hzsx/api/order/hasOrderUsing",
                  method: 'GET',
                  data: {
                    uid: getUid(),
                    channelId: getGloble('channelId'),
                  }
                }).then(res => {
                  if (res.data.data === true) {
                    my.call('verifyIdentity', {
                      action: 'getEnvData',
                    }, function (result) {
                      console.log(result.actionResult);
                      const actionResult = result.actionResult
                      if (actionResult) {
                        Request({
                          url: 'hzsx/api/components/riskRuning',
                          method: 'POST',
                          data: {
                            uid: getUid(),
                            channelId: getGloble('channelId'),
                            orderId: orderId,
                            bizRequestParams: actionResult,
                            userId: getBuyerId(),
                          }
                        }).then(res => {
                          const verifyId = res.data.data.verifyId;
                          const bizId = res.data.data.bizId;
                          my.call('verifyIdentity', {
                            verifyId: verifyId,
                            user_id: getBuyerId(),
                          }, function (result) {
                            Request({
                              url: 'hzsx/api/components/runingReceive',
                              method: 'POST',
                              data: {
                                bizId,
                                code: result.code,
                              }
                            }).then(res => {
                              console.log('这里是刷脸之后的调用 之前 已实名过1111')
                            })
                          });
                        })
                      }
                    });
                  }
                })
                setTimeout(() => {
                  Taro.redirectTo({
                    url: `/pages/checkSuccess/index?orderId=${orderId}&type=1`,
                  });
                }, 400)
              } else {
                // 取消预授权进入此判断
                this.setState({
                  showOnPayment: true,
                  showOnPaymentOrderId: orderId,
                })
                // setTimeout(() => {
                //   Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                // }, 1000)
              }
            }
          },
        });
    }
  };
  // 获取倒计时
  countDown = () => {
    console.log("进入倒计时！！！")
    let seconds = 8; // 设定倒计时秒数
    const timer = setInterval(() => {
      this.setState({ countDownStr: seconds });
      console.log(seconds); // 输出剩余秒数
      seconds--; // 剩余秒数减少1
      if (seconds < 0) { // 如果剩余秒数小于0，清除定时器
        clearInterval(timer);
        console.log("倒计时结束！");
      }
    }, 1000); // 设置定时器每秒执行一次
  };
  // 取消选择支付方式 预授权&&蚂蚁代扣
  onClosePayment = () => {
    setTimeout(() => {
      Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
    }, 1000)
  }
  // 选择支付方式提交
  submitPayment = () => {
    const { dispatch, confirmOrder } = this.props;
    this.setState({
      showOnPayment:false,
    })
    console.log(confirmOrder.orderId,"ssssssssssssssssssssssss111111")
    // 进入预授权流程
    if(this.state.payment_id == 1) {
      // this.submitOrder();
      // 请求预授权接口
      dispatch({
        type: "orderDetail/userFrezzAgain",
        payload: {
          orderId: confirmOrder.orderId,
        },
        callback: (orderId, type ) => {
          console.log("111111111111111111111111111111111",orderId, type)
          this.setState({
            stopDisabled: false,
          })
          // const data = Taro.getStorageSync("current_gg_id");
          // if (data != undefined && data != null && data.length > 0) {
          //   let obj = JSON.parse(data);
          //   const user_token = Taro.getStorageSync(obj.gg_id);
          //   let objs = {}
          //   if (user_token !== "") {
          //     objs = JSON.parse(user_token);
          //   } else {
          //     objs = {
          //       token: ""
          //     }
          //   }
          //   Request({
          //     url: `hzsx/llxzu/guanggao/add_guanggao_order`,
          //     method: "GET",
          //     data: {
          //       order_id: orderId,
          //       // 此时gg_id是跳转传参
          //       user_token: objs.token
          //     }
          //   }).then(res => {
          //     Taro.atMessage({
          //       'message': '传输成功',
          //       'type': type,
          //       'duration': 1000
          //     })
          //   });
          // }
          // let user_token = this.state.gg_token;
          if (type === 'detail') {
            Request({
              url: "hzsx/api/order/hasOrderUsing",
              method: 'GET',
              data: {
                uid: getUid(),
                channelId: '006',
              }
            }).then(res => {
              if (res.data.data === true) {
                my.call('verifyIdentity', {
                  action: 'getEnvData',
                }, function (result) {
                  console.log(result.actionResult);
                  const actionResult = result.actionResult
                  if (actionResult) {
                    Request({
                      url: 'hzsx/api/components/riskRuning',
                      method: 'POST',
                      data: {
                        uid: getUid(),
                        channelId: '006',
                        orderId: orderId,
                        bizRequestParams: actionResult,
                        userId: getBuyerId(),
                      }
                    }).then(res => {
                      const verifyId = res.data.data.verifyId;
                      const bizId = res.data.data.bizId;
                      my.call('verifyIdentity', {
                        verifyId: verifyId,
                        user_id: getBuyerId(),
                      }, function (result) {
                        Request({
                          url: 'hzsx/api/components/runingReceive',
                          method: 'POST',
                          data: {
                            bizId,
                            code: result.code,
                          }
                        }).then(res => {
                          console.log('这里是刷脸之后的调用 之前 已实名过1111')
                        })
                      });
                    })
                  }
                });
              }
            })
            setTimeout(() => {
              Taro.redirectTo({
                url: `/pages/checkSuccess/index?orderId=${orderId}&type=1`,
              });
            }, 400)
          } else {
            // 取消预授权进入此判断
            this.setState({
              showOnPayment: true,
            })
            // setTimeout(() => {
            //   Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            // }, 1000)
          }
        },
      });
    }else {
      Request({
        url: `hzsx/api/appZuLinPingTai/antZuLinPingTaiOrderComfirm?orderId=${this.state.showOnPaymentOrderId}&channel=006`,
        method: 'POST',
      }).then(res => {
        console.log(res, "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
        if (res.data.responseType == "SUCCESS") {
          //跳转下单成功
          setTimeout(() => {
            Taro.redirectTo({
              url: `/pages/checkSuccess/index?orderId=${this.state.showOnPaymentOrderId}&type=1`,
            });
          }, 400)
        } else {
          // 请求失败 跳转到订单列表
          setTimeout(() => {
            Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
          }, 1000)
          if (res.errorMessage) {
            Taro.showToast({
              title: res.errorMessage,
              icon: "none",
            });
          }
        }
      })
      //进入芝麻代扣流程
      // this.setState({
      //   showHint:true,
      // })
      // this.countDown();
      // Request({
      //   url:'hzsx/api/appAntContractWithhold/userAndOrgMainSgnFlow',
      //   method:'POST',
      //   data:{
      //     channel:'006',
      //     orderId:confirmOrder.orderId,
      //     // orderId:"008OI202304277521072469482250240",
      //   }
      // }).then(res=>{
      //   if(res.data.responseType == "SUCCESS") {
      //     this.setState({
      //       showHint:false,
      //       showRemind:true,
      //       longUrl:res.data.data.longUrl,
      //     })
      //   }else {
      //     // 请求失败 跳转到订单列表
      //     this.setState({
      //       showHint:false,
      //     })
      //     setTimeout(() => {
      //       Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
      //     }, 1000)
      //     if (res.errorMessage) {
      //       Taro.showToast({
      //         title: res.errorMessage,
      //         icon: "none",
      //       });
      //     }
      //   }
      // })
    }
  }
  // 芝麻代扣跳转方法
  submitRemind = () => {
    const { dispatch, confirmOrder } = this.props;
    if (this.state.longUrl) {
      const { params } = schemeToParams(this.state.longUrl);
      if (this.state.longUrl && params) {
        const { appId, path, query, ...extraData } = params;
        my.navigateToMiniProgram({
          appId,
          path,
          query,
          extraData,
          success: (res) => {
            this.setState({
              showRemind: false
            })
            console.log(JSON.stringify(res), "芝麻代扣合同签署成功！！！！！！")
            setTimeout(() => {
              Taro.redirectTo({
                url: `/pages/checkSuccess/index?orderId=${confirmOrder.orderId}&type=1`,
              });
            }, 400)
          },
          fail: (res) => {
            this.setState({
              showRemind: false
            })
            console.log(JSON.stringify(res), "芝麻代扣合同签署失败。。。。。。")
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          },
        });
      }
    } else {
      Taro.showToast({
        title: "请返回列表！",
        icon: "none",
      });
    }
  }
  handleChangePayment = (e) =>{
    console.log(e,"jjjjjjjjjjjjjjjjjjj")
    this.setState({
      payment_id:e.detail.value
    })
  }
  // 点击自定义按钮 
  gotoNewAddress = () => {

    this.setState({
      showAddress: true,
    })

    // Taro.navigateTo({
    //     url:"/pages/addAddress/index"
    // })
  }
  // 自定义地址
  handleAreaClick() {
    my.multiLevelSelect({
      title: '选择地址',
      list: citys,
      success: (data) => {
        if (data.success) {
          const addressValues = this.getAddressValues(data.result)
          this.setState({ currentAddress: addressValues });
        }
      },
    });
  }

  getAddressValues(result) {
    const provinceInfo = addressList.find(info => info.name === result[0].name);

    const cityInfo = provinceInfo.subList.find(info => info.name === result[1].name);
    const areaInfo = cityInfo.subList.find(info => info.name === result[2].name);
    return [
      { name: provinceInfo.name, value: provinceInfo.value },
      { name: cityInfo.name, value: cityInfo.value },
      { name: areaInfo.name, value: areaInfo.value },
    ];
  }
  showToast(title) {
    if (title) {
      Taro.showToast({
        title,
        icon: 'none',
        mask: true,
      });
    }
  }

  // 自定义提交事件
  formSubmit = (e) => {
    const { realname, telephone, street, isDefault } = e.detail.value;
    const { currentAddress, isAddressDefault } = this.state;
    const { addressInfo, confirmOrder } = this.props;
    const { dispatch } = this.props;
    let formId = e.detail.formId
    dispatch({
      type: 'unclaimed/userFormIdPool',
      payload: {
        type: '1',
        userFormId: formId
      }
    })
    if (!realname) {
      this.showToast('请输入收货人姓名');
      return;
    }
    if (!telephone || telephone.length !== 11) {
      this.showToast('请输入正确的手机号');
      return;
    }
    if (!currentAddress.length) {
      this.showToast('请选择省市区');
      return;
    }
    if (!street) {
      this.showToast('请输入详细地址');
      return;
    }
    let params = {
      realname,
      telephone,
      isDefault: isAddressDefault ? 1 : 0,
      street,
      id: addressInfo.id
    }
    if (currentAddress[0].value == '其它') {
      params.province = 999;
      params.city = 999;
      params.area = 999;
    } else {
      params.province = currentAddress[0].value;
      params.provinceStr = currentAddress[0].name;
      params.city = currentAddress[1].value;
      params.cityStr = currentAddress[1].name;
      params.area = currentAddress[2].value;
      params.areaStr = currentAddress[2].name
    }
    dispatch({
      type: 'addAddress/subAddress',
      payload: params,
      callback: (res) => {
        params.id = res.data
        dispatch({
          type: 'confirmOrder/setDefaultUserAddress',
          payload: params
        });
        this.setState({
          showAddress: false,
          isEditBtn: true,
        })
      }
    })



  }
  //   给取消按钮绑定点击事件
  onClose = () => {
    this.setState({
      showAddress: false,
    })
  }
  //   --------------------------
  onChangeMent = (e) => {
    const { checked } = this.state;
    this.setState({
      checked: !checked,
    });
  };
  // 点击更多优惠券
  changeCoupon(couponsLen) {
    if (couponsLen < 1) {
      return;
    }
    this.setState({ showQuanCoupons: true });
  }
  // 改变优惠券时
  couponChangeClick(defaultCode, code, item) {
    if (defaultCode === code) {
      return;
    }
    const { dispatch, confirmOrder } = this.props;

    dispatch({
      type: 'confirmOrder/couponChange',
      payload: {
        couponId: code,
        price:
          confirmOrder.orderPricesDto && confirmOrder.orderPricesDto.skuPrice,
        skuId: confirmOrder.skuDto && confirmOrder.skuDto.skuId,
        productId: confirmOrder.product && confirmOrder.product.productId,
        duration: confirmOrder.duration,
        start: confirmOrder.start,
        end: confirmOrder.end,
        num: confirmOrder.num,
        uid: getUid(),
        item,
      },
      callback: () => {
        this.hideQuanCoupons();
      },
    });
  }
  hideQuanCoupons() {
    this.setState({ showQuanCoupons: false });
  }

  onShowCoupons = () => {
    this.setState({ showCoupons: true });
  };
  onCouponClose = () => {
    this.setState({ showCoupons: false });
  };
  render() {
    const {
      confirmOrder,
      loading,
      addressInfo,
      confirmOrder: { orderByStagesDtoList },
    } = this.props;
    const { buyType } = this.$router.params;
    const { checked, showCoupons, showQuanCoupons, showAddress, currentAddress, stopDisabled, showOnPayment,payment_id,showHint,countDownStr,showRemind,  } = this.state;
    const {
      freeBuyOutPeriod,
      defaultUserAddress,
      coupons,
      skuDto,
      product,
      defaultCouponDto,
      orderPricesDto,
      nextPeriods,
      restPeriodsList,
      expireBuyOutPrice,
      additionalServicesDtoList,
      isSupported,
      detailDto,
      LastAddress,
    } = confirmOrder;
    let couponss = coupons || [];
    let billPlan = [];
    let indexList = [
      '一',
      '二',
      '三',
      '四',
      '五',
      '六',
      '七',
      '八',
      '九',
      '十',
      '十一',
      '十二',
    ];

    if (!!restPeriodsList && !!restPeriodsList.length) {
      restPeriodsList.map((item, index) =>
        billPlan.push({
          title:
            index === 0
              ? `首期租金 ¥${orderPricesDto.firstPeriodsRentPrice}`
              : `第${indexList[index]}期租金 ¥${orderPricesDto.firstPeriodsRentPrice}`,
          description: item,
          img:
            index === 0
              ? 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/b876c8e5b35b4a44b5349df9b1337051.png'
              : 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/04e5b460edb2420a895718d986bc766b.png',
        }),
      );
    }

    loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();

    const { type } = this.$router.params;
    //    const title=isshowModal
    return (
        <View className="confirmOrder-page">
        <AtMessage />
          <View className="" style="background:#f0f0f080;"></View>
          {buyType === 'continue' ? (
              ''
          ) : (
              <View className="top">
                    {LastAddress && LastAddress.realname ? 
                    <View className="address" >
                     <View className="new_img"><Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3463bd12c2cc48969d1d89e7695fdc77.png"  className="new_image"/></View>
                     <View className="contact-content">
                      <View className="contact-num">
                        <Text className="name">{LastAddress.realname}</Text>
                        <Text>{LastAddress.telephone}</Text>
                      </View>
                      <View className="content">
                          {LastAddress.cityStr}
                          {LastAddress.areaStr}
                          {LastAddress.street}
                      </View>
                     </View>
                      {isShowBtn==true?( <Button className="contact-btn" onClick={this.alipayAddress}>更换地址</Button>):''}
                    </View> : 
                  !!defaultUserAddress &&  defaultUserAddress.realname ? (
                        <View className="address" >
                         <View className="new_img"><Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3463bd12c2cc48969d1d89e7695fdc77.png"  className="new_image"/></View>
                         <View className="contact-content">
                          <View className="contact-num">
                            <Text className="name">{defaultUserAddress.realname}</Text>
                            <Text>{defaultUserAddress.telephone}</Text>
                          </View>
                          <View className="content">
                              {defaultUserAddress.provinceStr}
                              {defaultUserAddress.cityStr}
                              {defaultUserAddress.areaStr}
                              {defaultUserAddress.street}
                          </View>
                         </View>
                          {isShowBtn==true?( <Button className="contact-btn" onClick={this.alipayAddress}>更换地址</Button>):''}
                        </View>
                    ) : (
                          <View className="new-address"  onClick={this.alipayAddress}>
                          <View className="new_img"><Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/70d3ae33ab794e7489a889880ab9491d.png"  className="new_image"/></View>
                           <View className="new_text">
                               <View className="new_top">暂无收货地址</View>
                               <View className="new_bottom">（请详细填写本人收货地址，如xx小区x栋xx）</View>
                            </View>
                           <View className="new_tu">
                             <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/17c4c90c567d409bacbb536c02306cec.png" className="new_tu_img" />
                            </View>  
                        </View>
                    )}
                    {/* {!!defaultUserAddress && defaultUserAddress.realname ? ( */}
                    
                    {/* // <View className="address" > */}
                        {/* {isShowBtn==true?( <Button className="contact-btn" onClick={this.alipayAddress}>更换地址</Button>):''} */}
                        {/* 根据方案3 暂时注销 */}
                       {/* {isEditBtn==true? (<Button className="contact-btn" onClick={this.openModal}>编辑</Button>):''} */}
                     {/* <View className="new_img"><Image   className="new_image"/></View>
                     <View className="contact-content">
                      <View className="contact-num">
                        <Text className="name">{defaultUserAddress.realname}</Text>
                        <Text>{defaultUserAddress.telephone}</Text>
                      </View>
                      <View className="content"> */}
                        {/* <View className="location-img" /> */}
                        {/* <View> */}
                          {/* {defaultUserAddress.provinceStr}
                          {defaultUserAddress.cityStr}
                          {defaultUserAddress.areaStr}
                          {defaultUserAddress.street} */}
                        {/* </View> */}
                      {/* </View>
                     </View> */}
                      {/* {isShowBtn==true?( <Button className="contact-btn" onClick={this.alipayAddress}>更换地址</Button>):''} */}
                    {/* </View> */}
                {/* // ) : ( */}
                    {/* // <View className="empty-address" > */}
                    {/* //   <View className="new-address"  onClick={this.alipayAddress}> */}
                        {/* 方案一 原先的外面标签的类名是empty-address */}
                      {/* <Button className={showAddress==false ?'location add' :'location'}  onClick={this.gotoAddress}>选择收货地址</Button>
                      <AtIcon value="chevron-right" size="20" color="#ccc" /> */}
                      {/* 方案二  外面的标签类名是empty-address  */}
                      {/* <Button className={showAddress==false ?'location add' :'location'}  onClick={this.alipayAddress}>选择收货地址</Button>
                      <Button  className={showAddress==true ?'rightBtn add' :'rightBtn' } onClick={this.gotoNewAddress} >自定义收货地址</Button> */}
                      {/* 方案三 */}
                      {/* <View className="new_content">
                      </View> */}
                      {/* <View className="new_img"><Image   className="new_image"/></View>
                       <View className="new_text">
                           <View className="new_top">暂无收货地址</View>
                           <View className="new_bottom">（请详细填写本人收货地址，如xx小区x栋xx）</View>
                        </View>
                       <View className="new_tu">
                         <Image className="new_tu_img" />
                        </View>  
                    </View>
                )} */}
                
                {/* <Image
                    className="line-img"
                    mode="scaleToFill"
                
                /> */}
              </View>
          )}
          <View className="order-content">
            <View className="goods-info">
              {type === 'DIRECT' ? (
                  <Image
                      className="img"
                      mode="aspectFit"
                      src={confirmOrder && confirmOrder.productImage}
                  />
              ) : (
                  <Image
                      className="img"
                      mode="aspectFit"
                      src={
                        buyType !== 'continue'
                          ? product.images &&
                          product.images.length &&
                          product.images[0].src
                          : detailDto && detailDto.mainImageUrl
                      }
                  />
              )}
              <View className="goods">
                <View className="title">
                  {type === 'DIRECT' ? confirmOrder.productName : product.name}
                  {buyType === 'continue'
                      ? detailDto && detailDto.productName
                      : null}
                </View>
                <View className="spec">
                  规格：
                  {type === 'DIRECT'
                      ? confirmOrder.skuInfo
                      : skuDto &&
                      !!skuDto.specAll &&
                      skuDto.specAll
                          .map((val) => val.platformSpecValue)
                          .join(',')}
                  {buyType === 'continue'
                      ? detailDto && detailDto.skuTitle
                      : null}
                </View>
                <View className="rent">
                  {type === 'DIRECT' ? '总计：' : '总租金：'}

                  <Text className="price">
                    ¥
                    {type === 'DIRECT'
                        ? confirmOrder.totalAmount
                        : orderPricesDto.totalRent}
                  </Text>
                </View>
              </View>
              <View className='returnDate'>
                <View className='returnDateLeft'>
                  <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/10563f1f346c43b1880bf933da4a40ec.png" className="return_image" style={{marginLeft:'-50px'}}/>
                    <View className='returnDateLeft-text'>
                      <Text className='returnDateLeft_a'>预计起租日</Text>
                      <Text className='returnDateLeft_b'>{confirmOrder.estimateStart}</Text>
                    </View>
                  </View>
                <View className='returnDateRight'>
                    <Image  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/283ed3c935c74e45a2a43f03ca1cc7ad.png"  className="return_image" style={{marginLeft:'-40px'}}/>
                      <View className='returnDateRight-text'>
                        <Text className='returnDateRight_a'>预计归还日</Text>
                        <Text className='returnDateRight_b'>{confirmOrder.estimateEnd}</Text>
                      </View>
                    </View>
              </View>
            </View>
            {/* <View className="Tips">
              <View>提示：快递运输期间不算租期，实际起租日为快递签收当天</View>
            </View> */}
            {/* 实名认证 */}
            {/* {type === 'DIRECT'
                ? null
                : !this.state.isCard && (
                <View className="add_attestation">
                  <View className="attestation_head">实名认证</View>
                  <View className="attestation_main">
                    <View>姓名： </View>
                    <Input
                        className="input-mess"
                        placeholder="请在这里留下您的姓名"
                        onBlur={this.onAttestationName}
                        style={{ width: "70%"}}
                    />
                  </View>
                  <View className="attestation_main"> 
                    <View>身份证号：</View>
                    <Input
                        className="input-mess"
                        placeholder="请在这里留下您的身份证号"
                        onBlur={this.onAttestationId}
                    />
                  </View>
                </View>
              )} */}
              {/* <Button
                className="bottom-button disabled"
                scope="phoneNumber"
                open-type="getAuthorize"
                // formType="submit"
                onGetAuthorize={this.onGetPhone}
                >
                提交
              </Button> */}
            <View className="order-info">
              {!orderPricesDto.activityDiscountAmount ? null : (
                  <View className="item">
                    <View className="text">分享免租权益</View>
                    <View className="price">
                      -￥{orderPricesDto.activityDiscountAmount}
                    </View>
                  </View>
              )}
              <View className="item">
                <View className="text">优惠券</View>
                <View
                    className="price color3"
                    onClick={() => this.changeCoupon(couponss.length || 0)}
                >
                    {defaultCouponDto.delayDays>0? (<Text>{defaultCouponDto.delayDays}天</Text> ):(   <Text>-￥{defaultCouponDto.discountAmount || 0}</Text>)}
                  {couponss && couponss.length ? (
                      <AtIcon value="chevron-right" size="18" color="#666" />
                  ) : (
                      ''
                  )}
                </View>
              </View>
              {type === 'DIRECT' ? null : (
                  <View className="item">
                    <View className="text">第一期租金</View>
                    <View className="price">
                      ¥{orderPricesDto.firstPeriodsRentPrice}
                    </View>
                  </View>
              )}

              {orderPricesDto &&
              !!orderPricesDto.restPeriods &&
              !!orderPricesDto.orderByStagesDtoList &&
              !!orderPricesDto.orderByStagesDtoList.length &&
              orderPricesDto.orderByStagesDtoList.length > 1 && (
                  <Block>

                  <View className="item" onClick={this.onShowCoupons}>
                    <View className="text">
                      {/* 这里的还款改为支付 */}
                      <View>剩余支付时间</View>
                      {/* <View className="next-pay-time">
                        下次还款时间
                        {orderPricesDto.orderByStagesDtoList[1].statementDate &&
                        orderPricesDto.orderByStagesDtoList[1].statementDate.split(
                            ' ',
                        )[0]}
                        (¥
                        {
                          orderPricesDto.orderByStagesDtoList[1]
                              .currentPeriodsRent
                        }
                        )
                      </View> */}
                    </View>
                    <View className="price price_flex">
                      <View className="color3">
                        ¥{orderPricesDto.otherPeriodsPrice} *{' '}
                        {orderPricesDto && orderPricesDto.restPeriods}期
                      </View>
                      <View className="spot" />
                    </View>
                  </View>
                  <View className="item" style={{justifyContent:'flex-end'}}>
                      <View className="next-pay-time">
                        下次支付时间
                        {orderPricesDto.orderByStagesDtoList[1].statementDate &&
                        orderPricesDto.orderByStagesDtoList[1].statementDate.split(
                            ' ',
                        )[0]}
                        (¥
                        {
                          orderPricesDto.orderByStagesDtoList[1]
                              .currentPeriodsRent
                        }
                        )
                      </View>
                  </View>
                  </Block>
              )}
              {buyType === 'continue' ? (
                  ''
              ) : type === 'DIRECT' ? null : (
                  <View className="item">
                    <View className="text">运费</View>
                    <View className="price">
                      {this.state.freightTypeObj[product && product.freightType]}
                    </View>
                  </View>
              )}
              {type === 'DIRECT' ? (
                  <View className="item">
                    <View className="text">运费</View>
                    <View className="price">{confirmOrder.freightStr}</View>
                  </View>
              ) : null}
              {type === 'DIRECT' ? (
                  <View className="item">
                    <View className="text">商品价格</View>
                    <View className="price">{confirmOrder.price}</View>
                  </View>
              ) : null}
              {/* {additionalServicesDtoList && additionalServicesDtoList.length && (
                // 注销增值服务
                  <View>  
                    {additionalServicesDtoList.map((ser) => (
                        <View className="item">
                          <View className="text">{ser.name}</View>
                          <View className="price">￥{ser.price}</View>
                        </View>
                    ))}
                  </View>
              )} */}
              {type === 'DIRECT' ? null : (
                  <Block>

                      <View className="item">
                        <View>
                          <View className="text">冻结金额</View>
                          {/* <View className="zmxy" style={{paddingLeft:'50px'}}>
                            提交订单，基于您的信用免除{' '}
                            <Text style={{ color: 'red' }}>
                              ¥0-{orderPricesDto.depositAmount}
                            </Text>
                            额度
                          </View> */}
                        </View>
                        <View className="price color3">
                          ¥{orderPricesDto.freezePrice}
                        </View>
                      </View>
                      <View className="item"  style={{justifyContent:'flex-end'}}>
                           <View className="zmxy">
                            提交订单，基于您的信用免除{' '}
                            <Text style={{ color: 'red' }}>
                              ¥0-{orderPricesDto.depositAmount}
                            </Text>
                            {/* 额度 */}
                            金额
                          </View>
                      </View>
                  </Block>
                  )}
              {type === 'DIRECT' ? null : (
                  <View className="item">
                    <View className="text">
                      {product.buyOutSupport == 1
                          ? '到期买断价'
                          : '该商品暂不支持买断'}
                    </View>
                <View className="price color3">
                      {product.buyOutSupport == 1 ? '¥' + orderPricesDto.expireBuyOutPrice : ''}
                    </View>
                  </View>
              )}
            </View>
            <View className='ZhimaCredit'>
              <View className='ZhimaCredit_top'>
                 <View className='ZhimaCredit_topName'>
                     <Image className='img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/890a7f236fa44d929d61e481fce3db4d.png'></Image>
                     <View className='name'>芝麻信用减免押金</View>
                  </View>
                  <View className='ZhimaCredit_topPricer'>
                  ¥{orderPricesDto.freezePrice}
                  </View>
             
              </View>

              <View className='ZhimaCredit_button'>点击提交订单，最高可全免押金！</View>
            </View>
            {confirmOrder && confirmOrder.hbPeriodAmountDto ? (
                <View className="messages">
                  <View className="viwe1">
                    <View>付款方式</View>
                    <View>花呗分期</View>
                  </View>
                  <View className="viwe2">
                    <View>
                      分{confirmOrder.hbPeriodAmountDto.hbPeriodNum}期（含手续费）
                    </View>
                    <View>
                      ¥{confirmOrder.hbPeriodAmountDto.hbPeriodAmount / 100}/期
                    </View>
                  </View>
                </View>
            ) : null}
            {/* {type === 'DIRECT'
                ? null
                : !this.state.isCard && (
                <View className="messagess">
                  <View className="item">
                    <View>实名认证</View>
                    <View
                        style={{
                          color: '#C43737',
                          display: 'flex',
                        }}
                        onClick={() => {
                          Taro.navigateTo({ url: `/pages/Certificates/index` });
                        }}
                    >
                      去认证
                      <AtIcon value="chevron-right" size="18" color="#C43737" />
                    </View>
                  </View>
                </View>
            )} */}
             {/* !this.state.isCard && */}
             { this.state.isCard
                ? null
                :  (
                <View className="newIscard"  
                  onClick={() => {
                    confirmOrder.defaultUserAddress && confirmOrder.defaultUserAddress.id  || LastAddress != "" ? 
                      Taro.navigateTo({ url: `/pages/Certificates/index?productId=${ confirmOrder.product && confirmOrder.product.productId ? confirmOrder.product.productId : null}&skuId=${ confirmOrder.skuDto && confirmOrder.skuDto.skuId ? confirmOrder.skuDto.skuId : null }&addressId=${ confirmOrder.defaultUserAddress && confirmOrder.defaultUserAddress.id ? confirmOrder.defaultUserAddress.id : null}&orderId=${ confirmOrder.orderId  ? confirmOrder.orderId : null}` })
                      :
                      Taro.showToast({
                        title:"请选择收货地址!",
                        icon: 'none',
                      })
                  }}
                 >
                  <View className="item">
                    <View style={{marginTop:'5px'}}>
                      姓名 <Text style={{color:'#999',fontSize:'13px',marginLeft:'65px'}}>请输入姓名</Text>
                    </View>
                    <View style={{marginTop:'10px'}}>
                      身份证号 <Text style={{color:'#999',fontSize:'13px',marginLeft:'35px'}}>请输入身份证号</Text>
                    </View>
                    <View style={{marginTop:'10px',color:'red',fontSize:'13px'}}> *补全资料 加速审核</View>
                  </View>
                  <View style={{float:'right',marginTop:'-50px'}}>
                    <AtIcon value="chevron-right" size="24" color="red" />
                  </View>
                </View>
            )}
            <View className="message">
              <View>买家留言：</View>
              <Input
                  className="input-mess"
                  placeholder="请在这里留下您的备注"
                  onInput={this.onMessageInput}
              />
            </View>
            
            {type === 'DIRECT' ? null : (
                <View className="xieyi">
                  <View className="libs">
                    <View onClick={this.onChangeMent}>
                      {checked === true ? (
                          <Image
                              className="img"
                              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/382f17e7edda4aa4b093b6c2b58794a6.png"
                          />
                      ) : (
                          <Image
                              className="img"
                              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c9705d5df1024cda8487a41a0c143668.png"
                          />
                      )}
                    </View>
                    <View className="checkbox-text">
                      <Text onClick={this.onChangeMent}>我已阅读并同意签署</Text>
                      <Text
                       style={{color:'#00BFFF'}}
                       onClick={this.allAgreement}
                      >'租赁服务协议及相关'</Text>
                      {/* <Text onClick={this.gotoProtocol} className="text">
                        《租赁服务协议》
                      </Text> 与
                      <Text  onClick={this.digitalCertificate}  className="text">
                          《信用授权协议》
                      </Text> */}
                    </View>
                  </View>
                </View>
            )}
          </View>

          <View className="bottom-space" />
          {
      type === 'DIRECT' ? null : (
        <View className="bottom-info">
          <View className="info">
          <View className='pay-Info'>
          首期应付 
          <Text className='pay-Info-text'>
          ¥{orderPricesDto.firstPeriodsRentPrice}
          </Text>
              </View>
            {/* 注销了实付金额的字样  */}
            {/* <View className="info-item">
                    <Text className="text">实付</Text>￥
                    <Text className="price">
                      {orderPricesDto &&
                      String(orderPricesDto.firstPeriodsPrice).split('.')[0]}
                    </Text>
                    {orderPricesDto &&
                    String(orderPricesDto.firstPeriodsPrice).split('.')[1]
                        ? '.' + String(orderPricesDto.firstPeriodsPrice).split('.')[1]
                        : '.00'}
                  </View> */}
          </View>
          {/* <View
                    // className={
                    //   !this.state.isCard ||
                    //   (buyType !== 'continue' && !confirmOrder.defaultUserAddress) ||
                    //   !checked
                    //       ? 'pay-button disabled'
                    //       : 'pay-button'
                    // }
                    // 调整后的按钮 没有禁用的功能 但是当提交是时是有判断权限的 来进行提交支付
                    className='pay-button'
                    onClick={this.submitOrder}
                >
                  信用授权下单
                </View> */}
          {/* 实名认证 */}
          {/* {type === 'DIRECT'
                    ? null
                    : !this.state.isCard ? (
                    <Button
                      className='pay-button'
                      scope="phoneNumber"
                      open-type="getAuthorize"
                      // formType="submit"
                      onGetAuthorize={throttles(this.onGetPhone,1000)}
                    >
                      身份认证下单
                    </Button>
                  ) : (
                    <View
                        className='pay-button'
                        onClick={throttles(this.submitOrder,1000)}
                    >
                      信用授权下单
                    </View>
                  )
                } */}
          {type === 'DIRECT'
            ? null
            : (
              <View
                className='pay-button'
                onClick={throttles(this.submitOrder, 2000)}
              // style={stopDisabled ? {color:"#E7F9FF",background:"#B7E3FF"} : {color:"#fff"}}
              >
                信用授权下单
              </View>
            )
          }
        </View>
      )
    }

    {
      type === 'DIRECT' ? (
        <View className="bottom-info">
          <View className="info">
            <View className="info-item">
              <Text className="text">实付</Text>￥
              <Text className="price">{confirmOrder.totalAmount}</Text>
            </View>
          </View>
          <View onClick={this.submitOrders} className="pay-button">
            支付
          </View>
        </View>
      ) : null
    }

    {
      type === 'DIRECT' ? null : (
        <View>
          <View className="bill-plan">
            <AtFloatLayout
              isOpened={showQuanCoupons}
              onClose={() => this.hideQuanCoupons()}
              className="product-float"
            >
              {couponss &&
                couponss.length &&
                couponss.map((item, index) => (
                  <View
                    key={index + 'df'}
                    onClick={() =>
                      this.couponChangeClick(
                        defaultCouponDto.code,
                        item.code,
                        item,
                      )
                    }
                    className="coupon-item"
                  >
                    {/* {item.scene=='DELAYED'?(
                                 <View>
                            <Text className="item-left-1">
                              延期{item.delayedDay}天:{' '}
                            </Text>
                            <Text className="item-left-2">
                              {item.minAmount == 0
                                  ? '无门槛'
                                  : '满' + item.minAmount +'元'}
                              延期{item.delayedDay}天
                            </Text>
                          </View>):( <View>
                            <Text className="item-left-1">
                              减{item.discountAmount}:{' '}
                            </Text>
                            <Text className="item-left-2">
                              {item.minAmount == 0
                                  ? '无门槛'
                                  : '满 ' + item.minAmount}
                              减{item.discountAmount}
                            </Text>
                          </View>)}
                          */}
                    {item.scene == 'DELAYED' ? (
                      <View>
                        {
                          item.minLease > 0 ?
                            (<Block>
                              <Text className="item-left-1">
                                延期{item.delayDays}天:{' '}
                              </Text>
                              <Text className="item-left-2">
                                {item.amountType == 0
                                  ? '无门槛'
                                  : '满' + item.minLease + '天'}
                                延期{item.delayDays}天
                              </Text>
                            </Block>)
                            : (<Block>
                              <Text className="item-left-1">
                                延期{item.delayDays}天:{' '}
                              </Text>
                              <Text className="item-left-2">
                                {item.amountType == 0
                                  ? '无门槛'
                                  : '满' + item.minAmount + '元'}
                                延期{item.delayDays}天
                              </Text>
                            </Block>)
                        }
                      </View>) : (<View>
                        {item.minLease > 0 ?
                          (<Block>
                            <Text className="item-left-1">
                              减{item.discountAmount}:{' '}
                            </Text>
                            <Text className="item-left-2">
                              {item.amountType == 0
                                ? '无门槛'
                                : '满 ' + item.minLease + '天'}
                              减{item.discountAmount}元
                            </Text>
                          </Block>)
                          : (<Block>
                            <Text className="item-left-1">
                              减{item.discountAmount}:{' '}
                            </Text>
                            <Text className="item-left-2">
                              {item.amountType == 0
                                ? '无门槛'
                                : '满 ' + item.minAmount + '元'}
                              减{item.discountAmount}元
                            </Text>
                          </Block>)}

                      </View>)}
                    {defaultCouponDto.code === item.code ? (
                      <Image
                        mode="aspectFit"
                        className="coupon-icon"
                        src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/382f17e7edda4aa4b093b6c2b58794a6.png"
                      />
                    ) : (
                      <Image
                        mode="aspectFit"
                        className="coupon-icon"
                        src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c9705d5df1024cda8487a41a0c143668.png"
                      />
                    )}
                  </View>
                ))}
              <View
                className="coupon-item"
                onClick={() =>
                  this.couponChangeClick(defaultCouponDto.code, '', {})
                }
              >
                <View>
                  <Text className="item-left-1">不使用优惠券</Text>
                </View>
                {defaultCouponDto.code === item.code ? (
                  <Image
                    mode="aspectFit"
                    className="coupon-icon"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/382f17e7edda4aa4b093b6c2b58794a6.png"
                  />
                ) : (
                  <Image
                    mode="aspectFit"
                    className="coupon-icon"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c9705d5df1024cda8487a41a0c143668.png"
                  />
                )}
              </View>
              <View
                className="item-close-btn"
                onClick={() => this.hideQuanCoupons()}
              >
                关闭
              </View>
            </AtFloatLayout>
          </View>
          <View className="bill-plan">
            <AtFloatLayout
              isOpened={showCoupons}
              onClose={this.onCouponClose}
              className="product-float"
            >
              <View className="bill-plan-close" onClick={this.onCouponClose}>
                <Image
                  className="bill-plan-close-img"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0ae81c56cbba421bb8ba9f4c7bf9d23c.png"
                />
              </View>
              <View className="bill-plan-title">
                <Text className="bill-plan-title-line"></Text>
                {/* 这里有3处 */}
                月租金
                <Text className="bill-plan-title-text">
                  支付日当天或之前主动支付
                </Text>
              </View>
              <View className="bill-plan-content">
                {orderPricesDto &&
                  orderByStagesDtoList.map((item, index) => (
                    <View className="bill-plan-item" key={'a' + index}>
                      <View className="bill-plan-item-title">
                        第{index + 1}期
                        {index === 0 && freeBuyOutPeriod !== 1 ? (
                          <Image
                            mode="aspectFill"
                            className="this-time-oreder"
                            src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1faf6a5826184d9c8302032a983113e7.png"
                          />
                        ) : (
                          ''
                        )}
                        {freeBuyOutPeriod && freeBuyOutPeriod <= index + 1 ? (
                          <Image
                            mode="aspectFill"
                            className="zero-buyAble"
                            src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/709beefa302e4ab491623389e28e5491.png"
                          />
                        ) : (
                          ''
                        )}
                      </View>
                      <View className="bill-plan-item-content">
                        <Text>
                          {item.statementDate &&
                            item.statementDate.split(' ')[0]}
                        </Text>
                        <Text>￥{item.currentPeriodsRent}</Text>
                      </View>
                    </View>
                  ))}
              </View>
            </AtFloatLayout>
          </View>
        </View>
      )
    }


          <AtModal isOpened={showAddress} onClose={this.onClose}>
            {/* {isshowModal===true?'新增'：'修改'} */}
            <View className="title_header">地址</View>
            <AtModalContent>
              <View className='addAddress-page'>
                <Form report-submit='true' onSubmit={this.formSubmit}>
                  <View className='info'>
                    <View className='item'>
                      <label className="item-label">收货人</label>
                      <Input placeholder='请填写姓名' style={{ width: '100%' }} name='realname' value={addressInfo.realname} />
                    </View>
                    <View className='item'>
                      <label className="item-label">手机号码</label>
                      <Input placeholder='请填写手机号码' style={{ width: '100%' }} name='telephone' value={addressInfo.telephone} />
                    </View>
                    {currentAddress.length ? (
                      <View className='item areaSelect selectedText' onClick={this.handleAreaClick}>
                        <label className="item-label">所在区域</label>
                        <View>
                          <View>{currentAddress[0].name} {currentAddress[1].name} {currentAddress[2].name}</View>
                          <am-icon type='arrow-right' size={22} color='#ccc' />
                        </View>
                      </View>
                    ) : (
                      <View className='item areaSelect' onClick={this.handleAreaClick}>
                        <label className="item-label">所在区域</label>
                        <am-icon type='arrow-right' size={22} color='#ccc' />
                      </View>
                    )}

                    <View className='item'>
                      {/* <label  className="item-label"></label> */}
                      <Textarea placeholder='请填写详细地址' name='street' value={addressInfo.street} />
                      {/* <Input  placeholder='请填写详细地址' /> */}
                    </View >

                  </View>
                  <View className="item_btn">
                    <Button className='btn' onClick={this.onClose}>取消</Button> <Button className='btn' formType='submit'>确定</Button>
                  </View>
                </Form>
              </View>
            </AtModalContent>

          </AtModal>
          {/* 选择支付方式弹框 预授权&蚂蚁代扣 */}
          <AtModal isOpened={showOnPayment}  onClose={this.onClosePayment} closeOnClickOverlay={false} className="payment">
            <View className='payment_main'>
              <RadioGroup className='radioGroup' onChange={this.handleChangePayment}>
                <View className='payment_main_top'>
                  <View className='payment_main_top_up'>
                    <Image
                      className="up_img"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/405dd2ecd5f8446ebf60d190d9cbad9e.png"
                    />
                    <View className='radioText'>芝麻信用免押金</View>
                    <Image
                      className="up_img_t"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/647aa912d1d648dea2f6f51c8f00bd49.png"
                    />
                  </View>
                  <View className='payment_main_top_down'>凭芝麻信用最高可全免</View>
                  <Radio value={1} className='radio' checked />
                </View>
                {/* <View className='payment_main_buttom'>
                  <View className='payment_main_buttom_up'>
                    <Image
                      className="up_img"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/f6df7e20e10d41118e638e35d12fb04b.png"
                    />
                   <View className='radioText'>快速<View className='radioText_mian'>免押</View></View>
             
                  </View>
                  <View className='payment_main_buttom_down'>极速免押</View>
                  <Radio value={2} className='radio' />
                </View> */}
              </RadioGroup>

            </View>
            <AtModalAction className="payment_button"><Button className='payment_button_a' onClick={this.onClosePayment}>取消</Button> <Button className='payment_button_b' onClick={debounce(this.submitPayment, 2000)}>确定</Button> </AtModalAction>
          </AtModal>
          {/* 信用评估中弹窗 */}
          <AtModal isOpened={showHint} closeOnClickOverlay={false} className="hint">
            <View className='hint_main'>
              <Image
                className="hint_img"
                mode="scaleToFill"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/79a3db276bb548f1a8b99be7323a7ce4.gif"
                />
                <View className='hintText'>信用评估中</View>
                <View className='hintText_a'>
                  剩余 <View className='hint_time'>{countDownStr}</View> s
                </View>
            </View>
          </AtModal>
          {/* 提示信息弹窗 */}
          <AtModal isOpened={showRemind} closeOnClickOverlay={false} className="remind">
            <AtModalHeader className="remind_head">温馨提示</AtModalHeader>
            <View className='remind_main'>
              <View className='remindText'>
                即将前往支付宝智能合同小程序签署合同，签署合同完成请点击右上角关闭按钮，返回果果租查看订单审核进度！
              </View>
              <View className='remind_img'>
                <Image
                  className="remind_img_a"
                  mode="scaleToFill"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/25ae2108ada04a61a3c0714f6aa5f1ed.png"
                  />
              </View>
            </View>
            <AtModalAction><Button onClick={debounce(this.submitRemind, 2000)}>确定</Button></AtModalAction>
          </AtModal>
        </View >
    );
  }
}

export default Confirmorder;
