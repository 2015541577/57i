import Taro, { Component } from '@tarojs/taro';
import { View, Image, ScrollView, Text } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import * as shopsApi from './service';

import { getServicePhone } from '../../utils/localStorage'
import './index.scss';
import TagPage from '../../components/service'
import Search from '../home/component/search/index';

@connect(({ shops }) => ({
  ...shops,
}))
class Shops extends Component {
  config = {
    navigationBarTitleText: '店铺',
    usingComponents: {
      "modal": "../../npm/mini-antui/es/modal/index"
    }
  };

  state = {
    showServicePhone: false,
    isTagOpened:false,
    // 轮播图
    bannerList: []
  }

  componentDidMount = () => {
    const { queryInfo } = this.props;
    const { shopId } = this.$router.params;
    this.setDispatch({ ...queryInfo, pageNumber: 1 });

    // 轮播图
    shopsApi.queryOpeIndexShopBannerList({
      shopId
    }).then(res => {
      this.setState({
        bannerList: res.data || []
      })
    })
  };

  setDispatch(queryInfo, fetchType) {
    const { shopId } = this.$router.params;
    const { dispatch } = this.props;
    const info = { ...queryInfo, shopId };
    if (fetchType === 'scroll') {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    dispatch({
      type: 'shops/selectShopProductList',
      payload: { ...info },
    });
  }

  onScrollToLower = () => {
    const { total, queryInfo, queryInfo: { pageNumber, pageSize } } = this.props;
    if (pageNumber * pageSize - total >= 0) {
      Taro.showToast({
        title: '没有更多商品了',
        icon: 'none',
        duration: 500,
      });
      return;
    }
    this.setDispatch(queryInfo, 'scroll');
  };

  gotoProductDetail = (productId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${productId}&source=03` });
  }

  onClosePhoneModal = () => {
    this.setState({ showServicePhone: false });
  }

  onShowPhoneModal = () => {
    this.setState({ showServicePhone: true });
  }

  skip = (loinBanner) => {
    const url = loinBanner.jumpUrl
    if (url.indexOf('alipays://') === 0) {
      const index = url.indexOf('appId=');
      const indexPage = url.indexOf('=/');
      const appId = url.substr(index + 6, 16);
      const path = url.substring(indexPage + 1, url.length);
      if (indexPage !== -1) {
        my.navigateToMiniProgram({
          appId,
          path: path
        });
      }
      else {
        my.navigateToMiniProgram({
          appId,
        });
      }
    }
    else {
      Taro.navigateTo({ url });
    }
  }

  connectService = (number) => {
    let num = String(number);
    my.makePhoneCall({ number:num });
  }

  handleService = () => {
    this.setState({
      isTagOpened:true
    })
  }
  handleClose = () => {
    this.setState({
      isTagOpened:false
    })
  }
  onShareAppMessage() {
    const { shopId } = this.$router.params;
    const { shop  } = this.props
    return {
      title:  shop.name,
      // desc: shop.name,
      path: `pages/shops/index?shopId=${shopId}`,
    };
  }

  render() {
    const { list, shop } = this.props;
    const { showServicePhone ,isTagOpened, bannerList } = this.state;
    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = 115;
    if (systemInfo.model.indexOf('iPhone X') > -1) {
      fixedHeight = fixedHeight + 30;
    }
    const customerServiceTel = getServicePhone()
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;
    return (
      <View className='shops-page'>
        {/* <View className='search-view'>
          <Search
            value=''
            useLoc="商品页面"
          />
        </View> */}
        <View className="title">
          <View className='shop-info'>
            <Image className='header-img' mode='aspectFit' src={shop.logo} />
            <View>
              <View className="shop-hello">Hello，欢迎您~</View>
              <View className="shop-name">{shop.name}</View>
            </View>
          </View>
          <View className='shop-info-r'>
            <Image className='header-img' mode='aspectFit' src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/30f1d1f08c8c41abbc97d87e4ff2f5fe.png" />
            <Text>已缴纳保证金</Text>
          </View>
        </View>
        <View className='banner' style={{display:bannerList&&bannerList.length?'block':'none'}}>
          <swiper
            circular
            autoplay='{{true}}'
            interval='{{3000}}'
          >
            {
              bannerList.map((banner,index) => (
                <swiper-item key={'a'+index}>
                  <View className='item' onClick={this.skip.bind(this, banner)}>
                    <Image lazyLoad={true} className='item-img' src={banner.imgSrc} />
                  </View>
                </swiper-item>
              ))
            }
          </swiper>
        </View>
        <ScrollView
          className='products-area'
          scrollY
          scrollWithAnimation
          scrollTop='0'
          style={`height: ${scrollHeight}px;`}
          onScrollToLower={this.onScrollToLower}
        >
          <View className="product-title">全部商品</View>
          <View className="product-list">
            <View className="product-list-side">
              {
                list.map((item, index) => {
                  return (index % 2 === 0)
                      ? (
                          <View key={'al'+index} className="product-item" onClick={() => this.gotoProductDetail(item.productId)}>
                              <Image mode="widthFix" className="product-img" src={item.src} />
                              <Text className="product-name">{item.name}</Text>
                              <View className="product-msg">
                                <Text className="product-price">
                                  <Text className="product-price-num">￥{item.lowestSalePrice}</Text>
                                  <Text className="product-price-unit">元/天</Text>
                                </Text>
                                {/* <Text className="product-sell-num">销量{item.salesVolume}</Text> */}
                              </View>
                          </View>
                      )
                      : null
                })
              }
            </View>
            <View className="product-list-side">
              {
                list.map((item, index) => {
                  return (index % 2 !== 0)
                    ? (
                      <View key={'ar'+index} className="product-item" onClick={() => this.gotoProductDetail(item.productId)}>
                        <Image mode="widthFix" className="product-img" src={item.src} />
                        <Text className="product-name">{item.name}</Text>
                        <View className="product-msg">
                          <Text className="product-price">
                            <Text className="product-price-num">￥{item.lowestSalePrice}</Text>
                            <Text className="product-price-unit">元/天</Text>
                          </Text>
                          {/* <Text className="product-sell-num">销量{item.salesVolume}</Text> */}
                        </View>
                      </View>
                    )
                    : null
                })
              }
            </View>
        </View>
        </ScrollView>
        <TagPage
          onClose={this.handleClose}
          isOpened={isTagOpened}
          data = { shop && shop.serviceTel }
        />
      </View>
    )
  }
}

export default Shops;
