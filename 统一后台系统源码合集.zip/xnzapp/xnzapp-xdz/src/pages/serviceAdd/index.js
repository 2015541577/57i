import Taro, { Component, Fragment, request } from '@tarojs/taro';
import {View,Image} from  '@tarojs/components';
import ParseComponent from './wxParseComponent';
export default class serviceAdd extends Component {
   config = {
    navigationBarTitleText: '服务介绍',
    
  };
  state={
    content:null,
  }
  componentDidMount(){
    console.log(this.$router.params,'ieieiiparas')
    this.setState({
      content:this.$router.params.content,
    })
  }
  render() {
    const {content} = this.state
    return (
      <View style={{textAlign:'center',margin:'20px 10px'}}>
        {/* <Image style={{width:'100%'}} lazyLoad={true} src={content} /> */}
        <ParseComponent style={{margin:'auto'}} mark={content} />
      </View>
    )
  }
}
