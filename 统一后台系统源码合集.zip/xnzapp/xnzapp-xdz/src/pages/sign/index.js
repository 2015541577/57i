import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Button,
  Image,
} from "@tarojs/components";
import "./index.scss";
import { tradePay } from "../../utils/openApi";
import { connect } from '@tarojs/redux';
import * as billDetailApi from "./service";
import Request from "../../utils/request";

@connect(({ billDetail, loading }) => ({
  ...billDetail,
  loading: loading.models.billDetail,
}))
class sign extends Component {
  config = {
    navigationBarTitleText: "签到",
    usingComponents: {
      "point-asset": "plugin://myPlugin/point-asset"
    }
  };

  state = {
    data:[],
    show: my.canIUse('life-follow'),
    // favorite: my.canIUse('favorite'),
  };

  
    

  componentDidMount() {
 
  }
  render() {

    return (
        // <Button onClick={this.replaceSubmit}  className={`btn_b`}  >找人代付</Button>
        <View>
          <point-asset templateId="SI20211011000003031994" />
          <View className="c_app">
            <View className="c_app_top">
              <View className="c_app_text">专享福利</View>
              <View className="c_app_text_b">专享福利领不停</View>
            </View>
            <View className="c_app_main">
              {/* <View className="c_app_main_t">
                <View className="t_text">首次收藏小程序</View>
                <View className="t_text_b">收藏即获手机类租赁优惠券</View>
                <life-follow className="t_button" sceneId="3b6c88c21fad41f9a21a20f6ece5901b" />
                <favorite>收藏小程序，下次使用更方便</favorite>
              </View> */}
              <View className="c_app_main_b">
                <View className="b_text">首次关注生活号</View>
                <View className="b_text_b">关注即获手机类租赁优惠券</View>
                {/* <View className="t_button">查看生活号</View> */}
                <life-follow className="t_button" sceneId="3b6c88c21fad41f9a21a20f6ece5901b" />
              </View>
              
            </View>
          </View>
        </View>
    );
  }
}

export default sign;
