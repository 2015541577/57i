import Taro ,{Component} from '@tarojs/taro'
import {View,ScrollView} from '@tarojs/components'
import './index.scss';
class ProductImg extends Component {
    config = {
      navigationBarTitleText: "全新手机专项服务保障",
      titleBarColor: "#AEABCD",
      usingComponents: {
        modal: "../../npm/mini-antui/es/modal/index",
      },
    };
    render() {
      return (
        <View className="mine-page">
          <ScrollView
                  className="mine-page-info"
                  scrollY
                  scrollWithAnimation
                  lowerThreshold={60}
              >

          </ScrollView>
        </View>
      );
    }
  }
export default ProductImg 