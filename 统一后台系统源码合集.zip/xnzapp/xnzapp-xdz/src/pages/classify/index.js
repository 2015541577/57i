import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { connect } from '@tarojs/redux';

import MenuNav from './component/menu/index';
import List from './component/list/index';
import Search from '../home/component/search/index';
import umUpload from "../../utils/umengUploadData";
import './index.scss';

@connect(({ classify, loading }) => ({
  ...classify,
  loading: loading.models.classify,
}))
class Classify extends Component {
  config = {
    navigationBarTitleText: '分类',
  };

  state = {
    currentMenu: null,
    // 是否展开全部
    showAll: false,
    bannerIcon: ''
  };

  componentDidMount = () => {
    const { id } = this.$router.params;
    const { dispatch } = this.props;
    dispatch({
      type: 'classify/fetchCategoryList',
      payload: { categoryId: 0 },
      callback: (secondId, bannerIcon) => {
        let categoryId = secondId;
        if (Number(id)) {
          categoryId = id;
        }
        dispatch({
          type: 'classify/fetchCategoryList',
          payload: { categoryId },
          callback:()=>{
            this.setState({
              currentMenu: categoryId,
              bannerIcon
            });
          }
        });
      },
    });
  };

  // 展开全部分类
  showAll(){
    this.setState({
      showAll: true
    })
  }

  handleClickMenu = (id, bannerIcon) => {
    const { dispatch } = this.props;
    const { currentMenu } = this.state;
    if (currentMenu === id) {
      return;
    }
    dispatch({
      type: 'classify/clearRightList',
    });
    this.setState({
      currentMenu: id,
      bannerIcon
    });
    dispatch({
      type: 'classify/fetchCategoryList',
      payload: { categoryId: id },
    });
  }

  // 跳转去产品列表
  handleClickRight = (item) => {
    let { currentMenu } = this.state;
    
    Taro.navigateTo({ 
      url: `/pages/productList/index?type=category&catId=${item.id}&catName=${item.name}&currentMenu=${currentMenu}`
    });
  }

  // 监听点击tab栏，进行事件上报。这是个页面周期方法，试了下在app.js写无效，得复制到各个tab页面中
  onTabItemTap(object) {
    umUpload.bottomNavClickHandler(object);
  }

  render() {
    const { menuList, rightList, loading } = this.props;
    let { currentMenu, bannerIcon } = this.state;

    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='classify-page'>
        <View className='search-view'>
          <Search value='' useLoc="分类页面" />
        </View>
        <View className={'classify-page-top '+((!showAll && menuList && menuList.length && menuList.length)?'top-high-limit':'')}>
          {!!menuList && !!menuList.length && !!currentMenu && menuList.map(menu =>
            <MenuNav
              key={menu.id}
              sel={menu.id === currentMenu}
              value={menu.name}
              icon={menu.icon}
              onClick={this.handleClickMenu.bind(this, menu.id, menu.bannerIcon)}
            />
          )}
        </View>
        {
          !showAll && menuList && menuList.length && menuList.length > 8
            ? (
              <View className="banner" onClick={() => this.showAll()}>
                <View className="see-more"><Text>{'》'}</Text>展开全部分类</View>
                <Image className="banner-image" src={bannerIcon} />
              </View>
            )
            : <Image className="banner-image2" src={bannerIcon} />
        }
        <View className='classify-page-bottom'>
          <List list={rightList} onClick={this.handleClickRight} />
        </View>
      </View>
    )
  }
}

export default Classify;
