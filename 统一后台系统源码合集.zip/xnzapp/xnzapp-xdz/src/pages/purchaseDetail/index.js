import Taro, { Component, Fragment } from "@tarojs/taro";
import { View, Text, Image, Button, Input } from "@tarojs/components";
import { connect } from "@tarojs/redux";

import {
  AtIcon,
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
} from "taro-ui";

import {
  formatDate,
  leftTimer,
  leftTimerMS,
  transdate,
  addDate,
} from "../../utils/utils";
//import { orderStatus } from '../../assets/Constant';
import CancelOrder from "../../components/cancelOrder";
import "./index.scss";

import { getServicePhone, getGloble,getBuyerId,getUid } from "../../utils/localStorage";
import Request from "../../utils/request";
import TagPage from "../../components/service";
import { startAPVerify } from "../../utils/openApi";
import * as purchaseApi from "./service";
@connect(({ orderDetail, loading, confirmOrder, authentication }) => ({
  ...orderDetail,
  ...confirmOrder,
  ...authentication,
  // loading: loading.models.orderDetail,
}))
class Orderdetail extends Component {
  config = {
    navigationBarTitleText: "订单详情页",
    usingComponents: {
      "am-icon": "../../npm/mini-antui/es/am-icon/index",
      popover: "../../npm/mini-antui/es/popover/index",
      "popover-item": "../../npm/mini-antui/es/popover/popover-item/index",
      modal: "../../npm/mini-antui/es/modal/index",
    },
  };

  state = {
    cancelOrderDisplay: false, //取消订单模块显示
    receiveDoodsDisplay: false, // 确认收货模块显示
    modifySettlementDisplay: false, // 确认修改结算单模块显示
    showServicePhone: false, //model客服
    position: "topLeft",
    show: false,
    show2: false,
    show3: false,
    showMask: true,
    canCel: false,
    examineStatus: null,
    statusCancel: null,
    cancelOrderList: [
      {
        value: "想要重新下单",
      },
      {
        value: "商品价格较贵",
      },
      {
        value: "等待时机较长",
      },
      {
        value: "是想了解流程",
      },
      {
        value: "不想要了",
      },
    ],
    isTagOpened: false,
    statusObj: {
      "01": "WAITING_PAYMENT",
      "02": "PENDING_DEAL", //'PAYING',
      "03": "PAYED_USER_APPLY_CLOSE",
      "04": "PENDING_DEAL",
      "05": "WAITING_USER_RECEIVE_CONFIRM",
      "06": "RENTING",
      "07": "WAITING_SETTLEMENT",
      "08": "WAITING_SETTLEMENT_PAYMENT",
      "09": "FINISH",
      "10": "CLOSED",
    },
    purchaseData: {},
  };

  componentDidShow = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;

    purchaseApi.userOrdersPurchaseDetail({ orderId }).then((res) => {
      if (res.data.data) {
        this.setState(
          {
            purchaseData: res.data.data,
          },
          () => {
            this.countDown();
          }
        );
      }
    });
    dispatch({
      type: "orderDetail/getSysConfigByKey",
      payload: {
        configKey: "USER_CANCEL_ORDER:HOUR",
      },
    });
  };

  handleCancel = () => {
    this.setState({ cancelOrderDisplay: true });
  };

  handleModalCancel = () => {
    this.setState({ cancelOrderDisplay: false });
  };

  onClickReceiveGoods = () => {
    this.setState({ receiveDoodsDisplay: true });
  };

  handleCancalGoods = () => {
    this.setState({ receiveDoodsDisplay: false });
  };

  handleOkGoods = () => {
    const { dispatch } = this.props;
    const { orderId } = this.$router.params;
    dispatch({
      type: "orderList/userOrdersPurchasereceipt",
      payload: { orderId },
      callback: (res) => {
        purchaseApi.userOrdersPurchaseDetail({ orderId }).then((res) => {
          if (res.data.data) {
            this.setState({
              purchaseData: res.data.data,
            });
          }
        });
      },
    });
    this.setState({ receiveDoodsDisplay: false });
  };

  onClickFrezzAgain = (oreder) => {
    const { dispatch } = this.props;
    const { orderId } = this.$router.params;
    dispatch({
      type: "orderList/userOrdersPurchasepayAgain",
      payload: { orderId },
      callback: (res) => {
        purchaseApi.userOrdersPurchaseDetail({ orderId }).then((res) => {
          if (res.data.data) {
            this.setState({
              purchaseData: res.data.data,
            });
          }
        });
      },
    });
  };

  onClickBillDetail = () => {
    const { userOrdersDto, orderProductDetailDto, dispatch } = this.props;
    dispatch({
      type: "billDetail/saveProduct",
      payload: orderProductDetailDto,
    });
    Taro.navigateTo({
      url: `/pages/billDetail/index?orderId=${userOrdersDto.orderId}`,
    });
  };

  onClickSendBack = () => {
    const { userOrdersDto, orderProductDetailDto, dispatch } = this.props;
    dispatch({
      type: "sendBack/saveProductAndOrder",
      payload: { product: orderProductDetailDto, userOrdersDto },
    });
    Taro.navigateTo({
      url: `/pages/sendBack/index?orderId=${userOrdersDto.orderId}`,
    });
  };

  onClickModifySettlement = () => {
    this.setState({ modifySettlementDisplay: true });
  };

  handleCancelModifySettlement = () => {
    this.setState({ modifySettlementDisplay: false });
  };

  handleOkModifySettlement = (orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/userApplicationForAmendmentOfSettlementForm",
      payload: { orderId },
    });
    this.setState({ modifySettlementDisplay: false });
  };

  onClickConfirmSettlement = (orderId, waitTotalPay) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/confirmOrderSettlement",
      payload: {
        orderId,
        amount: waitTotalPay,
        channelId: getGloble('channelId'),
      },
    });
  };

  handleClickCopy = (orderId) => {
    // eslint-disable-next-line no-undef
    my.setClipboard({
      text: orderId,
      success: () => {
        Taro.showToast({
          title: "订单号复制成功" + orderId,
          icon: "none",
        });
      },
    });
  };
  onMaskClick = () => {
    this.setState({
      show: false,
    });
  };
  onMaskClick2 = () => {
    this.setState({
      show2: false,
    });
  };
  onShowPopoverTap2 = () => {
    this.setState({
      show2: true,
    });
  };
  onMaskClick3 = () => {
    this.setState({
      show3: false,
    });
  };
  onShowPopoverTap3 = () => {
    this.setState({
      show3: true,
    });
  };
  onShowPopoverTap = () => {
    this.setState({
      show: true,
    });
  };
  connectService = () => {
    this.setState({
      showServicePhone: true,
    });
  };

  connectServices = (val) => {
    let num = String(val);
    my.makePhoneCall({ number: val });
  };

  handleHelpDJ = () => {
    // eslint-disable-next-line no-undef
    my.alert({
      content: `您的冻结押金将冻结在您的支付宝或星动租账户中，当订单完结后，押金将立即原路退还予您的支付账户`,
      buttonText: "知道了",
    });
  };

  countDown = () => {
    const {
      purchaseData: { createTime, state },
    } = this.state;
    if (!createTime) {
      setTimeout(this.countDown, 1000);
    } else {
      const cdStr = leftTimerMS(createTime.replace(/-/g, "/"));
      if (state === "WAITING_FOR_PAY" && cdStr) {
        setTimeout(this.countDown, 1000);
        this.setState({ countDownStr: cdStr });
      } else {
      }
    }
  };

  onClosePhoneModal = () => {
    this.setState({ showServicePhone: false });
  };
  goShop = (val) => {
    Taro.navigateTo({
      url: `/pages/shops/index?shopId=${val}`,
    });
  };
  goProductDetails = (val) => {
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${val}&source=02&type=DIRECT`,
    });
  };
  handleCancelExpress = (orderId) => {
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${orderId}&type=购买`,
    });
  };
  handleClickRenewalBefore = () => {
    const { userOrdersDto } = this.props;
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${userOrdersDto.originalOrderId}`,
    });
  };
  onClickReturn(expressId, expressNo) {
    Taro.navigateTo({
      url: `/pages/express/index?expressId=${expressId}&expressNo=${expressNo}`,
    });
  }
  handleClickCancelOrder = (order) => {
    this.setState({
      cancelOrderDisplay: true,
    });
  };
  handleModalOk = (value) => {
    const { orderId } = this.$router.params;
    Request({
      url: "hzsx/userOrdersPurchase/cancel",
      method: "POST",
      data: {
        cancelReason: value,
        orderId: orderId,
      },
    }).then((res) => {
      purchaseApi.userOrdersPurchaseDetail({ orderId }).then((res) => {
        if (res.data.data) {
          this.setState({
            purchaseData: res.data.data,
          });
        }
      });
    });
    this.setState({ cancelOrderDisplay: false });
  };
  handleModalCancel = () => {
    this.setState({ cancelOrderDisplay: false });
  };

  oncanCelModal = () => {
    this.setState({
      canCel: false,
    });
  };

  handleService = () => {
    this.setState({
      isTagOpened: true,
    });
  };

  handleClose = () => {
    this.setState({
      isTagOpened: false,
    });
  };

  gotoProtocol = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;
    dispatch({
      type: "agreement/agreementPlaceorder",
      payload: { orderId: orderId },
      callback: (res) => {
        Taro.navigateTo({ url: `/pages/webview/xieyi?orderId=${orderId}` });
      },
    });
  };
  onBuyoutorder = (
    type,
    userOrderBuyOutDto,
    userOrderCashesDto,
    orderProductDetailDto
  ) => {
    const { orderId } = this.$router.params;
    if (userOrderBuyOutDto) {
      userOrderBuyOutDto.totalRent = userOrderCashesDto.totalRent;
      userOrderBuyOutDto.skuTitle = orderProductDetailDto.skuTitle;
      userOrderBuyOutDto.images = orderProductDetailDto.mainImageUrl;
    }

    userOrderBuyOutDto = userOrderBuyOutDto
      ? JSON.stringify(userOrderBuyOutDto)
      : "";
    // 0:只展示买断详情，1：买断
    let sign = userOrderBuyOutDto ? 0 : 1;
    Taro.navigateTo({
      url: `/pages/buyOutOrder/index?orderId=${orderId}&sign=${sign}&userOrderBuyOutDto=${userOrderBuyOutDto}`,
    });
  };
  onPushIdcard = () => {
    Taro.navigateTo({ url: `/pages/Certificates/index?idcard=2` });
  };
  onFacecertification = () => {
    const { dispatch } = this.props;
    const { orderId } = this.$router.params;
    dispatch({
      type: "confirmOrder/faceRecognition",
      payload: {
        orderId: orderId,
        uid:getUid(),
      },
      callback: (data) => {
        startAPVerify(
          {
            certifyId: data.certifyId,
            url: data.faceUrl,
          },
          function(verifyResult) {
            // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
            if (verifyResult.resultStatus === "9000") {
              // 验证成功，接入方在此处处理后续的业务逻辑
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                },
              });
               Request({
                    url:"hzsx/api/order/hasOrderUsing",
                    method:'GET',
                    data:{
                      uid:getUid(),
                      channelId:getGloble('channelId'),
                    }
                  }).then(res=>{
                    if(res.data.data===true){
                      my.call('verifyIdentity', {
                        action: 'getEnvData', 
                      }, function (result) {
                        console.log(result.actionResult);
                        const actionResult = result.actionResult
                        if(actionResult){
                          Request({
                            url:'hzsx/api/components/riskRuning',
                            method:'POST',
                            data:{
                              uid:getUid(),
                              channelId:getGloble('channelId'),
                              orderId: orderId,
                              bizRequestParams:actionResult,
                              userId:getBuyerId(),
                            }
                          }).then(res=>{
                            const verifyId = res.data.data.verifyId;
                            const bizId = res.data.data.bizId;
                            my.call('verifyIdentity', {
                              verifyId: verifyId,
                              user_id:getBuyerId(),
                            }, function (result) {
                              console.log(result.code);
                              console.log(result.verifyId);
                              Request({
                                url:'hzsx/api/components/runingReceive',
                                method:'POST',
                                data:{
                                  bizId,
                                  code:result.code,
                                }
                              }).then(res=>{
                              })
                            });
                          })
                        }
                      });
                    }
                  })
            } else {
              dispatch({
                type: "authentication/aliFaceAuthSync",
                payload: {
                  certifyId:data.certifyId,
                  passed: false,
                },
              });
            }
            // 用户主动取消认证
            if (verifyResult.resultStatus === "6001") {
              // 可做下 toast 弱提示m
              Taro.showToast({
                title: "取消认证成功",
              });
            }
            if (verifyResult.result) {
            }
            // 其他结果状态码判断和处理 ...
          }
        );
      },
    });
  };

  // 去评论
  toComment() {
    const { orderId } = this.$router.params;

    Taro.navigateTo({
      url:
        "/pages/commentOn/index?orderId=" +
        orderId +
        "&from=orderDetail" +
        "&type=type",
    });
  }
  // 续租
  buyAgain(productId, type, skuId) {
    const { orderId } = this.$router.params;
    // type:buyAgain(再次下单)，continue（续租）
    Taro.navigateTo({
      url:
        "/pages/productDetail/index?itemId=" +
        productId +
        "&buyType=" +
        type +
        "&skuId=" +
        skuId +
        "&orderId=" +
        orderId,
    });
  }

  // 修改地址
  changeAddress(orderId, type) {
    Taro.navigateTo({
      url:
        "/pages/address/index?orderId=" +
        orderId +
        "&pages=orderDetail" +
        "&type2=" +
        type +
        "&typess=购买",
    });
  }

  render() {
    const {
      cancelOrderDisplay,
      receiveDoodsDisplay,
      modifySettlementDisplay,
      countDownStr,
      showServicePhone,
      position,
      show,
      showMask,
      cancelOrderList,
      canCel,
      isTagOpened,
      purchaseData,
    } = this.state;
    const {
      userOrderCashesDto,
      userOrderBuyOutDto,
      orderByStagesDtoList,
      orderProductDetailDto,
      shopDto,
      orderAddressDto,
      userOrdersDto,
      idAuthStatus,
      reletOrders,
      buyOrder,
      loading,
      sysConfigValue,
      status,
      restBuyOutPrice,
    } = this.props;
    const createTiemStr =
      userOrdersDto &&
      userOrdersDto.createTime &&
      formatDate(new Date(userOrdersDto.createTimeStr), "yyyy年MM月dd日 hh:mm");
    const rentStartStr =
      userOrdersDto &&
      userOrdersDto.rentStart &&
      formatDate(new Date(userOrdersDto.rentStartStr), "yyyy年MM月dd日");
    const unrentTimeStr =
      userOrdersDto &&
      userOrdersDto.unrentTime &&
      formatDate(new Date(userOrdersDto.unrentTimeStr), "yyyy年MM月dd日");
    const rentStartStrs = formatDate(
      new Date(userOrdersDto.unrentTimeStr),
      "yyyy-MM-dd hh:mm"
    );
    const newTime = formatDate(new Date(), "yyyy-MM-dd hh:mm");
    const letTime = formatDate(
      new Date(userOrdersDto.createTimeStr),
      "yyyy-MM-dd hh:mm"
    );
    let dueTime =
      transdate(rentStartStrs) + 24 * 60 * 60 * 1000 - transdate(newTime);
    let dueTimeS =
      transdate(letTime) + sysConfigValue * 60 * 60 * 1000 - transdate(newTime);
    let dueTimeMs = dueTimeS / 1000;
    let customerServiceTel = getServicePhone();
    //
    const orderStatusInfo = (str, subStr) => {
      const orderStatus = {
        "01": "待支付",
        "02": "待发货", //'支付中',
        "03": "已支付申请关单",
        "04": "待发货",
        "05": "待确认收货",
        "06": "租用中",
        "07": "待结算",
        "08": "结算待支付",
        "09": "订单完成",
        "10": "交易关闭",
      };
      // let title = orderStatus[str];
      // if (subStr === 'USER_APPLICATION_CHANGE_SETTLEMENT') {
      //   title = '待商家修改结算单'
      // }
      return orderStatus[str];
    };
    const yqType = ["确认归还", "其他", "不退租"];
    let waitTotalPay =
      userOrderCashesDto.damagePrice + userOrderCashesDto.lostPrice;
    if (
      userOrderCashesDto.userViolationRecords &&
      userOrderCashesDto.userViolationRecords.length
    ) {
      userOrderCashesDto.userViolationRecords.forEach((info) => {
        waitTotalPay += info.amount;
      });
    }

    // 已支付总金额
    let totalPay = 0;
    if (orderByStagesDtoList && orderByStagesDtoList.length) {
      orderByStagesDtoList.map((payItem) => {
        if (payItem.status === "2" || payItem.status === "3") {
          totalPay += payItem.currentPeriodsRent;
        }
      });
    }

    // 待支付倒计时
    if (purchaseData.state === "WAITING_FOR_PAY" && !countDownStr) {
      this.countDown();
    }

    const states = {
      WAITING_FOR_PAY: "待支付",
      CANCEL: "已取消",
      WAITING_FOR_DELIVERY: "待发货",
      WAITING_RECEIVE: "待收货",
      FINISH: "已完成",
    };
    const stateCentont = {
      WAITING_FOR_PAY: `订单${countDownStr}后将自动取消，请尽快支付`,
      CANCEL: "订单已取消，期待下次为您服务",
      WAITING_FOR_DELIVERY: "已付款，等待商家发货",
      WAITING_RECEIVE: `剩余${purchaseData.receiptLeftDay}天订单将自动确认收货`,
      FINISH: "您的订单已完成",
    };
    // const stateImg = {
    //   WAITING_FOR_PAY: `https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/WAITING_PAYMENT.png`,
    //   CANCEL:
    //     "https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/FINISH.png",
    //   WAITING_FOR_DELIVERY:
    //     "https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/PENDING_DEAL.png",
    //   WAITING_RECEIVE:
    //     "https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/WAITING_USER_RECEIVE_CONFIRM.png",
    //   FINISH:
    //     "https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/FINISH.png",
    // };
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    const { type, imgUrl, productName, skuTitle } = this.$router.params;
    return (
      <View className="orderDetail-page">
        <View className="order-status">
          <View>
            <View className="status">
              <View className="text">{states[purchaseData.state]}</View>
            </View>

            <View className="sub-text">{stateCentont[purchaseData.state]}</View>
          </View>
          <View>
            <Image
              mode="aspectFill"
              className="status-icon"
              // src={stateImg[purchaseData.state]}
              src={`https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1af5be6776da4c7dbab1ea609d5b7529.png`}
            />
          </View>
        </View>
        <View className="content-area">
          {purchaseData &&
          purchaseData.addressDto &&
          purchaseData.addressDto.realname &&
          purchaseData.addressDto.telephone ? (
            <View className="address-area">
              <View className="contact-num">
                <Image
                  mode="aspectFill"
                  className="address-icon"
                  src={`https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ef63ee11a5144f0e87404341c9097783.png`}
                />
                <Text className="name">{purchaseData.addressDto.realname}</Text>
                <Text>{purchaseData.addressDto.telephone}</Text>
              </View>
              <View className="content">
                <View>
                  {purchaseData.addressDto.provinceStr}
                  {purchaseData.addressDto.cityStr}
                  {purchaseData.addressDto.areaStr}
                  {purchaseData.addressDto.street}
                </View>
              </View>

              <View
                className="see-wuliu"
                onClick={() =>
                  this.handleCancelExpress(purchaseData.addressDto.orderId)
                }
              >
                查询物流
              </View>
              <Image
                className="line-img"
                mode="scaleToFill"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/a0a6ef3f2736494485d9dc4962686bc0.png"
              />
            </View>
          ) : (
            ""
          )}
          <View className="goods-area">
            <View className="goods-info">
              <Image
                className="img"
                onClick={this.goProductDetails.bind(
                  this,
                  purchaseData.productId
                )}
                mode="aspectFit"
                src={purchaseData.productImage}
              />
              <View className="goods">
                <View className="title">{purchaseData.productName}</View>
                <View className="spec">
                  规格：
                  {purchaseData.skuInfo}
                </View>
                <View className="rent">
                  合计
                  <Text className="price">￥{purchaseData.totalAmount}</Text>
                </View>
              </View>
            </View>
          </View>
          <View className="price-area">
            <View className="black-info margin-bottom-36">
              <View className="left-text">合计</View>
              <View className="right-text">￥{purchaseData.totalAmount}</View>
            </View>
            <View className="gray-info margin-bottom-37">
              <View className="left-text">优惠券</View>
              <View className="right-text">-￥{purchaseData.couponAmount}</View>
            </View>
            <View className="black-info margin-bottom-36">
              <View className="left-text">运费</View>
              <View className="right-text">{purchaseData.freightStr}</View>
            </View>
            <View className="black-info margin-bottom-36">
              <View className="left-text">实际付款</View>
              <View className="right-text">￥{purchaseData.totalAmount}</View>
            </View>
          </View>
          <View className="order-info">
            <View className="gray-info margin-bottom-30">
              <View className="left-text">订单编号</View>
              <View className="right-text">{purchaseData.orderId}</View>
            </View>
            <View className="gray-info margin-bottom-30">
              <View className="left-text">下单时间</View>
              <View className="right-text">{purchaseData.createTime}</View>
            </View>
            <View className="gray-info">
              <View className="left-text">订单备注</View>
              <View className="right-text">{purchaseData.remark}</View>
            </View>
          </View>
        </View>
        <View className="bottom-space" />

        {purchaseData.state === "WAITING_FOR_PAY" ? (
          <View className="end-banner">
            <View>
              <popover
                className="popover"
                position={position}
                show={show2}
                showMask={showMask}
                onMaskClick={this.onMaskClick2}
              >
                <View onClick={this.onShowPopoverTap2}>
                  <View className="" style={{ marginRight: "10px" }}>
                    <Image
                      mode="aspectFit"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c2d7f0c25a8c4cfd83b5a19409587600.png"
                      style={{ width: "25px", height: "25px" }}
                    />
                  </View>
                </View>
                <View slot="items">
                  <popover-item onItemClick={this.handleService}>
                    <Text>联系客服</Text>
                  </popover-item>
                  <popover-item
                    onItemClick={() =>
                      this.handleClickCancelOrder(userOrdersDto.orderId)
                    }
                  >
                    <Text>取消订单</Text>
                  </popover-item>
                </View>
              </popover>
            </View>
            <View style={{ display: "flex" }}>
              <View
                className="button-bar"
                onClick={() => this.changeAddress(purchaseData.orderId)}
              >
                修改地址
              </View>
              <View
                className="button-bar-active"
                onClick={this.onClickFrezzAgain}
              >
                去支付
              </View>
            </View>
          </View>
        ) : null}

        {purchaseData.state === "WAITING_FOR_DELIVERY" ? (
          <View className="end-banner">
            <View></View>
            <View style={{ display: "flex" }}>
              <View className="button-bar" onClick={this.handleService}>
                联系客服
              </View>
              <View
                className="button-bar"
                onClick={this.handleClickCancelOrder}
              >
                取消订单
              </View>
              <View
                className="button-bar"
                onClick={() => this.changeAddress(purchaseData.orderId)}
              >
                修改地址
              </View>
            </View>
          </View>
        ) : null}
        {purchaseData.state === "WAITING_RECEIVE" ? (
          <View className="end-banner">
            <View></View>
            <View style={{ display: "flex" }}>
              <View className="button-bar" onClick={this.handleService}>
                联系客服
              </View>
              <View
                className="button-bar"
                onClick={this.onClickReceiveGoods}
                style={{
                  color: "#c43737",
                  border: "1px solid #c43737",
                }}
              >
                确认收货
              </View>
            </View>
          </View>
        ) : null}
        {purchaseData.state === "FINISH" ? (
          <View className="end-banner">
            <View></View>
            <View style={{ display: "flex" }}>
              <View className="button-bar" onClick={this.handleService}>
                联系客服
              </View>
              {!purchaseData.hasEvaluation && (
                <View
                  className="button-bar"
                  onClick={() =>
                    Taro.navigateTo({
                      url:
                        "/pages/commentOn/index?orderId=" +
                        this.$router.params.orderId +
                        "&from=orderList" +
                        "&type=type",
                    })
                  }
                >
                  评论
                </View>
              )}

              <View
                className="button-bar"
                onClick={() =>
                  Taro.navigateTo({
                    url: `/pages/productDetail/index?itemId=${purchaseData.productId}&source=02&type=DIRECT`,
                  })
                }
                style={{
                  color: "#c43737",
                  border: "1px solid #c43737",
                }}
              >
                再次下单
              </View>
            </View>
          </View>
        ) : null}

        <CancelOrder
          display={cancelOrderDisplay}
          onCancal={this.handleModalCancel}
          onOk={this.handleModalOk}
          cancelOrderList={cancelOrderList}
        />
        <AtModal isOpened={receiveDoodsDisplay}>
          <AtModalHeader>确认收货？</AtModalHeader>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>确认已收到商品</View>
          </AtModalContent>
          <AtModalAction>
            <Button onClick={this.handleCancalGoods}>取消</Button>
            <Button
              onClick={this.handleOkGoods.bind(this, userOrdersDto.orderId)}
            >
              确定
            </Button>
          </AtModalAction>
        </AtModal>
        <AtModal isOpened={modifySettlementDisplay}>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>
              是否申请商家修改结算单？
            </View>
          </AtModalContent>
          <AtModalAction>
            <Button onClick={this.handleCancelModifySettlement}>再想想</Button>
            <Button
              onClick={this.handleOkModifySettlement.bind(
                this,
                userOrdersDto.orderId
              )}
            >
              确认申请
            </Button>
          </AtModalAction>
        </AtModal>
        <modal
          show={showServicePhone}
          showClose={false}
          onModalClick={this.onClosePhoneModal}
          onModalClose={this.onClosePhoneModal}
        >
          <View slot="header">联系客服</View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            商家客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectServices.bind(this, shopDto.serviceTel)}
            >
              {shopDto.serviceTel}
            </Text>
          </View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            平台客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectServices.bind(this, customerServiceTel)}
            >
              {customerServiceTel}
            </Text>
          </View>
          <View style={{ textAlign: "left", paddingLeft: "15px" }}>
            工作时间：<Text style={{ color: "#777" }}>10:30 - 19:30</Text>
          </View>
          <View slot="footer">取消拨打</View>
        </modal>
        <modal
          show={canCel}
          // showClose={false}
          onModalClick={this.oncanCelModal}
          onModalClose={this.oncanCelModal}
          advice={true}
        >
          <View className="cancel-modal">
            <View slot="header" className="header">
              温馨提示·
            </View>
            <View className="content">
              退款处理中，预计24小时内操作完成，请耐心等待；
              如需加急处理，可联系客服：
              <Text
                style={{ color: "#51A0F9" }}
                onClick={this.connectServices.bind(this, customerServiceTel)}
              >
                {customerServiceTel}
              </Text>
            </View>
          </View>
        </modal>
        <TagPage
          // handleCallService={this.handleCallService}
          onClose={this.handleClose}
          isOpened={isTagOpened}
          data={shopDto && shopDto.serviceTel}
        />
      </View>
    );
  }
}

export default Orderdetail;
