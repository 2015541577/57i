import Taro from '@tarojs/taro';
import * as orderDetailApi from './service';
import { tradePay } from '../../utils/openApi';
import { getBuyerId, getUid, getGloble } from '../../utils/localStorage'
import * as orderListApi from '../orderList/service'
import { getGlobalData } from '../../utils/globalVariable'

export default {
  namespace: 'orderDetail',
  state: {
    userOrderCashesDto: {},
    orderProductDetailDto: {},
    orderAddressDto: {},
    userOrdersDto: {},
    shopDto: {}
  },

  effects: {
    // 获取用户订单详情
    *selectUserOrderDetail({ payload }, { call, put }) {
      let res = yield call(orderDetailApi.selectUserOrderDetail, payload);
      res = res.data
      if (res) {
        yield put({
          type: 'saveOrder',
          payload: res.data,
        });
      }
    },
    // 取消订单
    *userCancelOrder({ payload, callback }, { call, put }) {
      const api = (payload.status === '04' || payload.status === '02') ? orderDetailApi.payedCloseOrder : orderDetailApi.userCancelOrder
      let res = yield call(api, payload);
      res = res.data
      if (res.responseType === 'SUCCESS') {
        const nextStatus = '10';
        yield put({
          type: 'setOrderStatus',
          payload: nextStatus,
        });
        yield put({
          type: 'orderList/setOrderStatus',
          payload: {
            orderId: payload.orderId,
            status: '10',
          },
        });
        if (callback) {
          callback();
        }
      }else{
        res.errorMessage && Taro.showToast({
          title:res.errorMessage,
          icon:'none'
        })
      }
    },
    // 取消订单
    *userCancelOrderSendMsg({ payload, callback }, { call, put }) {
      const res = yield call(orderDetailApi.userCancelOrderSendMsg, payload)
      if (res) {
        if( res.code === 1){
          Taro.showToast({
            title:'取消成功',
            icon:'none'
          })
        }
        if (callback) {
          callback();
        }
      }
    },
    // 再次支付
    * userFrezzAgain({ payload }, { call, put }) {
      let res = yield call(orderDetailApi.userFrezzAgain, payload);
      res = res.data
      if (res && res.responseType === "SUCCESS") {
        try {
          const payres = yield tradePay('orderStr', res.data.freezeAgainUrl, 'Freeze', res.data.serialNo);
          if (payres.resultCode !== '9000') {
            Taro.showToast({
              title: '支付失败',
              icon: 'none',
            });
          } else {
            const nextStatus = '04';
            yield put({
              type: 'setOrderStatus',
              payload: nextStatus,
            });
            yield put({
              type: 'orderList/setOrderStatus',
              payload: {
                orderId: payload.orderId,
                status: '04',
              },
            });
          }
        } catch (e) {
          Taro.showToast({
            title: '支付失败，请重试或联系客服',
            icon: 'none',
          });
        }
      }
      else {
        Taro.showToast({
          title:`该笔订单为星动租订单，请前往星动租去支付`,
          icon:'none'
        })
      }
    },
    // 再次支付-续租
    * payReletAgain({ payload ,callback}, { call, put }) {
      const res = yield call(orderDetailApi.payReletAgain, {...payload,uid:getUid()});
      if (res) {
        try {
          const payres = yield tradePay('tradeNO', res.data);
          let type = 'suc';
          if (payres.resultCode !== '9000') {
            Taro.showToast({
              // title: payres.memo,
              title: '支付失败',
              icon: 'none',
            });
            type = 'error'
          }
          callback(type)
        } catch (e) {
          Taro.showToast({
            title: '支付失败，请重试或联系客服',
            icon: 'none',
          });
        }
      }
    },
    // 买断-支付
    * payBuyOutAgain({ payload }, { call, put }) {
      const res = yield call(orderDetailApi.payBuyOutAgain, {...payload,uid:getUid()});
      if (res) {
        try {
          const payres = yield tradePay('tradeNO', res.data);
          if (payres.resultCode !== '9000') {
            Taro.showToast({
              title:'支付失败',
              icon: 'none',
            });
          } else {
            yield put({
              type: 'orderDetail/selectUserOrderDetail',
              payload: {
                orderId: payload.orderId,
              },
            });
            const nextStatus = '01';
            yield put({
              type: 'setOrderStatus',
              payload: nextStatus,
            });
            yield put({
              type: 'orderList/setOrderStatus',
              payload: {
                orderId: payload.orderId,
                status: '01',
              },
            });
          }
        } catch (e) {
          Taro.showToast({
            title: '支付失败，请重试或联系客服',
            icon: 'none',
          });
        }
      }
    },
    // 获取系统参数
    * getSysConfigByKey({ payload }, { call, put }) {
      const res = yield call(orderListApi.getSysConfigByKey, { ...payload });
      if (res) {
        yield put({
          type: 'sysConfigValue',
          payload: res.data.sysConfigValue,

        });
      }
    },
    // 确认收货
    * userConfirmReceipt({ payload }, { call, put }) {
      const res = yield call(orderDetailApi.userConfirmReceipt, payload)
      if (res.data.responseType==="SUCCESS") {
        const nextStatus = '06';
        yield put({
          type: 'setOrderStatus',
          payload: nextStatus,
        });
        yield put({
          type: 'orderList/setOrderStatus',
          payload: {
            orderId: payload.orderId,
            status: '06',
          },
        });
      }
    },

    // 用户申请修改结算单
    * userApplicationForAmendmentOfSettlementForm({ payload }, { call, put }) {
      let res = yield call(orderDetailApi.userApplicationForAmendmentOfSettlementForm, payload);
      res = res.data
      if (res.responseType === 'SUCCESS') {
        const subStatus = 'USER_APPLICATION_CHANGE_SETTLEMENT';
        yield put({
          type: 'setOrderSubStatus',
          payload: subStatus,
        });

        const nextStatus = '07';
        yield put({
          type: 'setOrderStatus',
          payload: nextStatus,
        });
        yield put({
          type: 'orderList/setOrderStatus',
          payload: {
            orderId: payload.orderId,
            status: '07',
          },
        });
      }
    },

    // 结算单确认支付
    * confirmOrderSettlement({ payload }, { call, put }) {
      let res = yield call(orderDetailApi.confirmOrderSettlement, { ...payload, buyerId: getBuyerId() });
      res = res.data
      if (res && res.responseType === 'SUCCESS') {
        try {
          const payres = yield tradePay('orderStr', res.data.payUrl, 'TradeAppPay', res.data.serialNo)
          if (payres.resultCode !== '9000') {
            Taro.showToast({
              // title: payres.memo,
              title: '支付失败',
              icon: 'none',
            });
            return
          }

          const nextStatus = '09';
          yield put({
            type: 'setOrderStatus',
            payload: nextStatus,
          });
          yield put({
            type: 'orderList/setOrderStatus',
            payload: {
              orderId: payload.orderId,
              status: '09',
            },
          });
        } catch (e) {
          Taro.showToast({
            title: '支付失败，请重试或联系客服',
            icon: 'none',
          });
        }
      } else {
        if (res) {
          res.msg && Taro.showToast({
            title:res.msg,
            icon:'none'
          })
          const nextStatus = '09';
          yield put({
            type: 'setOrderStatus',
            payload: nextStatus,
          });
        }
      }
    },
  },

  reducers: {
    saveOrder(state, { payload }) {
      return  payload ;
    },
    sysConfigValue(state, { payload }) {
      return {
        ...state,
        sysConfigValue:payload
      };
    },
    setOrderStatus(state, { payload }) {
      return {
        ...state,
        userOrdersDto: {
          ...state.userOrdersDto,
          status: payload,
        },
      };
    },
    setOrderSubStatus(state, { payload }) {
      return {
        ...state,
        userOrdersDto: {
          ...state.userOrdersDto,
          subStatus: payload,
        },
      };
    },
  },

};
