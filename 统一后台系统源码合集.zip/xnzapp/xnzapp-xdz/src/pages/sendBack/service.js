import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const expressList = () => Request({
  url: 'hzsx/aliPay/platformExpress/selectExpressList',
  method: 'GET',
});

export const getOrderGiveBackAddress = data => Request({
  url: 'hzsx/api/order/giveBack/queryOrderGiveBackAddress',
  method: 'POST',
  data,
});

export const userOrderBackSubmitConfirm = data => Request({
  url: 'hzsx/api/order/giveBack/userOrderBackSubmitConfirm',
  method: 'POST',
  data,
});