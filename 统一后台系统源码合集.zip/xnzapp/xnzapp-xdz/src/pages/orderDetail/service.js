import Request from "../../utils/request";

export const demo = (data) => {
  return Request({
    url: "路径",
    method: "POST",
    data,
  });
};

export const selectUserOrderDetail = (data) =>
  Request({
    url: "hzsx/api/order/selectUserOrderDetail",
    method: "POST",
    data,
  });
export const userOrdersPurchaseDetail = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/detail",
    method: "GET",
    data,
  });
export const payedCloseOrder = (data) =>
  Request({
    url: "hzsx/api/order/payedCloseOrder",
    method: "POST",
    data,
  });
// export const userCancelOrder = (data) =>
//   Request({
//     url: "hzsx/api/order/userCancelOrder",
//     method: "POST",
//     data,
//   });
export const userCancelOrder = (data) =>
  Request({
    url: 'hzsx/api/order/setUserOrderStatus',
    method: "POST",
    data,
  });
  // export const userCancelOrder = (data) =>
  // Request({
  //   url: `hzsx/api/order/setUserOrderStatus?order_id=${data.order_id}&status=${data.status}&reson=${data.reson}`,
  //   method: "get"
  // });

export const userCancelOrderSendMsg = (data) =>
  Request({
    url: "hzsx/api/order/userCancelOrderSendMsg",
    method: "POST",
    data,
  });

export const userFrezzAgain = (data) =>
  Request({
    url: "hzsx/api/order/userFreezeAgain",
    method: "POST",
    data,
    test: "userFrezzAgain",
  });

export const userConfirmReceipt = (data) =>
  Request({
    url: "hzsx/api/order/userConfirmReceipt",
    method: "POST",
    data,
  });
//续租展示页面查询
export const userOrderReletPage = (data) =>
  Request({
    url: "hzsx/api/orderRelet/userOrderReletPage",
    method: "POST",
    data,
  });

export const userApplicationForAmendmentOfSettlementForm = (data) =>
  Request({
    url: "hzsx/api/order/settlement/userModifySettlementApply",
    method: "POST",
    data,
  });

export const userAlipayTradePay = (data) =>
  Request({
    url: "hzsx/api/order/userAlipayTradePay",
    method: "GET",
    data,
  });

export const confirmOrderSettlement = (data) =>
  Request({
    url: "hzsx/api/order/settlement/userPaySettlement",
    method: "POST",
    data,
  });
export const payReletAgain = (data) =>
  Request({
    url: "hzsx/api/order/payReletAgain",
    method: "GET",
    data,
  });
export const payBuyOutAgain = (data) =>
  Request({
    url: "hzsx/api/order/payBuyOutAgain",
    method: "GET",
    data,
  });
