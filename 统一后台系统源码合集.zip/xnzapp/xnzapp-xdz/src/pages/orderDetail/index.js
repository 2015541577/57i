import Taro, { Component, Fragment } from "@tarojs/taro";
import { View, Text, Image, Button, Input } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import {
  AtIcon,
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
  AtFloatLayout,
} from "taro-ui";

import {
  formatDate,
  leftTimer,
  leftTimerMS_C,
  transdate,
  addDate,
  debounce,
  getSignUrl,
} from "../../utils/utils";
//import { orderStatus } from '../../assets/Constant';
import CancelOrder from "../../components/cancelOrder";
import "./index.scss";
import { getServicePhone, getGloble, getBuyerId, getUid, getAvatar } from '../../utils/localStorage';
// import { getServicePhone, getGloble, getUid } from "../../utils/localStorage";
import TagPage from "../../components/service";
import { startAPVerify } from "../../utils/openApi";
import umUploadHandler from "../../utils/umengUploadData";
import Request from '../../utils/request';
const esignPlugin = requirePlugin("esign");

@connect(({ orderDetail, loading, confirmOrder, authentication }) => ({
  ...orderDetail,
  ...confirmOrder,
  ...authentication,
  loading: loading.models.orderDetail,
}))
class Orderdetail extends Component {
  config = {
    navigationBarTitleText: "订单详情页",
    usingComponents: {
      "am-icon": "../../npm/mini-antui/es/am-icon/index",
      popover: "../../npm/mini-antui/es/popover/index",
      "popover-item": "../../npm/mini-antui/es/popover/popover-item/index",
      modal: "../../npm/mini-antui/es/modal/index",
    },
  };

  state = {
      isRelet:null,
      isOpendRelet:false,
    cancelOrderDisplay: false, //取消订单模块显示
    receiveDoodsDisplay: false, // 确认收货模块显示
    modifySettlementDisplay: false, // 确认修改结算单模块显示
    showServicePhone: false, //model客服
    position: "topLeft",
    show: false,
    show2: false,
    show3: false,
    showMask: true,
    canCel: false,
    examineStatus: null,
    statusCancel: null,
    cancelOrderList: [
      {
        value: "想要重新下单",
      },
      {
        value: "商品价格较贵",
      },
      {
        value: "等待时机较长",
      },
      {
        value: "是想了解流程",
      },
      {
        value: "不想要了",
      },
    ],
    isTagOpened: false,
    statusObj: {
      "01": "WAITING_PAYMENT",
      "02": "PENDING_DEAL", //'PAYING',
      "03": "PAYED_USER_APPLY_CLOSE",
      "04": "PENDING_DEAL",
      "05": "WAITING_USER_RECEIVE_CONFIRM",
      "06": "RENTING",
      "07": "WAITING_SETTLEMENT",
      "08": "WAITING_SETTLEMENT_PAYMENT",
      "09": "FINISH",
      "10": "CLOSED",
    },
    isOpenedVis: false,
    data: {},
    reletCyclePricesDtoList: [],
    totalPrice: 1,
    days: "",
    price: "",
     orderByStagesDtoList:[],
     showCoupons:false,
    showOnPayment:false, //选择支付方式弹框 预授权&蚂蚁代扣
    payment_id:1,
    showHint:false, //信用评估中弹窗
    newCountDownStr:null, //倒计时
    showRemind:false, //提示弹窗
    newOrderId:null, //储存订单号
     signedPdf:null,
     orderContractTwo:{},
     creditStatus:false,
    faceAuthStatus:null, // 储存订单是否人脸状态
  };
  // 获取倒计时
  newCountDown = () => {
    console.log("进入倒计时！！！")
    let seconds = 8; // 设定倒计时秒数
    const timer = setInterval(() => {
      this.setState({ newCountDownStr: seconds });
      console.log(seconds); // 输出剩余秒数
      seconds--; // 剩余秒数减少1
      if (seconds < 0) { // 如果剩余秒数小于0，清除定时器
        clearInterval(timer);
        console.log("倒计时结束！");
      }
    }, 1000); // 设置定时器每秒执行一次
  };
  componentDidShow = () => {
    this.setState({
      isOpenedVis:false,
    })
    const { orderId } = this.$router.params;
    const { dispatch, userOrdersDto } = this.props;

    dispatch({
      type: "orderDetail/selectUserOrderDetail",
      payload: { orderId },
      callback: (res) => {
          this.setState({
              isRelet:res.data.isRelet,
               orderByStagesDtoList:res.data.orderByStagesDtoList,
                orderContractTwo:res.data.orderContractTwo,
               creditStatus:res.data.creditStatus,
          })
        if (res.data.userOrdersDto.showReletButton) {
          dispatch({
            type: "orderDetail/userOrderReletPage",
            payload: {
              orderId,
            },
            callback: (res) => {
              let reletCyclePricesDtoList = res.reletCyclePricesDtoList;
              for (let i = 0; i < reletCyclePricesDtoList.length; i++) {
                if (i === 0) {
                  reletCyclePricesDtoList[i].kz = true;
                } else {
                  reletCyclePricesDtoList[i].kz = false;
                }
              }
              this.setState({
                data: res,
                reletCyclePricesDtoList,
                price: reletCyclePricesDtoList[0].price,
                days: reletCyclePricesDtoList[0].days,
                totalPrice: reletCyclePricesDtoList[0].totalPrice,
              });
            },
          });
        }
      },
    });
    dispatch({
      type: "orderDetail/getSysConfigByKey",
      payload: {
        configKey: "USER_CANCEL_ORDER:HOUR",
      },
    });

    // userOrderReletPage
     // 通过插件js接口获取签署状态
     const {
      code,
      message,
    } = esignPlugin.getSignStatusInfo();
    console.log('code1111111', code)
    console.log('message222222222', message)
  };

  handleCancel = () => {
    this.setState({ cancelOrderDisplay: true });
  };

  handleModalCancel = () => {
    this.setState({ cancelOrderDisplay: false });
  };

  onClickReceiveGoods = () => {
    this.setState({ receiveDoodsDisplay: true });
  };

  handleCancalGoods = () => {
    this.setState({ receiveDoodsDisplay: false });
  };

  handleOkGoods = (orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/userConfirmReceipt",
      payload: { orderId },
    });
    this.setState({ receiveDoodsDisplay: false });
  };

  onClickFrezzAgain = (order) => {
    const { dispatch } = this.props;
    if (order.type === 2) {
      dispatch({
        type: "orderDetail/payReletAgain",
        payload: {
          orderId: order.orderId,
        },
      });
    } else if (order.type === 3) {
      dispatch({
        type: "orderDetail/payBuyOutAgain",
        payload: {
          orderId: order.orderId,
        },
      });
    } else {
      // 这里是走预授权的方法
      this.setState({
        showOnPayment: true,
        newOrderId:order.orderId,
        faceAuthStatus:order.faceAuthStatus,
      })
      // dispatch({
      //   type: "orderDetail/userFrezzAgain",
      //   payload: {
      //     orderId: order.orderId,
      //   },
      //    callback:res=>{
      //     dispatch({
      //       type: "orderList/fetchUserOrderList",
      //       payload: {
      //         overDueQueryFlag: false,
      //         pageNumber: 1,
      //         pageSize: 10,
      //       },
      //     });
      //   }
      // });
    }
  };

  onClickBillDetail = () => {
    const { userOrdersDto, orderProductDetailDto, dispatch } = this.props;
    dispatch({
      type: "billDetail/saveProduct",
      payload: orderProductDetailDto,
    });
    Taro.navigateTo({
      url: `/pages/billDetail/index?orderId=${userOrdersDto.orderId}`,
    });
  };
   
  onClickSendBack = () => {
    const { userOrdersDto, orderProductDetailDto, dispatch } = this.props;
    dispatch({
      type: "sendBack/saveProductAndOrder",
      payload: { product: orderProductDetailDto, userOrdersDto },
    });
    Taro.navigateTo({
      url: `/pages/sendBack/index?orderId=${userOrdersDto.orderId}`,
    });
  };

  onClickModifySettlement = () => {
    this.setState({ modifySettlementDisplay: true });
  };

  handleCancelModifySettlement = () => {
    this.setState({ modifySettlementDisplay: false });
  };

  handleOkModifySettlement = (orderId) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/userApplicationForAmendmentOfSettlementForm",
      payload: { orderId },
    });
    this.setState({ modifySettlementDisplay: false });
  };

  onClickConfirmSettlement = (orderId, waitTotalPay) => {
    const { dispatch } = this.props;
    dispatch({
      type: "orderDetail/confirmOrderSettlement",
      payload: {
        orderId,
        amount: waitTotalPay,
        channelId: getGloble('channelId'),
      },
    });
  };

  handleClickCopy = (orderId) => {
    // eslint-disable-next-line no-undef
    my.setClipboard({
      text: orderId,
      success: () => {
        Taro.showToast({
          title: "订单号复制成功" + orderId,
          icon: "none",
        });
      },
    });
  };
  onMaskClick = () => {
    this.setState({
      show: false,
    });
  };
  onMaskClick2 = () => {
    this.setState({
      show2: false,
    });
  };
  onShowPopoverTap2 = () => {
    this.setState({
      show2: true,
    });
  };
  onMaskClick3 = () => {
    this.setState({
      show3: false,
    });
  };
  onShowPopoverTap3 = () => {
    this.setState({
      show3: true,
    });
  };
  onShowPopoverTap = () => {
    this.setState({
      show: true,
    });
  };
  connectService = () => {
    this.setState({
      showServicePhone: true,
    });
  };

  connectServices = (val) => {
    let num = String(val);
    my.makePhoneCall({ number: val });
  };

  handleHelpDJ = () => {
    // eslint-disable-next-line no-undef
    my.alert({
      content: `您的冻结押金将冻结在您的支付宝或星动租账户中，当订单完结后，押金将立即原路退还予您的支付账户`,
      buttonText: "知道了",
    });
  };

  countDown = () => {
    const {
      userOrdersDto: { createTime, status },
      dispatch,
    } = this.props;
    if (!createTime) {
      setTimeout(this.countDown, 1000);
    } else {
      const cdStr = leftTimerMS_C(createTime.replace(/-/g, "/"));
      if (status === "01" && cdStr) {
        setTimeout(this.countDown, 1000);
        this.setState({ countDownStr: cdStr });
      } else {
      }
    }
  };

  onClosePhoneModal = () => {
    this.setState({ showServicePhone: false });
  };
  goShop = (val) => {
    Taro.navigateTo({
      url: `/pages/shops/index?shopId=${val}`,
    });
  };
  goProductDetails = (val) => {
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${val}`,
    });
  };
  handleCancelExpress = () => {
    const { orderId } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${orderId}`,
    });
  };
  handleClickRenewalBefore = () => {
    const { userOrdersDto } = this.props;
    Taro.navigateTo({
      url: `/pages/express/index?orderId=${userOrdersDto.originalOrderId}`,
    });
  };
  onClickReturn(expressId, expressNo) {
    Taro.navigateTo({
      url: `/pages/express/index?expressId=${expressId}&expressNo=${expressNo}`,
    });
  }
  handleClickCancelOrder = (order) => {
    //
    if (order.examineStatus === 0) {
      this.setState({
        cancelOrderDisplay: true,
        examineStatus: order.examineStatus,
        statusCancel: order.status,
      });
    } else {
      this.setState({
        cancelOrderDisplay: true,
      });
    }
  };
  handleModalOk = (value) => {
    const { dispatch, userOrdersDto } = this.props;
    const { orderId } = this.$router.params;
    const { examineStatus, statusCancel } = this.state;
    //
    if (examineStatus === 0 && statusCancel === "PENDING_DEAL") {
      dispatch({
        type: "orderList/userCancelOrderSendMsg",
        payload: {
          cancelReason: value,
          orderId: userOrdersDto.orderId,
        },
        callback: () => {
          dispatch({
            type: "orderDetail/selectUserOrderDetail",
            payload: {
              orderId: userOrdersDto.orderId,
            },
          });
        },
      });
    } else {
      dispatch({
        type: "orderDetail/userCancelOrder",
        // payload: {
        //   cancelReason: value,
        //   orderId: userOrdersDto.orderId,
        //   status: userOrdersDto.status,
        // },
        payload: {
          reson: value,
          order_id: userOrdersDto.orderId,
          status: "14",
        },
        callback: () => {
          umUploadHandler.cancelOrder(this.state.data);
        },
      });
    }
    this.setState({ cancelOrderDisplay: false });
  };
  handleModalCancel = () => {
    this.setState({ cancelOrderDisplay: false });
  };

  oncanCelModal = () => {
    this.setState({
      canCel: false,
    });
  };

  handleService = () => {
    this.setState({
      isTagOpened: true,
    });
  };

  handleClose = () => {
    this.setState({
      isTagOpened: false,
    });
  };

  gotoProtocol = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;
    Taro.navigateTo({ url: `/pages/webview/xieyi?orderId=${orderId}` })
    // dispatch({
    //   type: "agreement/agreementPlaceorder",
    //   payload: { orderId: orderId },
    //   callback: (res) => {
    //     Taro.navigateTo({ url: `/pages/webview/xieyi?orderId=${orderId}` });
    //   },
    // });
  };
    // 协议的点击事件
  gotoAllAuth = (url) =>{
    const pdfurl = url.replace('http:','https:')
    console.log(pdfurl,'pdfurkekeieiei')
     my.downloadFile({
      // 示例 url，并非真实存在
          url:pdfurl,
          success({ apFilePath }) {
              my.hideLoading();
              my.openDocument({
              filePath: apFilePath,
              fileType: 'pdf',
              success: (res) => {
                  console.log('open document success')
                  }
              })
              }
       })
  }
  //信用授权书
  gotoAuthorization = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;
    Taro.navigateTo({ url: `/pages/webview/credit?orderId=${orderId}` })
    // dispatch({
    //   type: "agreement/agreementPlaceorder",
    //   payload: { orderId: orderId },
    //   callback: (res) => {
    //     Taro.navigateTo({ url: `/pages/webview/xieyi?orderId=${orderId}` });
    //   },
    // });
  };
  onBuyoutorder = (
      type,
      userOrderBuyOutDto,
      userOrderCashesDto,
      orderProductDetailDto
  ) => {
    const { orderId } = this.$router.params;
    if (userOrderBuyOutDto) {
      userOrderBuyOutDto.totalRent = userOrderCashesDto.totalRent;
      userOrderBuyOutDto.skuTitle = orderProductDetailDto.skuTitle;
      userOrderBuyOutDto.images = orderProductDetailDto.mainImageUrl;
    }

    userOrderBuyOutDto = userOrderBuyOutDto
        ? JSON.stringify(userOrderBuyOutDto)
        : "";
    // 0:只展示买断详情，1：买断
    let sign = userOrderBuyOutDto ? 0 : 1;
    Taro.navigateTo({
      url: `/pages/buyOutOrder/index?orderId=${orderId}&sign=${sign}&userOrderBuyOutDto=${userOrderBuyOutDto}`,
    });
  };
  onPushIdcard = () => {
    Taro.navigateTo({ url: `/pages/Certificates/index?idcard=2` });
  };
  onFacecertification = () => {
    const { dispatch } = this.props;
    const { orderId } = this.$router.params;
    dispatch({
      type: "confirmOrder/faceRecognition",
      payload: {
        orderId: orderId,
        uid:getUid()
      },
      callback: (data) => {
        startAPVerify(
            {
              certifyId: data.certifyId,
              url: data.faceUrl,
            },
            function(verifyResult) {
              // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
              if (verifyResult.resultStatus === "9000") {
                  Request({
                      url:"hzsx/api/order/hasOrderUsing",
                      method:'GET',
                      data:{
                        uid:getUid(),
                        channelId:getGloble('channelId'),
                      }
                    }).then(res=>{
                      if(res.data.data===true){
                        my.call('verifyIdentity', {
                          action: 'getEnvData', 
                        }, function (result) {
                          const actionResult = result.actionResult
                          if(actionResult){
                            Request({
                              url:'hzsx/api/components/riskRuning',
                              method:'POST',
                              data:{
                                uid:getUid(),
                                channelId:getGloble('channelId'),
                                orderId: orderId,
                                bizRequestParams:actionResult,
                                userId:getBuyerId(),
                              }
                            }).then(res=>{
                              const verifyId = res.data.data.verifyId;
                              const bizId = res.data.data.bizId;
                              my.call('verifyIdentity', {
                                verifyId: verifyId,
                                user_id:getBuyerId(),
                              }, function (result) {
                                Request({
                                  url:'hzsx/api/components/runingReceive',
                                  method:'POST',
                                  data:{
                                    bizId,
                                    code:result.code,
                                  }
                                }).then(res=>{

                                })
                              });
                            })
                          }
                        });
                      }
                    })
                // 验证成功，接入方在此处处理后续的业务逻辑
                dispatch({
                  type: "authentication/aliFaceAuthSync",
                  payload: {
                    certifyId: data.certifyId,
                    bizId:data.bizId,
                  },
                });
               
              } else {
                dispatch({
                  type: "authentication/aliFaceAuthSync",
                  payload: {
                    certifyId:data.certifyId,
                    passed: false,
                    bizId:data.bizId,
                  },
                });
              }
              // 用户主动取消认证
              if (verifyResult.resultStatus === "6001") {
                // 可做下 toast 弱提示m
                Taro.showToast({
                  title: "取消认证成功",
                });
              }
              if (verifyResult.result) {
              }
              // 其他结果状态码判断和处理 ...
            }
        );
      },
    });
  };
  onDianj = () => {
    // const { totalPrice,
    //   days} = this.st
    // let obj = {
    //   skuId: 42485,
    //   price: 0.01,
    //   originalOrderId: "006OI202011064843761999304605696",
    //   uid: getUid(),
    //   buyType: "continue",
    //   duration: 30,
    // };
    const { price, days, data } = this.state;

    let obj = {
      skuId: data.skuId,
      price: price,
      originalOrderId: data.originalOrderId,
      uid: getUid(),
      buyType: "continue",
      duration: days,
    };

    this.props.dispatch({
      type: "confirmOrder/userConfirmOrder",
      payload: obj,
      callback: (res) => {
        Taro.navigateTo({
          url:
              "/pages/confirmOrder/index?buyType=" +
              "continue" +
              "&originalOrderId=" +
              data.originalOrderId +
              "&type=" +
              "",
        });
      },
    });
  };
  // 去评论
  toComment() {
    const { orderId } = this.$router.params;

    Taro.navigateTo({
      url: "/pages/commentOn/index?orderId=" + orderId + "&from=orderDetail",
    });
  }
  // 续租
  buyAgain(productId, type, skuId) {
    const { orderId } = this.$router.params;
    // type:buyAgain(再次下单)，continue（续租）
    Taro.navigateTo({
      url:
          "/pages/productDetail/index?itemId=" +
          productId +
          "&buyType=" +
          type +
          "&skuId=" +
          skuId +
          "&orderId=" +
          orderId,
    });
  }

  // 修改地址
  changeAddress(orderId, type) {
    Taro.navigateTo({
      url:
          "/pages/address/index?orderId=" +
          orderId +
          "&pages=orderDetail" +
          "&type2=" +
          type,
    });
  }
//   handleCloseVis() {
//     //   这里的是原先的逻辑
//     // this.setState({
//     //   isOpenedVis: true,
//     // });
//     // 现在的逻辑是直接跳到支付账单 去支付续租的钱
   

//   }
    handleRelet = () =>{
        const {isRelet} = this.state
        if(isRelet==1){
            this.setState({
                isOpendRelet:true,
            })
        }else {
         this.handleCloseVis()
        }
    }
    handleCloseVis = () => {
    const { userOrdersDto, orderProductDetailDto, dispatch } = this.props;
   
    const {isRelet} = this.state
    dispatch({
      type: 'billDetail/userAllNewOrderRelet',
      payload: {orderId: userOrdersDto.orderId },
      callback:res=>{
          if(res.data==true){
              Taro.navigateTo({
                url: `/pages/billDetail/index?orderId=${userOrdersDto.orderId}`,
              });
          }
      }
    });
  };
  onSKUPopupClose = () => {
    this.setState({ isOpenedVis: false });
  };
  onTabChange = (val, cycle) => {
    let goodList = this.state.reletCyclePricesDtoList;
    // if (goodList[val]["kz"]) {
    //   goodList[val]["kz"] = false;
    //   this.setState({
    //     totalPrice: "",
    //   });
    // } else {
    let index = goodList.findIndex((item) => item.kz === true);

    if (index !== -1) {
      goodList[index]["kz"] = false;
      // this.setState({
      //   totalPrice: "",
      // });
    }
    goodList[val]["kz"] = true;
    this.setState({
      totalPrice: cycle.totalPrice,
      days: cycle.days,
      price: cycle.price,
    });

    this.setState({ reletCyclePricesDtoList: goodList.slice() });
  };

  handleOkRelet = ()=>{
      this.handleCloseVis()
      this.setState({
          isOpendRelet:false,
      })
  }

  oncanCelModals = () =>{
      this.setState({
          isOpendRelet:false,
      })
  }
  // 去签约
  onClickSign  = (order) => {
    console.log(order,"kkkkkkkkkkkkkkk",order.orderId)
    //进入芝麻代扣流程
    this.newCountDown();
    this.setState({
      showHint:true,
    })
    Request({
      url:'hzsx/api/appZuLinPingTai/zuLinPingTaiUserSgnMainFlow',
      method:'POST',
      data:{
        channel:'006',
        orderId:order.orderId,
      }
    }).then(res=>{
      if(res.data.responseType == "SUCCESS") {
        // 【contractSign=合同签署，withholdSign=代扣签署】
        // 当signType=contractSign合同签署时，就是签署合同用这个zuLinPingTaiContractSignLinkOfRes返回签署合同
        //     当signType=withholdSign代扣签署时，就是签署合同用以下返回签署合同
        // private String myZuLinPingTai_signStr;
        // private String myZuLinPingTai_tenantId_res;
        // private String myZuLinPingTai_merchantId_res;
        // private String myZuLinPingTai_orderId_res;
        if(res.data.data.signType == 'contractSign'){
          if(res.data.data.zuLinPingTaiContractSignLinkOfRes){
            my.navigateTo({
              // url: 'plugin://esign/esign?env=${env}&flowId=${flowId}&signerId=${signerId}&skipResult=${skipResult}&skipGuide=${skipGuide}',
              url: res.data.data.zuLinPingTaiContractSignLinkOfRes,
            })
            this.setState({
              showHint:false,
            })
          }else {
            // 请求失败 跳转到订单列表
            this.setState({
              showHint:false,
            })
            Taro.showToast({
              title: "正在处理，请稍后再次点击！",
              icon: "none",
            });
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          }
        }
        if(res.data.data.signType == 'withholdSign') {
          my.navigateToMiniProgram({
            appId:"2021001152620480", // 区块链合同真实appId
            path:"pages/tripartite/index", // 支付宝商家跳转区块链合同代扣签署地址（真实路径
            query:{
            signStr:res.data.data.myZuLinPingTai_signStr,// 签署代扣必要的字符串参数
            tenantId:res.data.data.myZuLinPingTai_tenantId_res,
            merchantId:res.data.data.myZuLinPingTai_merchantId_res,
            orderId:res.data.data.myZuLinPingTai_orderId_res,
            redirectUrl:'alipays://platformapi/startapp?appId=2021004124697663&page=pages/orderList/index?type=all', // 代扣签署成功/失败回跳地址，示例 alipays://platformapi/startapp?appId=2021004108689505&page=pages/home/index，appId 和 page 需要根据实际情况调整真实数值
          }, // 需要携带的必要参数
          success: () => {
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          },
          fail: () => {
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          },
          });
        }
      }else {
        // 请求失败 跳转到订单列表
        this.setState({
          showHint:false,
        })
        setTimeout(() => {
          Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
        }, 1000)
        if (res.errorMessage) {
          Taro.showToast({
            title: res.errorMessage,
            icon: "none",
          });
        }
      }
    })
  };
  // 取消选择支付方式 预授权&&蚂蚁代扣
  onClosePayment = () => {
    // setTimeout(() => {
    //   Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
    // }, 1000)
    this.setState({
      showOnPayment:false,
    })
  }
  // 选择支付方式提交
  submitPayment = () => {
    const { dispatch } = this.props;
    const then = this;
    this.setState({
      showOnPayment:false,
    })
    // 进入预授权流程
    if( this.state.faceAuthStatus == "01" || this.state.faceAuthStatus == "02" ) {
      console.log("进入人脸！！！！！！！！！！！！！！！！！",then.state.newOrderId)
      dispatch({
        type: "confirmOrder/faceRecognition",
        payload: {
          orderId: this.state.newOrderId,
          uid:getUid()
        },
        callback: (data) => {
          console.log(data,"sssssssssssssssssssssssssss")
          startAPVerify(
            {
              certifyId: data.certifyId,
              url: data.faceUrl,
            },
            function (verifyResult) {
              console.log(verifyResult.result,"看下这是什么参数！！！！！！！！！！",verifyResult,then.state.payment_id)
              // 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
              if (verifyResult.resultStatus === '9000') {
                // 验证成功，接入方在此处处理后续的业务逻辑
                if (
                  verifyResult.result &&
                  verifyResult.result.certifyId
                ) {
                  // 验证成功，接入方在此处处理后续的业务逻辑
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId: verifyResult.result && verifyResult.result.certifyId,
                      bizId:data.bizId,
                    },
                  });
                }
                // 人脸请求成功之后，进行是走预授权还是走代扣判断 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<===================================================
                // 进入预授权流程
                if(then.state.payment_id == 1) {
                  dispatch({
                    type: "orderDetail/userFrezzAgain",
                    payload: {
                      orderId: then.state.newOrderId,
                    },callback: (e) => {
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                    }
                  });
                }else {
                  // 生成代扣订单
                  Request({
                    url:`hzsx/api/appZuLinPingTai/antZuLinPingTaiOrderComfirm?orderId=${this.state.newOrderId}&channel=006`,
                    method:'POST',
                    data:{
                      // channel:'067',
                      // orderId:then.state.newOrderId,
                      // orderId:"031OI202304277521072469482250240",
                    }
                  }).then(res=>{
                    console.log(res,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
                    if(res.data.responseType == "SUCCESS") {
                      Taro.showToast({
                        title: "操作成功，请等待商家审核！",
                      });
                      //跳转下单成功
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                    }else {
                      // 请求失败 跳转到订单列表
                      setTimeout(() => {
                        Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
                      }, 1000)
                      if (res.errorMessage) {
                        Taro.showToast({
                          title: res.errorMessage,
                          icon: "none",
                        });
                      }
                    }
                  })
                }
              } else {
                if (
                    verifyResult.result &&
                    verifyResult.result.certifyId
                ) {
                  // Request({
                  //   url: `hzsx/api/components/faceAuthInitAsync`,
                  //   method: "GET",
                  //   data: {
                  //     certifyId: verifyResult.result && verifyResult.result.certifyId,
                  //   }
                  // }).then(res => {
                  //   console.log("请求成功")
                  // });
                  dispatch({
                    type: "authentication/aliFaceAuthSync",
                    payload: {
                      certifyId:
                        verifyResult.result && verifyResult.result.certifyId,
                        bizId:data.bizId,
                    },
                  });
                }
              }
              // 用户主动取消认证-
              if (verifyResult.resultStatus === '6001') {
                then.setState({
                  showOnPayment:true,
                })
                Taro.showToast({
                  title: '取消认证成功！',
                });
                //取消认证直接返回上一页 预授权时 再调人脸 
                return;
              }
              if (verifyResult.result) {
                // Taro.redirectTo({ url: `/pages/checkSuccess/index?orderId=${orderId}&type=1` });
              }
            },
          );
        },
      });
    }else {
      // 已经人脸的订单进入else
      // 进入预授权流程
      if(this.state.payment_id == 1) {
        dispatch({
          type: "orderDetail/userFrezzAgain",
          payload: {
            orderId: this.state.newOrderId,
          },
        });
      }else {
        // 生成代扣订单
        Request({
          url:`hzsx/api/appZuLinPingTai/antZuLinPingTaiOrderComfirm?orderId=${this.state.newOrderId}&channel=006`,
          method:'POST',
          data:{
            // channel:'067',
            // orderId:then.state.newOrderId,
            // orderId:"031OI202304277521072469482250240",
          }
        }).then(res=>{
          console.log(res,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
          if(res.data.responseType == "SUCCESS") {
            Taro.showToast({
              title: "操作成功，请等待商家审核！",
            });
            //跳转下单成功
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          }else {
            // 请求失败 跳转到订单列表
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
            if (res.errorMessage) {
              Taro.showToast({
                title: res.errorMessage,
                icon: "none",
              });
            }
          }
        })
      }
    }
  }
  // 芝麻代扣跳转方法
  submitRemind = () => {
    if(this.state.longUrl) {
      const { params } = schemeToParams(this.state.longUrl);
      if (this.state.longUrl && params) {
        const { appId, path, query, ...extraData } = params;
        my.navigateToMiniProgram({
          appId,
          path,
          query,
          extraData,
          success: (res) => {
            this.setState({
              showRemind:false
            })
            console.log(JSON.stringify(res),"芝麻代扣合同签署成功！！！！！！")
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          },
          fail: (res) => {
            this.setState({
              showRemind:false
            })
            console.log(JSON.stringify(res),"芝麻代扣合同签署失败。。。。。。")
            setTimeout(() => {
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            }, 1000)
          },
        });
      }
    }else {
      Taro.showToast({
        title: "请返回列表！",
        icon: "none",
      });
    }
  }
  handleChangePayment = (e) =>{
    console.log(e,"jjjjjjjjjjjjjjjjjjj")
    this.setState({
      payment_id:e.detail.value
    })
  }
  render() {
    const {
      cancelOrderDisplay,
      receiveDoodsDisplay,
      modifySettlementDisplay,
      countDownStr,
      showServicePhone,
      position,
      show,
      showMask,
      cancelOrderList,
      canCel,
      isTagOpened,
      isOpenedVis,
      data,
      isOpendRelet,
      orderByStagesDtoList,
      showOnPayment,payment_id,showHint,
      newCountDownStr,
      showRemind,
      orderContractTwo,
      creditStatus,
    } = this.state;
    const {
      userOrderCashesDto,
      userOrderBuyOutDto,
      // orderByStagesDtoList,
      orderProductDetailDto,
      shopDto,
      orderAddressDto,
      userOrdersDto,
      idAuthStatus,
      reletOrders,
      buyOrder,
      loading,
      sysConfigValue,
      status,
      restBuyOutPrice,
    } = this.props;
    const createTiemStr =
        userOrdersDto &&
        userOrdersDto.createTime &&
        formatDate(new Date(userOrdersDto.createTimeStr), "yyyy年MM月dd日 hh:mm");
    const rentStartStr =
        userOrdersDto &&
        userOrdersDto.rentStart &&
        formatDate(new Date(userOrdersDto.rentStartStr), "yyyy年MM月dd日");
    const unrentTimeStr =
        userOrdersDto &&
        userOrdersDto.unrentTime &&
        formatDate(new Date(userOrdersDto.unrentTimeStr), "yyyy年MM月dd日");
    const rentStartStrs = formatDate(
        new Date(userOrdersDto.unrentTimeStr),
        "yyyy-MM-dd hh:mm"
    );
    const newTime = formatDate(new Date(), "yyyy-MM-dd hh:mm");
    const letTime = formatDate(
        new Date(userOrdersDto.createTimeStr),
        "yyyy-MM-dd hh:mm"
    );
    let dueTime =
        transdate(rentStartStrs) + 24 * 60 * 60 * 1000 - transdate(newTime);
    let dueTimeS =
        transdate(letTime) + sysConfigValue * 60 * 60 * 1000 - transdate(newTime);
    let dueTimeMs = dueTimeS / 1000;
    let customerServiceTel = getServicePhone();
    //
    const orderStatusInfo = (str, subStr) => {
      const orderStatus = {
        "01": "待下单",
        "02": "待发货", //'支付中',
        "03": "已支付申请关单",
        "04": "待发货",
        "05": "待确认收货",
        "06": "租用中",
        "07": "待结算",
        "08": "结算待支付",
        "09": "订单完成",
        "10": "交易关闭",
      };
      // let title = orderStatus[str];
      // if (subStr === 'USER_APPLICATION_CHANGE_SETTLEMENT') {
      //   title = '待商家修改结算单'
      // }
      return orderStatus[str];
    };
    const yqType = ["确认归还", "其他", "不退租"];
    let waitTotalPay =
        userOrderCashesDto.damagePrice + userOrderCashesDto.lostPrice;
    if (
        userOrderCashesDto.userViolationRecords &&
        userOrderCashesDto.userViolationRecords.length
    ) {
      userOrderCashesDto.userViolationRecords.forEach((info) => {
        waitTotalPay += info.amount;
      });
    }
    // 已支付总金额
    let totalPay = 0;
    if (orderByStagesDtoList && orderByStagesDtoList.length) {
      orderByStagesDtoList.map((payItem) => {
        if (payItem.status === "2" || payItem.status === "3") {
          totalPay += payItem.currentPeriodsRent;
        }
      });
    }

    // 待支付倒计时
    if (userOrdersDto.status === "01" && !countDownStr) {
      this.countDown();
    }
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    const { type, imgUrl, productName, skuTitle } = this.$router.params;
    const idCard = (
        <View
            className={
              userOrdersDto.userFaceCertStatus ||
              type == "payment" ||
              type == "WAITING_PAYMENT"
                  ? "noface"
                  : "face"
            }
            onClick={this.onFacecertification}
        >
          {" "}
          刷脸认证
        </View>
    );
    return (
        <View className="orderDetail-page">
          <View className="order-status">
            <View>
              <View className="status">
                <View className="text">
                  {orderStatusInfo(userOrdersDto.status, userOrdersDto.subStatus)}
                </View>
              </View>
              {userOrdersDto.status !== "09" && (
                  <View className="sub-text">
                    商品租用到期归还后，冻结预授权金额将会释放
                  </View>
              )}
              {userOrdersDto.status === "01" && (
                  <View className="sub-text">
                    订单{countDownStr}后将自动取消，请尽快支付
                  </View>
              )}
              {userOrdersDto.status === "09" && (
                  <View className="sub-text">
                    您的订单已完成，如有押金冻结将在3个工作日内原路退还
                  </View>
              )}
              {
                   userOrdersDto.status==="01"?<View onClick={this.onClickFrezzAgain.bind(this, userOrdersDto)} className="porli_f">
                    <Button className="porli_button">
                      去下单
                    </Button>
                </View>:""
               }
            </View>
            <View>
              {/* <Image
                  mode="aspectFill"
                  className="status-icon"
                  src={`https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/order/${
                      this.state.statusObj[userOrdersDto.status]
                      }.png`}
              /> */}
               <Image
                  mode="aspectFill"
                  className="status-icon"
                  src={`https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ce4fb9de39e34c1d882e0e033f8fe874.png`}
              />
            </View>
          </View>
          <View className="content-area">
            {orderAddressDto.realname && orderAddressDto.telephone ? (
                <View className="address-area">
                  <View className="contact-num">
                    <Image
                        mode="aspectFill"
                        className="address-icon"
                        src={`https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3a68af7017e94cb2a6a50dc9898323dc.png`}
                    />
                    <Text className="name">{orderAddressDto.realname}</Text>
                    <Text>{orderAddressDto.telephone}</Text>
                  </View>
                  <View className="content">
                    <View>
                      {orderAddressDto.provinceStr}
                      {orderAddressDto.cityStr}
                      {orderAddressDto.areaStr}
                      {orderAddressDto.street}
                    </View>
                  </View>
                  {!["01", "02", "03", "04", "10"].includes(
                      userOrdersDto.status
                  ) && (
                      <View className="see-wuliu" onClick={this.handleCancelExpress}>
                        查询物流
                      </View>
                  )}
                  <Image
                      className="line-img"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/bbabe74139494c8a9b5f7a7a4afa6d48.png"
                  />
                </View>
            ) : (
                ""
            )}
            <View className="goods-area">
              <View className="goods-info">
                <Image
                    className="img"
                    onClick={this.goProductDetails.bind(
                        this,
                        orderProductDetailDto.productId
                    )}
                    mode="aspectFit"
                    src={
                      !!orderProductDetailDto
                          ? orderProductDetailDto.mainImageUrl
                          : null
                    }
                />
                <View className="goods">
                  <View className="title">
                    {!!orderProductDetailDto.productName
                        ? orderProductDetailDto.productName
                        : null}
                  </View>
                  <View className="spec">
                    规格：
                    {!!orderProductDetailDto && orderProductDetailDto.skuTitle}
                  </View>
                  <View className="rent">
                    {" "}
                    总租金：{" "}
                    <Text className="price">
                      ￥
                      {userOrderCashesDto.totalRent
                          ? userOrderCashesDto.totalRent.toFixed(2)
                          : "0.00"}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            <View className="price-area">
              <View className="black-info margin-bottom-36">
                <View className="left-text">总租金</View>
                <View className="right-text">
                  ￥
                  {userOrderCashesDto.totalRent
                      ? userOrderCashesDto.totalRent.toFixed(2)
                      : "0.00"}
                </View>
              </View>
              <View className="black-info margin-bottom-36">
                <View className="left-text">运费</View>
                <View className="right-text">到付</View>
              </View>
              {!!userOrderCashesDto.couponReduction && (
                  <View className="gray-info margin-bottom-37">
                    <View className="left-text">优惠券</View>
                    <View className="right-text">
                      -￥{userOrderCashesDto.couponReduction.toFixed(2)}
                    </View>
                  </View>
              )}
              <View className="black-info margin-bottom-36">
                <View className="left-text">增值服务费</View>
                <View className="right-text">
                  ￥
                  {userOrderCashesDto.additionalServicesPrice
                      ? userOrderCashesDto.additionalServicesPrice.toFixed(2)
                      : "0.00"}
                </View>
              </View>
              {!userOrderCashesDto.activityDiscountAmount ? null : (
                  <View className="gray-info margin-bottom-25">
                    <View className="left-text">分享免租权益</View>
                    <View className="right-text">
                      ￥
                      {userOrderCashesDto.activityDiscountAmount
                          ? userOrderCashesDto.activityDiscountAmount.toFixed(2)
                          : "0.00"}
                    </View>
                  </View>
              )}
              {/* {!!orderByStagesDtoList &&
              !!orderByStagesDtoList.length &&
              orderByStagesDtoList.map((item, index) => (
                  <View
                      className="black-info margin-bottom-36"
                      key={"s" + index}
                      style={{
                        display:
                            item.status === "2" || item.status === "3"
                                ? "flex"
                                : "none",
                      }}
                  >
                    <View className="left-text">
                      第{item.currentPeriods}期租金
                    </View>
                    <View className="right-text">
                      ￥
                      {item.currentPeriodsRent
                          ? item.currentPeriodsRent.toFixed(2)
                          : "0.00"}
                    </View>
                  </View>
              ))} */}
              <View className="black-info margin-bottom-36">
                <View className="left-text">合计已支付</View>
                <View className="right-text">
                  ￥{totalPay ? totalPay.toFixed(2) : "0.00"}
                </View>
              </View>
              {orderProductDetailDto.buyOutSupport == 1 && (
                  <View className="black-info">
                    <View className="left-text">到期买断价</View>
                    {orderProductDetailDto.buyOutSupport == 1 ? (
                        <View className="right-text">
                          ￥
                          {userOrderCashesDto.buyOutAmount
                              ? userOrderCashesDto.buyOutAmount.toFixed(2)
                              : "0.00"}
                        </View>
                    ) : (
                        <View className="right-text">该商品不支持买断</View>
                    )}
                  </View>
              )}
            </View>

            {userOrdersDto.status !== "07" &&
            userOrdersDto.status !== "08" &&
            userOrdersDto.status !== "OVER_DUE" ? (
                ""
            ) : (
                <View className="price-area">
                  <View className="black-info margin-bottom-36">
                    <View className="left-text">实付租金</View>
                    <View className="right-text">
                      ￥{totalPay ? totalPay.toFixed(2) : "0.00"}
                    </View>
                  </View>
                  <View className="gray-info margin-bottom-30">
                    <View className="left-text">应还日期</View>
                    <View className="right-text">{userOrdersDto.unrentTime}</View>
                  </View>
                  <View className="gray-info margin-bottom-30">
                    <View className="left-text">实还日期</View>
                    <View className="right-text">{userOrdersDto.returnTime}</View>
                  </View>
                  {(userOrdersDto.status === "08" ||
                      userOrdersDto.subStatus ===
                      "USER_APPLICATION_CHANGE_SETTLEMENT" ||
                      userOrdersDto.status === "OVER_DUE") && (
                      <Fragment>
                        <View className="dividing margin-bottom-30" />
                        <View className="gray-info margin-bottom-30">
                          <View className="left-text" style={{ color: "#333" }}>
                            待结算金额
                          </View>
                          <View className="right-text" style={{ color: "#333" }}>
                            ￥
                            {userOrderCashesDto.settlementRent
                                ? userOrderCashesDto.settlementRent.toFixed(2)
                                : "0.00"}
                          </View>
                        </View>
                        <View className="gray-info margin-bottom-30">
                          <View className="left-text">损坏</View>
                          <View className="right-text">
                            ￥
                            {userOrderCashesDto.damagePrice
                                ? userOrderCashesDto.damagePrice.toFixed(2)
                                : "0.00"}
                          </View>
                        </View>
                        <View className="gray-info margin-bottom-30">
                          <View className="left-text">丢失金额</View>
                          <View className="right-text">
                            ￥
                            {userOrderCashesDto.lostPrice
                                ? userOrderCashesDto.lostPrice.toFixed(2)
                                : "0.00"}
                          </View>
                        </View>
                        <View className="gray-info margin-bottom-30">
                          <View className="left-text">违约赔偿金</View>
                          <View className="right-text">
                            ￥
                            {userOrderCashesDto.penaltyAmount
                                ? userOrderCashesDto.penaltyAmount.toFixed(2)
                                : "0.00"}
                          </View>
                        </View>
                      </Fragment>
                  )}
                </View>
            )}

            <View className="order-info">
              <View className="order-info-title margin-bottom-30">订单信息</View>
              <View className="gray-info margin-bottom-30">
                <View className="left-text">订单编号</View>
                <View className="right-text">{userOrdersDto.orderId}</View>
              </View>
              <View className="gray-info margin-bottom-30">
                <View className="left-text">下单时间</View>
                <View className="right-text">{userOrdersDto.createTime}</View>
              </View>
              <View className="gray-info margin-bottom-30">
                <View className="left-text">还租时间</View>
                <View className="right-text">
                  {userOrdersDto.rentStart &&
                  userOrdersDto.rentStart.split(" ")[0]}
                  -
                  {userOrdersDto.unrentTime &&
                  userOrdersDto.unrentTime.split(" ")[0]}
                </View>
              </View>
              <View className="gray-info">
                <View className="left-text">订单备注</View>
                <View className="right-text">{userOrdersDto.remark}</View>
              </View>
            </View>
          </View>
          {/* <View className="order-ment" onClick={this.gotoProtocol}>
            《租赁服务协议》
          </View> */}
           {/* {
             (creditStatus==false ||creditStatus==null)&& orderContractTwo.rzzlhtPdf==null ?
              <View className="order-ment" onClick={this.gotoProtocol}>
                    租赁服务协议
              </View>
                 :
              <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.rzzlhtPdf)}>
                   融资租赁合同授权书
              </View>
          } */}
            {/* {
            creditStatus==false ||creditStatus==null? ''
            :
            <Block>
               <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.grzxPdf)}>
                  个人征信授权书
              </View>
             {
              orderContractTwo.wtdbPdf ==null ?'':
              <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.wtdbPdf)}>
                   委托担保合同
              </View>
             }
              <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.yhxyPdf)}>
                  用户授权书
              </View>
            </Block>
          } */}
          {/* <View className="order-ments" onClick={this.gotoAuthorization}>
            《个人信用信息查询及提供授权书》
          </View> */}
         {
            orderContractTwo.orderContractUrl != null ?
            <View className="order-ment" onClick={()=>this.gotoAllAuth(orderContractTwo.orderContractUrl)}>
                <View className="orde-name">
                    租赁服务协议
                </View>
                <View className="coder-rot"></View>
              </View> : ''
          }
          {
            orderContractTwo.grzxSignPdf != null ? 
            <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.grzxSignPdf)}>
                <View className="order-names">
                  个人征信授权书
                </View>
                <View className="coder-rots"></View>
              </View> : ''
          }
          {
            orderContractTwo.yhxySignPdf != null ?
            <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.yhxySignPdf)}>
                <View className="order-names">
                  用户授权书
                </View>
                <View className="coder-rots"></View>
              </View> : ''
          }
          {
            orderContractTwo.rzzlhtSignPdf != null ?
            <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.rzzlhtSignPdf)}>
                <View className="order-names">
                   融资租赁合同授权书
                </View>
                <View className="coder-rots"></View>
              </View> : ''
          }
          {
            orderContractTwo.wtdbSignPdf != null ?
            <View className="order-ments" onClick={()=>this.gotoAllAuth(orderContractTwo.wtdbSignPdf)}>
                <View className="order-names">
                   委托担保合同
                </View>
                <View className="coder-rots"></View>
              </View> : ''
          }
            <View style={{height:'50px'}}></View>
          {userOrdersDto.userIdCardPhotoCertStatus ? null : (
              <View
                  className={
                    "idCord_wrap " +
                    (userOrdersDto.status === "10" || userOrdersDto.status === "14" ? "idCord_wrap_bottom" : "")
                  }
              >
                <Text className="left">上传身份证照片才能发货哦！</Text>
                <Text onClick={this.onPushIdcard}>去上传{">"}</Text>
              </View>
          )}
          <View className="bottom-space" />
          {userOrdersDto.status === "01" && (
              <View className="end-banner">
                <popover
                    className="popover"
                    position={position}
                    show={show2}
                    showMask={showMask}
                    onMaskClick={this.onMaskClick2}
                >
                  <View onClick={this.onShowPopoverTap2}>
                    <View className="" style={{ marginRight: "10px" }}>
                      <Image
                          mode="aspectFit"
                          src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/eaf4ce7529ac4d509977304e02967c65.png"
                          style={{ width: "25px", height: "25px" }}
                      />
                    </View>
                  </View>
                  <View slot="items">
                    <popover-item onItemClick={this.handleService}>
                      <Text>联系客服</Text>
                    </popover-item>
                  </View>
                </popover>
                {/* <View
                    className="button-bar"
                    onClick={this.handleClickCancelOrder.bind(this, userOrdersDto)}
                >
                  申请取消
                </View> */}
                <View
                    className="button-bar"
                    onClick={() => this.changeAddress(userOrdersDto.orderId)}
                >
                  修改地址
                </View>
                <View
                    className="button-bar-active"
                    onClick={this.onClickFrezzAgain.bind(this, userOrdersDto)}
                >
                  去下单
                </View>
              </View>
          )}
          
          {userOrdersDto.status === "USER_OVERTIME_PAYMENT_CLOSED" && (
              <View className="end-banner">
                <View className="button-bar" onClick={this.handleService}>
                  联系客服
                </View>
                {idCard}
              </View>
          )}
          {(userOrdersDto.status === "04" || userOrdersDto.status === "02") && (
              <View className="end-banner">
                <View className="button-bar" onClick={this.handleService}>
                  联系客服
                </View>
                {/* {userOrdersDto.status === "04" ? (
                    <View
                        className="button-bar"
                        onClick={this.handleClickCancelOrder.bind(this, userOrdersDto)}
                    >
                      申请取消
                    </View>
                ) : (
                    ""
                )} */}
                {userOrdersDto.subStatus !== "USER_ORDER_PENDING_DEAL" && (
                  ((userOrdersDto.withholdType == 2 || userOrdersDto.withholdType == 4 ) &&( userOrdersDto.userIsSigned == 2)) ||  // (是蚂蚁链合同代扣或租赁宝plus) 且已经签署了 
                  ((userOrdersDto.withholdType == 7  ) && (userOrdersDto.userIsSigned == 3)) ||  //  (是租赁平台代扣) 且已经签署了 
                  ((userOrdersDto.withholdType != 2  ) && (userOrdersDto.withholdType != 4 )&& (userOrdersDto.withholdType != 7))  // 不是蚂蚁链合同代，也不是 租赁宝plus，也不是 租赁平台代扣
                ) && (
                  <View
                    className="button-bar-active"
                    onClick={this.onClickBillDetail}
                  >
                    支付账单
                  </View>
                )}
                {userOrdersDto.isCanSignAntchainContract === 2 ? (
                  <Button
                    className="btn careful"
                    onClick={this.onClickSign.bind(this, userOrdersDto)}
                  >
                    去签约
                  </Button>
                ) : (
                  ""
                )}
                {idCard}
              </View>
          )}
          {userOrdersDto.status === "05" && (
              <View className="end-banner">
                <View className="button-bar" onClick={this.handleService}>
                  联系客服
                </View>
                <View className="button-bar" onClick={this.onClickBillDetail}>
                  支付账单
                </View>
                <View className="button-bar" onClick={this.onClickReceiveGoods}>
                  确认收货
                </View>
                {idCard}
              </View>
          )}
          {userOrdersDto.status === "06" && (
              <View className="end-banner">
                <popover
                    className="popover"
                    position={position}
                    show={show}
                    showMask={showMask}
                    onMaskClick={this.onMaskClick}
                >
                  <View
                      onClick={this.onShowPopoverTap}
                      style={{ marginRight: "10px" }}
                  >
                    <Image
                        mode="aspectFit"
                        src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/162e2986b36b4b56a56be74fe9d91218.png"
                        style={{ width: "25px", height: "25px" }}
                    />
                  </View>
                  <View slot="items">
                    <popover-item onItemClick={this.handleService}>
                      <Text>联系客服</Text>
                    </popover-item>

                    {!userOrdersDto.evaluationStatus && (
                        <popover-item onItemClick={() => this.toComment()}>
                          <Text>评论</Text>
                        </popover-item>
                    )}
                  </View>
                </popover>
                <View className="button-bar" onClick={this.onClickBillDetail}>
                  账单
                </View>
                {orderProductDetailDto.buyOutSupport === 1 ? (
                    <View
                        className="button-bar"
                        onClick={() => this.onBuyoutorder("buyout", "")}
                    >
                      买断
                    </View>
                ) : (
                    ""
                )}
                {userOrdersDto.showReletButton ? (
                    <View
                        className="button-bar"
                        onClick={() => this.handleRelet()}
                        // this.handleCloseVis()
                        // this.buyAgain(
                        //   orderProductDetailDto.productId,
                        //   "continue",
                        //   orderProductDetailDto.skuId
                        // )
                    >
                      续租
                    </View>
                ) : (
                    ""
                )}
                <View className="button-bar" onClick={this.onClickSendBack}>
                  归还
                </View>
                {idCard}
              </View>
          )}
          {userOrdersDto.status === "08" && (
              <View className="end-banner">
                <View className="button-bar" onClick={this.handleService}>
                  联系客服
                </View>
                <View className="button-bar" onClick={this.onClickModifySettlement}>
                  申请修改
                </View>
                <View
                    className="button-bar-active"
                    onClick={this.onClickConfirmSettlement.bind(
                        this,
                        userOrdersDto.orderId,
                        userOrderCashesDto.settlementRent
                    )}
                >
                  确认并支付
                </View>
                {idCard}
              </View>
          )}
          {userOrdersDto.status === "07" && (
              <View className="end-banner">
                <View className="button-bar" onClick={this.handleService}>
                  联系客服
                </View>
                <View className="button-bar" onClick={this.onClickBillDetail}>
                  支付账单
                </View>
                <View
                    className="button-bar"
                    onClick={() =>
                        this.onClickReturn(
                            userOrdersDto.unrentExpressId,
                            userOrdersDto.unrentExpressNo
                        )
                    }
                >
                  归还状态
                </View>
                {idCard}
              </View>
          )}
          {userOrdersDto.status === "09" && (
              <View className="end-banner">
                <popover
                    className="popover"
                    position={position}
                    show={show3}
                    showMask={showMask}
                    onMaskClick={this.onMaskClick3}
                >
                  <View
                      onClick={this.onShowPopoverTap3}
                      style={{ marginRight: "10px" }}
                  >
                    <Image
                        mode="aspectFit"
                        src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/162e2986b36b4b56a56be74fe9d91218.png"
                        style={{ width: "25px", height: "25px" }}
                    />
                  </View>
                  <View slot="items">
                    <popover-item onItemClick={this.handleService}>
                      <Text>联系客服</Text>
                    </popover-item>
                    {userOrderBuyOutDto ? (
                        <popover-item
                            onItemClick={() =>
                                this.onBuyoutorder(
                                    "buyoutDetail",
                                    userOrderBuyOutDto,
                                    userOrderCashesDto,
                                    orderProductDetailDto
                                )
                            }
                        >
                          <Text>买断详情</Text>
                        </popover-item>
                    ) : (
                        ""
                    )}
                  </View>
                </popover>
                <View className="button-bar" onClick={this.onClickBillDetail}>
                  账单详情
                </View>
                <View
                    className="button-bar"
                    onClick={() =>
                        this.buyAgain(orderProductDetailDto.productId, "buyAgain")
                    }
                >
                  再次下单
                </View>
                {!userOrdersDto.evaluationStatus && (
                    <View
                        className="button-bar-active"
                        onClick={() => this.toComment()}
                    >
                      评论
                    </View>
                )}
                {idCard}
              </View>
          )}
          <CancelOrder
              display={cancelOrderDisplay}
              onCancal={this.handleModalCancel}
              onOk={this.handleModalOk}
              cancelOrderList={cancelOrderList}
          />
          <AtModal isOpened={receiveDoodsDisplay}>
            <AtModalHeader>确认收货？</AtModalHeader>
            <AtModalContent>
              <View style={{ textAlign: "center" }}>确认已收到商品</View>
            </AtModalContent>
            <AtModalAction>
              <Button onClick={this.handleCancalGoods}>取消</Button>
              <Button
                  onClick={this.handleOkGoods.bind(this, userOrdersDto.orderId)}
              >
                确定
              </Button>
            </AtModalAction>
          </AtModal>
          <AtModal isOpened={modifySettlementDisplay}>
            <AtModalContent>
              <View style={{ textAlign: "center" }}>
                是否申请商家修改结算单？
              </View>
            </AtModalContent>
            <AtModalAction>
              <Button onClick={this.handleCancelModifySettlement}>再想想</Button>
              <Button
                  onClick={this.handleOkModifySettlement.bind(
                      this,
                      userOrdersDto.orderId
                  )}
              >
                确认申请
              </Button>
            </AtModalAction>
          </AtModal>
          <modal
              show={showServicePhone}
              showClose={false}
              onModalClick={this.onClosePhoneModal}
              onModalClose={this.onClosePhoneModal}
          >
            <View slot="header">联系客服</View>
            <View
                style={{
                  textAlign: "left",
                  marginBottom: "10px",
                  paddingLeft: "15px",
                }}
            >
              商家客服：
              <Text
                  style={{ color: "#51A0F9" }}
                  onClick={this.connectServices.bind(this, shopDto.serviceTel)}
              >
                {shopDto.serviceTel}
              </Text>
            </View>
            <View
                style={{
                  textAlign: "left",
                  marginBottom: "10px",
                  paddingLeft: "15px",
                }}
            >
              平台客服：
              <Text
                  style={{ color: "#51A0F9" }}
                  onClick={this.connectServices.bind(this, customerServiceTel)}
              >
                {customerServiceTel}
              </Text>
            </View>
            <View style={{ textAlign: "left", paddingLeft: "15px" }}>
              工作时间：<Text style={{ color: "#777" }}>10:30 - 19:30</Text>
            </View>
            <View slot="footer">取消拨打</View>
          </modal>
          <modal
              show={canCel}
              // showClose={false}
              onModalClick={this.oncanCelModal}
              onModalClose={this.oncanCelModal}
              advice={true}
          >
            <View className="cancel-modal">
              <View slot="header" className="header">
                温馨提示·
              </View>
              <View className="content">
                退款处理中，预计24小时内操作完成，请耐心等待；
                如需加急处理，可联系客服：
                <Text
                    style={{ color: "#51A0F9" }}
                    onClick={this.connectServices.bind(this, customerServiceTel)}
                >
                  {customerServiceTel}
                </Text>
              </View>
            </View>
          </modal>
            <modal
              show={isOpendRelet}
              onModalClick={this.handleOkRelet}
              onModalClose={this.oncanCelModals}
            >
              <view slot="header">温馨提示！</view>
              <view slot="footer">确定</view>
              您已经续租过了，是否确定再续一期？
            </modal>
          <TagPage
              // handleCallService={this.handleCallService}
              onClose={this.handleClose}
              isOpened={isTagOpened}
              // data={shopDto && shopDto.serviceTel}
          />
          <View className="popup-sku">
            <AtFloatLayout isOpened={isOpenedVis} className="onFloatLayout">
              <View className="close" onClick={() => this.onSKUPopupClose()}>
                <Image
                    className="close-img"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e88f0cc6419945d39528747317814fa1.png"
                />
              </View>
              <View className="popup-sku-header">
                <View className="popup-sku-header-img">
                  <Image className="img" src={data.mainImageUrl} />
                </View>
                <View className="popup-sku-header-dec">
                  <View className="price-name">{data.productName}</View>
                  <View className="sku-info">规格：{data.skuTitle}</View>
                  <View className="price-name">
                    总租金 ￥ {this.state.totalPrice}
                  </View>
                  <View className="price-day">
                    <Text className="unit-text">{"总金额"}</Text>
                    <Text className="price-text">¥ {this.state.totalPrice}</Text>
                    <Text className="day-text">元</Text>
                  </View>
                </View>
              </View>
              <View className="item">
                <View className="item-text">租期</View>
                <View className="item-tags">
                  {this.state.reletCyclePricesDtoList.map((cycle, val) => (
                      <View
                          key={cycle.days}
                          className={`${cycle.kz && "tag-active"} tag `}
                          onClick={() => this.onTabChange(val, cycle)}
                      >
                        {cycle.days}天
                      </View>
                  ))}
                </View>
              </View>
              <View className="after-text">租后推荐方案</View>
              <Image
                  mode="aspectFit"
                  className="after-img"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/f02703b2ab4643219c9e0d75c8bfd8e5.png"
              />
              <Button onClick={this.onDianj} className="buttons">确定</Button>
            </AtFloatLayout>
          </View>
          {/* 下面是申请代扣代码 */}
          {/* 选择支付方式弹框 预授权&蚂蚁代扣 */}
          <AtModal isOpened={showOnPayment}  onClose={this.onClosePayment} closeOnClickOverlay={false} className="payment">
            <View className='payment_main'>
              <RadioGroup className='radioGroup' onChange={this.handleChangePayment}>
                <View className='payment_main_top'>
                  <View className='payment_main_top_up'>
                    <Image
                      className="up_img"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/65b24c432ff54956bfcc28a99fe56f1a.png"
                    />
                    <View className='radioText'>芝麻信用免押金</View>
                    <Image
                      className="up_img_t"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c36faa2709074b5ab44bce4ece31a807.png"
                    />
                  </View>
                  <View className='payment_main_top_down'>凭芝麻信用最高可全免</View>
                  <Radio value={1} className='radio' checked />
                </View>
                {/* <View className='payment_main_buttom'>
                  <View className='payment_main_buttom_up'>
                    <Image
                      className="up_img"
                      mode="scaleToFill"
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ac7bf0133b7a4f6aae8b7a4796f46a29.png"
                    />
                  <View className='radioText'>快速<View className='radioText_mian'>免押</View></View>
                  </View>
                  <Radio value={2} className='radio' />
                </View> */}
              </RadioGroup>

            </View>
            <AtModalAction className="payment_button"><Button className='payment_button_a' onClick={this.onClosePayment}>取消</Button> <Button className='payment_button_b' onClick={debounce(this.submitPayment, 2000)}>确定</Button> </AtModalAction>
          </AtModal>
          {/* 信用评估中弹窗 */}
          <AtModal isOpened={showHint} closeOnClickOverlay={false} className="hint">
            <View className='hint_main'>
              <Image
                className="hint_img"
                mode="scaleToFill"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/b3bdd9e05e6a4247904a3ea9cea73ba3.gif"
                />
                <View className='hintText'>信用评估中</View>
                <View className='hintText_a'>
                  剩余 <View className='hint_time'>{newCountDownStr}</View> s
                </View>
            </View>
          </AtModal>
          {/* 提示信息弹窗 */}
          <AtModal isOpened={showRemind} closeOnClickOverlay={false} className="remind">
            <AtModalHeader className="remind_head">温馨提示</AtModalHeader>
            <View className='remind_main'>
              <View className='remindText'>
              即将前往支付宝智能合同小程序签署合同，签署合同完成请点击右上角关闭按钮，返回星动租查看订单审核进度！
              </View>
              <View className='remind_img'>
                <Image
                  className="remind_img_a"
                  mode="scaleToFill"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e4973a40b3de4eff9565660716de5a3a.png"
                  />
              </View>
            </View>
            <AtModalAction><Button onClick={debounce(this.submitRemind, 2000)}>确定</Button></AtModalAction>
          </AtModal>
        </View>
    );
  }
}

export default Orderdetail;
