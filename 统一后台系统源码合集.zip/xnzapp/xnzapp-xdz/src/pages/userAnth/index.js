import Taro, {Component} from '@tarojs/taro';
import {View,Image} from '@tarojs/components';
import './index.scss';
class UserAnth extends Component{
    config={
        navigationBarTitleText:"授权协议"
    }
    render () {
        return (
        <View className="userAnth">
           <Image className="userAnth_img"  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/789066a0e4634960ae7db2b9185810aa.png"/>
        </View>)
    }
}
export default UserAnth