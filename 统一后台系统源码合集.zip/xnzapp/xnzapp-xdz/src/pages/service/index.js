import Taro,{Component} from '@tarojs/taro';
import {View,Image} from '@tarojs/components';
import './index.scss';
class Service extends Component{
    config = {
        navigationBarTitleText:"服务协议"
    }
    render () {
        return (
            <View className="service">
                <Image className="service_img"  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/ca52e4aea6934b43ab62f99053b20a4a.png"/>
            </View>
        )
    }
}

export default Service