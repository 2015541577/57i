import Taro,{Component} from '@tarojs/taro'
import {View} from '@tarojs/components'
import Request from '../../utils/request'
import './index.scss'
class Guarantee extends Component {
    config = {
        navigationBarTitleText:'担保协议'
    }

    render () {
        return (
            <View>
                <View className="guarantee">
                    <Image className="guarantee_img" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d9c474b62dd44da1886f09605e7b847f.png"/>
                </View>
            </View>
        )
    }
}

export default Guarantee