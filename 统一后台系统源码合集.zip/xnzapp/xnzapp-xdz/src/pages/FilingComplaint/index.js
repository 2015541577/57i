import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Image,
  Text,
  ScrollView,
  Button,
  Checkbox,
} from "@tarojs/components";
import { AtImagePicker, AtIcon } from "taro-ui";
import { connect } from "@tarojs/redux";
import { baseUrl } from "../../config/index";
import "./index.scss";
import {
  getUid,
  getTelephone,
  getUserName,
  getNickName,
} from "../../utils/localStorage";
import Request from "../../utils/request";
@connect(({}) => ({}))
class FilingComplaint extends Component {
  config = {
    navigationBarTitleText: "提交投诉",
    usingComponents: {},
  };

  state = {
    files: [],
    banks: [
      {
        contactString: "请选择",
      },
    ],
    bankstype: [
      {
        name: "请选择",
      },
    ],
    index: 0,
    indextype: 0,
    inputValue: null,
    textarea: "",
    imgData: [],
  };
  showToast(title) {
    if (title) {
      Taro.showToast({
        title,
        icon: "none",
        mask: true,
      });
    }
  }
  componentDidMount() {
    Request({
      url: `hzsx/aliPay/orderComplaints/getOrderAndShopName?uid=${getUid()}`,
      method: "get",
    }).then((res) => {
      this.setState({
        banks: res.data.data,
      });
    });
    Request({
      url: `hzsx/aliPay/orderComplaints/getOrderComplaintsTypes`,
      method: "get",
    }).then((res) => {
      this.setState({
        bankstype: res.data.data,
      });
    });
  }
  bindPickerChange(e) {
    this.setState({
      index: e.detail.value,
    });
  }
  bindPickerChangeType(e) {
    this.setState({
      indextype: e.detail.value,
    });
  }
  handleMobile = (e) => {
    this.setState({
      inputValue: e.detail.value,
    });
  };
  onChange = (e) => {
    this.setState({
      textarea: e.detail.value,
    });
  };
  deleteTempKeyword = (index) => {
    const imgData = [...this.state.imgData];
    imgData.splice(index, 1);
    this.setState({
      imgData,
    });
  };
  onUploadFile = () => {
    const { imgData } = this.state;
    if (imgData.length > 3) {
      this.showToast("图片信息只能上传4张");
      return;
    }
    my.chooseImage({
      chooseImage: 1,
      success: (res) => {
        my.uploadFile({
          url: baseUrl + "hzsx/api/components/uploadFile",
          fileType: "image",
          fileName: "multipartFile",
          filePath: res.apFilePaths[0],
          header: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          success: (data) => {
            data = JSON.parse(data.data);
            if (data.responseType !== "SUCCESS") {
              if (data.errorMessage) {
                Taro.showToast({
                  title: data.errorMessage,
                  icon: "none",
                });
              }
            } else {
              const { imgData } = this.state;
              let imgdata = imgData;
              imgdata.push(data.data);
              this.setState({
                imgData: imgdata,
              });
            }
          },
          fail: (res) => {
            my.alert({
              content: "上传错误",
            });
          },
        });
      },
    });
  };
  onConp = () => {
    const {
      inputValue,
      textarea,
      banks,
      index,
      bankstype,
      indextype,
      imgData,
    } = this.state;
    if (!inputValue || inputValue.length !== 11) {
      this.showToast("请输入正确的手机号");
      return;
    }
    if (!textarea) {
      this.showToast("请输入投诉内容");
      return;
    }
    Request({
      url: `hzsx/aliPay/orderComplaints/addOrderComplaints`,
      method: "post",
      data: {
        uid: getUid(),
        name: getNickName(),
        telphone: inputValue,
        content: textarea,
        // shopId: banks[index].shopId,
        // orderId: banks[index].orderId,
        orderId: this.$router.params.orderId ? this.$router.params.orderId : null,
        typeId: bankstype[indextype].id,
        images: imgData,
      },
    }).then((res) => {
      if (res.data.data) {
        Taro.navigateTo({ url: "/pages/FilingType/index" });
      }
    });
  };
  render() {
    const { index, imgData, indextype, inputValue, textarea } = this.state;

    return (
      <View className="complaint">
        <View className="title">
          此投诉适用于检举商户的不合规行为。我们承诺会严格保护投诉人信息。对于商户的违法违规行为，我们都将严肃核实并严格处置。
        </View>
        {/* <picker
          onChange={this.bindPickerChange}
          value={index}
          range={this.state.banks}
          range-key="contactString"
        >
          <View class="row">
            <View class="row-title">涉诉商户订单</View>
            <View class="row-extra">
              {this.state.banks[index].contactString}{" "}
              <AtIcon value="chevron-right" size="20" color="#999999" />
            </View>
          </View>
        </picker> */}
        <picker
          onChange={this.bindPickerChangeType}
          value={indextype}
          range={this.state.bankstype}
          range-key="name"
        >
          <View class="row">
            <View class="row-title">涉诉类型</View>
            <View class="row-extra">
              {this.state.bankstype[indextype].name}{" "}
              <AtIcon value="chevron-right" size="20" color="#999999" />
            </View>
          </View>
        </picker>
        <View className="item">
          <View
            style={{
              fontWeight: 700,
              color: "#333",
            }}
          >
            联系电话
          </View>
          <Input
            className="item-input"
            placeholder="请输入手机号"
            // name="mobile"
            onInput={this.handleMobile}
            style="text-align:right; padding-right:5.2vw"
          />
        </View>
        <Textarea
          style="background:#fff;min-height:294rpx;margin:0 30rpx;
            border-radius: 16rpx;
            border: 1rpx solid #C2C4C8;margin: 30rpx; padding:20rpx"
          autoHeight
          placeholder="请输入详细投诉内容，包括涉及的具体事件、人员、时间、金额等。"
          onInput={this.onChange}
          maxlength="120"
        />
        <View className="imgs">
          {imgData.map((item, val) => {
            return (
              <View className="kuang" key={ val }>
                <Image
                  className="ione"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/897802a6f87e4c398cb219f58cad73d6.png"
                  onClick={() => this.deleteTempKeyword(val)}
                />
                <Image src={item} className="imgjias" />
              </View>
            );
          })}
          {imgData.length === 4 ? null : (
            <Image
              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/da5b9f7496d644389689d5f02e9ba922.png"
              className="imgjia"
              onClick={() => this.onUploadFile()}
            />
          )}
        </View>
        <View
          className="footer_button"
          style={inputValue && textarea ? {} : { opacity: 0.4 }}
        >
          <Button className="footer_button_child" onClick={() => this.onConp()}>
            提交投诉
          </Button>
        </View>
      </View>
    );
  }
}

export default FilingComplaint;
