

const nav = [
  {
    id: 'phone',
    key:1,
    text: '手机优选',
    cname: 'phone',
  },
  {
    id: 'pc',
    key:2,
    text: '电脑平板',
    cname: 'pc',
  },
  {
    id: 'game',
    key:3,
    text: '游戏电玩',
    cname: 'game',
  },
  {
    id: 'photo',
    key:4,
    text: '数码相机',
    cname: 'photo',
  },
  {
    id: 'costume',
    key:5,
    text: '腕表服饰',
    cname: 'costume',
  },
  {
    id: 'appliances',
    key:6,
    text: '生活电器',
    cname: 'appliances',
  },
  {
    id: 'care',
    key:7,
    text: '健康护理',
    cname: 'care',
  },
  {
    id: 'maternal',
    key:8,
    text: '母婴玩具',
    cname: 'maternal',
  },
  {
    id: 'equipment',
    key:9,
    text: '办公设备',
    cname: 'equipment',
  },
  {
    id: 'bags',
    key:10,
    text: '服饰箱包',
    cname: 'bags',
  },
  {
    id: 'Entertainment',
    key:11,
    text: '影音娱乐',
    cname: 'Entertainment',
  },
]
export default nav;
