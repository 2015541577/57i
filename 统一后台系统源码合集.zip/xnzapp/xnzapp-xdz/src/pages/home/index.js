import Taro, { Component, Fragment } from "@tarojs/taro";
import {
  View,
  Image,
  Text,
  ScrollView,
  Icon,
  CoverImage,
  CoverView,
} from "@tarojs/components";
import {
  AtCurtain,
  AtIcon,
  AtButton,
  AtModal,
  AtModalContent,
  AtToast,
} from "taro-ui";
import { connect } from "@tarojs/redux";
import Search from "./component/search/index";
import Channel from "./component/channel/index";
import {
  setAvatar,
  setUserName,
  setNickName,
  setTelephone,
  setUid,
  setBuyerId,
  getUid,
  getBuyerId,
  getActivityCode,
  getshareCode,
  getGloble,
} from "../../utils/localStorage.js";
import { redirectToOtherMiniProgram, leftTimerMS_C } from "../../utils/utils";
import Request from "../../utils/request";
import umUpload from "../../utils/umengUploadData";
import "./index.scss";
import { orderDetailShowType2Cn } from "../../../dist/utils/constant";

@connect(({ classify, home }) => ({
  ...home,
  ...classify,
  // loading: loading.models.home,
}))
class Home extends Component {
  config = {
    //  titleBarColor:'#52BEFF',
    // navigationBarTitleText: '星动租',
    navigationBarTitleText: "",
    enablePullDownRefresh: true,
    transparentTitle: "always",
    titlePenetrate: "YES",
    allowsBounceVertical: "NO",
    // transparentTitle: "always",
    usingComponents: {
      filter: "../../npm/mini-antui/es/filter/index",
      "filter-item": "../../npm/mini-antui/es/filter/filter-item/index",
      // "tblive-list": "plugin://tbliveListPlugin/tblive-list",
      modal: "../../npm/mini-antui/es/modal/index",
    },
  };

  // appName = getGloble('appTitle') // 小程序注册名字，很多地方会用到这个appTitle数据
  uid = getUid(); // 用户信息
  activeMenuId = ""; // 当前选中菜单的id
  activeMenuIds = "";
  systemInfo = Taro.getSystemInfoSync(); // 系统信息，之前在render里面，应避免每次render都执行不变的计算工作

  state = {
    activeMenuIndex: 0, // 当前选中的menu的index
    classifyMenuIndex: 0, // 新分类
    Tips: true,
    Collect: false,
    getScrollTop: false,
    templateId2: "8266035f20504cdfa0c4416409428000",
    templateId3: "b5efd5d08d2c4e71a12c4fc4ddd4ea82",
    templateId1: "9fb596d20e594d5ba8e100839b628ea8",
    templateList: [],
    btnDisabled: true,
    heat_list: [], // 储存热门产品
    classifyList: [],
    opeFirstColumnLists: [],
    honeCoverList: [],
    menuList: [],
    menuListLeft: [],
    menuListRight: [],
    guangGao_token: null,
    colorFrom: "",
    baColor: "",
    fontColor: "",
    baflase: false,
    safeArea: {},
    currentTindex: 0,
  };
  // 对应 onLoad
  componentWillMount = () => {
    if (this.$router.params.mipLink) {
      my.switchTab({
        url: `/pages/classifyAgain/index`,
      });
    }
    my.getSystemInfo({
      success: (res) => {
        this.setState({
          safeArea: res.screen,
        });
      },
    });
    const { dispatch } = this.props;
    dispatch({
      type: "home/getIndexActionListByPage",
      payload: {
        pageNum: 1,
        pageSize: 10,
        channelId: getGloble("channelId"),
      },
      callback: (type) => {
        const list = [];
        if (this.props.tabList) {
          this.classifyIndexChange(0, this.props.tabList[0]);
        }
        this.setState({
          shopType: type,
        });
        this.activeMenuId = type;
        this.activeMenuIds = type;
      },
    });

    // ---------------- 拿下面数据
    // 获取新分类的接口
    dispatch({
      type: "home/queryCategoryCollectionPage",
      payload: { pageNumber: 1, pageSize: 99 },
      callback: (res, bannerIcon) => {
        const { menuListLeft, menuListRight } = this.state;
        this.setState({
          menuList: res,
        });
        res.forEach((item, index) => {
          if (index > 7) {
            menuListRight.push(item);
          } else {
            menuListLeft.push(item);
          }
        });
      },
    });
    // 获取优选好物的接口
    dispatch({
      type: "home/optimization",
      payload: {},
      callback: (res) => {},
    });
    // 获取用户是否收藏
    const ress = my.getMenuButtonBoundingClientRect();
    Request({
      url: "hzsx/api/components/getSwitch",
      method: "GET",
      data: {
        channelId: getGloble("channelId"),
      },
    }).then((res) => {
      if (res.data.data.redBagSwitch == true) {
      }
      if (res.data.data.subscribeMsgSwitch == true) {
        this.setState({
          Collect: true,
        });
      }
    });
  };
  //  onShow
  componentDidShow = () => {
    // 获取缓存埋点
    const { gg_id } = this.$router.params;
    // Taro.removeStorageSync(gg_id);
    if (gg_id != undefined && gg_id != null && gg_id.length > 0) {
      // 进入条件：从外部进入 有gg_id
      // Taro.removeStorageSync(gg_id);
      // 获取历史缓存的gg_id
      const data = Taro.getStorageSync(gg_id);
      if (data != null && data.length > 0) {
        // 历史缓存中有数据的情况进入
        this.state.guangGao_token = JSON.parse(data);
      }
      const obj_current = {
        gg_id: gg_id,
        time: new Date(),
      };
      Taro.setStorageSync("current_gg_id", JSON.stringify(obj_current));

      if (this.state.guangGao_token == null) {
        // 没有历史缓存的情况
        //本地没有用户token和time
        Request({
          url: `hzsx/llxzu/guanggao/add_guanggao_token`,
          method: "GET",
          data: {
            // 此时gg_id是跳转传参
            gg_id: gg_id,
          },
        }).then((res) => {
          const token = res.data.data;
          const obj = {
            token: token,
            time: new Date(),
          };
          // 没有历史缓存 请求接口获取token和time 进行缓存
          Taro.setStorageSync(gg_id, JSON.stringify(obj));
          // 再次获取历史缓存
          const data = Taro.getStorageSync(gg_id);
          if (data != null && data.length > 0) {
            // 判断如果有token和time给guanggao_token赋值
            this.state.guangGao_token = JSON.parse(data);
          }
        });
      } else {
        // 有历史缓存
        // 如果有
        let that = this;
        Request({
          url: `/hzsx/llxzu/guanggao/set_guanggao_cont`,
          method: "GET",
          data: {
            user_token: that.state.guangGao_token.token,
          },
        }).then((res) => {
          if (gg_id) {
            if (!res.data.data) {
              Taro.removeStorageSync(gg_id);
              Request({
                url: `hzsx/llxzu/guanggao/add_guanggao_token`,
                method: "GET",
                data: {
                  product_id: product_id,
                  // 此时gg_id是跳转传参
                  gg_id: gg_id,
                },
              }).then((res) => {
                const token = res.data.data;
                const obj = {
                  token: token,
                  time: new Date(),
                };
                // 没有历史缓存 请求接口获取token和time 进行缓存
                Taro.setStorageSync(gg_id, JSON.stringify(obj));
                // 再次获取历史缓存
                const data = Taro.getStorageSync(gg_id);
                if (data != null && data.length > 0) {
                  // 判断如果有token和time给guanggao_token赋值
                  that.state.guangGao_token = JSON.parse(data);
                }
              });
            }
          }
        });
      }
    }
  };
  // 商品激活项改变
  classifyIndexChange(index, item) {
    const { dispatch } = this.props;
    const info = {
      pageNum: 1,
      pageSize: 10,
      tabId: item.id,
      type: 1,
    };
    this.activeMenuIds = item.id;
    this.setState({
      classifyMenuIndex: index,
      classifyList: [],
    });
    dispatch({
      type: "home/getIndexTabAndProduct",
      payload: { ...info },
      callback: (res) => {
        this.setState({
          classifyList: res,
        });
      },
    });
  }
  // menu激活项改变
  activeMenuIndexChange(index, item) {
    const { dispatch } = this.props;
    const id = item.id;
    this.activeMenuId = id;
    this.setState({ activeMenuIndex: index }, () => {
      const info = { pageNum: 1, pageSize: 10, tabId: id };
      dispatch({
        type: "home/getIndexTabAndProduct",
        payload: { ...info },
      });
    });
  }

  /**
   * 合成请求下一页产品数据接口所需要的参数，发起请求
   * @param {*} queryInfo
   * @param {*} fetchType
   */
  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === "scroll") {
      info.pageNum += 1;
      info.fetchType = fetchType;
      info.type = 0;
    }
    info.tabId = this.activeMenuId;
    dispatch({
      type: "home/getIndexTabAndProduct",
      payload: { ...info },
    });
  }
  onScroll = (e) => {
    // console.log(e,'e.detail.sceollTope.detail.sceollTop');
    if (e.detail.scrollTop > 150) {
      this.setState({
        sceolltopFalse: true,
      });
    } else {
      this.setState({
        sceolltopFalse: false,
      });
    }

    const then = this;
    const query = Taro.createSelectorQuery();
    query.select("#the-id").boundingClientRect();
    query.selectViewport().scrollOffset();
    query.exec(function(res) {
      if (res[0].top <= 120) {
        then.setState({
          getScrollTop: true,
        });
      } else {
        then.setState({
          getScrollTop: false,
        });
      }
      // res[0].top       // #the-id节点的上边界坐标
      // res[1].scrollTop // 显示区域的竖直滚动位置
    });
    // if(e.detail.scrollTop >= 2280 ) {
    //   this.setState({
    //     getScrollTop:true
    //   })
    // }else {
    //   this.setState({
    //     getScrollTop:false
    //   })
    // }
  };
  // onScroll = (e) => {

  // 	if(e.detail.scrollTop<28.8){
  // 		this.setState({
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			colorFrom:"",
  // 			baflase:false,
  // 		})

  // 	}else if(e.detail.scrollTop>=28.8&&e.detail.scrollTop<70){
  // 		this.setState({
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 			// colorFrom:0.9
  // 		})

  // 	}else if(e.detail.scrollTop>=70&&e.detail.scrollTop<110){
  // 		this.setState({
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,

  // 			// colorFrom:0.85
  // 		})

  // 	}else if(e.detail.scrollTop>=110&&e.detail.scrollTop<150){
  // 		this.setState({
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 			// colorFrom:0.8
  // 		})

  // 	} else if(e.detail.scrollTop>=150&&e.detail.scrollTop<190){
  // 		this.setState({
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 			// colorFrom:0.75
  // 		})

  // 	} else if(e.detail.scrollTop>=190&&e.detail.scrollTop<230){
  // 		this.setState({
  // 			// colorFrom:0.7,
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 		})

  // 	}else if(e.detail.scrollTop>=230&&e.detail.scrollTop<270){
  // 		this.setState({
  // 			// colorFrom:0.7,
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 		})

  // 	}else if(e.detail.scrollTop>=270&&e.detail.scrollTop<310){
  // 		this.setState({
  // 			// colorFrom:0.7,
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 		})

  // 	}else if(e.detail.scrollTop>=310&&e.detail.scrollTop<350){
  // 		this.setState({
  // 			// colorFrom:0.7,
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 		})

  // 	}else if(e.detail.scrollTop>=350&&e.detail.scrollTop<380){
  // 		this.setState({
  // 			// colorFrom:0.7,
  // 			baColor:"#F45171",
  // 			fontColor:"#ffffff",
  // 			baflase:false,
  // 		})

  // 	}else   {
  // 		this.setState({
  // 			baColor:"#ffffff",
  // 			fontColor:"#000",
  // 			baflase:true,
  // 			// colorFrom:0.7
  // 		})
  // 	}

  // 	const then = this
  // 	const query = Taro.createSelectorQuery()
  // 	query.select('#the-id').boundingClientRect()
  // 	query.selectViewport().scrollOffset()
  // 	query.exec(function(res) {
  // 		if (res[0].top <= 0) {
  // 			then.setState({
  // 				getScrollTop: true,
  // 			})
  // 		} else {
  // 			then.setState({
  // 				getScrollTop: false,
  // 			})
  // 		}
  // 	})
  // }
  /**
   * scrollView的下拉加载更多动作
   */
  onScrollToLower = () => {
    const {
      //total,
      queryInfo,
      queryInfo: { pageNum, pageSize },
    } = this.props;
    if (pageNum * pageSize - this.props.total >= 0) {
      Taro.showToast({
        title: "更多商品，敬请期待！",
        icon: "none",
        duration: 1000,
      });
      return;
    }
    this.setDispatch(queryInfo, "scroll");
  };
  //  toGoOptimal =(id)=>{
  //      Taro.navigateTo({
  //          url:`/activity/activityTimeLimitTOPIC/index?id=${id}`
  //      })
  //  }
  //  实现可配置的优选好物
  toGoOptimal = (url) => {
    Taro.navigateTo({
      url: url,
    });
  };
  // 关注生活号
  skip = (loinBanner) => {
    const url = loinBanner.jumpUrl;
    if (url.indexOf("alipays://") === 0) {
      const index = url.indexOf("appId=");
      const indexPage = url.indexOf("=/");
      const appId = url.substr(index + 6, 16);
      const path = url.substring(indexPage + 1, url.length);
      if (indexPage !== -1) {
        my.navigateToMiniProgram({
          appId,
          path: path,
        });
      } else {
        my.navigateToMiniProgram({
          appId,
        });
      }
    } else {
      Taro.navigateTo({ url });
    }
  };

  // 监听点击tab栏，进行事件上报。这是个页面周期方法，试了下在app.js写无效，得复制到各个tab页面中
  onTabItemTap(object) {
    umUpload.bottomNavClickHandler(object);
  }

  /**
   * 跳转到商品详情页面
   * @param {*} itemId : 商品ID
   */
  onGotoProduct = (itemId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` });
  };
  onGotoClassify = (value, index) => {
    console.log(value, "valuevalue");
    if (value == "安卓") {
      Taro.navigateTo({ url: `/activity/anzhuo/index` });
		} else if (value == "二手手机") {
			Taro.navigateTo({ url: `/activity/iphone99/index` });
    } else {
      Taro.navigateTo({
        url: `/pages/productList/index?type=search&content=${value}&useLoc=${this.$router.params.useLoc}`,
      });
    }
  };
  onGotoClassifyNew = (url) => {
    Taro.navigateTo({ url: url });
  };
  onProcess = () => {
    Taro.navigateTo({ url: `/pages/process/index` });
  };
  /**
   * 当菜单处于第一个焦点的时候，会显示banner
   * 点击banner触发该方法
   * @param {*} url
   */
  onGoToMore = (url) => {
      Taro.navigateTo({ url:"/pages/classifyAgain/index?id=8&index=1&tertiary=9&tertiaryIndex=0"});

    // if (url.indexOf("alipays://") === 0) {
    //   redirectToOtherMiniProgram(url);
    // } else {
    //   Taro.navigateTo({ url });
    // }
  };

  /**
   * 当焦点菜单处于第一个时，会显示轮播banner 以及 文字slogan 以及文字下的 活动豆腐块
   * 点击 活动豆腐块的时候将会触发 这个方法
   * @param {*} menu
   */
  handleGotoClassify = (menu) => {
    const url = menu.jumpUrl;
    if (url.indexOf("alipays://") === 0) {
      redirectToOtherMiniProgram(url);
    } else {
      Taro.navigateTo({ url });
    }
  };

  onTips = () => {
    this.setState({
      Tips: false,
    });
  };
  goCollect = () => {
    const {
      templateId1 = "9fb596d20e594d5ba8e100839b628ea8",
      // templateId2 = '8266035f20504cdfa0c4416409428000',
      // templateId3 = 'b5efd5d08d2c4e71a12c4fc4ddd4ea82',
    } = this.state;
    // 模板id列表
    const templateList = [];
    templateId1 && templateList.push(templateId1);
    // templateId2 && templateList.push(templateId2)
    // templateId3 && templateList.push(templateId3)
    if (templateList.length === 0) {
      my.showToast({
        type: "fail",
        content: "9fb596d20e594d5ba8e100839b628ea8",
        duration: 3000,
      });
      return;
    }
    // 调用方法，唤起订阅组件
    my.requestSubscribeMessage({
      // 模板id列表，最多3个
      entityIds: templateList,
      // 接收结果的回调方法
      callback(res) {
        if (res.success) {
          const successIds = templateList
            .filter((i) => res[i.entityId] === "accept")
            .map((i) => i.entityId);
          // 订阅成功
          my.call("toast", {
            content: `模板${successIds.join(",")}订阅成功`,
            type: "success",
          });
        } else {
          switch (res.errorCode) {
            case 11: {
              my.call("toast", {
                content: "用户未订阅关闭弹窗",
              });
              break;
            }
            default: {
              my.call("toast", {
                content: `ErrorCode: ${res.errorCode}, ErrorMsg: ${res.errorMessage}`,
              });
              break;
            }
          }
        }
      },
    });
  };
  /**
   * 判断数组是否能够用来进行渲染
   * @param {Array} arr
   */
  arrIsUseful = (arr) => arr && arr.length;
  tosix = () => {
    // Taro.switchTab({
    //     url:'/pages/midyear/index'
    // })
  };
  onChangephotog = (e) => {
    this.setState({
      currentTindex: e.detail.current,
    });
  };
  render = () => {
    const { activityNo = "", shareCode = "" } = this.$router.params;
    getActivityCode(activityNo);
    getshareCode(shareCode);
    const {
      bannerList,
      specialIndexs,
      oldNewDegreeList,
      loinBanner, // 豆腐块banner下面的轮播banner
      loading,
      waterbanner, // 文字slogan下面的豆腐块banner
      products,
      classifyProducts, // 新分类
      tabList,
      total,
      queryInfo: { pageNum, pageSize },
      optimizationList,
      // honeCoverList,
      opeFirstColumnArrayList, // 首页活动类目
    } = this.props;
    const {
      classifyList,
      heat_list,
      menuList, // 分类页面列表
      menuListLeft,
      menuListRight,
      opeFirstColumnLists,
      honeCoverList,
      safeArea,
      currentTindex,
    } = this.state;
    let fixedHeight = 0;
    this.systemInfo.model
      ? this.systemInfo.model.indexOf("iPhone X") > -1 && (fixedHeight = 30)
      : null;
    const scrollHeight = this.systemInfo.windowHeight - fixedHeight;

    // 当前页面发起任意一个请求，都会出现loading弹窗。对于首页来说，这样做的确是可以的，因为这里发起的大部分都是和UI相关的
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading()

    return (
      <View style={`height: ${safeArea.height}px;`} className="home_box">
        <View className="home-top">
          <View className="search_top" style={{ color: "#fff" }}>
          星动租-租享划算
            {/* <Image
              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/119434d48f2842f5b3bcbae45b9da682.png"
              className="img"
            ></Image> */}
          </View>
          <View className="search-view">
            <Search value="" useLoc="首页" />
          </View>
        </View>
        <ScrollView
          className="products"
          scrollY
          scrollWithAnimation
          // style={`height: ${scrollHeight}px;`}
          scrollAnimationDuration={150}
          lowerThreshold={60}
          onScrollToLower={this.onScrollToLower}
          onScroll={this.onScroll}
        >
          <View className="home-page">
            <Fragment>
              {/** 轮播banner */}
              <View className="swiper">
                <swiper
                  circular
                  autoplay="{{true}}"
                  interval="{{3000}}"
                  next-margin="200px"
                  display-multiple-items="{{1}}"
                  indicator-dots
                  indicator-active-color="#DBDBDB"
                  onChange={this.onChangephotog}
                >
                  {this.arrIsUseful(bannerList) &&
                    bannerList.map((banner, index) => (
                      <swiper-item key={banner.id}>
                        <View
                          className={currentTindex === index ? "items" : "item"}
                          onClick={this.onGoToMore.bind(this, banner.jumpUrl)}
                        >
                          <Image
                            lazyLoad={true}
                            className={currentTindex === index ? "imgs" : "img"}
                            src={banner.imgSrc}
                          />
                        </View>
                      </swiper-item>
                    ))}
                </swiper>
              </View>
              {/* <View  style={{fontSize:'12px',color:'#ff9900',padding:'0 6px',marginTop:'5px',verticalAlign:'text-bottom'}}>
							<AtIcon value='volume-minus' size='20' color='#ff9900' style={{marginTop:'2px'}}></AtIcon>
							<text style={{marginLeft:'5px',marginTop:'2px'}}>
							公告： 严禁18岁及以下用户下单！
							</text>
						</View> */}
              <View className="home_nav">
                {this.arrIsUseful(menuList) &&
                  menuList.map((item, index) => (
                    <View
                      key={item.id}
                      className="home_img"
                      onClick={this.onGotoClassify.bind(
                        this,
                        item.jumpUrl,
                        index
                      )}
                    >
                      <Image
                        lazyLoad={true}
                        className="nav_img"
                        src={item.icon}
                      />
                      <View className="nav_title">{item.name}</View>
                    </View>
                  ))}
              </View>
              {/* {this.state.Collect ? ( */}
              {/* <View className="collect">
								<Image
									className="collect_img"
									onClick={this.goCollect}
								/>
							</View> */}
              {/* ) : null} */}
              <View className="home-menu">
                {this.arrIsUseful(waterbanner) &&
                  waterbanner.map((menu) => (
                    <View
                      key={menu.id}
                      className={
                        "home-menu-view home-menu-view2 home-menu-w" +
                        [menu.indexSort]
                      }
                      onClick={this.handleGotoClassify.bind(this, menu)}
                    >
                      <View className="home-menu-view-box">
                        <Image
                          lazyLoad={true}
                          className="home-menu-view-box-img"
                          mode="aspectFit"
                          src={menu.imgUrl}
                        />
                      </View>
                    </View>
                  ))}
              </View>
            </Fragment>

            {!!optimizationList && !!optimizationList.length ? (
              <View className="optimal">
                <View className="optimal_main">
                  <View className="optimal_top">
                    <Image
                      src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/920267992b9242b2934fc0177f7ecc22.gif"
                      className="optimal_img"
                      lazyLoad={true}
                    ></Image>
                    <Text>优选好物</Text>
                    <Text className="optimal_text" decode="{{true}}">
                      实惠全品类&nbsp;月付无压力
                    </Text>
                  </View>
                  <View className="optimal_bottom">
                    {optimizationList.map((item, index) => (
                      <View
                        className="optimal_mains"
                        key={item.id}
                        onClick={() => this.toGoOptimal(item.jumpUrl)}
                      >
                        <Image
                          src={item.imgSrc}
                          className="optimal_img"
                          lazyLoad={true}
                        />
                      </View>
                    ))}
                  </View>
                </View>
              </View>
            ) : (
              ""
            )}
            {/* 直播插件 */}
            {/* <tblive-list disableLiveBack="{{true}}"/> */}

            {/* <View className="home-share">
                  <swiper circular>
                      {this.arrIsUseful(loinBanner) &&
                          loinBanner.map((banner) => (
                              <swiper-item key={banner.id}>
                                  <View
                                      className="item"
                                      onClick={this.skip.bind(
                                          this,
                                          banner
                                      )}
                                  >
                                      <Image
                                          lazyLoad={true}
                                          className="item-img"
                                          src={banner.imgSrc}
                                      />
                                  </View>
                              </swiper-item>
                      ))}
                  </swiper>
						</View> */}
            {/* 设置可配置的活动栏目 */}
            {!!opeFirstColumnArrayList &&
            !!opeFirstColumnArrayList.opeFirstColumnLists &&
            !!opeFirstColumnArrayList.opeFirstColumnLists.length ? (
              <Block>
                {opeFirstColumnArrayList.opeFirstColumnLists.map(
                  (item, index) => (
                    <View className="classify" key={item.id}>
                      <View className="classify_main">
                        <View className="classify_main_head">
                          <Image
                            style={{ width: "100%", height: "100%" }}
                            src={item.backgIocn}
                            lazyLoad={true}
                          />
                        </View>
                        <View className="classify_commodity">
                          <ScrollView
                            className="classify_commodity_ScrollView"
                            scrollX
                            scrollWithAnimation
                          >
                            {item.shopProductAddReqDtos.map((items, indexS) => (
                              <View
                                key={items.itemId || items.productId}
                                className="new_main_f"
                                onClick={this.onGotoProduct.bind(
                                  this,
                                  items.itemId || items.productId
                                )}
                              >
                                <View className="new_main_f_img">
                                  <Image
                                    lazyLoad={true}
                                    className="new_main_f_box"
                                    mode="aspectFit"
                                    src={items.src}
                                  />
                                </View>
                                <View className="new_main_f_title">
                                  <View className="title">
                                    <Text className="name">
                                      <View className="product-name">
                                        <View className="new-tags">
                                          {
                                            oldNewDegreeList[
                                              items.oldNewDegree - 1
                                            ]
                                          }
                                        </View>
                                        {items.title}
                                      </View>
                                    </Text>
                                  </View>
                                  <View className="price">
                                    <Text className="box">
                                      <Text className="unit">￥</Text>
                                      <Text className="unit2">
                                        {/* {
                                         items.lowestSalePrice
                                       } */}
                                        {
                                          String(
                                            items.lowestSalePrice || 0
                                          ).split(".")[0]
                                        }
                                      </Text>
                                      <Text className="decimal">
                                        .
                                        {
                                          String(
                                            items.lowestSalePrice || 0
                                          ).split(".")[1]
                                        }
                                      </Text>
                                      <Text className="unit"> /天</Text>
                                    </Text>
                                  </View>
                                </View>
                              </View>
                            ))}
                          </ScrollView>
                          <View
                            className="seeMore"
                            onClick={this.onGotoClassifyNew.bind(
                              this,
                              item.url
                            )}
                          >
                            <View className="seeMore_text">{"查看更多 >"}</View>
                          </View>
                        </View>
                      </View>
                    </View>
                  )
                )}
              </Block>
            ) : (
              ""
            )}

            {/* 锚点 */}
            <View id="the-id" className="the_id"></View>
            {this.state.getScrollTop ? (
              <View className="the_stance"></View>
            ) : null}
            <ScrollView
              className={
                "products-lists " +
                (this.state.getScrollTop ? "c_getScrollTop" : "")
              }
              scrollX
              scrollWithAnimation
              ref="myScrollView"
            >
              {tabList.map((item, index) => (
                <View
                  className={
                    "products-item " +
                    (index === this.state.activeMenuIndex
                      ? "products-item-active"
                      : "")
                  }
                  key={"kk" + index}
                  onClick={() => this.activeMenuIndexChange(index, item)}
                >
                  {index === 0 ? (
                    <View className="list_div">
                      <View
                        className={
                          index === this.state.activeMenuIndex
                            ? "lets_name"
                            : "let_name"
                        }
                      >
                        <Block>{item.name}</Block>
                        <Image
                          src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/22a294c5c9f845d98a4031b0e6b6c912.png"
                          className="active-hot"
                        />
                      </View>
                      <View
                        className={
                          index === this.state.activeMenuIndex
                            ? "lets_title"
                            : "let_title"
                        }
                      >
                        {item.name}
                      </View>
                    </View>
                  ) : (
                    <View className="list_div">
                      <View
                        className={
                          index === this.state.activeMenuIndex
                            ? "lets_name"
                            : "let_name"
                        }
                      >
                        <Block>{item.name}</Block>
                      </View>
                      <View
                        className={
                          index === this.state.activeMenuIndex
                            ? "lets_title"
                            : "let_title"
                        }
                      >
                        {item.name}
                      </View>
                    </View>
                  )}
                  {/* {index === this.state.activeMenuIndex ? (
									<View className={"active-line "+(index===0?'active-one':'')}></View>
								) : null} */}
                </View>
              ))}
            </ScrollView>
            {/** 产品列表显示 */}
            <View className="home-channel">
              <Channel
                formType="submit"
                products={products}
                oldNewDegreeList={oldNewDegreeList}
                onGotoProduct={(itemId) => this.onGotoProduct(itemId)}
                onGoToMore={this.onGoToMore}
              />
              {pageNum * pageSize - total >= 0 && (
                <View className="home-bottom">
                  <Text className="text"> 没有更多啦，快去挑选商品吧～ </Text>
                </View>
              )}
            </View>
          </View>
        </ScrollView>
      </View>
    );
  };
}

export default Home;
