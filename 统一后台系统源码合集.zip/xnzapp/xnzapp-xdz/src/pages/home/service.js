import Request from "../../utils/request";

export const IndexList = (data) => {
  return Request({
    url: "hzsx/aliPay/index/getIndexActionList",
    method: "GET",
    data,
  });
};
export const putMessage = (data) => {
  return Request({
    url: "hzsx/sendMessageTemplate/insertUserMessageTemplate",
    method: "POST",
    data,
  });
};

export const queryCategoryCollectionPages = (data) => {
  return Request({
    url: "hzsx/aliPay/category/queryCategoryCollectionPage",
    method: "POST",
    data,
  });
};
export const queryCategoryCollectionPage = (data) => {
  return Request({
    url: "hzsx/aliPay/category/queryCategoryCollectionPage",
    method: "GET",
    data,
  });
};
export const getIndexActionListByPage = (data) => {
  return Request({
    url: "hzsx/aliPay/index/getIndexActionListByPage",
    method: "GET",
    data,
  });
};
export const getZhifubaoFlow = (data) => {
  return Request({
    url: "hzsx/aliPay/index/getZhifubaoFlow",
    method: "GET",
    data,
  });
};

export const getIndexTabAndProduct = (data) => {
  return Request({
    url: "hzsx/aliPay/index/getIndexTabAndProductByPage",
    method: "GET",
    data,
  });
};
export const newcomerVerification = (data) => {
  return Request({
    url: "hzsx/aliPay/user/newcomerTask/newcomerVerification",
    method: "POST",
    data,
  });
};
export const submitAppointment = (data) => {
  return Request({
    url: "hzsx/api/appointment/submitAppointment",
    method: "POST",
    data,
  });
};
export const getSysConfigByKey = (data) => {
  return Request({
    url: "hzsx/api/sysConfig/getSysConfigByKey",
    method: "GET",
    data,
  });
};

export const checkUserExist = (data) => {
  return Request({
    url: "hzsx/aliPay/user/checkUserExist",
    method: "GET",
    data,
  });
};

export const optimization = (data) => {
  return Request({
    url: "hzsx/aliPay/product/getOpeIndexOptimizationList",
    method: "GET",
    data,
  });
};
export const getCoverHome = (data) =>{
  return Request({
    url:"hzsx/aliPay/product/getOpeFirstColumnList",
    method:'GET',
    data,
  })
}