import Taro, { Component } from "@tarojs/taro";
import { View, Image, Button } from "@tarojs/components";
import * as homeApi from "../../service";
import { AtCurtain } from "taro-ui";
import { setGlobalData } from "../../../../utils/globalVariable";
import { setGloble, getUid, getBuyerId } from "../../../../utils/localStorage";
import "./index.scss";

class TagPage extends Component {
  state = {};

  onClose() {
    const { onClose } = this.props;
    onClose(false);
  }
  // 获取formId
  onSubmit(e) {
    if (e.detail && e.detail.formId) {
      setGloble("formId", e.detail.formId);
    }
  }
  render() {
    const { isOpened, data, onGetAuthorize, isPhone, onGetPhone } = this.props;
    return (
      <View className="container-curtain">
        <AtCurtain
          className="container-curtain-con"
          isOpened={isOpened}
          onClose={this.onClose.bind(this)}
        >
          <View className="box">
            <Image className="img" src={data} />
            <View className="names">登录授权</View>
            {isPhone ? (
              <Button
                className="authorize"
                open-type="getAuthorize"
                scope="phoneNumber"
                onGetAuthorize={onGetPhone}
              >
                {" "}
                手机号授权{" "}
              </Button>
            ) : (
              <form onSubmit={(e) => this.onSubmit(e)} report-submit="true">
                <Button
                  className="authorize"
                  formType="submit"
                  open-type="getAuthorize"
                  scope="userInfo"
                  onGetAuthorize={onGetAuthorize}
                  // onClick={onGetAuthorize}
                >
                  {" "}
                  立即授权{" "}
                </Button>
              </form>
            )}
          </View>
        </AtCurtain>
      </View>
    );
  }
}
export default TagPage;
