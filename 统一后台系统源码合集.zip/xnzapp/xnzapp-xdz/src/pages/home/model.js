import * as homeApi from "./service";

import Taro from "@tarojs/taro";
import * as mineApi from "../mine/service";
import { getGlobalData, setGlobalData } from "../../utils/globalVariable";
import { tradePay, getAuthCode } from "../../utils/openApi";
import {
  getGloble,
  setGloble,
  setBuyerId,
  setTelephone,
  setNickName,
  setUid,
  setUserName,
  getUid,
  getBuyerId,
  setServicePhone,
} from "../../utils/localStorage";
import { put } from "../../../dist/npm/redux-saga/lib/effects";

export default {
  namespace: "home",
  state: {
    bannerList: [],
    iconList: [],
    tabList: [],
    specialIndexs: [],
    opeFirstColumnArrayList:{},
    oldNewDegreeList: ["全新", "99新", "95新", "9成新", "8成新", "7成新","98新","85成新","准新"],
    queryInfo: {
      pageNum: 0,
      pageSize: 10,
    },
    optimizationList:[],
    honeCoverList:[],
  },

  effects: {
    // 获取首页各项数据列表
    *getIndexActionListByPage({ payload, callback }, { call, put }) {
      const res = yield call(homeApi.getIndexActionListByPage, { ...payload });
      if (res.data) {
        yield put({
          type: "save",
          payload: res.data,
        });
        if (callback && res.data.tabList && res.data.tabList.length) {
          callback(res.data.tabList[0].id);
        }
      }
    },
    // 获取好物优选的数据
    *optimization({ payload, callback }, { call, put }) {
      const res = yield call(homeApi.optimization, { ...payload });
      if (res.data) {
        yield put({
          type: "saveList",
          payload: res.data.data,
        });
      }
    },
    // 分页查询前台类目集合控制器
    *queryCategoryCollectionPage({ payload, callback }, { call, put }) {
      const res = yield call(homeApi.queryCategoryCollectionPage, { ...payload });
      if(res.data.responseType === "SUCCESS") {
        if (res.data) {
          callback(res.data.data.records);
        }
      }else {
        const ress = yield call(homeApi.queryCategoryCollectionPages, { ...payload });
        if (ress.data) {
          callback(ress.data.data.records);
        }
      }
      // res.responseType
    },
    /* * getZhifubaoFlow({ payload}, { call, put }) {
      const res = yield call(homeApi.getZhifubaoFlow, { ...payload });
      if (res) {
        yield put({
          type: 'save',
          payload: res.data,
        });
      }
    }, */
    // 发送formid给后台，用于推送消息
    *putMessageFn({ payload }, { call, put }) {
      if (!getUid() || !getBuyerId()) {
        return;
      }

      const data = {
        channelId: getGloble('channelId'),
        formId: payload.formId,
        uid: getUid(),
        userId: getBuyerId(),
        userBehaviorType: payload.userBehaviorType,
        productId: payload.productId,
      };
      const res = yield call(homeApi.putMessage, { ...data });
      setGloble("formId", "");
    },
    // 获取tab栏信息及对应产品列表
    *getIndexTabAndProduct({ payload, callback }, { call, put }) {
      const newPayload = { ...payload };
      const keys = Object.keys(payload);
      if (keys.length) {
        keys.forEach((key) => {
          if (newPayload[key] === null) {
            delete newPayload[key];
          }
        });
      }
      //
      newPayload.tabId = newPayload.tabId || 124
      newPayload.pageNum = newPayload.pageNum || 1
      newPayload.pageSize = newPayload.pageSize || 10
      const res = yield call(homeApi.getIndexTabAndProduct, { ...newPayload });
      if (res) {
        if (payload.fetchType === "scroll") {
          yield put({
            type: "concatProductList",
            payload: res.data.products || res.data,
          });
        } else if(payload.type == 1){
          callback(res.data.products.records);
        } else {
          yield put({
            type: "saveProductList",
            payload: {
              data: res.data.products || res.data,
              queryInfo: payload,
            },
          });
        }
        // ----------------
        // if(payload.type == 1) {
        //   callback(res.data.products.records);
        // }
        // if (callback && res.data.tabList && res.data.tabList.length) {
        // }
        // -----------------
      }
    },
    /* * newcomerVerification({ payload,callback}, { call}) {
      const res = yield call(homeApi.newcomerVerification, { ...payload,uid:getUid()});
      if(res){
        if(res.data === false){
          Taro.showToast({
            title:'亲您已经是老用户啦'
          })
        }
        if(res.data === true){
          Taro.showToast({
            title:'授权登录成功'
          })
        }
        if(callback){
          callback()
        }
      }
    }, */
    // 获取系统配置-客服热线
    *getSysConfigByKey({ payload, callback }, { call }) {
      const res = yield call(homeApi.getSysConfigByKey, {
        ...payload,
        configKey: "CONSUMER_HOTLINE",
      });
      if (res.data.responseType === "SUCCESS") {
        setServicePhone(res.data.data.sysConfigValue);
      }
    },
    // 用户是否存在
    *checkUserExist({ payload, callback }, { call, put }) {
      let res = null;
      try {
        res = yield call(homeApi.checkUserExist, { ...payload });
      } catch (e) {
        Taro.showToast({
          title: "授权失败，请重试",
          icon: "none",
        });
      }
      if (
        res &&
        res.data &&
        res.data.responseType &&
        res.data.responseType === "SUCCESS"
      ) {
        callback && callback(res);
      }
    },
    // 获取用户授权等信息
    *fetchAuthCode({ callback }, { call, put }) {
      let res = null;
      try {
        res = yield getAuthCode();
      } catch (e) {
        Taro.showToast({
          title: "授权失败，请重试",
          icon: "none",
        });
      }

      if (res) {
        const exeRes = yield call(mineApi.exemptLogin, {
          authCode: res.authCode,
        });
        if (exeRes.data && exeRes.data.data) {
          yield put({
            type: "saveUser",
            payload: exeRes.data.data,
          });
        }
        if (callback) {
          callback();
        }
      }
    },
    *submitAppointment({ payload, callback }, { call }) {
      const api = homeApi.submitAppointment;

      let res = yield call(api, { ...payload, uid: getUid() });

      res = res.data;
      if (res) {
        try {
          const payres = yield tradePay(
            "orderStr",
            res.data.payUrl,
            "Freeze",
            res.data.serialNo
          );
          // 支付成功进入订单详情页，失败则进入订单列表页
          let type = "detail";
          if (payres.resultCode !== "9000") {
            Taro.showToast({
              title: "支付失败",
              icon: "none",
            });
            type = "list";
          } else {
            if (callback) callback(payres);
            Taro.showToast({
              title: "预约成功～",
              icon: "none",
            });
          }
        } catch (e) {
          Taro.showToast({
            title: "授权失败，请重试或联系客服",
            icon: "none",
          });
        }
      }
    },
    // 获取首页活动栏目的数据
    *getCoverHome({payload,callback},{call,put}){
      const res = yield call(homeApi.getCoverHome,{...payload })
      if(res.data){
        yield put({
          type:'honeCover',
          payload:res.data.data.opeFirstColumnLists,
        });
        callback(res.data.data)
      }
    }
  },

  reducers: {
    saveUser(state, { payload }) {
      setUserName(payload.userName);
      setNickName(payload.nickName);
      setTelephone(payload.telephone);
      setUid(payload.uid);
      setBuyerId(payload.thirdId);
      return { ...state, ...payload };
    },
    save(state, { payload }) {
      delete payload['products'];
      //
      return {
        ...state,
        ...payload,
        products: (payload.products && payload.products.records) || [],
      };
    },
    // CollectionPage(state, { payload }) {
    //   return {
    //     ...state,
    //     menuList: payload,
    //   };
    // },
    saveTab(state, { payload }) {
      return {
        ...state,
        tabList: payload,
      };
    },
    saveList(state, { payload }) {
      return {
        ...state,
        optimizationList: payload,
      };
    },
    honeCover(state,{payload}){
      return {
        ...state,
        honeCoverList:payload,
      }
    },
    concatProductList(state, { payload }) {
      const products = [...state.products];
      return {
        ...state,
        products: (products || []).concat(payload.records || []),
        queryInfo: {
          ...state.queryInfo,
          pageNum: state.queryInfo.pageNum + 1,
        },
        total: payload.total,
      };
    },
    saveProductList(state, { payload }) {
      return {
        ...state,
        products: payload.data.records,
        queryInfo: {
          ...payload.queryInfo,
          pageNum: payload.data.current,
        },
        // total:payload.data.current
      };
    },
  },
};
