import Taro from '@tarojs/taro';
import * as productDetailApi from './service';
// import { getAuthCode, apNsf, getOpenUserInfo } from '../../utils/openApi';
import { getGlobalData } from '../../utils/globalVariable'
import { setUid, setBuyerId, setUserName, setTelephone, getUid, setAvatar } from '../../utils/localStorage';
export default {
  namespace: 'productAssess',
  state: {
    
  },

  effects: {
    
  },

  reducers: {
  }
};
