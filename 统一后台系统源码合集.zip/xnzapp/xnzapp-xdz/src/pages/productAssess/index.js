import Taro, { Component, Fragment } from '@tarojs/taro';
import { View, Image, Text, ScrollView, Input, Button, Form } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { AtIcon, AtFloatLayout, AtCurtain } from 'taro-ui';
import * as productDetailApi from '../productDetail/service';
import { getGlobalData } from '../../utils/globalVariable'
import { formatDate, blankSpace, compare } from '../../utils/utils';
import { getServicePhone, getshareCode, getActivityCode, getUid, getTelephone } from '../../utils/localStorage'

import './index.scss';

@connect(({ productAssess, loading }) => ({
  ...productAssess,
  loading: loading.models.productAssess
}))
class ProductAssess extends Component {
  config = {
    navigationBarTitleText: '用户评价',
    usingComponents: {
      "popup": "../../npm/mini-antui/es/popup/index",
      "modal": "../../npm/mini-antui/es/modal/index",
      "collapse": '../../npm/mini-antui/es/collapse/index',
      "collapse-item": '../../npm/mini-antui/es/collapse/collapse-item/index'
    }
  };
  state = {
    pages: {
      size: 20,
      page: 1
    },
    comentList: [],
    // all-全部，pic-有图，append-追加,chosen-精选
    type: 'all',
    typeList: [
      {
        val: 'all',
        label: '全部'
      },
      {
        val: 'pic',
        label: '有图'
      },
      {
        val: 'append',
        label: '追加'
      },
      {
        val: 'chosen',
        label: '精选'
      }
    ]
  }

  componentDidMount = () => {
    this.getComment('new')
  }

  typeChange(type){
    if(type === this.state.type){
      return
    }

    this.setState({
      type,
      pages: {
        size: 20,
        page: 1
      }
    }, () => {
      this.getComment('new')
    })
  }

  onScrollToLower = () =>{
    const { pages }  = this.state
    pages.page += 1
    
    this.setState({
      pages
    }, () => {
      this.getComment('add')
    })
  }

  // 获取产品评价
  getComment(dataType){
    const { itemId } = this.$router.params;
    const { pages, type } = this.state
    
    const params = {
      productId: itemId,
      pageNumber: pages.page,
      pageSize: pages.size
    }
    if(type === 'pic'){
      params.containsPic = 'T'
    }else if(type === 'append'){
      params.containsAppend = 'T'
    }else if(type === 'chosen'){
      params.isChosen = 'T'
    }

    productDetailApi.queryProductEvaluationPage(params).then(res => {
      let comentList = []
      if(dataType === 'new'){
        comentList = res.data.data.records || []
      }else{
        let records = res.data.data.records || []
        if(!records.length){
          Taro.showToast({
            title: '没有更多评论了~',
            icon: 'none',
            mask: true,
          });
          return
        }
        comentList = [...this.state.comentList, ...records]
      }
      this.setState({
        comentList
      })
    })
  }
    
  // 根据用户芝麻信用情况给予押金减免。
  render() {
    const { typeList, comentList } = this.state;
    const { loading } = this.props;

    const starArr = [1,2,3,4,5]
    
    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='productAccess-page'>
        <ScrollView
          scrollY
          scrollTop='0'
          scrollWithAnimation
          className='info-deliver'
          onScrollToLower={this.onScrollToLower}
        >
          <View className="info-deliver-title">
            <Text className="info-deliver-title-l">评论</Text>
          </View>
          <View className="info-deliver-sub">
            <View className="info-deliver-sub-title">商品评论</View>
            <View className="info-deliver-sub-content">
              {
                typeList.map((item,index) => (
                  <View
                    key={'kkk'+index}
                    onClick={() => this.typeChange(item.val)}
                    className={"info-deliver-sub-item "+(item.val===type?'sub-item-active':'')}
                  >{item.label}</View>
                ))
              }
            </View>
          </View>
          <View className="info-deliver-content">
            {
              comentList.map((item,index) => (
                <View key={'k'+index} className="info-deliver-content-item">
                  <View className="info-deliver-content-top">
                    <View className="info-deliver-content-top-l">
                      <Image className='user-img' src={item.userIcon || 'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/852d1b66fd7344b3afeea55060e62c64.png'} />
                      <Text>
                        <Text className="user-name">{item.userName}</Text>
                        <Text className="user-time">{item.createTime}</Text>
                      </Text>
                    </View>
                    <View className="info-deliver-content-top-r">
                      {
                        starArr.map((item2,index) => {
                          return (item2 <= item.starCount)
                            ? <Image key={"star"+index} className='star-img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1fc702005bd04c0aad766bbf7bb526a5.png' />
                            : <Image key={"star"+index} className='star-img' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/e816ee5663c445e482a6d6f67ef1ce08.png' />
                        })
                      }
                    </View>
                  </View>
                  <View className="info-deliver-content-bottom">
                    <View className="user-text">
                      {item.content}
                    </View>
                    {
                      !!item.images && !!item.images.length
                        ? (
                          <View className="user-img">
                            {
                              item.images.map(itemImg => (
                                <Image mode="aspectFit" key={itemImg.id} className='user-img-item' src={itemImg.imageUrl} />
                              ))
                            }
                          </View>
                        )
                        : ''
                    }
                  </View>
                  <View className="append-view">
                    {
                      !!item.append && !!item.append.length && item.append.map((appendItem, appendIndex) =>
                        <View key={'aa'+appendIndex}>
                          <View className="append-title">
                            <Text>用户于{appendItem.createTime}追加</Text>
                          </View>
                          <View className="append-content">{appendItem.content}</View>
                          {
                            !!appendItem.images && !!appendItem.images.length
                              ? (
                                <View className="user-img">
                                  {
                                    appendItem.images.map(appendItemImg => (
                                      <Image mode="aspectFit" key={appendItemImg.id} className='user-img-item' src={appendItemImg.imageUrl} />
                                    ))
                                  }
                                </View>
                              )
                              : ''
                          }
                        </View>
                      )
                    }
                  </View>
                  {
                    item.reply && item.reply.content
                      ? (
                        <View className="response-server">
                          <View className="response-server-title">
                            <Image mode="aspectFit" className='server-icon' src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/1139dc2614014954831ac6cdb8fde2e8.png' />
                            <Text className="server-text">客服回复</Text>
                          </View>
                          <View className="response-server-content">
                            {item.reply.content}
                          </View>
                        </View>
                      )
                      : ''
                  }
                </View>
              ))
            }
          </View>
        </ScrollView>
      </View>
    )
  }
}

export default ProductAssess;
