import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, Button } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { AtIcon } from 'taro-ui';
import PaymentPage from '../../components/payment'
import BillTitle from './component/billTitle/index';
import Payment from './component/payment/index';
import BillList from './component/billList/index';
import Request from "../../utils/request";
import { baseUrl } from "../../config/index";
import './index.scss';

@connect(({ billDetail, loading }) => ({
  ...billDetail,
  loading: loading.models.billDetail,
}))
class BillDetail extends Component {
  config = {
    navigationBarTitleText: '账单详情',
  };

  state = {
    payTotal: 0,
    selectedTransNos: [],
    isTagOpened:false,
    img_url:""
  }

  componentDidMount = () => {
    const { orderId } = this.$router.params;
    const { dispatch } = this.props;
    dispatch({
      type: 'billDetail/selectOrderByStagesList',
      payload: { orderId },
    });
        
  };

  selectPayment = (info) => {
    const { payTotal, selectedTransNos } = this.state;
    const index = selectedTransNos.indexOf(info.outTransNo);
    const newSelectedTransNos = [...selectedTransNos];
    if (index > -1) {
      newSelectedTransNos.splice(index, 1);
    } else {
      newSelectedTransNos.push(info.outTransNo);
    }
    this.setState({
      payTotal: (payTotal + info.rent),
      selectedTransNos: newSelectedTransNos,
    });
  }
  // 关闭弹窗
  handleClose = () => {
    this.setState({
      isTagOpened: false
    })
  }
  // 找人代付
  replaceSubmit = () => {
    const { payTotal, selectedTransNos } = this.state;
    const { unpaidList } = this.props;
    let isSubmit = false;
    if (selectedTransNos.length) {
      isSubmit = selectedTransNos.every((_, index) => selectedTransNos.indexOf(unpaidList[index].outTransNo) > -1);
    }
    const { orderId } = this.$router.params;
    const outTradeNo = selectedTransNos.join('_');
    const { dispatch } = this.props;
    // Taro.navigateTo({
    //   url: `/pages/otherPayment/index?itemId=${itemId}`,
    // });
    // Request({
    //   url:'hzsx/api/orderByStages/orderByStagesPayQr/' + orderId + "/periods=" + outTradeNo + "/amount=" + payTotal,
    //   method:'post',
    //   // data:{
    //   //   orderid: orderId,
    //   //   periods: outTradeNo,
    //   //   amount: payTotal,
    //   // }
    // }).then(res=>{
    // })
    this.setState({
      isTagOpened: true,
      img_url: baseUrl +  "hzsx/api/orderByStages/orderByStagesPayQrEx/" + orderId + "/" + payTotal + "/" + outTradeNo
    })
    // dispatch({
    //   type: 'billDetail/orderbyStagesPay',
    //   payload: { payTotal, outTradeNo, orderId },
    //   callback:(data)=>{
    //     if(data === 'suc'){
    //       dispatch({
    //         type: 'billDetail/selectOrderByStagesList',
    //         payload: { orderId },
    //       });
    //     }
    //   }
    // });
  }
  submit = () => {
    const { payTotal, selectedTransNos } = this.state;
    const { unpaidList } = this.props;
    let isSubmit = false;
    if (selectedTransNos.length) {
      isSubmit = selectedTransNos.every((_, index) => selectedTransNos.indexOf(unpaidList[index].outTransNo) > -1);
    }
    const { orderId } = this.$router.params;
    const outTradeNo = selectedTransNos.join('_');
    const { dispatch } = this.props;
    dispatch({
      type: 'billDetail/orderbyStagesPay',
      payload: { payTotal, outTradeNo, orderId },
      callback:(data)=>{
        if(data === 'suc'){
          dispatch({
            type: 'billDetail/selectOrderByStagesList',
            payload: { orderId },
          });
          this.setState({
            selectedTransNos : [],
          })
        }
          setTimeout(()=>{
              Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
            },1000)
      }
    });
  }

  render() {
    const { loading, totalRent, repaidRent, repaidList, unpaidList, product } = this.props;
    const { payTotal, selectedTransNos } = this.state;
    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    const payTotalStr = payTotal.toFixed(2);
    let noteStr = null;
    if (unpaidList.length) {
      if (unpaidList[0].status == 4) {
        // 请尽快还款改为请尽快支付 3 处
        noteStr = '您已逾期！请尽快支付，以免影响信用！';
      } else {
        const leftTime = new Date(unpaidList[0].statementDate.replace(/-/g,'/')) - (new Date());
        const days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10);
        noteStr = `您的支付日还有${days}天，请注意支付时间，以免逾期！`
      }
    }
    return (
      <View className='bill-detail'>
        {!!noteStr && (
          <View className='bill-detail-broadcast'>
            <AtIcon value='volume-plus' size='18' color='#FFFFFF' />
            <Text className='text'>{noteStr}</Text>
            <AtIcon value='close' size='18' color='#FFFFFF' />
          </View>
        )}

        {/* <View className='bill-detail-goods' style={{marginTop: !!noteStr?'0.68rem':'0'}}> */}
        <View className='bill-detail-goods'>
          <View className='bill-detail-goods-info'>
            <Image className='img' mode='aspectFit' src={product.mainImageUrl} />
            <View className='bill-detail-goods-info-box'>
              <View className='title-info'>
                <View>
                  <Text className='name'>{product.productName}</Text>
                </View>
                <View className='device-type'>
                  <Text className='name type'>规格：{product.skuTitle}</Text>
                </View>
                <View>
                  <Text className='name'>总租金：<Text>&yen; {totalRent.toFixed(2)}</Text> </Text>
                </View>
              </View>
            </View>
          </View>
          <View className='bill-detail-goods-border'></View>
          <View className='bill-detail-goods-account'>

            <View className='account-info'>
              <View className='info-num'>
                <Text className='text'>￥{totalRent.toFixed(2)}</Text>
              </View>
              <View className='info-num desc'>
                <Text className='text desc'>应还租金(元)</Text>
              </View>
            </View>
            <View className='account-info'>
              <View className='info-num'>
                <Text className='text'>￥{repaidRent.toFixed(2)}</Text>
              </View>
              <View className='info-num desc'>
                <Text className='text desc'>已还租金(元)</Text>
              </View>
            </View>
            <View className='account-info'>
              <View className='info-num'>
                <Text className='text'>￥{(totalRent - repaidRent).toFixed(2)}</Text>
              </View>
              <View className='info-num desc'>
                <Text className='text desc'>未还租金(元)</Text>
              </View>
            </View>
          </View>
        </View>
        <View className="pay-list">
          <BillTitle title='可提前归还本金' />
          {!!unpaidList && !!unpaidList.length && unpaidList.map(data =>
            <Payment data={data} onClick={this.selectPayment} />
          )}
          {!!repaidList && !!repaidList.length && repaidList.map(data =>
            <BillList data={data} />
          )}
        </View>

        {!!selectedTransNos && !!selectedTransNos.length && (
          <View className='bill-detail-bottom'>
            <View className='bill-detail-bottom-bill'>
              <Text className='sum'>总计</Text>
              <Text className='num'>
                <Text className='symbol'>&yen;</Text>
                <Text className='symbol money'>{payTotalStr.split('.')[0]}</Text>
                <Text className='symbol'>.{payTotalStr.split('.')[1]}</Text>
              </Text>
            </View>
            <Button className={`btn ${!selectedTransNos.length && 'disabled'}`} style={{marginRight:'12px'}} disabled={!selectedTransNos.length} onClick={this.submit}>去支付</Button>
            {/* <Button className={`btn_b ${!selectedTransNos.length && 'disabled'}`} disabled={!selectedTransNos.length} onClick={this.replaceSubmit}>找人代付</Button> */}
          </View>
        )}

        <PaymentPage
          onClose={this.handleClose}
          isOpened={this.state.isTagOpened}
          data = {this.state.img_url}
          //44"
          // data={product && product.shop && product.shop.serviceTel}
        />
      </View>
    );
  }
}

export default BillDetail;
