import Taro from "@tarojs/taro";
import * as billDetailApi from "./service";
import { getGloble, getBuyerId, getUid } from "../../utils/localStorage";
import { tradePay } from "../../utils/openApi";
import { getGlobalData } from "../../utils/globalVariable";

export default {
  namespace: "billDetail",
  state: {
    totalRent: 0,
    repaidRent: 0,
    repaidList: [], // 已支付列表
    unpaidList: [], // 未支付列表
    product: {},
  },

  effects: {
    // 根据状态获取订单列表
    *selectOrderByStagesList({ payload }, { call, put }) {
      let res = yield call(billDetailApi.selectOrderByStagesList, payload);
      res = res.data;
      if (res) {
        yield put({
          type: "saveList",
          payload: res.data,
        });
      }
    },
    //  新增的续租的接口
        *userAllNewOrderRelet({ payload ,callback}, { call, put }) {
      let res = yield call(billDetailApi.userAllNewOrderRelet, payload);
      res = res.data;
      if(callback){
          callback(res)
      }
    },
    // 获取分期订单
    *orderbyStagesPay({ payload, callback }, { call, put }) {
      let res = yield call(billDetailApi.orderbyStagesPay, {
        totalAmount: Number(payload.payTotal.toFixed(2)),
        orderId: payload.orderId,
        periodList: payload.outTradeNo.split("_"),
        buyerId: getBuyerId() || getUid(),
        channelId: getGloble('channelId'),
        newVersion:666,
      });
      res = res.data;
      if (res.responseType === "SUCCESS") {
        try {
          // const payres = yield tradePay(
          //   "orderStr",
          //   res.data.payUrl,
          //   "TradeAppPay",
          //   res.data.serialNo
          // );
          const payres = yield tradePay(
            "tradeNO",
            res.data.tradeNo,
            "TradeAppPay",
            res.data.serialNo
          );
          let type = "suc";
          if (payres.resultCode !== "9000") {
            type = "error";
          }
          if (callback) {
            callback(type);
          }
        } catch (e) {
          Taro.showToast({
            title: "支付失败，请重试或联系客服",
            icon: "none",
          });
        }
      } else {
        if (res.errorMessage) {
          Taro.showToast({
            title: res.errorMessage,
            icon: "none",
          });
        }
      }
    },
    // demo
    *effectsDemo(_, { call, put }) {
      const { status, data } = yield call(billDetailApi.demo, {});
      if (status === "ok") {
        yield put({
          type: "save",
          payload: {
            topData: data,
          },
        });
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    saveList(state, { payload }) {
      const list = [...payload];
      let totalRent = 0;
      let repaidRent = 0;
      let unpaidList = []; // 未支付
      let repaidList = []; // 已支付
      list.forEach((info) => {
        totalRent = info.totalRent;
        if (info.status === "1" || info.status === "4" || info.status === "0") {
          unpaidList.push(info);
        }
        if (info.status === "2" || info.status === "3") {
          repaidList.push(info);
          repaidRent += info.currentPeriodsRent;
        }
      });
      return {
        ...state,
        totalRent,
        repaidRent,
        repaidList,
        unpaidList,
      };
    },
    saveProduct(state, { payload }) {
      return {
        ...state,
        product: payload,
      };
    },
  },
};
