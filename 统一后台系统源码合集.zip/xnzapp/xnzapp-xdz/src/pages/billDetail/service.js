import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const selectOrderByStagesList = (data) => Request({
  url: 'hzsx/api/orderByStages/queryOrderByStagesByOrderId',
  method: 'GET',
  data,
});
// 新增续租的接口
export const userAllNewOrderRelet = (data) => Request({
  url: 'hzsx/api/orderRelet/userAllNewOrderRelet',
  method: 'POST',
  data,
});
export const orderbyStagesPay = data => Request({
  url: 'hzsx/api/orderByStages/orderByStagesPay',
  method: 'POST',
  data,
});