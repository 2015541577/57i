import Taro, { Component } from '@tarojs/taro';
import { View, Text } from '@tarojs/components';
import { formatStrDate } from '../../../../utils/utils';
import './index.scss';

class BillList extends Component {

  render() {
    const { data } = this.props;
    let  dateStr =null
    if(data && data.repaymentDate){
       dateStr = formatStrDate(data.repaymentDate, 'yyyy年MM月dd日');
    }
    const dateStrS = formatStrDate(data && data.statementDate ? data.statementDate : '', 'yyyy年MM月dd日');
    return (
      <View className='bill'>
        <View className='bill-list'>
          <View className='bill-list-num'>
            <View>
              <Text className='num'>{data.currentPeriods}/{data.totalPeriods}期</Text>
              <Text style={{color:'red'}}>
                {
                  data.isXuZuFlag==1?('  续租'):''
                }
              </Text>
            </View>
            <View className='box'>
              <Text className='text'>
                <Text className='text-symbol'>&yen;</Text>
                <Text className='text-num'>{data.currentPeriodsRent}</Text>
              </Text>
            </View>
          </View>
          <View className='bill-list-num'>
          </View>
        </View>
        <View className='bill-border'></View>
        <View className="bill-status">
            <View className="deal-time">
              支付时间：
              {
                dateStr && !! dateStr?
                  (
                    <Text className='time'>
                      <Text className='num text'>{dateStr}</Text>
                    </Text>
                  )
                  :
                  (
                    <Text className='time'>
                      <Text className='num text'>{dateStrS}</Text>
                    </Text>
                  )
              }
            </View>
            <View className='right-text'>
              <Text className='num'>已支付</Text>
            </View>
        </View>
      </View>
    )
  }
}

export default BillList;
