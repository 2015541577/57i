import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Image,
  Text,
  ScrollView,
  Button,
  Checkbox,
} from "@tarojs/components";
import { AtRate } from "taro-ui";
import { connect } from "@tarojs/redux";
import { baseUrl } from "../../config/index";
import "./index.scss";
import {
  getUid,
  getTelephone,
  getUserName,
  getNickName,
} from "../../utils/localStorage";
import Request from "../../utils/request";
@connect(({}) => ({}))
class Complaint extends Component {
  config = {
    navigationBarTitleText: "发表评论",
    usingComponents: {},
  };

  state = {
    rateValue: null,
    textarea: "",
    type: "",
  };

  componentDidMount = () => {
    Request({
      url: `hzsx/aliPay/orderComplaints/getOrderAndShopName?uid=${getUid()}`,
      method: "get",
    }).then((res) => {
      this.setState({
        type: res.data.data,
      });
    });
  };
  handleChange = (e) => {
    this.setState({
      rateValue: e,
    });
  };
  onChange = (e) => {
    this.setState({
      textarea: e.detail.value,
    });
  };

  onPublish = () => {
    const { rateValue, textarea } = this.state;
    if (!rateValue) {
      return;
    }
    Request({
      url: `hzsx/aliPay/appletsComment/addAppletsComment`,
      method: "post",
      data: {
        telphone: getTelephone() || Taro.getStorageSync("userPhone"),
        uid: getUid(),
        name: getNickName(),
        content: textarea,
        starCountService: rateValue,
      },
    }).then((res) => {
      Taro.showToast({
        title: "发表成功",
      });
      setTimeout(() => {
        Taro.switchTab({
          url: `/pages/mine/index`,
        });
      }, 1000);
    });
  };
  render() {
    const { rateValue } = this.state;

    return (
      <View className="complaint">
        <View className="content">
          <View className="content_atrate">
            <AtRate
              value={rateValue}
              size="30"
              margin="10"
              onChange={this.handleChange}
            />
          </View>
          <Textarea
            style="background:#fff;min-height:294rpx;margin:0 30rpx;
            border-radius: 16rpx;
            border: 1rpx solid #C2C4C8;margin: 30rpx; padding:20rpx"
            autoHeight
            placeholder="请留下您的宝贵意见让我们改进！"
            onInput={this.onChange}
          />
        </View>
        <View className="footer">
          {this.state.type ? (
            <View
              className="footer_txet"
              onClick={() =>
                Taro.navigateTo({
                  url: `/pages/FilingComplaint/index`,
                })
              }
            >
              我要投诉
            </View>
          ) : null}
          <Button
            className={rateValue ? "publish" : "publishc"}
            onClick={() => this.onPublish()}
          >
            发表
          </Button>
        </View>
      </View>
    );
  }
}

export default Complaint;
