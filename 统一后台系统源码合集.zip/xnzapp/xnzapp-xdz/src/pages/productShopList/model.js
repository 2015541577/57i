import * as productListApi from './service';
import * as classifyApi from '../classify/service';
import { getUid } from '../../utils/localStorage';
import umUploadHandler from '../../utils/umengUploadData';
import { getFromPagePath } from '../../utils/utils';

export default {
  namespace: 'productShopList',
  state: {
    queryInfo: {
      oldNewDegreeStatus: null,// 新旧排序
      priceSort: null,  // 价格排序
      salesSort: null,  // 销量排序
      minRentCycleDays: null, // 起租天数
      minPrice: null, // 最小价格
      maxPrice: null, // 最大价格
      LogisticsService: null, // 物流服务
      categoryId: null, // 类目
      content: null, // 搜索内容
      pageNumber: 1,
      pageSize: 10,
    },
    list: [],
    oldNewDegreeList: ['全新', '99新', '95新', '9成新', '8成新', '7成新','98新','85成新','准新'],
    total: 0,
  },

  effects: {
    // 获取二级目录列表
    *fetchSubCategoryList({ payload, callback }, { call, put }) {
      const res = yield call(classifyApi.selectReceptionCategoryList, {...payload, channel:2});
      if(res){
        const list = res.data.category || []
        callback && callback(list)
      }
    },
    // 获取产品列表
    *fetchProductList({ payload }, { call, put }) {
      payload.uid = getUid()
      let work = payload.intType === 'search' ? productListApi.productSearch : productListApi.selectCategoryProduct;
      if(payload.categoryId) {
        work = productListApi.selectCategoryProduct;
      }
      if (payload.isAbility) {
        work = productListApi.abilityProductSearch
      }
      const res = yield call(work, payload);
      if (res) {
        if (payload.intType === 'search') {
          const loc = getFromPagePath(); // 获取到上一个页面的路径
          umUploadHandler.searchSuc(payload, res, loc); // 当成功搜索到数据之后，使用友盟进行数据上报
        }
        if (payload.fetchType === 'scroll') {
          yield put({
            type: 'concatProductList',
            payload: payload.isAbility ? res.data.data : res.data,
          });
        } else {
          yield put({
            type: 'saveProductList',
            payload: { data: payload.isAbility ? res.data.data : res.data, queryInfo: payload },
          });
        }
      }
    },
    // demo
    * effectsDemo(_, { call, put }) {
      const { status, data } = yield call(productListApi.demo, {});
      if (status === 'ok') {
        yield put({
          type: 'save',
          payload: {
            topData: data,
          }
        });
      }
    },
  },

  reducers: {
    saveProductList(state, { payload }) {
      return {
        ...state,
        list: payload.data.records,
        total: payload.data.total,
        queryInfo: {
          ...payload.queryInfo,
          pageNumber: payload.data.current,
        },
      };
    },

    concatProductList(state, { payload }) {
      const list = [...state.list];
      return {
        ...state,
        list: list.concat(payload.records),
        total: payload.total,
        queryInfo: {
          ...state.queryInfo,
          pageNumber: payload.current,
        },
      };
    },

    addPageIndex(state) {
      return {
        ...state,
        queryInfo: {
          ...state.queryInfo,
        },
      };
    },

    setQueryInfo(state, { payload }) {
      return {
        ...state,
        queryInfo: {
          ...state.queryInfo,
          ...payload,
        },
      };
    },
  },
};
