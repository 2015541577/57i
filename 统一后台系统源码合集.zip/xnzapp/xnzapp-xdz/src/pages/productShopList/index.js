import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, ScrollView } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import NoData from '../../components/noData/index'
import { abilityNewPhone, abilitySecondHand } from '../../utils/constant';
import './index.scss';

@connect(({ productList, loading }) => ({
  ...productList,
  loading: loading.models.productList,
}))
class productShopList extends Component {
  config = {
    navigationBarTitleText: '商户列表',
    usingComponents: {
      "popup": "../../npm/mini-antui/es/popup/index"
    }
  };

  state = {
    // 是否显示筛选项
    showPopup: false,
    oldNewDegreeStatus: null,
    priceSort: null,
    salesSort: null,
    minRentCycleDays: null,
    minPrice: null,
    maxPrice: null,
    logisticsService: null,
    categoryId: null,
    // 是否显示排序筛选页面
    topMenuShow: false,
    // 筛选品牌list
    rightList: [],
    // 初始化时的类目id
    initCategoryId: '',
    // 加入页面的渠道，category-类目；search-搜索
    intType: ''
  }

  componentDidMount = () => {
    const { type } = this.$router.params;
    const { dispatch } = this.props;
    const newQueryInfo = {
      oldNewDegreeStatus: null,// 新旧排序
      priceSort: null,  // 价格排序
      salesSort: null,  // 销量排序
      minRentCycleDays: null, // 起租天使
      minPrice: null, // 最小价格
      maxPrice: null, // 最大价格
      logisticsService: null, // 物流服务
      categoryId: null, // 类目
      // orderBy: null, // 排序规则 asc  desc  升序降序
      // oldNewDegreeStatus: null, // 全新二手 0全新,1二手
      content: null, // 搜索内容
      pageNumber: 1,
      pageSize: 10,
    };

    // 分类进来
    if (type === 'category') {
      const { catId, currentMenu } = this.$router.params;
      newQueryInfo.categoryId = catId;
      newQueryInfo.content = null;

      // 筛选项的商品标签list
      // 转为二层数组，内层每项最多3个
      dispatch({
        type: 'productList/fetchSubCategoryList',
        payload: { categoryId: currentMenu },
        callback: (list) => {
          const rightList = []
          list.map((item, index) => {
            if(index % 3 === 0){
              const lastIndex = rightList.length
              rightList[lastIndex] = [item]
            }else{
              const lastIndex = rightList.length - 1
              rightList[lastIndex].push(item)
            }
          })
          this.setState({
            rightList
          })
        }
      });

      // 显示筛选项等
      this.setState({
        topMenuShow: true,
        initCategoryId: catId
      })
    } else {  // 搜索进来
      const { content } = this.$router.params;
      newQueryInfo.content = content;
      newQueryInfo.categoryId = null;
    }
    dispatch({
      type: 'productList/setQueryInfo',
      payload: { ...newQueryInfo },
    });

    this.setState({
      intType: type
    }, () => {
      this.setDispatch(newQueryInfo);
    })
  };

  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    if (fetchType === 'scroll') {
      info.pageNumber += 1;
      info.fetchType = fetchType;
    }
    info.intType = this.state.intType
    const { useLoc } = this.$router.params;
    if (useLoc === abilityNewPhone || useLoc === abilitySecondHand) {
      info.type = useLoc;
      info.isAbility = true;
    }
    dispatch({
      type: 'productList/fetchProductShopList',
      payload: { ...info },
    });
  }

  handleClickFilter = () => {
    this.setState({ showPopup: true });
  }

  onPopupClose = () => {
    this.setState({ showPopup: false });
  }

  // onScrollToLower = () => {
  //   const { total, queryInfo, queryInfo: { pageNumber, pageSize } } = this.props;
  //   if (pageNumber * pageSize - total >= 0) {
  //     Taro.showToast({
  //       title: '没有更多商品了',
  //       icon: 'none',
  //     });
  //     return;
  //   }
  //   this.setDispatch(queryInfo, 'scroll');
  // };

  handleGoBack = () => {
    Taro.navigateBack();
  }

  handleGotoClassify = () => {
    Taro.navigateTo({ url: '/pages/classify/index' });
  }

  handleClickDegree = (type) => {
    const { queryInfo } = this.props;
    const newQueryInfo = { ...queryInfo, pageNumber: 1, pageSize: 10 };

    // 切换排序选项
    if (queryInfo[type] === 0) {
      newQueryInfo[type] = 1
    } else if (queryInfo[type] === 1) {
      newQueryInfo[type] = null
    } else {
      newQueryInfo[type] = 0
    }

    this.setDispatch(newQueryInfo);
  }

  // 点击筛选项
  handleChoicedClick = (val, key) => {
    this.setState({
      [`${key}`]: val
    })
  }
  // 价格区间切换
  priceChage(key, e){
    const val = e.currentTarget.value
    this.setState({
      [`${key}`]: val
    })
  }

  // 点击确定-筛选
  handleFilterOk = () => {
    let { minPrice, maxPrice, minRentCycleDays, logisticsService, categoryId, initCategoryId } = this.state;
    const { queryInfo } = this.props;

    // 没选择类目则用初始类目
    categoryId = categoryId || initCategoryId
    const newQueryInfo = { ...queryInfo, minPrice, maxPrice, minRentCycleDays, logisticsService, categoryId: categoryId + '' };
    this.setDispatch(newQueryInfo);
    this.setState({ showPopup: false });
  }
  // 点击重置-筛选
  handleFilterCancel = () => {
    this.setState({
      minPrice: null,
      maxPrice: null,
      minRentCycleDays: null,
      logisticsService: null,
      categoryId: this.state.initCategoryId
    });
  }

  // handleDetailClick = (id) => {
  //   Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${id}&source=01` });
  // }
  gotoWhere = (shopId) => {
    Taro.navigateTo({ url: `/pages/shops/index?shopId=${shopId}` });
  };
  /**
   * 判断一个商品是否是直购商品
   * @param {*} productObj 
   */
  checkIsDirectProduct = productObj => {
    if (Object.prototype.toString.call(productObj) !== '[object Object]') return false;
    // 在能力中心搜索结果的场景下，接口返回数据并不包含判断直购的字段，后续加入进来可以修改该判断的优先级
    const { productId='' } = productObj;
    return `${productId}`.includes('ZG');
  }

  render() {
    const { showPopup, minRentCycleDays, categoryId, logisticsService, orderBy, rightList } = this.state;
    const { list, loading, oldNewDegreeList, queryInfo } = this.props;
    const { type, catName } = this.$router.params;

    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = this.state.topMenuShow ? 87 : 0;
    if (systemInfo.model.indexOf('iPhone X') > -1) {
      fixedHeight = fixedHeight + 30;
    }
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;

    loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className='productList-page'>
        {/* <popup show={showPopup} disableScroll={false} position='right' zIndex={999} onClose={this.onPopupClose}>
          <View className='popup-right'>
            <ScrollView 
              className='filter-info'
              scrollY
              scrollWithAnimation
              scrollTop='0'
              //style={`height: ${scrollHeight}px;`}
            >
              <View className='lease-term'>
                <View>品牌</View>
                <View className='term-info'>
                  {
                    rightList && rightList.length && rightList.map((item, index) => 
                      <View className='terms' key={"level1"+index}>
                        {
                          item && item.length && item.map((item2, index2) =>
                            <View
                              key={'level2'+index2}
                              className={`filter-botton right-margin ${categoryId === item2.id && 'filter-action'}`}
                              onClick={this.handleChoicedClick.bind(this, item2.id, 'categoryId')}
                            >
                              {item2.name}
                            </View>
                          )
                        }
                      </View>
                    )
                  }
                </View>
              </View>
              <View className='lease-term'>
                <View>物流服务</View>
                <View className='term-info'>
                  <View className='terms'>
                    <View
                      className={`filter-botton right-margin ${logisticsService === 'FREE' && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 'FREE', 'logisticsService')}
                    >
                      包邮
                     </View>
                    <View
                      className={`filter-botton left-margin ${logisticsService === 'PAY' && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 'PAY', 'logisticsService')}
                    >
                      到付
                    </View>
                    <View
                      className={`filter-botton left-margin ${logisticsService === 'SELF' && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 'SELF', 'logisticsService')}
                    >
                      自提
                    </View>
                  </View>
                </View>
              </View>
              <View className='lease-term'>
                <View>最低租期</View>
                <View className='term-info'>
                  <View className='terms'>
                    <View
                      className={`filter-botton right-margin ${minRentCycleDays === 1 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 1, 'minRentCycleDays')}
                    >
                      1天
                    </View>
                    <View
                      className={`filter-botton right-margin ${minRentCycleDays === 3 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 3, 'minRentCycleDays')}
                    >
                      3天
                     </View>
                    <View
                      className={`filter-botton right-margin ${minRentCycleDays === 7 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 7, 'minRentCycleDays')}
                    >
                      7天
                    </View>
                  </View>
                  <View className='terms'>
                    <View
                      className={`filter-botton left-margin ${minRentCycleDays === 30 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 30, 'minRentCycleDays')}
                    >
                      1个月
                    </View>
                    <View
                      className={`filter-botton right-margin ${minRentCycleDays === 90 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 90, 'minRentCycleDays')}
                    >
                      3个月
                    </View>
                    <View
                      className={`filter-botton left-margin ${minRentCycleDays === 180 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 180, 'minRentCycleDays')}
                    >
                      6个月
                    </View>
                  </View>
                  <View className='terms'>
                    <View
                      className={`filter-botton left-margin ${minRentCycleDays === 365 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 365, 'minRentCycleDays')}
                    >
                      1年
                    </View>
                    <View
                      className={`filter-botton right-margin ${minRentCycleDays === 730 && 'filter-action'}`}
                      onClick={this.handleChoicedClick.bind(this, 730, 'minRentCycleDays')}
                    >
                      2年
                    </View>
                  </View>
                </View>
              </View>
              <View className='lease-term'>
                <View>价格区间</View>
                <View className='term-info-price'>
                  <Input type='number' onInput={e => this.priceChage('minPrice', e)} placeholder='最低价'/>
                  <Text> — </Text>
                  <Input type='number' onInput={e => this.priceChage('maxPrice', e)} placeholder='最高价'/>
                </View>
              </View>
            </ScrollView>
            <View className='popup-bottom'>
              <View className='bottom-info' onClick={this.handleFilterCancel}>重置</View>
              <View className='bottom-info bottom-confirm' onClick={this.handleFilterOk}>确定</View>
            </View>
          </View>
        </popup> */}
        {/* <View className='top-menu' style={{display:this.state.topMenuShow?'flex':'none'}}>
          <View className='menu-item' onClick={() => this.handleClickDegree('oldNewDegreeStatus')}>
            <View>新旧</View>
            {queryInfo.oldNewDegreeStatus === null && (
              <View className='default' />
            )}
            {queryInfo.oldNewDegreeStatus === 0 && (
              <View className='new' />
            )}
            {queryInfo.oldNewDegreeStatus === 1 && (
              <View className='old' />
            )}
          </View>
          <View className='menu-item' onClick={() => this.handleClickDegree('priceSort')}>
            <View>价格</View>
            {queryInfo.priceSort === null && (
              <View className='default' />
            )}
            {queryInfo.priceSort === 0 && (
              <View className='new' />
            )}
            {queryInfo.priceSort === 1 && (
              <View className='old' />
            )}
          </View>
          <View className='menu-item' onClick={() => this.handleClickDegree('salesSort')}>
            <View>销量</View>
            {queryInfo.salesSort === null && (
              <View className='default' />
            )}
            {queryInfo.salesSort === 0 && (
              <View className='new' />
            )}
            {queryInfo.salesSort === 1 && (
              <View className='old' />
            )}
          </View>
          <View className='menu-item' onClick={this.handleClickFilter} >
            <View>筛选</View>
            <View className={(!!queryInfo.orderBy || !!queryInfo.minRentCycleDays) ? 'filter-action' : 'filter'} />
          </View>
        </View> */}
        {/* <View className='top-space' style={{display:this.state.topMenuShow?'flex':'none'}} /> */}
        <View />
        <ScrollView
          scrollY
          scrollWithAnimation
          scrollTop='0'
          className='products-area'
          style={`height: ${scrollHeight}px;`}
          // onScrollToLower={this.onScrollToLower}
        >
          {!!list && !!list.length && list.map(info =>
            <View className='item' key={info.productId} onClick={this.gotoWhere.bind(this, info.shopId)}>
              <Image className='img' mode='aspectFit' src={info.logo} />
              <View className='title'>
                {info.name}
              </View>
              <View className='title_right'>
                进店{" >"}
              </View>
            </View>
          )}
          {
            (!list || !list.length) && <NoData type='product' display='block' />
          }
        </ScrollView>
      </View>
    )
  }
}

export default productShopList;
