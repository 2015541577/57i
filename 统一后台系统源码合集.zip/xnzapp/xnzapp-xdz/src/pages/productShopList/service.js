import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
}; 

export const selectCategoryProduct = data => Request({
  url: 'hzsx/aliPay/category/selectCategoryProduct',
  method: 'POST',
  data,
  contentType: 'application/json',
});

// export const productSearch = data => Request({
//   url: 'hzsx/aliPay/product/searchProduct',
//   method: "POST",
//   contentType: 'application/json',
//   data,
// });
export const productSearch = data => Request({
  url: '/hzsx/aliPay/product/searchShop',
  method: "POST",
  contentType: 'application/json',
  data,
});

// 来自能力中心的搜索
export const abilityProductSearch = data => Request({
  url: '/hzsx/aliPay/competenceCenterIndex/searchCompetenceCenterProduct',
  method: "POST",
  contentType: 'application/json',
  data,
});