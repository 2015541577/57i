import Taro from "@tarojs/taro";
import * as productDetailApi from "./service";
import { getAuthCode, getOpenUserInfo } from "../../utils/openApi";
// apNsf, 
import {
  setUid,
  setBuyerId,
  setNickName,
  setUserName,
  setTelephone,
  getUid,
  getTelephone,
  setAvatar,
  getGloble,
} from '../../utils/localStorage';
import umUploadHandler from "../../utils/umengUploadData";

export default {
  namespace: 'productDetail',
  state: {
    detail: {},
    currentSku: {
      currentCyclePrice: {},
    },
    currentDays: null, // 当前选中的租用天数
    advancedDays: [], // 起租日期列表
    saveServers: [], // 选中的安心服务列表id
    saveServersPrice: [], // 选中的安心服务列表price+id
    saveServersAdd: [], // 选中的增值服务列表id
    saveServersPriceAdd: [], // 选中的增值服务列表price+id
    startDay: null, // 选中的起租日期
    oldNewDegreeList: ['全新', '99新', '95新', '9成新', '8成新', '7成新','98新','85成新','准新'],
    serviceMarkList: [
      '包邮',
      '免押金',
      '免赔',
      '随租随还',
      '全新品',
       '支付', // '分期支付',
    ],
    // 为你推荐列表
    recommendproductsList: [],
    images_ismain: [],
    minRentCycleday: null,
    processRule: '',
    productCoupons: [],
    isCycs:false,
    productSeckillRes: null, // /hzsx/special/getSpikeProductListByProductId接口所返回的响应数据
  },

  effects: {
    // 获取商品详情
    *fetchProductDetail({ payload, callback }, { call, put }) {
      let res = yield call(productDetailApi.selectProductDetail, {
        ...payload,
        type: 1,
      });
      if (res.data && res.data.productId) {
        yield put({
          type: 'saveDetail',
          payload: res.data,
        });
        callback(res.data);
      } else {
        my.alert({
          content: '商品已下架，请重新选择商品！',
          buttonText: '确认',
          success: () => {
            Taro.switchTab({ url: '/pages/home/index' });
          },
        });
      }
    },
    // 跳转-暂存参数
    *saveTempParam({ payload, callback }, { call, put }) {
      let res = yield call(productDetailApi.saveTempParam, payload);
      if (res) {
        if (callback) callback(res);
      }
    },
    // 获取商品详情-购买
    *selectProductDirectDetail({ payload, callback }, { call, put }) {
      let res = yield call(productDetailApi.selectProductDirectDetail, {
        ...payload,
        type: 1,
      });
      if (res.data.data && res.data.data.productId) {
        yield put({
          type: 'saveDetails',
          payload: res.data.data,
        });
        callback(res.data.data);
      } else {
        my.alert({
          content: '商品已下架，请重新选择商品！',
          buttonText: '确认',
          success: () => {
            Taro.switchTab({ url: '/pages/home/index' });
          },
        });
      }
    },

    // itemid商品详情其他接口
    *recommendproducts({ payload, callback }, { call, put }) {
      //
      const res = yield call(productDetailApi.recommendproducts, payload);
      //
      if (res) {
        yield put({
          type: 'saveRecommend',
          payload: res.data.products,
        });

        callback && callback(res.data.products);
      }
    },
    *recommendProductDirects({ payload, callback }, { call, put }) {
      const res = yield call(productDetailApi.recommendProductDirects, payload);
      if (res) {
        yield put({
          type: 'saveRecommend',
          payload: res.data.data.products,
        });

        callback && callback(res.data.data.products);
      }
    },
    // 获取优惠券
    *getCoupon({ payload, callback }, { call, put }) {
      const res = yield call(productDetailApi.getCoupon, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        if (res.msg) {
          Taro.showToast({
            title: res.msg,
            icon: 'none',
          });
        }
        callback();
      }
    },
    // 优惠券搜索
    *conuponSearch({ payload }, { call, put }) {
      const res = yield call(productDetailApi.conuponSearch, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        Taro.navigateTo({ url: '/pages/active_pages/unclaimed/index' });
      }
    },
    /* *getProductCoupon({ payload }, { call, put }) {
      const res = yield call(productDetailApi.getProductCoupon, {
        ...payload,
        uid: getUid(),
        type: 1,
      });
      if (res) {
        yield put({
          type: "productCoupon",
          payload: res.data,
        });
      }
    }, */
    // 获取产品优惠券列表
    *getProductCouponList({ payload }, { call, put }) {
      const res = yield call(productDetailApi.getProductCouponList, {
        ...payload,
      });
      if (res && res.data) {
        yield put({
          type: 'productCoupons',
          payload: res.data.data,
        });
      }
    },
    // 获取授权信息
    *fetchAuthCodedetail({ callback }, { call, put }) {
      let res = null;
      try {
        res = yield getAuthCode();
      } catch (e) {
        Taro.showToast({
          title: '授权失败，请重试',
          icon: 'none',
        });
        umUploadHandler.loginFailed("调用getAuthCode方法发生错误");
      }
      if (res) {
        const obj = {
          authCode: res.authCode,
        };
        let newObj = null;
        try {
          newObj = yield getOpenUserInfo();
        } catch (e) {
          Taro.showToast({
            title: '授权失败，请重试',
            icon: 'none',
          });
          umUploadHandler.loginFailed("调用getOpenUserInfo方法发生错误");
        }
        let userInfo = JSON.parse(newObj.response).response;
        if (userInfo.code !== '40003') {
          let alipayUserInfoNewDTO = {
            authCode: obj.authCode,
            avatar: userInfo.avatar,
            city: userInfo.city,
            telephone: userInfo.telephone || getTelephone(),
            gender: userInfo.gender,
            nickName: userInfo.nickName,
            province: userInfo.province,
            channelId: '001',
          };
          alipayUserInfoNewDTO.channelId = getGloble('channelId');
          const exeRes = yield call(productDetailApi.exemptLoginNew, {
            ...alipayUserInfoNewDTO,
          });
          if (exeRes.data && exeRes.data.data) {
            yield put({
              type: 'saveUser',
              payload: exeRes.data.data,
            });
            if (callback) {
              callback();
            }
            const uid = exeRes.data && exeRes.data.data && exeRes.data.data.uid;
            umUploadHandler.loginSuccess(uid); // 使用友盟上报成功登录的事件
          } else {
            const obj = exeRes.data || {};
            umUploadHandler.loginFailed(`调用exemptLoginNew方法发生错误，错误状态码为${obj.errorCode}，接口描述信息为${obj.errorMessage}`);
          }
        } else {
          umUploadHandler.loginFailed(`调用getOpenUserInfo方法发生问题-${userInfo.code}`);
        }
      }
    },

    // 加载商品的秒杀信息数据
    *fetchProductSpeckillDetail({ payload }, { call, put }) {
      let res = yield call(productDetailApi.fetchSeckillProductDetail, payload);
      yield put({
        type: 'saveSeckillProductDetail',
        payload: (res.data && res.data.data) || {},
      });
    },

    // 初始化秒杀商品的一些信息
    *restProductSeckillRes({}, { put }) {
      yield put({ type: 'resetSeckillProduct' });
    }
  },

  reducers: {
    saveUser(state, { payload }) {
      setAvatar(payload.avatar), setUserName(payload.userName);
      setNickName(payload.nickName);
      setTelephone(payload.telephone);
      setUid(payload.uid);
      setBuyerId(payload.thirdId);
      return { ...state, ...payload };
    },
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    saveDetail(state, { payload }) {
      const { minAdvancedDays, maxAdvancedDays } = payload;
      let startTime = new Date().getTime();
      if (minAdvancedDays) {
        startTime += minAdvancedDays * 24 * 3600 * 1000;
      }
      const advancedDays = [startTime];

      let endDay = 30 - minAdvancedDays;
      if (maxAdvancedDays && maxAdvancedDays > minAdvancedDays) {
        endDay = maxAdvancedDays - minAdvancedDays;
      }
      if (minAdvancedDays === maxAdvancedDays) {
      } else {
        for (let i = 1; i <= endDay; i += 1) {
          advancedDays.push(startTime + i * 24 * 3600 * 1000);
        }
      }

      // 增值服务-必选
      // let saveServers = [];
      // let saveServersPrice = [];
      // if (payload.additionals && payload.additionals.length) {
      //   payload.additionals.forEach((ser) => {
      //     if (ser.isMust) {
      //       saveServers.push(ser.shopAdditionalServices.id);
      //       saveServersPrice.push({
      //         id: ser.shopAdditionalServices.id,
      //         price: ser.shopAdditionalServices.price,
      //       });
      //     }
      //   });
      // }
      // 新的质选服务
       let saveServers = [];
      let saveServersPrice = [];
      if (payload.repairOrderCofigs && payload.repairOrderCofigs.length) {
        payload.repairOrderCofigs.forEach((ser) => {
          saveServers.push(ser.id);
          saveServersPrice.push({
            id: ser.id,
            price: ser.price,
          });
        });
      }
      if (payload.images && payload.images.length) {
        payload.images.sort(function compare(a, b) {
          return b.isMain - a.isMain;
        });
      }
      let cyclePricesArr = [...payload.productSkuses[0].cycs];
      //days注释
      if (cyclePricesArr.length) {
        // cyclePricesArr = cyclePricesArr.filter(info => info.days >= payload.minRentCycle && info.days <= payload.maxRentCycle);
      }
      cyclePricesArr.length &&
        cyclePricesArr.sort((a, b) => {
          if (a.price === b.price) {
            return a.days - b.days;
          } else {
            return a.price - b.price;
          }
        });
      return {
        ...state,
        detail: payload,
        images_ismain: payload.images,
        currentSku: {
          ...payload.productSkuses[0],
          currentCyclePrice: cyclePricesArr[0],
        },
        currentDays: cyclePricesArr[0].days,
        minRentCycleday: payload.minRentCycle,
        advancedDays,
        startDay: startTime,
        saveServersAdd:saveServers,
        saveServersPriceAdd:saveServersPrice,
        processRule: payload.processRule,
      };
    },
    saveDetails(state, { payload }) {
      const { minAdvancedDays, maxAdvancedDays } = payload;
      let startTime = new Date().getTime();
      if (minAdvancedDays) {
        startTime += minAdvancedDays * 24 * 3600 * 1000;
      }
      const advancedDays = [startTime];

      let endDay = 30 - minAdvancedDays;
      if (maxAdvancedDays && maxAdvancedDays > minAdvancedDays) {
        endDay = maxAdvancedDays - minAdvancedDays;
      }
      if (minAdvancedDays === maxAdvancedDays) {
      } else {
        for (let i = 1; i <= endDay; i += 1) {
          advancedDays.push(startTime + i * 24 * 3600 * 1000);
        }
      }

      if (payload.images && payload.images.length) {
        payload.images.sort(function compare(a, b) {
          return b.isMain - a.isMain;
        });
      }
      return {
        ...state,
        detail: payload,
        images_ismain: payload.images,
        currentSku: {
          ...payload.productSkuses[0],
        },
        minRentCycleday: payload.minRentCycle,
        advancedDays,
        startDay: startTime,
        processRule: payload.processRule,
      };
    },
    setCurrentSku(state, { payload }) {
      const { currentSku } = state;
      const { productSkuses } = state.detail;
      // 这里是先做判断 ids 是传过来的 存在吗 如果存在的话 让其在每次切换的时候 去显示其下的第一项
      // 如果不存在ids 说明是切换的规格2  那原先的逻辑正常来显示
      const specIds =!!payload.ids ? currentSku.specAll.map((value) =>
        value.platformSpecId === payload.preId
          ? payload.valueId
          : payload.ids,
      ):currentSku.specAll.map((value) =>
        value.platformSpecId === payload.preId
          ? payload.valueId
          : value.platformSpecId,
      );
      let newCurrentSku = {};
      if (productSkuses.length) {
        newCurrentSku = productSkuses.find((sku) => {
          let returnVal = true;
          sku.specAll.forEach((value) => {
            if (specIds.indexOf(value.platformSpecId) < 0) {
              returnVal = false;
            }
          });
          return returnVal;
        });
      }
      return {
        ...state,
        currentSku: {
          ...state.currentSku,
          ...newCurrentSku,
          currentCyclePrice: newCurrentSku&&newCurrentSku.cycs[0] ? newCurrentSku.cycs[0]:{},
        },
        currentDays:newCurrentSku&&newCurrentSku.cycs[0] ? newCurrentSku.cycs[0].days:'',
      };
    },
    setCurrentSkus(state, { payload }) {
      const { currentSku } = state;
      const { productSkuses } = state.detail;
      const specIds = currentSku.specAll.map((value) =>
        value.platformSpecId === payload.preId
          ? payload.valueId
          : value.platformSpecId,
      );
      let newCurrentSku = {};
      if (productSkuses.length) {
        newCurrentSku = productSkuses.find((sku) => {
          let returnVal = true;
          sku.specAll.forEach((value) => {
            if (specIds.indexOf(value.platformSpecId) < 0) {
              returnVal = false;
            }
          });
          return returnVal;
        });
      }
      return {
        ...state,
        currentSku: {
          ...state.currentSku,
          ...newCurrentSku,
        },
      };
    },
    setCurrentDays(state, { payload }) {
      const { currentSku } = state;
      let newCurrentCyclePrice = {};
      currentSku.cycs &&
        currentSku.cycs.sort(function (a, b) {
          return a.days - b.days;
        });
      currentSku.cycs.forEach((cycle) => {
        if (cycle.days <= payload) {
          newCurrentCyclePrice = cycle;
        }
      });
      return {
        ...state,
        currentSku: {
          ...state.currentSku,
          currentCyclePrice: { ...newCurrentCyclePrice },
        },
        currentDays: payload,
      };
    },

    setStartDay(state, { payload }) {
      return {
        ...state,
        startDay: payload,
      };
    },
    productCoupon(state, { payload }) {
      return {
        ...state,
        productCoupon: payload,
      };
    },
    productCoupons(state, { payload }) {
      return {
        ...state,
        productCoupons: payload,
      };
    },
    setSaveServers(state, { payload }) {
      const { saveServers, saveServersPrice } = state;
      const index = saveServers.indexOf(payload.id);
      let newServers = [...saveServers];
      let newServersPrice = [...saveServersPrice];
      if (index > -1) {
        newServers.splice(index, 1);
        newServersPrice.splice(index, 1);
      } else {
        newServers.push(payload.id);
        newServersPrice.push(payload);
      }
      return {
        ...state,
        saveServers: newServers,
        saveServersPrice: newServersPrice,
      };
    
    },
     setSaveServersAdd(state, { payload }) {
      const { saveServersAdd, saveServersPriceAdd } = state;
      const index = saveServersAdd.indexOf(payload.id);
      let newServers = [...saveServersAdd];
      let newServersPrice = [...saveServersPriceAdd];
      if (index > -1) {
        newServers.splice(index, 1);
        newServersPrice.splice(index, 1);
      } else {
        newServers.push(payload.id);
        newServersPrice.push(payload);
      }
      return {
        ...state,
        saveServersAdd: newServers,
        saveServersPriceAdd: newServersPrice,
      };
    
    },
    // 为你推荐
    saveRecommend(state, { payload }) {
      //
      return {
        ...state,
        recommendproductsList: payload,
      };
    },
    saveSeckillProductDetail(state, { payload }) {
      return {
        ...state,
        productSeckillRes: payload
      };
    },
    resetSeckillProduct(state) {
      return {
        ...state,
        productSeckillRes: null,
      };
    }
  },
};
