import Request from "../../utils/request";
import { getUid } from "../../utils/localStorage";
export const selectProductDetail = (data) =>
  Request({
    url: `hzsx/aliPay/product/selectProductDetail?uid=${getUid()}`,
    // url: `hzsx/aliPay/product/selectProductDetail`,
    method: "GET",
    data,
  });
//购买
export const selectProductDirectDetail = (data) =>
  Request({
    url: `/hzsx/aliPay/productDirect/selectProductDirectDetail?uid=${getUid()}`,
    // url: `/hzsx/aliPay/productDirect/selectProductDirectDetail`,
    method: "GET",
    data,
  });
// itemid其他详情
export const recommendproducts = (data) =>
  Request({
    url: "hzsx/aliPay/product/recommendproducts",
    method: "GET",
    data,
  });
export const recommendProductDirects = (data) =>
  Request({
    url: "hzsx/aliPay/productDirect/recommendProductDirects",
    method: "GET",
    data,
  });
export const getProductCouponList = (data) =>
  Request({
    url: "hzsx/aliPay/couponCenter/getProductCoupon",
    method: "GET",
    data,
  });

export const userConfirmOrder = (data) =>
  Request({
    url: "hzsx/api/order/confirm",
    method: "POST",
    data,
    contentType: "application/json",
  });
export const userOrdersPurchase = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/submit",
    method: "POST",
    data,
    contentType: "application/json",
  });
export const userOrderReletConfirm = (data) =>
  Request({
    url: "hzsx/api/orderRelet/userOrderReletConfirm",
    method: "POST",
    data,
    contentType: "application/json",
  });

export const getCoupon = (data) =>
  Request({
    url: "hzsx/aliPay/coupon/getCoupon",
    method: "GET",
    data,
  });

export const addProductCollection = (data) =>
  Request({
    url: "hzsx/userCollection/addProductCollection",
    method: "POST",
    data,
  });

export const queryProductEvaluationPage = (data) =>
  Request({
    url: "hzsx/productEvaluation/queryProductEvaluationPage",
    method: "POST",
    data,
  });

export const queryOpeIndexProductBannerList = (data) =>
  Request({
    url: "hzsx/aliPay/product/queryOpeIndexProductBannerList",
    method: "GET",
    data,
  });

export const cancelProductCollection = (data) =>
  Request({
    url: "hzsx/userCollection/cancelProductCollection",
    method: "POST",
    data,
  });

//查询红包

export const conuponSearch = (data) =>
  Request({
    url: "hzsx/aliPay/coupon/getOneUserPlatformCoupon",
    method: "GET",
    data,
  });

//折扣
export const getUserMembersDisCount = () =>
  Request({
    url: "hzsx/aliPay/user/members/getUserMembersDisCount",
    method: "GET",
  });

//优惠劵
export const getProductCoupon = (data) =>
  Request({
    url: "hzsx/aliPay/couponCenter/getProductCoupon",
    method: "GET",
    data,
  });
export const exemptLoginNew = (data) =>
  Request({
    url: "hzsx/aliPay/user/exemptLogin",
    method: "POST",
    data,
  });
//跳转-暂存参数
export const saveTempParam = (data) =>
  Request({
    url: "hzsx/api/sysConfig/saveTempParam",
    method: "POST",
    data,
  });

// 加载秒杀的详情数据
export const fetchSeckillProductDetail = data => 
  Request({
    url: "hzsx/special/getSpikeProductListByProductId",
    method: "GET",
    data,
  })