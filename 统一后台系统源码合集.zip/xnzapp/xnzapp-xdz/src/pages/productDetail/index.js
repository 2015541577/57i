import Taro, { Component, Fragment, request } from "@tarojs/taro";
import {
  View,
  Image,
  Text,
  ScrollView,
  Input,
  Button,
  Form,
  Block,
  Icon,
} from "@tarojs/components";
import { connect } from "@tarojs/redux";
import {
  AtIcon,
  AtFloatLayout,
  AtCurtain,
  AtModal,
  AtModalHeader,
  AtModalContent,
  AtModalAction,
} from "taro-ui";
import * as productDetailApi from "./service";
import {
  formatDate,
  blankSpace,
  compare,
  numberFormat,
  convertGPSToAddress,
  throttle,
  getSignUrl,
} from "../../utils/utils";
import {
  getServicePhone,
  getshareCode,
  getActivityCode,
  getUid,
  getTelephone,
  getGloble,
} from "../../utils/localStorage";
import ParseComponent from "./wxParseComponent";
import NoData from "../../components/noData/index";
import TagPage from "../../components/service";
import Channel from "../home/component/channel/index";
import umUploadHandler from "../../utils/umengUploadData";
import Optimization from "../coupon/component/optimization";
import {
  miaoShaIndexId,
  miaoShaPageId,
  isSeckillProduct,
} from "../../utils/constant";

import "./index.scss";

import Request from "../../utils/request";
import { object } from "../../../dist/npm/redux-saga/lib/internal/utils";

let isclick = true;
let timer;
let localAddress = ""; // 地址
@connect(({ productDetail, loading, confirmOrder, realName }) => ({
  ...productDetail,
  loading: loading.models.productDetail,
  orderLoading: loading.effects["confirmOrder/userConfirmOrder"], // loading.models.confirmOrder,
  userOrdersPurchaseLoading: loading.effects["confirmOrder/userOrdersPurchase"], // loading.models.confirmOrder,
  fetchAuthCodedetailLoading:
    loading.effects["productDetail/fetchAuthCodedetail"], // loading.models.confirmOrder,
  mineLoading: loading.models.mine,
  ...realName,
}))
class Productdetail extends Component {
  config = {
    navigationBarTitleText: "星动租",
    // 	navigationBarBackgroundColor : "#fff",
    //   transparentTitle:'always',
    // defaultTitle: "商品详情",
    usingComponents: {
      popup: "../../npm/mini-antui/es/popup/index",
      modal: "../../npm/mini-antui/es/modal/index",
      collapse: "../../npm/mini-antui/es/collapse/index",
      "collapse-item": "../../npm/mini-antui/es/collapse/collapse-item/index",
      // 'credit-pay': 'plugin://myPlugin/CreditPay', //信用支付组件
    },
  };
  state = {
    isShowTags: 0,
    serveiceShow: false,
    contentServer: "",
    isChecked: false,
    isToProduct: false,
    isOpenTitle: false,
    showTop: false,
    showSKUPopup: false,
    showServicePopup: false,
    showzimServicePopup: false,
    showCoupons: false,
    mainActive: "detail",
    showServicePhone: false,
    editRentDays: false,
    daysValue: null,
    input_bottom: 0,
    display: "block", // none -> 没数据隐藏
    detailes: {},
    isTagOpened: false,
    repairOrderCofigs: [],
    isActivities: false,
    activetyTimeOut: null,
    activetyTimeOut2: null,
    getCoupons: [],
    canUse: my.canIUse("lifestyle"),
    bannerList: [
      {
        channel: getGloble("channelId"),
        channelNames: null,
        createTime: "2021-04-27 18:26:17",
        deleteTime: null,
        id: 187,
        imgSrc:
          "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/112a8b6853754361b4dc900bece589a2.png",
        indexSort: 1,
        jumpUrl: "/pages/classifyAgain/index",
        name: "111",
        onlineTime: null,
        status: false,
        updateTime: null,
      },
    ],
    comentObj: {},
    guangGao_token: null,
    // freightType对照
    freightTypeObj: {
      FREE: "包邮",
      PAY: "到付",
      SELF: "自提",
    },
    // 是否为购买
    isBuy: false,
    ggId: false,
    scrollTop: 0,
    buyType: "",
    hb_fq_num: "",
    goodList: [
      {
        label: "分3期",
        value: "3",
        selected: false,
        ServiceCharge: "(含手续费)",
        noServiceCharge: "(免息)",
      },
      {
        label: "分6期",
        value: "6",
        selected: false,
        ServiceCharge: "(含手续费)",
        noServiceCharge: "(免息)",
      },
      {
        label: "分12期",
        value: "12",
        selected: false,
        ServiceCharge: "(含手续费)",
        noServiceCharge: "(免息)",
      },
    ],
    itemId: "",
    localAddress: "", // 地址
    canCel: false,
    canCelNum: null,
    stopDisabled: false,
    specsValuesTag: [],
    templateId1: "0dcd5f5612cb41c18b29827b066e0bf6",
    templateId2: "fbb81dba60424d01b1b38bb8c0e78522",
    templateId3: "9fb596d20e594d5ba8e100839b628ea8",
    Collect: false,
  };
  onPageScroll() {
    clearTimeout(timer);
    const then = this;
    const query = Taro.createSelectorQuery();
    query.select("#main").boundingClientRect();
    query.selectViewport().scrollOffset();
    timer = setTimeout(() => {
      query.exec(function(res) {
        // 如果是距离顶部的是小于等于0 时让其固定
        if (res[0].top > 0) {
          then.setState({
            showTop: false,
          });
        }
      });
    }, 100);
  }
  //   消息组件弹窗
  goCollect = () => {
    const {
      templateId1 = "0dcd5f5612cb41c18b29827b066e0bf6",
      // templateId2 = 'fbb81dba60424d01b1b38bb8c0e78522',
      // templateId3 = '9fb596d20e594d5ba8e100839b628ea8',
    } = this.state;
    // 模板id列表
    const templateList = [];
    const { dispatch } = this.props;
    const then = this;
    this.setState({
      stopDisabled: true,
    });
    templateId1 && templateList.push(templateId1);
    // templateId2 && templateList.push(templateId2)
    // templateId3 && templateList.push(templateId3)
    if (templateList.length === 0) {
      my.showToast({
        type: "fail",
        content: "0dcd5f5612cb41c18b29827b066e0bf6",
        duration: 3000,
      });
      return;
    }
    // 调用方法，唤起订阅组件
    my.requestSubscribeMessage({
      // 模板id列表，最多3个
      entityIds: templateList,
      // 接收结果的回调方法
      callback(res) {
        if (res.success) {
          const successIds = templateList
            .filter((i) => res[i.entityId] === "accept")
            .map((i) => i.entityId);
          // 订阅成功
          // my.call('toast', {
          //     content: `模板${successIds.join(',')}订阅成功`,
          //     type: 'success',
          // })
        } else {
          switch (res.errorCode) {
            case 11: {
              // my.call('toast', {
              //     // content: '用户未订阅关闭弹窗',
              // })
              break;
            }
            default: {
              // my.call('toast', {
              //     // content: `ErrorCode: ${res.errorCode}, ErrorMsg: ${res.errorMessage}`,
              // })
              break;
            }
          }
        }
        then.setState({
          stopDisabled: false,
        });
        return;
      },
    });
  };
  // 活动使用
  componentWillUnmount() {
    if (this.state.activetyTimeOut2) {
      clearTimeout(this.state.activetyTimeOut2);
      this.setState({
        activetyTimeOut2: null,
      });
    }
  }
  // 对应 onLoad
  componentWillMount = () => {
    const {
      itemId,
      buyType,
      skuId,
      type,
      is,
      [miaoShaIndexId]: indexId,
      exclusivePrice,
    } = this.$router.params;
    const { dispatch } = this.props;
    if (itemId) {
      this.setState({
        itemId,
      });
    }

    if (buyType) {
      this.setState({
        buyType,
      });
    }
    // DIRECT
    let liebao =
      type === "DIRECT"
        ? "productDetail/recommendProductDirects"
        : "productDetail/recommendproducts";

    let chaxun =
      type === "DIRECT"
        ? "productDetail/selectProductDirectDetail"
        : "productDetail/fetchProductDetail";
    // productDetail/selectProductDirectDetail
    const datas = {
      itemId,
      exclusivePrice,
    };
    if (itemId) {
      dispatch({
        type: chaxun,

        payload: exclusivePrice ? datas : { itemId },
        callback: (data) => {
          this.setState({
            detailes: data,
            // specsValuesTag:data.specs[0].values[1].secDtoLst,
            repairOrderCofigs: data.repairOrderCofigs,
          });
          dispatch({
            type: liebao,
            payload: { productId: itemId, shopId: data.shopId },
            callback: (data2) => {
              // 续租
              //if(data.productSkuses && data.productSkuses.length){
              if (
                buyType === "continue" &&
                data.productSkuses &&
                data.productSkuses.length
              ) {
                let specAll = [];
                let specAllFist = [];
                data.productSkuses.map((item, index) => {
                  if (index === 0) {
                    specAllFist = item.specAll;
                  }
                  if (Number(item.skuId) === Number(skuId)) {
                    specAll = item.specAll;
                  }
                });
                // 设置根据skuId的值
                specAll.map((item, index) => {
                  setTimeout(() => {
                    dispatch({
                      type: "productDetail/setCurrentSku",
                      payload: {
                        valueId: item.platformSpecId,
                        preId: specAllFist[index].platformSpecId, // item.platformSpecId
                      },
                    });
                  }, 0);
                });
              }
            },
          });
          umUploadHandler.seeProductDetail(data); // 在componentDidMount中 当加载到商品详情数据时，使用友盟上报 查看商品详情页面 的事件
        },
      });

      // 获取轮播图
      // productDetailApi
      //   .queryOpeIndexProductBannerList({
      //     productId: itemId,
      //   })
      //   .then((res) => {
      //     this.setState({
      //       bannerList: res.data || [],
      //     });
      //   });
      // 获取产品评价
      productDetailApi
        .queryProductEvaluationPage({
          productId: itemId,
          pageNumber: 1,
          pageSize: 1,
        })
        .then((res) => {
          let records = res.data.data.records || [];
          let comentObj = {};
          if (records && records.length) {
            comentObj = records[0];
          } else {
            comentObj = {};
          }
          this.setState({
            comentObj,
          });
        });
    }

    if (itemId && indexId) {
      // 如果是从秒杀活动来的，那么去获取商品的秒杀信息
      dispatch({
        type: "productDetail/fetchProductSpeckillDetail",
        payload: { productId: itemId, indexId },
      });
    } else {
      // reset
      dispatch({ type: "productDetail/restProductSeckillRes" });
    }
    // 页面一进来让有优惠券的显示
    const reqParams = {
      url: "hzsx/aliPay/couponCenter/getUserAlreadyGetCoupon",
      method: "GET",
      data: {
        productId: itemId,
        uid: getUid(),
      },
    };
    Request(reqParams).then((res) => {
      this.setState({
        getCoupons: res.data.data,
      });
    });
    Request({
      url: "hzsx/api/components/getSwitch",
      method: "GET",
      data: {
        channelId: getGloble("channelId"),
      },
    }).then((res) => {
      if (res.data.data.subscribeMsgSwitch == true) {
        this.setState({
          Collect: true,
        });
      }
    });
  };
  // 对应onReady
  // componentDidMount = () => {
  //  onShow
  componentDidShow = () => {
    const { timeDown2 } = this.$router.params;
    const { gg_id } = this.$router.params;
    const { itemId } = this.$router.params;
    let product_id = itemId;
    // Taro.removeStorageSync(gg_id);

    if (gg_id != undefined && gg_id != null && gg_id.length > 0) {
      // 进入条件：从外部进入 有gg_id
      this.setState({
        ggId: true,
      });
      // Taro.removeStorageSync(gg_id);

      // 获取历史缓存的gg_id
      const data = Taro.getStorageSync(gg_id);
      if (data != null && data.length > 0) {
        // 历史缓存中有数据的情况进入
        this.state.guangGao_token = JSON.parse(data);
      }

      const obj_current = {
        gg_id: gg_id,
        time: new Date(),
      };
      Taro.setStorageSync("current_gg_id", JSON.stringify(obj_current));

      if (this.state.guangGao_token == null) {
        // 没有历史缓存的情况
        //本地没有用户token和time
        Request({
          url: `hzsx/llxzu/guanggao/add_guanggao_token`,
          method: "GET",
          data: {
            product_id: product_id,
            // 此时gg_id是跳转传参
            gg_id: gg_id,
          },
        }).then((res) => {
          const token = res.data.data;
          const obj = {
            token: token,
            time: new Date(),
          };
          // 没有历史缓存 请求接口获取token和time 进行缓存
          Taro.setStorageSync(gg_id, JSON.stringify(obj));
          // 再次获取历史缓存
          const data = Taro.getStorageSync(gg_id);
          if (data != null && data.length > 0) {
            // 判断如果有token和time给guanggao_token赋值
            this.state.guangGao_token = JSON.parse(data);
          }
        });
      } else {
        // 有历史缓存
        // 如果有
        let that = this;
        Request({
          url: `/hzsx/llxzu/guanggao/set_guanggao_cont`,
          method: "GET",
          data: {
            user_token: that.state.guangGao_token.token,
          },
        }).then((res) => {
          if (gg_id) {
            if (!res.data.data) {
              Taro.removeStorageSync(gg_id);
              Request({
                url: `hzsx/llxzu/guanggao/add_guanggao_token`,
                method: "GET",
                data: {
                  product_id: product_id,
                  // 此时gg_id是跳转传参
                  gg_id: gg_id,
                },
              }).then((res) => {
                const token = res.data.data;
                const obj = {
                  token: token,
                  time: new Date(),
                };
                // 没有历史缓存 请求接口获取token和time 进行缓存
                Taro.setStorageSync(gg_id, JSON.stringify(obj));
                // 再次获取历史缓存
                const data = Taro.getStorageSync(gg_id);
                if (data != null && data.length > 0) {
                  // 判断如果有token和time给guanggao_token赋值
                  that.state.guangGao_token = JSON.parse(data);
                }
              });
            }
          }
        });
      }
    }
  };

  onPush = () => {
    my.navigateToMiniProgram({
      appId: "2018122562686742",
      path: `pages/index/index?originAppId=${getGloble(
        "appId"
      )}&newUserTemplate=KP20200528000002523213`,
    });
    this.setState({
      isActivities: false,
    });
  };
  onActiveClose = () => {
    this.setState({
      isActivities: false,
    });
  };
  allAgreement = () => {
    Taro.navigateTo({
      url: `/pages/productImg/index`,
    });
  };
  onShowSKUClicks = () => {
    // hzsx/api/order/getUserOrderTipCount  获取规定时间内下单数
    Request({
      url: "hzsx/api/order/getUserOrderTipCount",
      method: "POST",
      data: {
        uid: getUid(),
      },
    }).then((res) => {
      if (res.data.data > 0) {
        this.setState({
          canCel: true,
          canCelNum: res.data.data,
        });
      } else {
        this.onShowSKUClick(false);
      }
    });
  };
  onShowSKUClick = (isBuy) => {
    const then = this;
    //  if(then.state.Collect==true){
    //     then.goCollect()
    //   }
    // 获取地理位置
    // my.getLocation({
    //   type: '1',
    //   // cacheTimeout: '10',
    //   success(res) {
    //     const latitude = res.latitude
    //     const longitude = res.longitude
    //     convertGPSToAddress(longitude, latitude).then(response => {
    //       then.setState({
    //         localAddress: response.regeocode.formatted_address,
    //       });
    //         // that.data.form.addr = response.regeocode.formatted_address
    //         // that.setData({
    //         //   form: that.data.form
    //         // })
    //     }).catch(err => {})
    //   },
    //   fail(res){
    //     // 判断位置授权
    //     // my.getSetting({
    //     //   success: (res) => {
    //     //     let authSetting = res.authSetting
    //     //     if (authSetting['scope.userLocation']) {
    //     //       // 已授权
    //     //     } else {
    //     //       my.showModal({
    //     //         title: '您未开启地理位置授权',
    //     //         content: '是否前去授权？',
    //     //         success: res => {
    //     //           if (res.confirm) {
    //     //             my.openSetting()
    //     //           }
    //     //         }
    //     //       })
    //     //     }
    //     //   }
    //     // })
    //   }
    // })
    // convertGPSToAddress
    // if (getGloble("appTitle") === "拼租") {
    //   this.onTito();
    // } else {
    //   umUploadHandler.clickMianYaZuBtnHandler(this.state.detailes); // 使用友盟进行数据上报
    // this.setState({
    //   isBuy,
    //   showSKUPopup: true,
    // });
    // }
    umUploadHandler.clickMianYaZuBtnHandler(this.state.detailes); // 使用友盟进行数据上报
    this.setState({
      isBuy,
      showSKUPopup: true,
      isChecked: true,
    });
  };
  onSKUPopupClose = () => {
    this.setState({
      showSKUPopup: false,
      isToProduct: false,
    });
  };

  onServicePopupClose = () => {
    this.setState({ showServicePopup: false });
  };

  onShowAdditionalClick = () => {
    this.setState({ showAdditionalPopup: true });
  };
  onShowAdditionalClicks = (set) => {
    my.navigateTo({
      url: `/pages/serviceAdd/index?content=${set.content}`,
    });
  };
  handleCloseService = () => {
    this.setState({
      serveiceShow: false,
    });
  };
  onAdditionalPopupClose = () => {
    this.setState({ showAdditionalPopup: false });
  };

  componentDidShow() {
    const { type } = this.$router.params;
    if (type !== "DIRECT") this.onShowCoupons("control"); // 非直购类型的才需要加载优惠券数据
  }

  onShowCoupons = (e) => {
    const { dispatch } = this.props;
    const { itemId } = this.$router.params;

    dispatch({
      type: "home/getSysConfigByKey",
    });
    my.getSetting({
      success: (res) => {
        const phoneNumber = res.authSetting.phoneNumber;

        if (!!getUid() && !!Taro.getStorageSync("userPhone") && phoneNumber) {
          if (e !== "control") {
            this.setState({ showCoupons: true });
          }

          dispatch({
            type: "productDetail/getProductCouponList",
            payload: {
              productId: itemId,
              uid: getUid(),
            },
          });
        } else {
          // 未授权
          dispatch({
            type: "realName/getPhoneNumber",
            callback: () => {
              if (e !== "control") {
                this.setState({ showCoupons: true });
              }
              dispatch({
                type: "productDetail/getProductCouponList",
                payload: {
                  productId: itemId,
                  uid: getUid(),
                },
              });
            },
          });
        }
      },
    });
  };

  onCouponClose = () => {
    this.setState({ showCoupons: false });
  };

  onMainTabActive = (action) => {
    this.setState({
      showTop: false,
    });
    const then = this;
    const query = Taro.createSelectorQuery();
    query.select("#main").boundingClientRect();
    query.selectViewport().scrollOffset();
    query.exec(function(res) {
      // 如果是距离顶部的是小于等于0 时让其固定
      if (res[0].top <= 0) {
        my.pageScrollTo({
          selector: "#info",
          success: (data) => {
            then.setState({
              showTop: true,
            });
          },
        });
      } else {
        then.setState({
          showTop: false,
        });
      }
    });

    this.setState({ mainActive: action });
  };
  handleSkuClick = (e, i, valueId, preId, value) => {
    if (e == 1) {
      this.setState({
        isShowTags: i,
      });
    }
    const { buyType } = this.$router.params;
    const tabId =
      value &&
      value.secDtoLst.find((item, index) => {
        return item.show == true;
      });
    const ids = tabId.productSpecId;
    if (valueId === preId) {
      return;
    }
    // 续租时不允许修改
    if (buyType === "continue") {
      return;
    }
    const { dispatch } = this.props;
    // 这里多传了一个字段ids 是符合条件的第一项的productSpecId
    // 这里多传了一个字段ids 是符合条件的第一项的productSpecId
    dispatch({
      type: "productDetail/setCurrentSku",
      payload: { valueId, preId, ids },
    });
  };
  // 点击规格2 的逻辑事件
  handleSkuClickss = (e, i, valueId, preId) => {
    if (e == 1) {
      this.setState({
        isShowTags: i,
      });
    }
    const { buyType } = this.$router.params;
    if (valueId === preId) {
      return;
    }
    // 续租时不允许修改
    if (buyType === "continue") {
      return;
    }
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setCurrentSku",
      payload: { valueId, preId },
    });
  };
  // handleSkuClick= (valueId, preId) => {
  //   const { buyType } = this.$router.params;
  //   if (valueId === preId) {
  //     return;
  //   }
  //   // 续租时不允许修改
  //   if (buyType === 'continue') {
  //     return;
  //   }
  //   const { dispatch } = this.props;
  //   dispatch({
  //     type: 'productDetail/setCurrentSku',
  //     payload: { valueId, preId },
  //   });
  // };
  handleDirect = (valueId, preId) => {
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setCurrentSkus",
      payload: { valueId, preId },
    });
  };
  handleDayChange = (days) => {
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setCurrentDays",
      payload: days,
    });
  };

  handleCustomValue = (e) => {
    this.setState({ daysValue: e.target.value });
  };

  handleCustomClick = () => {
    this.setState({ editRentDays: true });
  };

  handleAdvancedClick = (day) => {
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setStartDay",
      payload: day,
    });
  };

  handleSaveServiceClick = (ser) => {
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setSaveServers",
      payload: {
        id: ser.shopAdditionalServices.id,
        price: ser.shopAdditionalServices.price,
      },
    });
  };

  handleSaveServiceClicks = (ser) => {
    const { dispatch } = this.props;
    dispatch({
      type: "productDetail/setSaveServersAdd",
      payload: {
        id: ser.id,
        price: ser.price,
      },
    });
  };
  // 跳转至产品
  onGotoProduct = (itemId) => {
    const { type } = this.$router.params;
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${itemId}&type=${type}`,
    });
  };

  handleCustomBlur = () => {
    this.setState({ editRentDays: false, input_bottom: 0 });
    const { daysValue } = this.state;
    if (daysValue) {
      const {
        detail: { minRentCycle, maxRentCycle },
        dispatch,
      } = this.props;
      let newValue = blankSpace(daysValue);
      if (newValue < minRentCycle) {
        newValue = minRentCycle;
      }
      if (newValue > maxRentCycle) {
        newValue = maxRentCycle;
      }
      this.setState({ daysValue: newValue });
      dispatch({
        type: "productDetail/setCurrentDays",
        payload: newValue,
      });
    }
  };
  gotoWhere = (where) => {
    const { detail, dispatch } = this.props;
    if (where === "shop") {
      Taro.navigateTo({ url: `/pages/shops/index?shopId=${detail.shopId}` });
    }
  };
  gotoHome = () => {
    Taro.switchTab({
      url: `/pages/home/index`,
    });
  };
  oncanCelModal = () => {
    this.onShowSKUClick(false);
    this.setState({
      canCel: false,
    });
  };
  oncanCelModals = () => {
    // this.onShowSKUClick(false)
    this.setState({
      canCel: false,
    });
  };
  onButtonClick5(e) {
    const {
      target: { dataset },
    } = e;
    this.setData({
      modalOpened5: false,
    });
    my.alert({
      title: `点击了：${JSON.stringify(dataset)}`,
      buttonText: "关闭",
    });
  }
  formSubmits = (e) => {
    // 获取用户的定位信息  不是必须定位
    this.formSubmit();
    // const then = this;
    // my.getLocation({
    //   type: '1',
    //   success(res) {
    //     const latitude = res.latitude
    //     const longitude = res.longitude
    //     convertGPSToAddress(longitude, latitude).then(response => {
    //       // then.setState({
    //       //   localAddress: response.regeocode.formatted_address,
    //       // });
    //       localAddress = response.regeocode.formatted_address;
    //       then.formSubmit();
    //     }).catch(err => {})
    //   },
    //   fail(res){
    //     localAddress = "";
    //     then.formSubmit();
    //   }
    // })
  };
  showToast(title) {
    if (title) {
      Taro.showToast({
        title,
        icon: "none",
        mask: true,
      });
    }
  }
  formSubmit = (e) => {
    const {
      dispatch,
      currentSku,
      currentDays,
      detail,
      startDay,
      saveServers,
      saveServersPrice,
      saveServersAdd,
      saveServersPriceAdd,
    } = this.props;
    const {
      itemId,
      source,
      buyType,
      skuId,
      orderId,
      type,
      credit_goodsid,
      exclusivePrice,
    } = this.$router.params;
    if (currentDays == "") {
      this.showToast("请选择租期");
      return;
    }
    const seckillObj = this.isCurrentSkuProductBelongToSeckill(); // 当前商品是否处于秒杀对象
    const obj =
      type === "DIRECT"
        ? {
            uid: getUid(),
            additionalServiceIds: [],
            repairOrderCofigsIds: saveServersAdd,
            hbPeriodNum: this.state.hb_fq_num,
            skuId: currentSku.skuId,
          }
        : {
            originalPrice: currentSku.currentCyclePrice.price,
            price: seckillObj
              ? seckillObj.price
              : currentSku.currentCyclePrice.price,
            productName: detail.name,
            skuId: currentSku.skuId,
            productId: itemId,
            duration: currentDays,
            start: formatDate(new Date(startDay), "yyyy-MM-dd"),
            end: formatDate(
              new Date(startDay + (currentDays - 1) * 24 * 3600 * 1000),
              "yyyy-MM-dd"
            ),
            num: 1,
            additionalServicesIds: [],
            repairOrderCofigsIds: saveServersAdd,
            logisticId: "",
            logisticForm: this.state.detailes.freightType,
            uid: getUid(),
            logisticForm: "1",
            from: "1",
            channelId: source,
            activityNo: getActivityCode(),
            shareCode: getshareCode(),
            buyType,
            localAddress: localAddress,
          };

    if (orderId && type === "DIRECT") {
      obj.originalOrderId = orderId;
    }

    // 下面几行都是关于秒杀商品的处理方式
    seckillObj && (obj.source = "02");
    const sourceValue = this.$router.params[miaoShaPageId];
    seckillObj && sourceValue && (obj.sourceValue = +sourceValue);

    // 续租时，需要原订单id
    if (orderId && buyType === "continue") {
      obj.originalOrderId = orderId;
      obj.skuId = skuId;
    }
    // TODO: 1.确定在调用purchase接口的时候携带了这个Purchase接口会出现什么情况
    const xiadan =
      type === "DIRECT"
        ? "confirmOrder/userOrdersPurchase"
        : "confirmOrder/userConfirmOrder";
    Taro.setStorageSync(`isShow`, 0);
    // if (getGloble('appTitle') === '拼租') {
    //   dispatch({
    //     type: 'productDetail/saveTempParam',
    //     payload: obj,
    //     callback: (res) => {
    //       if (type === 'DIRECT') {
    //         // Taro.navigateTo({
    //         //   url:
    //         //     '/pages/confirmOrder/index?buyType=' +
    //         //     buyType +
    //         //     '&originalOrderId=' +
    //         //     orderId +
    //         //     '&type=' +
    //         //     type +
    //         //     '&additionalServiceIds=' +
    //         //     JSON.stringify(saveServers) +
    //         //     '&hbPeriodNum=' +
    //         //     JSON.stringify(this.state.hb_fq_num) +
    //         //     '&skuId=' +
    //         //     currentSku.skuId,
    //         // });
    //         my.navigateToMiniProgram({
    //           appId: '2021002109683174',
    //           path:
    //             '/pages/confirmOrder/index?buyType=' +
    //             buyType +
    //             '&originalOrderId=' +
    //             orderId +
    //             '&type=' +
    //             type +
    //             '&additionalServiceIds=' +
    //             JSON.stringify(saveServers) +
    //             '&hbPeriodNum=' +
    //             JSON.stringify(this.state.hb_fq_num) +
    //             '&skuId=' +
    //             currentSku.skuId,
    //         });
    //       } else {
    //         // Taro.navigateTo({
    //         //   url:
    //         //     '/pages/confirmOrder/index?buyType=' +
    //         //     buyType +
    //         //     '&originalOrderId=' +
    //         //     orderId +
    //         //     '&type=' +
    //         //     type +
    //         //     '&data=' +
    //         //     res.data.data,
    //         // });
    //         my.navigateToMiniProgram({
    //           appId: '2021002109683174',
    //           path:
    //             '/pages/confirmOrder/index?buyType=' +
    //             buyType +
    //             '&originalOrderId=' +
    //             orderId +
    //             '&type=' +
    //             type +
    //             '&data=' +
    //             res.data.data,
    //         });
    //       }

    //       // my.navigateToMiniProgram({
    //       //   appId: '2021001168611816',
    //       //   path: '/pages/confirmOrder/index?buyType=' +
    //       //   buyType +
    //       //   '&originalOrderId=' +
    //       //   orderId +
    //       //   '&type=' +
    //       //   type+'&data='+ res.data.data,
    //       // });
    //     },
    //   });
    // } else {
    const indexId = this.$router.params[miaoShaPageId]; // before is miaoShaIndexId

    dispatch({
      type: xiadan,
      payload: obj,
      callback: (res) => {
        let gg_token = "";
        if (this.state.guangGao_token != null) {
          gg_token = this.state.guangGao_token.token;
        }

        Taro.navigateTo({
          url:
            "/pages/confirmOrder/index?buyType=" +
            buyType +
            "&originalOrderId=" +
            orderId +
            "&type=" +
            type +
            `&${miaoShaIndexId}=` +
            indexId +
            `&${isSeckillProduct}=` +
            !!seckillObj +
            `&originPrice=` +
            currentSku.currentCyclePrice.price +
            "&token=" +
            gg_token,
        });
      },
    });
    // }
  };

  gotoHome() {
    Taro.switchTab({ url: "/pages/home/index" });
  }

  handleGetCoupon = (couponId) => {
    const { dispatch } = this.props;
    const { itemId } = this.$router.params;
    dispatch({
      type: "productDetail/getCoupon",
      payload: { couponId },
      callback: () => {
        dispatch({
          type: "productDetail/getProductCouponList",
          payload: {
            productId: itemId,
            uid: getUid(),
          },
        });
      },
    });
  };

  /**
   * 领取优惠券的时候调用
   */
  handleGetCoupons = (couponId, coupon) => {
    if (coupon.bindUrl) {
      let appidAndUrl = coupon.bindUrl
        .split("alipays://platformapi/startapp?appId=")[1]
        .split("&page=");
      my.navigateToMiniProgram({
        appId: appidAndUrl[0],
        // appId为对应模板配置的小程序AppID，
        //templateId为活动进行汇总的模板ID，可以在有礼活动列表中查看
        path: appidAndUrl[1],
        success: (res) => {},
        fail: (res) => {},
      });
      return;
    }
    const { dispatch } = this.props;
    const { itemId } = this.$router.params;
    dispatch({
      type: "coupon/bindCoupon",
      payload: {
        uid: getUid(),
        phone: getTelephone(),
        templateId: couponId,
      },
      callback: () => {
        umUploadHandler.bindCouponHandler(coupon, "商品详情"); // 使用友盟上报领取优惠券的数据
        dispatch({
          type: "productDetail/getProductCouponList",
          payload: {
            productId: itemId,
            uid: getUid(),
          },
        });
      },
    });
    const reqParams = {
      url: "hzsx/aliPay/couponCenter/getUserAlreadyGetCoupon",
      method: "GET",
      data: {
        productId: itemId,
        uid: getUid(),
      },
    };
    Request(reqParams).then((res) => {
      this.setState({
        getCoupons: res.data.data,
      });
    });
  };

  onClosePhoneModal = () => {
    this.setState({ showServicePhone: false });
  };

  goInmeddiate = () => {
    Taro.switchTab({
      url: "/pages/home/index",
    });
  };
  gotodetail = (id) => {
    Taro.navigateTo({
      url: `/pages/productDetail/index?itemId=${id}`,
    });
  };
  connectService = (number) => {
    let num = String(number);
    my.makePhoneCall({ number: num });
  };
  //优惠劵更多
  GoMoreCoupon = () => {
    Taro.navigateTo({
      url: `/pages/coupon/collector`,
    });
  };

  // 是否收藏
  collect(collected, resourceId) {
    const { dispatch } = this.props;

    dispatch({
      type: "productDetail/fetchAuthCodedetail",
      callback: () => {
        const detailes = { ...this.state.detailes };
        if (collected) {
          // 取消收藏
          productDetailApi
            .cancelProductCollection({
              uid: getUid(),
              resourceId,
              resourceType: "PRODUCT",
            })
            .then(() => {
              detailes.collected = !collected;
              this.setState({
                detailes,
              });
            });

          umUploadHandler.moveGoodsToUnFavorite(this.state.detailes); // 使用友盟 进行 取消收藏行为的 数据上报
        } else {
          // 收藏
          umUploadHandler.addGoodsToFavorite(this.state.detailes); // 使用友盟进行收藏行为的数据上报
          productDetailApi
            .addProductCollection({
              uid: getUid(),
              resourceId,
              resourceType: "PRODUCT",
            })
            .then(() => {
              detailes.collected = !collected;
              this.setState({
                detailes,
              });
            });
        }
      },
    });
  }

  // 查看更多评论
  moreAssess() {
    const { itemId } = this.$router.params;

    Taro.navigateTo({
      url: `/pages/productAssess/index?itemId=${itemId}`,
    });
  }

  onShareAppMessage() {
    const { detail } = this.props;
    const { itemId } = this.$router.params;

    umUploadHandler.shareGoods(this.state.detailes); // 使用友盟上报 分享商品 的行为

    return {
      title: "分享商品",
      desc: detail.name,
      path: `pages/productDetail/index?itemId=${itemId}`,
    };
  }
  handleService = () => {
    this.setState({
      isTagOpened: true,
    });
  };
  handleClose = () => {
    this.setState({
      isTagOpened: false,
    });
  };
  handleCallService = () => {
    const { detail } = this.props;
    let num = String(detail.serviceTel);
    my.makePhoneCall({ number: num });
  };

  onGetAuthorize = (res) => {
    // console.log("666666666666666666666666666666666666")
    // let finalSignUrl; // 最终需要跳转的签署地址
    // //  小程序签署地址（设置签署平台ALIPAY时）
    // const alipaySignUrl = 'alipays://platformapi/startapp?appId=2021001152620480&page=pages/signH5/index&query=signUrl%3Dhttps%253A%252F%252Ftsign.cloud.alipay.com%252Fweb%252FhandMultifileSign%253Ftimestamp%253D1682314757165%2526flowId%253Da5a216b79ed844029e4de14477422f65%2526accountId%253DNGLDDEPSconsumerUid274817hid0d%2526sign%253Dfa64731ae19b01213a9b41f4697a3f04fd58e4a0e092fa9b4b9f683e6e915df8';
    // // if 生成的签署地址为小程序版本，需要按照以下进行处理 **/
    // finalSignUrl = getSignUrl(alipaySignUrl);

    // /* 他方小程序跳转至区块链合同小程序 */
    // my.navigateToMiniProgram({
    //   appId: '2021001152620480', // 非示例，真实小程序appId
    //   path:`pages/signH5/index?signUrl=${finalSignUrl}`, // 非示例，真实小程序签署页面地址
    //   success: (res) => {
    //     console.log(JSON.stringify(res))
    //   },
    //   fail: (res) => {
    //     console.log(JSON.stringify(res))
    //   }
    // });
    const { dispatch } = this.props;
    const then = this;
    this.setState({
      stopDisabled: true,
    });

    // my.getPhoneNumber({
    //   success: (res) => {
    //     dispatch({
    //       type: 'productDetail/fetchAuthCodedetail',
    //       callback: () => {
    //         this.formSubmits();
    //       },
    //     });
    //   },
    //   fail: () => {
    //     Taro.showToast({
    //       title: "授权失败",
    //       icon: "none",
    //       duration: 2000,
    //     });
    //   },
    // });
    dispatch({
      type: "realName/getPhoneNumber",
      callback: () => {
        then.formSubmits();
        then.setState({
          stopDisabled: false,
        });
      },
    });
  };
  // 获取formId2
  onSubmit2(e) {
    const { dispatch } = this.props;

    if (e.detail && e.detail.formId) {
      dispatch({
        type: "home/putMessageFn",
        payload: {
          formId: e.detail.formId,
          //userTemplateId: "ODc2YmIxMTBkZmZiYmRhYWJjNjliNzUxMzkyM2E5MGM="
          userBehaviorType: "COLLECTION",
        },
      });
    }
  }
  // 获取formId
  onSubmit(e) {
    const { dispatch } = this.props;
    const { itemId } = this.$router.params;
    if (e.detail && e.detail.formId) {
      dispatch({
        type: "home/putMessageFn",
        payload: {
          formId: e.detail.formId,
          // userTemplateId: "MDZiYTdkYzQ3Mzc0ZTA3NmU3MTlkZWJmNDgxNzI5MmM=",
          userBehaviorType: "LEASE",
          productId: itemId,
        },
      });
    }
  }
  onScroll = (e) => {
    const { scrollTop } = this.state;
    // 原先的逻辑是通过scrollTop滚动的值来让下面的导航固定 有个问题是不同的机子 滚动的高度是不一样的
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (scrollTop !== 0 || e.detail.scrollTop >= 0) {
        this.setState({
          scrollTop: e.detail.scrollTop,
        });
      }
    }, 100);
  };
  onChanges = (e, i) => {
    this.setState({
      hb_fq_num: e.hb_fq_num,
    });
  };
  // onGoToMore = (url) => {
  //   if (url.indexOf('alipays://') === 0) {
  //     const index = url.indexOf('appId=');
  //     const indexPage = url.indexOf('=/');
  //     const appId = url.substr(index + 6, 16);
  //     const path = url.substring(indexPage + 1, url.length);
  //     if (indexPage !== -1) {
  //       my.navigateToMiniProgram({
  //         appId,
  //         path: path,
  //       });
  //     } else {
  //       my.navigateToMiniProgram({
  //         appId,
  //       });
  //     }
  //   } else {
  //     if (url == '/SharingRentFree/sharerent/index') {
  //       let shareFun = this.onShare;
  //       shareFun && shareFun();
  //       // this.onShare();
  //     } else {
  //       Taro.navigateTo({ url });
  //     }
  //   }
  // };
  onGoToMore = (url) => {
    if (url.indexOf("alipays://") === 0) {
      redirectToOtherMiniProgram(url);
    } else {
      if (url == "/SharingRentFree/sharerent/index") {
        this.onShare();
      } else if (url == "/pages/classifyAgain/index") {
        Taro.reLaunch({ url });
      } else {
        Taro.navigateTo({ url });
      }
    }
  };
  onTabChange = (val, hb_fq_num) => {
    let goodList = this.state.goodList;
    if (goodList[val]["selected"]) {
      goodList[val]["selected"] = false;
      this.setState({
        hb_fq_num: "",
      });
    } else {
      let index = goodList.findIndex((item) => item.selected === true);

      if (index !== -1) {
        goodList[index]["selected"] = false;
        this.setState({
          hb_fq_num: "",
        });
      }
      goodList[val]["selected"] = true;
      this.setState({
        hb_fq_num,
      });
    }
    this.setState({ goodList: goodList.slice() });
  };
  onTito = () => {
    const { type } = this.$router.params;
    if (type === "DIRECT") {
      my.navigateToMiniProgram({
        appId: "2021002109683174",
        path: `pages/productDetail/index?itemId=${this.state.itemId}&is=1&type=DIRECT`,
      });
    } else {
      my.navigateToMiniProgram({
        appId: "2021002109683174",
        path: `pages/productDetail/index?itemId=${this.state.itemId}&is=1`,
      });
    }
  };
  // 判断当前所选中这个商品的SKU是否属于秒杀活动，如果属于秒杀活动的话，那么会返回该商品的秒杀对象
  isCurrentSkuProductBelongToSeckill = () => {
    const { productSeckillRes, currentSku, currentDays } = this.props;
    if (
      !productSeckillRes ||
      Object.prototype.toString.call(productSeckillRes) !== "[object Array]"
    )
      return null;
    if (!currentSku || !currentSku.skuId) return null;
    const { skuId } = currentSku; // 当前的sku
    const hitObj = productSeckillRes.find((obj) => obj.skuId == skuId);
    if (hitObj) return hitObj.days == currentDays ? hitObj : null;
    return null;
  };

  /**
   * 渲染价格，能够适用于秒杀活动
   * @param {*} isDirect : 是否表示直购
   * @param {Number} days : 租赁天数
   * @param {Boolean} showOrigin : 如果属于秒杀商品的话，是否必须显示原价1
   * @param {Boolean} showSuffix : 是否显示结尾的后缀
   * @param {string} clsName : 自定义的样式名
   */
  renderBeforeAndAfterPrice = (
    isDirect,
    days = 1,
    showOrigin = true,
    showSuffix = true,
    clsName
  ) => {
    let suffix = isDirect ? "元" : "元/天";
    !showSuffix && (suffix = "");

    const miaoshaProductObj = this.isCurrentSkuProductBelongToSeckill(); // 当前选中sku商品所对应的秒杀对象
    const { currentSku } = this.props;
    if (miaoshaProductObj) {
      // 属于秒杀商品
      let originShowPrice = numberFormat(miaoshaProductObj.originPrice * days); // 显示的原价
      let afterShowPrice = numberFormat(miaoshaProductObj.price * days); // 显示的秒杀价
      return (
        <Text className={`price-text ${clsName}`}>
          {showOrigin && (
            <Text className="origin-price">
              ¥{originShowPrice}
              {suffix}
            </Text>
          )}
          ¥{afterShowPrice}
          {suffix}
        </Text>
      );
    }

    // 非秒杀商品的处理，如果不是秒杀的话，那么商品的显示价格所取字段 和 是否是直购商品有关
    let showPrice;
    if (isDirect) {
      showPrice = currentSku && currentSku.salePrice; // 直购商品直接取salePrice
    } else {
      // 非直购商品所取的字段
      showPrice = Number(
        currentSku &&
          currentSku.currentCyclePrice &&
          currentSku.currentCyclePrice.price
      ).toFixed(2);
    }
    showPrice = numberFormat(showPrice * days);
    // this.setState({
    //  monthlyRent:numberFormat((showPrice*365)/12)
    // })

    return (
      <Text className={`price-text ${clsName}`}>
        ¥{showPrice}
        {suffix}
      </Text>
    );
  };

  // 获取租赁的天数
  getRentDays = () => {
    const { currentSku } = this.props;
    const days =
      currentSku &&
      currentSku.currentCyclePrice &&
      currentSku.currentCyclePrice.days;
    return days || 1;
  };

  // 显示商品的价格
  returnShowPrice = () => {
    let { miaoshaPrice } = this.$router.params;
    miaoshaPrice = Number(miaoshaPrice);
    if (miaoshaPrice && !Number.isNaN(miaoshaPrice)) {
      // 表明这是从秒杀页面点进来的
      return miaoshaPrice.toFixed(2);
    } else {
      // 非秒杀商品，按照原有
      const { detailes } = this.state;
      return detailes.lowestSalePrice && detailes.lowestSalePrice.toFixed(2);
    }
  };
  checkFollowCb = (e) => {};
  // 根据用户芝麻信用情况给予押金减免。
  handleOpenTitle = () => {
    this.setState({
      isOpenTitle: true,
    });
  };

  handleCloseOpen = () => {
    this.setState({
      isOpenTitle: false,
    });
  };
  toProduct = () => {
    this.setState({
      showSKUPopup: true,
      isToProduct: true,
      isChecked: true,
    });
  };

  handleFormSubmits = (e) => {
    this.setState({
      showSKUPopup: false,
      isToProduct: false,
    });
  };
  imgName = () => {
    Taro.showToast({
      title:
        "划线价：由商家提供，与实时标价比较，并非原价，该划线价可能是商品/服务的门市价、建议零售价、品牌指导价、历史标价中的一项（划线价可能会与实际展示的价格不一致，该价格仅供参考）。",
      icon: "none",
      width: "300px",
    });
  };
  render() {
    const {
      isChecked,
      isToProduct,
      isOpenTitle,
      scrollTop,
      showTop,
      showzimServicePopup,
      comentObj,
      bannerList,
      showSKUPopup,
      freightTypeObj,
      showServicePopup,
      showServicePhone,
      showCoupons,
      showAdditionalPopup,
      mainActive,
      editRentDays,
      daysValue,
      display,
      isTagOpened,
      detailes,
      canCel,
      canCelNum,
      canUse,
      ggId,
      getCoupons,
      repairOrderCofigs,
      stopDisabled,
      contentServer,
      serveiceShow,
      isShowTags,
      specsValuesTag,
    } = this.state;
    const {
      loading,
      orderLoading,
      mineLoading,
      fetchAuthCodedetailLoading,
      userOrdersPurchaseLoading,
      currentSku,
      oldNewDegreeList,
      serviceMarkList,
      currentDays,
      advancedDays,
      startDay,
      saveServers,
      saveServersPrice,
      saveServersAdd,
      saveServersPriceAdd,
      recommendproductsList,
      images_ismain,
      processRule,
      productCoupon,
      productCoupons,
    } = this.props;
    const { c_buttonss } = [
      { text: "取消" },
      { text: "主操作", extClass: "buttonBold" },
    ];
    let customerServiceTel = getServicePhone();

    if (currentSku.cycs && currentSku.cycs.length > 2) {
      currentSku.cycs &&
        currentSku.cycs.sort(function(a, b) {
          return a.days - b.days;
        });
    }
    // 租期选项
    let currentValidCyclePrices = [];
    // 按最大，最小租期过滤租期选项
    if (currentSku.cycs && currentSku.cycs.length) {
      currentValidCyclePrices = currentSku.cycs.filter(function(info) {
        return info.days > 0; // info.days >= detailes.minRentCycle && info.days <= detailes.maxRentCycle;
      });
    }
    currentValidCyclePrices = currentValidCyclePrices.sort(
      compare("days", true)
    );
    let totelRentPrice = 0;
    if (currentSku.cycs && currentSku.cycs.days && currentSku.cycs.price) {
      totelRentPrice = (currentDays * currentSku.cycs.price).toFixed(2);
    }
    let couponValue = 0;
    if (!!detailes.allCoupons && !!detailes.allCoupons.length) {
      couponValue = detailes.allCoupons[0].value.toFixed(2);
    } else if (detailes.platformCoupon && detailes.platformCoupon.length) {
      couponValue = detailes.platformCoupon[0].value.toFixed(2);
    }
    let input_bottom = this.state.input_bottom;
    //    重新封装一个获取特定数量的小标签
    let labels = detailes.labels;
    let userLabs = [];
    if (labels && labels.length > 3) {
      userLabs.push(labels[0]);
      userLabs.push(labels[1]);
      userLabs.push(labels[2]);
    } else {
      if (labels && labels.length > 0) {
        labels.forEach((e) => {
          userLabs.push(e);
        });
      }
    }
    // 最低的官方售价
    let minMarketPrice = 99999;
    if (detailes.productSkuses && detailes.productSkuses.length) {
      detailes.productSkuses.forEach((item) => {
        if (item.marketPrice < minMarketPrice) {
          minMarketPrice = item.marketPrice;
        }
      });
    }
    const { type } = this.$router.params;
    // orderLoading ||
    // mineLoading ||
    // fetchAuthCodedetailLoading ||
    // userOrdersPurchaseLoading
    //   ? my.showLoading({ content: '加载中...' })
    //   : my.hideLoading();
    return (
      <View
        className="productDetail-page"
        // scrollY
        // scrollWithAnimation
        // scrollTop="0"
        // onScroll={this.onScroll}
      >
        <View style={{ background: "#fff" }}>
          {canUse ? (
            <lifestyle
              onFollow
              public-id="2021002119692059"
              memo="关注生活号,快速审核极速发货"
              className="lifeStyle"
            />
          ) : null}
          {/* <Text className="tiels_text">
            <Image
              lazy-load={true}
              className="tiels_img"
              mode="aspectFit"
               src="http://img.llxzu.com/image/onlife.png" 
            />
            <View>
              <View>{getGloble('appTitle')} - 生活号</View>
              <View className="onlife-bottom">
                          <View class="onlife-bottom-life">关注生活号</View>
                          <View class="onlife-bottom-btn">优先审核</View>
                          <View class="onlife-bottom-btn">极速发货</View>
                      </View>
            </View>
          </Text>
          {canUse ? (
            <life-follow  sceneId='3b6c88c21fad41f9a21a20f6ece5901b' />
          ) : null} */}
        </View>
        {/* <View  className="onlife">
            <View className="onlife-left">
                  <View className="onlife-image">
                      <Image src="http://img.llxzu.com/image/onlife.png" className="onlife-left-img" />
                  </View>
                  <View className="onlife-text">
                      <View className="onlife-life">星动租-生活号</View>
                      <View className="onlife-bottom">
                          <View class="onlife-bottom-life">关注生活号</View>
                          <View class="onlife-bottom-btn">优先审核</View>
                          <View class="onlife-bottom-btn">极速发货</View>
                      </View>
                  </View>
               </View>
            <View className="onlife-right">
               {getGloble('sceneId') ? (
                        <life-follow sceneId='3b6c88c21fad41f9a21a20f6ece5901b'  />
                    ) : null}
                </View>
            </View> */}
        <View className="swiper">
          <swiper circular indicator-dots indicator-active-color="#DBDBDB">
            {!!detailes.images &&
              !!detailes.images.length &&
              detailes.images.map((img) => (
                <swiper-item key={img.src}>
                  <View className="item">
                    <Image
                      lazyLoad={true}
                      className="img"
                      mode="aspectFit"
                      src={img.src}
                    />
                  </View>
                </swiper-item>
              ))}
          </swiper>
        </View>
        <View className='swiper_tips2'>
            <Image className='img' src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/890a7f236fa44d929d61e481fce3db4d.png"></Image>
            <View className='swiper_name'>芝麻信用·免押金·租用无压力</View>
            <View></View>
           </View>
     
        {/* {type === 'DIRECT' ? null : (
          <View className="swiper-tips2">
            <Image
              lazyLoad={true}
              className="img"
            />
          </View>
        )} */}

        <View className="info-area">
          <View className="price-info">
            <View className="price">
              <Text className="unit">
                <Text className="unit-red">
                  <Text style={{ fontSize: "18px" }}>¥</Text>

                  {this.returnShowPrice()}
                  {/* {detailes.lowestSalePrice &&
                        detailes.lowestSalePrice.toFixed(2)} */}
                </Text>
                <Text style={{ fontSize: "18px" }}>
                  {type === "DIRECT" ? "元起" : "元/天"}
                </Text>
              </Text>
              <Text className="price_decoration">
                  {(this.returnShowPrice() * 1.3).toFixed(2)}元/天
                  <Image
                    onClick={this.imgName.bind(this)}
                    className="price_img"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6ef2379db6994fbca7f8faaafe3e25ab.png"
                  ></Image>
                </Text>

              {/* <Text className="mark">
                {this.returnShowPrice()
                  ? "原价" + (this.returnShowPrice() * 1.3).toFixed(2)
                  : ""}
                  {" "}
              </Text> */}
              {/* <Text className="mark">官方售价{minMarketPrice}元起</Text> */}
            </View>

            {/* <View className="sales-volume">
                  已售{detailes.salesVolume || 0}
                </View> */}
            {/* <Button  scope="userInfo"
                      open-type="getAuthorize"
                      scope="phoneNumber"
                      onGetAuthorize={this.onShowCoupons}  
                      className="price-coupon">
                          去领券
                </Button> */}
            <View className="item">
              <View className="share-img" />
              <button className="share-img-btn" open-type="share"></button>
            </View>
          </View>
          <View>
            <Button
              scope="userInfo"
              open-type="getAuthorize"
              scope="phoneNumber"
              onGetAuthorize={this.onShowCoupons}
              className="price-coupon"
            >
              <Text>店铺券</Text>
              <Text>领取</Text>
            </Button>
          </View>
          {detailes && detailes.name && (
            <View>
              <View className="name">
                {oldNewDegreeList[detailes.oldNewDegree - 1] && (
                  <Text className="new-tags">
                    {oldNewDegreeList[detailes.oldNewDegree - 1]}
                  </Text>
                )}
                {detailes.name}
              </View>
              <View className="title">
                <Text className="product-box">
                  {!!userLabs &&
                    !!userLabs.length &&
                    userLabs.map((item, index) => (
                      <Text className="oldNewDegree" key={"label" + index}>
                        {item}
                      </Text>
                    ))}
                </Text>
                {/* <View className="share-img-view">
                  <Image
                    className="share-img"
                  />
                  <button className="share-img-btn" open-type="share"></button>
                </View> */}
              </View>
            </View>
          )}
        </View>
        {/* <View className="receive-info">
            <View className='receive-info-bottom'>
                <View className='receive-info-bottom-box' onClick={this.allAgreement}>
                    <Text className='receive-info-bottom-box-text'>查看&gt;</Text>
                </View>
                <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/cfb84be5274e49c092aaa6be90508304.png" className="receive-info-bottom-img" />
            </View>
        </View> */}
        <View className="receive-info">
          <View className="receive-info-deliver">
            <View className="receive-info-deliver-title">已选 </View>
            <View className="receive-info-deliver-dec" onClick={this.toProduct}>
              {isChecked == true ? (
                <Text>
                  {currentSku.specAll &&
                    currentSku.specAll.map(
                      (value) => `${value.platformSpecValue}`
                    )}
                  {currentDays ? currentDays + "天" : ""}
                </Text>
              ) : (
                <Input
                  className="receive-info-deliver-input"
                  disabled="disabled"
                  placeholder="请选择租期;自定义规格"
                />
              )}
              <View className="spot" />
            </View>
          </View>
          <View className="receive-info-deliver">
            <View className="receive-info-deliver-title">发货 </View>
            <View className="receive-info-deliver-dec">
              {detailes.city} |{" "}
              {type === "DIRECT"
                ? detailes.freightType
                : freightTypeObj[detailes.freightType] || ""}
              | 归还自付
            </View>
          </View>

          {!!getCoupons && !!getCoupons.length > 0 ? (
            <View className="receive-info-deliver">
              <View className="receive-info-deliver-title">优惠券 </View>
              <View className="receive-info-deliver-dec">
                <View className="receive-info-deliver-dec-con">
                  {/* <Image src="http://img.llxzu.com/image/coupon.png" className="coupons"/> */}
                  {/* 增加延期券的逻辑 */}
                  {getCoupons[0].scene == "DELAYED" ? (
                    <View className="name">
                      {getCoupons[0].minLease > 0 ? (
                        <Block>
                          满{getCoupons[0].minLease}天延
                          {getCoupons[0].delayDays} 天
                        </Block>
                      ) : (
                        <Block>
                          满{getCoupons[0].minAmount}元延
                          {getCoupons[0].delayDays} 天
                        </Block>
                      )}
                    </View>
                  ) : (
                    <View className="name">
                      {getCoupons[0].minLease > 0 ? (
                        <Block>
                          满{getCoupons[0].minLease}天减
                          {getCoupons[0].discountAmount} 元
                        </Block>
                      ) : (
                        <Block>
                          满{getCoupons[0].minAmount}元减
                          {getCoupons[0].discountAmount} 元
                        </Block>
                      )}
                    </View>
                  )}
                </View>
              </View>
            </View>
          ) : (
            <View className="receive-info-deliver">
              <View className="receive-info-deliver-title">优惠券 </View>
              <View className="receive-info-deliver-dec">
                <View
                  style={{ color: "#999999" }}
                  className="receive-info-deliver-dec-con"
                >
                  暂无可使用的优惠券
                </View>
              </View>
            </View>
          )}
        </View>
        {/* 轮播图区域 */}
        {/* <View className="swiper-two">
              <swiper circular indicator-dots indicator-active-color="#DBDBDB" autoplay="{{true}}" interval="{{3000}}">
                {!!bannerList &&
                  !!bannerList.length &&
                  bannerList.map((img) => (
                    <swiper-item key={img.imgSrc}>
                      <View
                        className="product-banner"
                        onClick={this.onGoToMore.bind(this, img.jumpUrl)}
                      >
                        <Image
                          lazyLoad={true}
                          className="img"
                          mode="aspectFit"
                          src={img.imgSrc}
                        />
                      </View>
                    </swiper-item>
                  ))}
              </swiper>
         </View> */}
        <View className="main-area" id="main">
          {/* 此处注销的是原先的逻辑 */}
          {/* <View className={'tab ' + (scrollTop >630 ? 'tab-fixed' : '')}> */}
          <View className="tab">
            <View
              className={`item ${mainActive === "detail" && "active-item"}`}
              onClick={this.onMainTabActive.bind(this, "detail")}
            >
              <View>商品详情</View>
              {mainActive === "detail" && <View className="active-line" />}
            </View>
            <View className="dividing" />
            <View
              className={`item ${mainActive === "problem" && "active-item"}`}
              onClick={this.onMainTabActive.bind(this, "problem")}
            >
              <View>常见问题</View>
              {mainActive === "problem" && <View className="active-line" />}
            </View>
            {/* <View
              className={`item ${mainActive === "rent" && "active-item"}`}
              onClick={this.onMainTabActive.bind(this, "rent")}
            >
              <View>商品参数</View>
              {mainActive === "rent" && <View className="active-line" />}
            </View> */}
            {type === "DIRECT" ? null : (
              <View
                className={`item ${mainActive === "rule" && "active-item"}`}
                onClick={this.onMainTabActive.bind(this, "rule")}
              >
                <View>租赁流程</View>
                {mainActive === "rule" && <View className="active-line" />}
              </View>
            )}
          </View>
          <View className={showTop == true ? "showInfo" : "info"} id="info">
            {/* {mainActive === 'deliver' && (
              <Fragment>
                <View className="info-deliver-c">
                  <View className="info-deliver-c-title">
                    <Text className="info-deliver-c-title-l">用户评论</Text>
                    {comentObj.content && (
                      <Text
                        className="info-deliver-c-title-r"
                        onClick={() => this.moreAssess()}
                      >
                        查看更多 {'>'}
                      </Text>
                    )}
                  </View>
                  {comentObj.content ? (
                    <View className="info-deliver-c-content">
                      <View className="info-deliver-c-content-top">
                        <View className="info-deliver-c-content-top-l">
                          <Image
                            className="user-img"
                            src={
                              comentObj.userIcon ||
                            }
                          />
                          <Text>
                            <Text className="user-name">
                              {comentObj.userName}
                            </Text>
                            <Text className="user-time">
                              {comentObj.createTime}
                            </Text>
                          </Text>
                        </View>
                        <View className="info-deliver-c-content-top-r">
                          {[1, 2, 3, 4, 5].map((item, index) => {
                            return item <= comentObj.starCount ? (
                              <Image
                                key={'star' + index}
                                className="star-img"
                              />
                            ) : (
                              <Image
                                key={'star' + index}
                                className="star-img"
                              />
                            );
                          })}
                        </View>
                      </View>
                      <View className="info-deliver-c-content-bottom">
                        <View className="user-text">{comentObj.content}</View>
                        {!!comentObj.images && !!comentObj.images.length ? (
                          <View className="user-img">
                            {comentObj.images.map((itemImg) => (
                              <Image
                                mode="aspectFit"
                                key={itemImg.id}
                                className="user-img-item"
                                src={itemImg.imageUrl}
                              />
                            ))}
                          </View>
                        ) : (
                          ''
                        )}
                      </View>
                    </View>
                  ) : (
                    <View
                      className="info-deliver-c-content"
                      style={{ textAlign: 'center' }}
                    >
                      暂无评论
                    </View>
                  )}
                </View>
              </Fragment>
            )} */}
            {mainActive === "detail" && (
              <ParseComponent mark={detailes.detail} />
            )}
            {mainActive === "problem" && (
              <View className="problem-img">
                <Image
                  className="img h2"
                  src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0c9cf4c9a04245e88343d14492cb84c4.png"
                />
              </View>
            )}
            {mainActive === "rent" && (
              <View className="rent-content">
                <View className="rent-title">商品参数</View>
                <View className="rent-table">
                  <View className="rent-table-title">
                    {!!detailes.parameters && !!detailes.parameters.length > 0
                      ? "主要参数"
                      : "详见详情页"}
                  </View>
                  {!!detailes.parameters &&
                    !!detailes.parameters.length &&
                    detailes.parameters.map((item, index) => (
                      <View className="rent-table-content" key={"rent" + index}>
                        <View>{item.name}</View>
                        <View>{item.value}</View>
                      </View>
                    ))}
                </View>
              </View>
            )}
            {mainActive === "rule" && (
              <View className="rule-img">
                <Image
                  className={
                    "img " + (detailes.buyOutSupport === 1 ? "h1" : "")
                  }
                  src={
                    detailes.buyOutSupport === 1
                      ? "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6213463f4d5a4ad9abbf129a9e666cf1.png"
                      : "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6213463f4d5a4ad9abbf129a9e666cf1.png"
                  }
                />
              </View>
            )}
          </View>
        </View>
        {mainActive === "deliver" && (
          <Fragment>
            <View className="detail">
              <View className="detail-title">商品详情</View>
              <View className="detail-content">
                <ParseComponent mark={detailes.detail} />
              </View>
              <View
                className="detail-more"
                onClick={this.onMainTabActive.bind(this, "detail")}
              >
                查看更多详情<Text>{`>>`}</Text>
              </View>
            </View>
          </Fragment>
        )}
        <View className="up-for-you">
          <View className="up-title">为你推荐</View>
          <View className="up-content">
            <Channel
              formType="submit"
              products={recommendproductsList}
              onGotoProduct={this.onGotoProduct}
            />
          </View>
        </View>
        <View className="no-more">没有更多啦，快去挑选商品吧～</View>
        <View className="footer-area">
          <View className="left-area">
            {/* <View className="item" onClick={this.gotoWhere.bind(this, 'shop')}>
              <View className="shop-img" />
              <View>店铺</View>
            </View> */}
            <View className="item" onClick={this.gotoHome}>
              <View className="home-to" />
              <View>首页</View>
            </View>
            <View className="item" onClick={this.handleService}>
              <View className="message-img" />
              <View>客服</View>
            </View>
            {type === "DIRECT" ? null : (
              <View className="item item-collect">
                {detailes.collected ? (
                  <View className="home-star-img" />
                ) : (
                  <View className="home-img" />
                )}
                <View>收藏</View>
                <Button
                  className="collect-btn"
                  open-type="getAuthorize"
                  onGetAuthorize={() =>
                    this.collect(detailes.collected, detailes.productId)
                  }
                  scope="userInfo"
                ></Button>
              </View>
            )}
            {/* <View className="item" >
              <View className="share-img" />
              <View>分享</View>
               <button className="share-img-btn" open-type="share"></button>
            </View> */}
          </View>
          <View className="right-area">
            <form onSubmit={(e) => this.onSubmit(e)} report-submit="true">
              <Button
                className="red-botton"
                formType="submit"
                // onClick={() => this.onShowSKUClicks(false)}
                onClick={() => this.onShowSKUClick(false)}
              >
                {type === "DIRECT" ? "立即买" : "去下单"}
              </Button>
            </form>
            <modal
              show={canCel}
              // buttons={ c_buttonss }
              // showClose={false}
              // onButtonClick={this.oncanCelModal}
              onModalClick={this.oncanCelModal}
              onModalClose={this.oncanCelModals}
              // buttons= {[
              //   { text: '取消' },
              //   { text: '主操作', extClass: 'buttonBold' },
              // ]}
            >
              <view slot="header">温馨提示！</view>
              <view slot="footer">确定</view>
              您当前已下{canCelNum}单了，是否继续下单？
            </modal>
          </View>
        </View>
        <popup
          show={showServicePopup}
          position="bottom"
          zIndex={999}
          disableScroll
          onClose={this.onServicePopupClose}
        >
          <View className="service-popup">
            <View className="service-popup-title">服务说明</View>
            <View className="service-popup-content">
              <View className="service-popup-content-item">
                <View className="service-popup-content-item-type">
                  芝麻信用免押金
                </View>
                <View>根据用户芝麻信用情况给予押金减免</View>
              </View>
              {!!detailes.serviceMarks &&
                !!detailes.serviceMarks.length &&
                detailes.serviceMarks.map((service) => (
                  <View className="service-popup-content-item" key={service.id}>
                    <View className="service-popup-content-item-type">
                      {serviceMarkList[service.type]}
                    </View>
                    <View>{service.description}</View>
                  </View>
                ))}
            </View>
            <View
              className="service-popup-close"
              onClick={this.onServicePopupClose}
            >
              关闭
            </View>
          </View>
        </popup>
        <View className="coupon-popup">
          <AtFloatLayout
            isOpened={showCoupons}
            style={{ zIndex: "1" }}
            onClose={this.onCouponClose}
            className="product-float"
          >
            <ScrollView
              scrollY
              scrollTop="0"
              scrollWithAnimation
              onScroll={this.onScroll}
              className="coupon-popup-content"
            >
              {!!productCoupons && !!productCoupons.length > 0 ? (
                //  <Optimization
                // onGotoTake={id => this.handleGotoTake(id)}
                // key={coupon.id}
                // type='red'
                // isNew={coupon.couponTemplateId === 1}
                // data={coupon}
                // />
                <Block>
                  {!!productCoupons &&
                    !!productCoupons.length &&
                    productCoupons.map((coupon) => (
                      <View
                        className={"coupon-popup-content-item "}
                        key={coupon.id}
                      >
                        <View className="box">
                          <View className="box2">
                            <View className="item">
                              <View className="li">{coupon.title}</View>
                              <View className="dec">
                                {coupon.delayDayNum
                                  ? `有效期${coupon.delayDayNum}日`
                                  : `${
                                      coupon.startTime
                                        .split(" ")[0]
                                        .split("-")[1]
                                    }.${
                                      coupon.startTime
                                        .split(" ")[0]
                                        .split("-")[2]
                                    }-${
                                      coupon.endTime.split(" ")[0].split("-")[1]
                                    }.${
                                      coupon.endTime.split(" ")[0].split("-")[2]
                                    }有效`}{" "}
                              </View>
                              <View className="destr">{coupon.rangeStr}</View>
                            </View>
                          </View>
                          <View className="num">
                            {coupon.scene == "DELAYED" ? (
                              <Text style={{ position: "relative" }}>
                                <Text className="price">
                                  {" "}
                                  {coupon.delayDays}
                                </Text>
                                <Text className="bol">天</Text>
                              </Text>
                            ) : (
                              <Text>
                                <Text className="bol">¥</Text>
                                <Text className="price">
                                  {" "}
                                  {coupon.discountAmount}
                                </Text>
                              </Text>
                            )}
                            <View className="titlecoupon">
                              {coupon.minAmount > 0 ? (
                                <Block>
                                  {coupon.minLease > 0 ? (
                                    <Block>满{coupon.minLease}天可用</Block>
                                  ) : (
                                    <Block>满{coupon.minAmount}元可用</Block>
                                  )}
                                </Block>
                              ) : (
                                <Block>无门槛</Block>
                              )}
                            </View>
                            <View className="btn">
                              {coupon.isCanGet == true ? (
                                <Text
                                  className="get-now"
                                  onClick={this.handleGetCoupons.bind(
                                    this,
                                    coupon.templateId,
                                    coupon
                                  )}
                                >
                                  立即领取
                                </Text>
                              ) : (
                                <Text className="to-use">已领取</Text>
                              )}
                            </View>
                          </View>
                        </View>
                      </View>
                    ))}
                </Block>
              ) : (
                <View style={{ margin: "auto 18px", fontSize: "16px" }}>
                  优惠券已抢完啦，关注我们期待下次活动{" "}
                </View>
              )}
              {/* {
                    !!productCoupons &&
                            !!productCoupons.length>0?(
                                <Block>
                                       {!!productCoupons &&
                            !!productCoupons.length &&
                            productCoupons.map((coupon) => (
                            <View
                                className={
                                'coupon-popup-content-item ' +
                                (coupon.bind ? 'coupon-popup-content-item2' : '')
                                }
                                key={coupon.id}
                            >
                                <View className="coupon-popup-content-item-left">
                                <View>
                                    {coupon.scene=='DELAYED'?(
                                    <Text className="coupon-popup-content-item-price" style={{position:'relative'}}>
                                    <Text style={{position:'absolute',fontSize:'19px',top:'9px',left:'45px'}} >天</Text>
                                    {coupon.delayDays}
                                    </Text>):(<Text className="coupon-popup-content-item-price">
                                    <Text className="bol">¥</Text>
                                    {coupon.discountAmount}
                                    </Text>)}
                                </View>
                                </View>
                                <View className="coupon-popup-content-item-right">
                                <View className="coupon-popup-content-item-right-content">
                                    <View className="coupon-popup-content-item-right-content-dec">
                                    {coupon.title}
                                    </View>
                                    <View>
                                    {coupon.limitTimeStr && (
                                        <View className="coupon-popup-content-item-right-content-time">
                                        {coupon.delayDayNum
                                            ? `有效期${coupon.delayDayNum}日`
                                            : `${
                                                coupon.startTime.split(' ')[0].split('-')[1]
                                            }.${
                                                coupon.startTime.split(' ')[0].split('-')[2]
                                            }-${
                                                coupon.endTime.split(' ')[0].split('-')[1]
                                            }.${
                                                coupon.endTime.split(' ')[0].split('-')[2]
                                            }有效`}{' '}
                                        | {coupon.rangeStr}
                                        </View>
                                    )}
                                    </View>
                                </View>
                                <View>
                                    {coupon.isCanGet==true ? (
                                    <View
                                        className="coupon-popup-content-item-right-draw"
                                        onClick={this.handleGetCoupons.bind(
                                        this,
                                        coupon.templateId,
                                        coupon,
                                        )}
                                    >
                                        立即领取
                                    </View>
                                    ) : (
                                    <View className="coupon-popup-content-item-right-draw coupon-popup-content-item-right-draw-al">
                                        已领取
                                    </View>
                                    )}
                                </View>
                                </View>
                            </View>
                            ))}
                                </Block>
                            ):(<View style={{margin:'auto 18px',fontSize:'16px'}}>优惠券已抢完啦，关注我们期待下次活动 </View>)
                } */}

              {/* {!!productCoupon &&
                            !!productCoupon.platformCoupon &&
                            !!productCoupon.platformCoupon.length > 0 &&
                            productCoupon.platformCoupon.map((coupon) => (
                            <View className="coupon-popup-content-item" key={coupon.id}>
                                <View className="coupon-popup-content-item-left">
                                <View>
                                    <Text className="coupon-popup-content-item-price">
                                    <Text className="bol">¥</Text>
                                    {coupon.value}
                                    </Text>
                                </View>
                                <View className="coupon-popup-content-item-name">
                                    {coupon.name}
                                </View>
                                </View>
                                <View className="coupon-popup-content-item-right">
                                <View className="coupon-popup-content-item-right-content">
                                    <View className="coupon-popup-content-item-right-content-name">
                                    平台劵
                                    </View>
                                    <View className="coupon-popup-content-item-right-content-dec">
                                    满{coupon.minPurchase}-{coupon.value}
                                    </View>
                                    {coupon.type === 0 && (
                                    <View>
                                        {!!coupon.end && (
                                        <View className="coupon-popup-content-item-right-content-time">
                                            {coupon.start.substr(0, 10)}~
                                            {coupon.end.substr(0, 10)}
                                        </View>
                                        )}
                                    </View>
                                    )}
                                </View>
                                <View>
                                    {coupon.status === 0 ? (
                                    <View
                                        className="coupon-popup-content-item-right-draw"
                                        onClick={this.handleGetCoupon.bind(
                                        this,
                                        coupon.couponId,
                                        )}
                                    >
                                        立即领取
                                    </View>
                                    ) : (
                                    <View className="coupon-popup-content-item-right-draw coupon-popup-content-item-right-draw-al">
                                        已领取
                                    </View>
                                    )}
                                </View>
                                </View>
                            </View>
                            ))}
                        {productCoupon &&
                            !productCoupon.shopCoupon.length &&
                            !productCoupon.platformCoupon.length && (
                            <NoData
                                className="NoData"
                                type="receive-coupon"
                                display={display}
                            />
                            )} */}
            </ScrollView>
            <View className="close-btn">
              <Button onClick={this.onCouponClose}>关闭</Button>
            </View>
          </AtFloatLayout>
        </View>
        {/** 直购商品和租赁商品都有这个 */}
        <View catchtouchmove="filterViewMove">
          {type === "DIRECT" ? (
            <View className="popup-sku">
              <AtFloatLayout
                isOpened={showSKUPopup}
                onClose={this.onSKUPopupClose}
                scrollY={false}
                style={{ zIndex: "1" }}
                className="product-float"
              >
                <View
                  className="popup-sku-close"
                  onClick={this.onSKUPopupClose}
                >
                  <Image
                    className="popup-sku-close-img"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/cb88f80a3fb3403d847fa62ad4de6261.png"
                  />
                </View>
                <View className="popup-sku-header">
                  <View className="popup-sku-header-img">
                    <Image
                      className="img"
                      src={
                        currentSku.specAll[0].image || detailes.images[0].src
                      }
                    />
                  </View>
                  <View className="popup-sku-header-dec">
                    {/* <View className="price-name">{detailes.name}</View> */}
                    <View className="sku-info">
                      已选
                      {currentSku.specAll &&
                        currentSku.specAll.map(
                          (value) => `${value.platformSpecValue}`
                        )}
                      天
                    </View>
                    <View className="price-name">{detailes.name}</View>

                    <View className="price-day">
                      <Text className="unit-text">{"总金额"}</Text>
                      {this.renderBeforeAndAfterPrice(true)}
                    </View>
                  </View>
                </View>
                <View className="popup-bottom">
                  <View className="area-scroll">
                    <ScrollView
                      scrollY
                      scrollTop="0"
                      scrollWithAnimation
                      className="content-area"
                    >
                      <View className="sku-area">
                        {!!detailes.specs &&
                          !!detailes.specs.length &&
                          detailes.specs.map((spec, i) => (
                            <View className="item" key={spec.id}>
                              <View className="item-text">{spec.name}</View>
                              <View className="item-tags">
                                {!!spec.values &&
                                  !!spec.values.length &&
                                  spec.values.map((value) => (
                                    <View
                                      onClick={this.handleDirect.bind(
                                        this,
                                        value.productSpecId,
                                        currentSku.specAll[i].platformSpecId
                                      )}
                                      className={`tag ${!!currentSku.specAll &&
                                        currentSku.specAll[i].platformSpecId ===
                                          value.productSpecId &&
                                        "tag-active"}`}
                                      key={value.productSpecId}
                                    >
                                      {value.name}
                                    </View>
                                  ))}
                              </View>
                            </View>
                          ))}
                      </View>

                      {/* <View className="sku-area">
                      <View className="item">
                        {!!detailes.additionals &&
                          !!detailes.additionals.length && (
                            <Fragment>
                              <View className="item-text save-server">
                                <View className="title">
                                  <View>
                                    增值服务{' '}
                                    <Text className="text">(非必选)</Text>
                                  </View>
                                  <View>
                                    <Image
                                      className="img"
                                      onClick={this.onShowAdditionalClick}
                                    />
                                  </View>
                                </View>
                              </View>
                              <View className="item-tags-server">
                                {detailes.additionals.map((ser) => (
                                  <View
                                    key={ser.shopAdditionalServices.id}
                                    className={`tag-server ${
                                      saveServers.findIndex(
                                        (id) =>
                                          id === ser.shopAdditionalServices.id,
                                      ) > -1 && 'tag-server-active'
                                    }`}
                                    onClick={this.handleSaveServiceClick.bind(
                                      this,
                                      ser,
                                    )}
                                  >
                                    {ser.name}
                                    <View className="choice">
                                      <View>
                                        {`${ser.shopAdditionalServices.name} ￥${ser.shopAdditionalServices.price}元`}
                                      </View>
                                      <View>
                                        <Image
                                          className="img"
                                          src={
                                            saveServers.findIndex(
                                              (id) =>
                                                id ===
                                                ser.shopAdditionalServices.id,
                                            ) > -1
                                              ? ''
                                              : ''
                                          }
                                        />
                                      </View>
                                    </View>
                                  </View>
                                ))}
                              </View>
                            </Fragment>
                          )}
                      </View>
                    </View> */}

                      <View className="sku-area">
                        <View className="item">
                          {!!detailes.repairOrderCofigs &&
                            !!detailes.repairOrderCofigs.length && (
                              <Fragment>
                                <View className="item-text save-server">
                                  <View className="title">
                                    <View>
                                      质选服务{" "}
                                      {/* <Text className="text">(非必选)</Text> */}
                                    </View>
                                    {/* <View>
                                    <Image
                                      className="img"
                                      onClick={this.onShowAdditionalClick}
                                      src=""
                                    />
                                  </View> */}
                                  </View>
                                </View>
                                <View className="item-tags-server">
                                  {detailes.repairOrderCofigs.map((ser) => (
                                    <Block>
                                      <View
                                        key={ser.id}
                                        className={`tag-server ${saveServersAdd.findIndex(
                                          (id) => id === ser.id
                                        ) > -1 && "tag-server-active"}`}
                                      >
                                        <View className="choice">
                                          <View
                                            onClick={this.handleSaveServiceClicks.bind(
                                              this,
                                              ser
                                            )}
                                          >
                                            <Image
                                              style={{ marginRight: "5px" }}
                                              className="img"
                                              src={
                                                saveServersAdd.findIndex(
                                                  (id) => id === ser.id
                                                ) > -1
                                                  ? "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/32b2d1bb652c4180ad29ef8a443d3a5f.png"
                                                  : "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/25bce7be297e49de812547a506edb0a6.png"
                                              }
                                            />
                                          </View>
                                          <View
                                            onClick={this.handleSaveServiceClicks.bind(
                                              this,
                                              ser
                                            )}
                                          >
                                            {`${ser.name} ￥${ser.price}元`}
                                          </View>
                                          <View>
                                            <Image
                                              title="点击查看服务介绍"
                                              className="img"
                                              onClick={this.onShowAdditionalClicks.bind(
                                                this,
                                                ser
                                              )}
                                              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0377ef3d5a34415e9b5d759f55c6e89b.png"
                                            />
                                          </View>
                                        </View>
                                      </View>
                                    </Block>
                                  ))}
                                </View>
                              </Fragment>
                            )}
                        </View>
                      </View>

                      {detailes && detailes.isSupportStage === 0 ? null : (
                        <View style={{ margin: "10px" }} className="Huabei">
                          <View className="hbTitle">花呗分期</View>

                          <View className="dKuang">
                            {this.state.goodList.map((item, val) => {
                              return (
                                <View
                                  // key={val}
                                  onClick={() =>
                                    this.onTabChange(val, item.value)
                                  }
                                  style={
                                    item.selected
                                      ? {
                                          border: "1px solid #C43737",
                                        }
                                      : { border: "1px solid #f3f4f9" }
                                  }
                                  className="Kuang"
                                >
                                  <View className="Kuang_1">
                                    {item.label}
                                    {currentSku &&
                                    currentSku.isHandlingFee !== 0
                                      ? item.noServiceCharge
                                      : item.ServiceCharge}
                                  </View>
                                  <View className="Kuang_2">
                                    {val === 0
                                      ? `¥${currentSku.phasePrice3}/期`
                                      : null}
                                    {val === 1
                                      ? `¥${currentSku.phasePrice6}/期`
                                      : null}
                                    {val === 2
                                      ? `¥${currentSku.phasePrice12}/期`
                                      : null}
                                  </View>
                                </View>
                              );
                            })}
                          </View>
                        </View>
                      )}
                    </ScrollView>
                  </View>
                  <View className="bottom">
                    <Form report-submit="true" onSubmit={this.formSubmits}>
                      <Button
                        className="submit"
                        open-type="getAuthorize"
                        onGetAuthorize={this.onGetAuthorize}
                        scope="userInfo"
                      >
                        确定
                      </Button>
                    </Form>
                  </View>
                </View>
              </AtFloatLayout>
            </View>
          ) : (
            <View className="popup-sku">
              <AtFloatLayout
                isOpened={showSKUPopup}
                style={{ zIndex: "1" }}
                // isOpened='true'
                onClose={this.onSKUPopupClose}
                scrollY={false}
                className="product-float"
              >
                <View
                  className="popup-sku-close"
                  onClick={this.onSKUPopupClose}
                >
                  <Image
                    className="popup-sku-close-img"
                    src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/419c20832a124bf59bda3deaac569bfe.png"
                  />
                </View>
                <View className="popup-sku-close-b">
                  {/* <Image
                  className="popup-sku-close-img"
                /> */}
                </View>
                <View className="popup-sku-header">
                  <View className="popup-sku-header-img">
                    <Image
                      className="img"
                      src={
                        currentSku.specAll[0].image || detailes.images[0].src
                      }
                    />
                  </View>
                  <View className="popup-sku-header-dec">
                    {this.state.isBuy ? (
                      <View className="price-day">
                        <Text className="unit-text">{"总金额"}</Text>
                        {this.renderBeforeAndAfterPrice(
                          false,
                          this.getRentDays(),
                          true,
                          false
                        )}
                      </View>
                    ) : (
                      <View className="price-day">
                        {this.renderBeforeAndAfterPrice(false, 1, true)}
                      </View>
                    )}
                    {/* <View className="price-name">{detailes.name}</View> */}
                    {this.state.isBuy ? (
                      ""
                    ) : currentSku &&
                      currentSku.currentCyclePrice &&
                      currentSku.currentCyclePrice.days > 30 ? (
                      <View
                        className="price-name"
                        style={"background-color:rgba(254, 238, 238)"}
                      >
                        <View classsName="price-name-a" style={"color:#eb7167"}>
                          月租金
                          {this.renderBeforeAndAfterPrice(
                            false,
                            30.41666,
                            false,
                            false,
                            "zongzujing"
                          )}
                          {detailes.buyOutSupport === 1 ? (
                            <Text
                              decode="{{true}}"
                              style={{ color: "#eb7167" }}
                              onClick={this.handleOpenTitle}
                            >
                              &nbsp;到期买断款¥
                              {currentSku.currentCyclePrice.expireBuyOutPrice}
                              {/* <AtIcon size='9' value="help" style={{marginTop:'5px'}} /> */}
                              <AtIcon size="9" value="help" />
                            </Text>
                          ) : (
                            ""
                          )}
                        </View>
                      </View>
                    ) : (
                      <View
                        className="price-name"
                        style={"background-color:rgba(254, 238, 238)"}
                      >
                        <View classsName="price-name-a" style={"color:#eb7167"}>
                          总租金
                          {this.renderBeforeAndAfterPrice(
                            false,
                            this.getRentDays(),
                            false,
                            false,
                            "zongzujing"
                          )}
                          {detailes.buyOutSupport === 1 ? (
                            <Text
                              decode="{{true}}"
                              style={{ color: "#eb7167" }}
                              onClick={this.handleOpenTitle}
                            >
                              &nbsp; 到期买断款¥
                              {currentSku.currentCyclePrice.expireBuyOutPrice}
                              {/* <AtIcon size='12' value="help" style={{marginTop:'5px'}}  /> */}
                              <AtIcon size="9" value="help" />
                            </Text>
                          ) : (
                            ""
                          )}
                        </View>
                      </View>
                    )}
                    <View className="price-name">{detailes.name}</View>
                    <View className="sku-info">
                      已选
                      {currentSku.specAll &&
                        currentSku.specAll.map(
                          (value) => `${value.platformSpecValue}`
                        )}
                      <Text className="days-mr">
                        {currentDays ? currentDays + "天" : ""}
                      </Text>
                    </View>

                    {/* {this.state.isBuy ? (
                    <View className="price-day">
                      <Text className="unit-text">{'总金额'}</Text>
                      { this.renderBeforeAndAfterPrice(false, this.getRentDays(), true, false) }
                    </View>
                  ) : (
                    <View className="price-day">
                      { this.renderBeforeAndAfterPrice(false, 1, true) }
                    </View>
                  )} */}
                  </View>
                </View>

                <View className="popup-bottom">
                  <View className="area-scroll">
                    <ScrollView
                      scrollY
                      scrollTop="0"
                      scrollWithAnimation
                      className="content-area"
                    >
                      <View className="sku-area">
                        {/* <View ><Text  decode='{{true}}' style={{color:'red'}}>*&nbsp;</Text>下单备注颜色</View> */}
                        {/* 原先是数据显示  */}
                        {/* {!!detailes.specs &&
                        !!detailes.specs.length &&
                        detailes.specs.map((spec, i) => (
                          <View className="item" key={spec.id}>
                            {i==0?( <View className="item-text">规格1</View>):( <View className="item-text">规格2</View>)}
                           
                            <View className="item-tags">
                              {!!spec.values &&
                                !!spec.values.length &&
                                spec.values.map((value) => (
                                  <View
                                    onClick={this.handleSkuClick.bind(
                                      this,
                                      value.productSpecId,
                                      currentSku.specAll[i].platformSpecId,
                                    )}
                                    className={`tag ${
                                      !!currentSku.specAll &&
                                      currentSku.specAll[i].platformSpecId ===
                                        value.productSpecId &&
                                      'tag-active'
                                    }`}
                                    key={value.productSpecId}
                                  >
                                  {value.name}
                                  </View>
                                ))}
                            </View>
                          </View>
                        ))} */}
                        {!!detailes.specs &&
                          !!detailes.specs.length &&
                          detailes.specs.map((spec, i) => (
                            <View className="item" key={i}>
                              {i == 0 ? (
                                <View className="item-text">
                                  {detailes.speFirstName
                                    ? detailes.speFirstName
                                    : "规格1"}
                                </View>
                              ) : (
                                ""
                              )}
                              {i == 0 ? (
                                <View className="item-tags">
                                  {!!spec.values &&
                                    !!spec.values.length &&
                                    spec.values.map((value, i) => (
                                      <View
                                        onClick={this.handleSkuClick.bind(
                                          this,
                                          1,
                                          i,
                                          value.productSpecId,
                                          currentSku.specAll[0].platformSpecId,
                                          value
                                        )}
                                        className={`tag ${!!currentSku.specAll &&
                                          currentSku.specAll[0]
                                            .platformSpecId ===
                                            value.productSpecId &&
                                          "tag-active"}`}
                                        key={value.productSpecId}
                                      >
                                        {value.name}
                                      </View>
                                    ))}
                                </View>
                              ) : (
                                ""
                              )}
                              {i == 0 ? (
                                <Block>
                                  <View className="item-text">
                                    {detailes.speSecName
                                      ? detailes.speSecName
                                      : "规格2"}
                                  </View>
                                </Block>
                              ) : (
                                ""
                              )}
                              <View className="item-tags">
                                {!!spec.values &&
                                  !!spec.values[isShowTags].secDtoLst &&
                                  !!spec.values[isShowTags].secDtoLst.length &&
                                  spec.values[isShowTags].secDtoLst.map(
                                    (value, i) =>
                                      value.show == true ? (
                                        <View
                                          onClick={this.handleSkuClickss.bind(
                                            this,
                                            2,
                                            i,
                                            value.productSpecId,
                                            currentSku.specAll[1].platformSpecId
                                          )}
                                          className={
                                            value.show == true
                                              ? `tag ${!!currentSku.specAll &&
                                                  currentSku.specAll[1]
                                                    .platformSpecId ===
                                                    value.productSpecId &&
                                                  "tag-active"}`
                                              : "tag tag-text"
                                          }
                                          key={value.productSpecId}
                                        >
                                          {value.name}
                                        </View>
                                      ) : (
                                        <View
                                          className={
                                            value.show == true
                                              ? `tag ${!!currentSku.specAll &&
                                                  currentSku.specAll[1]
                                                    .platformSpecId ===
                                                    value.productSpecId &&
                                                  "tag-active"}`
                                              : "tag tag-text"
                                          }
                                          key={value.productSpecId}
                                        >
                                          {value.name}
                                        </View>
                                      )
                                  )}
                              </View>
                            </View>
                          ))}
                        {currentSku.cycs && currentSku.cycs.length && (
                          <View className="item">
                            <View className="item-text">租期</View>
                            <View className="item-tags">
                              {currentValidCyclePrices.map((cycle) => (
                                <View
                                  key={cycle.id}
                                  className={`tag ${cycle.days ===
                                    currentDays &&
                                    !editRentDays &&
                                    "tag-active"}`}
                                  onClick={this.handleDayChange.bind(
                                    this,
                                    cycle.days
                                  )}
                                >
                                  {cycle.days}天
                                </View>
                              ))}
                            </View>
                          </View>
                        )}
                      </View>
                      {/* <View className="sku-area">
                      <View className="item">
                        {!!detailes.additionals &&
                          !!detailes.additionals.length && (
                            <Fragment>
                              <View className="item-text save-server">
                                <View className="title">
                                  <View>
                                    增值服务{' '}
                                    <Text className="text">(非必选)</Text>
                                  </View>
                                  <View>
                                    <Image
                                      className="img"
                                      onClick={this.onShowAdditionalClick}
                                    />
                                  </View>
                                </View>
                              </View>
                              <View className="item-tags-server">
                                {detailes.additionals.map((ser) => (
                                  <View
                                    key={ser.shopAdditionalServices.id}
                                    className={`tag-server ${
                                      saveServers.findIndex(
                                        (id) =>
                                          id === ser.shopAdditionalServices.id,
                                      ) > -1 && 'tag-server-active'
                                    }`}
                                    onClick={this.handleSaveServiceClick.bind(
                                      this,
                                      ser,
                                    )}
                                  >
                                    {ser.name}
                                    <View className="choice">
                                      <View>
                                        {`${ser.shopAdditionalServices.name} ￥${ser.shopAdditionalServices.price}元`}
                                      </View>
                                      <View>
                                        <Image
                                          className="img"
                                          src={
                                            saveServers.findIndex(
                                              (id) =>
                                                id ===
                                                ser.shopAdditionalServices.id,
                                            ) > -1
                                              ? ''
                                              : ''
                                          }
                                        />
                                      </View>
                                    </View>
                                  </View>
                                ))}
                              </View>
                            </Fragment>
                          )}
                        <View className="after-text">租后推荐方案</View>
                        <Image
                          mode="aspectFit"
                          className="after-img"
                          src=""
                        />
                      </View>
                    </View> */}
                      <View className="sku-area">
                        <View className="item">
                          {!!detailes.repairOrderCofigs &&
                            !!detailes.repairOrderCofigs.length && (
                              <Fragment>
                                <View className="item-text save-server">
                                  <View className="title">
                                    <View>
                                      质选服务{" "}
                                      {/* <Text className="text">(非必选)</Text> */}
                                    </View>
                                    {/* <View>
                                    <Image
                                      className="img"
                                      onClick={this.onShowAdditionalClick}
                                      src=""
                                    />
                                  </View> */}
                                  </View>
                                </View>
                                <View className="item-tags-server">
                                  {detailes.repairOrderCofigs.map((ser) => (
                                    <Block>
                                      <View
                                        key={ser.id}
                                        className={`tag-server ${saveServersAdd.findIndex(
                                          (id) => id === ser.id
                                        ) > -1 && "tag-server-active"}`}
                                      >
                                        <View className="choice">
                                          <View
                                            onClick={this.handleSaveServiceClicks.bind(
                                              this,
                                              ser
                                            )}
                                          >
                                            <Image
                                              style={{ marginRight: "5px" }}
                                              className="img"
                                              src={
                                                saveServersAdd.findIndex(
                                                  (id) => id === ser.id
                                                ) > -1
                                                  ? "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/119ac6a232d54b3f9d6e0d4e0ff3075a.png"
                                                  : "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/119ac6a232d54b3f9d6e0d4e0ff3075a.png"
                                              }
                                            />
                                          </View>
                                          <View
                                            onClick={this.handleSaveServiceClicks.bind(
                                              this,
                                              ser
                                            )}
                                          >
                                            {`${ser.name} ￥${ser.price}元`}
                                          </View>
                                          <View>
                                            <Image
                                              title="点击查看服务介绍"
                                              className="img"
                                              onClick={this.onShowAdditionalClicks.bind(
                                                this,
                                                ser
                                              )}
                                              src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c823670395e146fd98e3daddefa91646.png"
                                            />
                                          </View>
                                        </View>
                                      </View>
                                    </Block>
                                  ))}
                                </View>
                              </Fragment>
                            )}
                          <View className="after-text">租后推荐方案</View>
                          <Image
                            mode="aspectFit"
                            className="after-img"
                            src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/3fa1ce982a0c4042bc6fcbffe23d4400.png"
                          />
                        </View>
                      </View>
                    </ScrollView>
                  </View>
                  <View className="bottom">
                    {isToProduct == true ? (
                      <Form report-submit="true">
                        <Button
                          className="submit"
                          onClick={this.handleFormSubmits}
                        >
                          确定
                        </Button>
                      </Form>
                    ) : (
                      <Form report-submit="true" onSubmit={this.formSubmits}>
                        {/* <Button
                      className="submit"
                      open-type="getAuthorize"
                      onGetAuthorize={this.onGetAuthorize}
                      scope="userInfo"
                    >
                      确定啊
                    </Button> */}
                        <Button
                          className="submit"
                          open-type="getAuthorize"
                          onGetAuthorize={throttle(this.onGetAuthorize, 1000)}
                          // onGetAuthorize={this.onGetAuthorize}
                          // onTap={() => {
                          //   this.setState({
                          //     stopDisabled:true
                          //   })
                          // }}
                          scope="phoneNumber"
                          hoverClass="newSubmit"
                          hoverStayTime="2000"
                          disabled={stopDisabled}
                          style={
                            stopDisabled
                              ? { color: "#E7F9FF", background: "#d0cded" }
                              : { color: "#fff" }
                          }
                        >
                          确定
                        </Button>
                      </Form>
                    )}
                  </View>
                </View>
              </AtFloatLayout>
            </View>
          )}
        </View>
        <modal
          show={showServicePhone}
          showClose={false}
          onModalClick={this.onClosePhoneModal}
          onModalClose={this.onClosePhoneModal}
        >
          <View slot="header">联系客服</View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            商家客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectService.bind(this, detailes.serviceTel)}
            >
              {detailes.serviceTel}
            </Text>
          </View>
          <View
            style={{
              textAlign: "left",
              marginBottom: "10px",
              paddingLeft: "15px",
            }}
          >
            平台客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectService.bind(this, customerServiceTel)}
            >
              {customerServiceTel}
            </Text>
          </View>
          <View style={{ textAlign: "left", paddingLeft: "15px" }}>
            工作时间：<Text style={{ color: "#777" }}> 10:30 - 19:30</Text>
          </View>
          <View slot="footer">取消拨打</View>
        </modal>
        {/* <popup
          show={showAdditionalPopup}
          position="bottom"
          zIndex={2003}
          disableScroll
          onClose={this.onAdditionalPopupClose}
        >
          <View className="service-popup">
            <View className="service-popup-title">服务介绍</View>
            <View className="service-popup-content">
              {!!detailes.additionals &&
                !!detailes.additionals.length &&
                detailes.additionals.map((service) => (
                  <View
                    className="service-popup-content-item"
                    key={service.shopAdditionalServices.id}
                  >
                    <View className="service-popup-content-item-type">
                      {service.shopAdditionalServices.name}
                    </View>
                    <View>{service.shopAdditionalServices.content}</View>
                  </View>
                ))}
            </View>
            <View
              className="service-popup-close"
              onClick={this.onAdditionalPopupClose}
            >
              关闭
            </View>
          </View>
        </popup> */}
        <TagPage
          onClose={this.handleClose}
          isOpened={isTagOpened}
          //   data={detailes && detailes.serviceTel}
        />
        <AtModal
          style={{ zIndex: "99999" }}
          onClose={this.handleCloseOpen}
          isOpened={isOpenTitle}
        >
          <AtModalHeader>到期买断款</AtModalHeader>
          <AtModalContent>
            <View style={{ textAlign: "center" }}>
              租期完成后，如需购买手机所付金额
            </View>
            <View style={{ textAlign: "center" }}>(买断价-总租金) </View>
            {/* <View style={{textAlign:'center'}}> 到期买断：到期后，无需支付额外费用 </View> */}
          </AtModalContent>
          <AtModalAction>
            {" "}
            <Button onClick={this.handleCloseOpen}>确定</Button>{" "}
          </AtModalAction>
        </AtModal>
        {/* 质选服务的弹框 */}
        <AtModal
          style={{ zIndex: "99999" }}
          onClose={this.handleCloseService}
          isOpened={serveiceShow}
        >
          <AtModalHeader>服务说明</AtModalHeader>
          <AtModalContent>
            <View style={{ textAlign: "center", wordBreak: "break-word" }}>
              {contentServer}
            </View>
          </AtModalContent>
          <AtModalAction>
            {" "}
            <Button onClick={this.handleCloseService}>关闭</Button>{" "}
          </AtModalAction>
        </AtModal>
        {/* <modal
            show={serveiceShow}
            width="100%"
             zIndex={999229}
            // onModalClick={this.onClosePhoneModal}
            onModalClose={this.handleCloseService}
           >
              <Image  style={{width:'100%'}} src={contentServer} />

          </modal> */}
        {/* <AtCurtain
          isOpened={this.state.isActivities}
          onClose={this.onActiveClose}
          closeBtnPosition="top-left"
        >
          <View className="activity-wrap">
            <Image
              lazyLoad={true}
              className="activity-img-header"
              src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/activity/activity-header.png"
              onClick={this.onPush}
            />
            <Image
              lazyLoad={true}
              className="activity-img-footer"
              src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/activity/activity-button.png"
              onClick={this.onPush}
            />
            <form onSubmit={(e) => this.onSubmit2(e)} report-submit="true">
              <Button
                className="activity-img-btn"
                formType="submit"
                onClick={this.onPush}
              ></Button>
            </form>
          </View>
        </AtCurtain> */}
      </View>
    );
  }
}

export default Productdetail;
