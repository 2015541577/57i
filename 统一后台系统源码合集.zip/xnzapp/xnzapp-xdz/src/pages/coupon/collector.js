/**
 * 领券中心页面
 * 券分为多种券，体现在tab栏上，每个tab都是一种券，通过后台进行配置
 * 每种券又分为多种类型，比如说普通的优惠券 以及 大礼包
 */
import Taro, { Component } from '@tarojs/taro';
import { View, Image } from '@tarojs/components'
import { connect } from '@tarojs/redux';
import NoData from '../../components/noData/index'
import Optimization from './component/optimization/index'
import './index.scss';
import { getUid, getTelephone } from '../../utils/localStorage'
import umUploadHandler from "../../utils/umengUploadData";

@connect(({ coupon, productDetail, mine, loading }) => ({
  ...coupon,
  ...productDetail,
  productDetilsLoading: loading.models.productDetail,
  loading: loading.models.mine,
}))
class Collector extends Component {
  config = {
    navigationBarTitleText: '领券中心',
    allowsBounceVertical:"NO",
    usingComponents: {
      "tabs": "../../npm/mini-antui/es/tabs/index",
      "tab-content": "../../npm/mini-antui/es/tabs/tab-content/index"
    }
  };

  state = {
    display: 'block', // none -> 没数据隐藏
    tabs: [
      {
        title: '租赁劵',
        key: 'RENT'
      },
      {
        title: '买断劵',
        key: 'BUY_OUT'
      },
    ],
    activeTab: 0,
    ggId:false,
  }

  componentDidMount = () => {
    const { dispatch } = this.props;
     const { gg_id } = (this.$router.params)
    // this.getList()
     if(gg_id != undefined && gg_id != null && gg_id.length>0){
         this.setState({
             ggId:true,
         })
     }
  };
    componentDidShow(){
    this.getList()
    }
  getList(){
    const { dispatch } = this.props;
    dispatch({
      type: 'coupon/couponCenter',
      payload: {
        'scene': this.state.tabs[this.state.activeTab].key
      }
    })
  }

  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    dispatch({
      type: 'coupon/getAllUserCouponList',
      payload: { ...info },
    });
  }

  onScrollToLower = () => {
    const { queryInfo } = this.props;
    this.setDispatch(queryInfo, 'scroll');
  };

  handleTabClick = ({ index }) => {
    this.setState({
      activeTab: index
    }, () => {
      this.getList()
    })
  }

  /**
   * 领取普通券时所调用的方法
   * @param {*} id : 券的ID
   * @param {*} data : 券对象
   */
  handleReceive = (id, data) => {
    if(data.bindUrl){
      let appidAndUrl = data.bindUrl.split("alipays://platformapi/startapp?appId=")[1].split("&page=")

      my.navigateToMiniProgram({
        appId: appidAndUrl[0],
        // appId为对应模板配置的小程序AppID，
        //templateId为活动进行汇总的模板ID，可以在有礼活动列表中查看
        path: appidAndUrl[1],
        success: (res) => {
        },
        fail: (res) => {
        }
      });
      return
    }
    const { dispatch } = this.props
    dispatch({
      type: 'coupon/bindCoupon',
      payload: {
        uid: getUid(),
        phone: getTelephone(),
        templateId: id
      },
      callback: () => {
        umUploadHandler.bindCouponHandler(data, "领券中心"); // 友盟 上报 Um_Event_CollectCoupon 事件
        dispatch({
          type: 'coupon/couponCenter',
          payload: {
            'scene': this.state.tabs[this.state.activeTab].key
          }
        });
      }
    });
  }

  handleGotoTake = (shopId) => {
    if (shopId) {
      Taro.navigateTo({
        url: `/pages/couponList/index?shopId=${shopId}`
      })
    }
    else {
      Taro.switchTab({ url: '/pages/home/index' });
    }
  }
  onToReceive = (id) => {
    const { dispatch } = this.props
    dispatch({
      type: 'coupon/bindCouponPackage',
      payload: {
        uid: getUid(),
        phone: getTelephone(),
        packageId: id
      },
      callback: () => {
        dispatch({
          type: 'coupon/couponCenter',
          payload: {
            'scene': this.state.tabs[this.state.activeTab].key
          }
        })
      }
    })

  }

    router(url){
    Taro.navigateTo({
      url
    })
  }
  render() {
    const { loading, productDetilsLoading, optimizationList, optimizationLists, packageData } = this.props;
    const { display, tabs, activeTab ,ggId} = this.state;
    // (loading || productDetilsLoading) ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    // 定义一个优惠券可以全部可见或者是仅特殊渠道可见的数组
    let userPlatform=[] //这里的是全部可见 当为true时
    let userFalseForm=[]
    if(optimizationLists&&optimizationLists.length){
        optimizationLists.forEach((item)=>{
            // 1 代表的是全部可见
            if(item.activitiesCoupon== 1 && item.isBind==false){
                userPlatform.push(item)
                // 2 代表的是仅特殊渠道可见
            }else if(item.activitiesCoupon == 0 && item.isBind==false){
                userFalseForm.push(item) 
            }
        })
    }
    return (
      <view className="coupon-view">
        <tabs
         className="tabs_new"
          tabs={tabs}
          showPlus={false}
          swipeable={false}
          activeTab={activeTab}
          tabBarUnderlineWidth="48px"
          onTabClick={({ index }) => this.handleTabClick({ index })}
          tabBarActiveTextColor='rgba(51,51,51)'
          tabBarUnderlineColor='#1AA9FF'
          tabBarInactiveTextColor='rgba(153,153,153)'
        ></tabs>
        {/** 大礼包，比较常见的一种大礼包是新人专享，不同类别的券对应了不同的大礼包以及普通优惠券 */}
        <View  style={{minHeight:'1130px'}}>
          {
            packageData && packageData.length && packageData.map((item, val) => {
              return (
                <View className='coupon-package'>
                  <View className="coupon-package-title">
                    <Text className="coupon-package-title1">{item.name}</Text>
                    <Text className="coupon-package-title2">各种优质礼券，快去领取吧～</Text>
                  </View>
                  {
                    !item.isBind
                      ? (
                        <View className='coupon-package-view' onClick={() => this.onToReceive(item.id)}>
                          <Text>立即领取</Text>
                          <Image
                            src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/57fc6234303d49d6b448b0b31e1ab391.png'
                            className='coupon-package-img'
                          />
                        </View>
                      )
                      : <View className='coupon-package-txet'>已领取</View>
                  }
                </View>
              )
            })
          }

          {/** 这是普通优惠券 */}
          {
           ggId==false ? (
                <View className='coupon-page'>
                  {!!userPlatform && !!userPlatform.length && userPlatform.map(coupon =>
                    <Optimization
                      onReceive={(id) => this.handleReceive(id, coupon)}
                      onGotoTake={id => this.handleGotoTake(id)}
                      key={coupon.id}
                      type='red'
                      isNew={coupon.couponTemplateId === 1}
                      data={coupon}
                    />
                  )}
                  {/* {!(packageData && packageData.length) && !(optimizationLists && optimizationLists.length) && (
                    <NoData type='coupon' display={display} />
                  )} */}
                </View>
            ):(
                <View className='coupon-page'>
                  {!!userFalseForm && !!userFalseForm.length && userFalseForm.map(coupon =>
                    <Optimization
                      onReceive={(id) => this.handleReceive(id, coupon)}
                      onGotoTake={id => this.handleGotoTake(id)}
                      key={coupon.id}
                      type='red'
                      isNew={coupon.couponTemplateId === 1}
                      data={coupon}
                    />
                  )}
                  {/* {!(packageData && packageData.length) && !(optimizationLists && optimizationLists.length) && (
                    <NoData type='coupon' display={display} />
                  )} */}
                </View>
            )
          }
        </View>
       <View className="coupon-btn">
          {/* <View className="coupon-btn3" onClick={() => this.router('/pages/coupon/collector')}>领券中心</View> */}
          <View className="coupon-btn1" onClick={() => this.router('/pages/coupon/oldCoupon')}>我的券包</View>
          <View className="coupon-btn2" >去领券
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/123390eef0c04433bbf3fd865f3e068d.gif" className="coupon-img" />
          </View>
        </View>
      </view>
    )
  }
}

export default Collector;
