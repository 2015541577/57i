import Taro from '@tarojs/taro';
import * as couponApi from './service';
import { getUid } from '../../utils/localStorage';

export default {
  namespace: 'coupon',
  state: {
    queryInfo: {
      status: 0,
      pageNumber: 1,
      pageSize: 10,
    },
    userPlatformCoupon: [],
    userShopCoupon: [],
    optimizationLists: [],
    packageData: [],
    userPlatformCoupons: []
  },

  effects: {
    // demo
    * effectsDemo(_, { call, put }) {
      const { status, data } = yield call(couponApi.demo, {});
      if (status === 'ok') {
        yield put({
          type: 'save',
          payload: {
            topData: data,
          }
        });
      }
    },
    * checkInvokeCode({ payload, callback }, { call, put }) {
      const res = yield call(couponApi.checkInvokeCode, { ...payload, uid: getUid() });
      if (res) {
        if (callback) {
          callback(res)
        }
      }
    },
    // 获取我的优惠券
    * couponMy({ payload, callback }, { call, put }) {
     let res = yield call(couponApi.couponMy, { ...payload, });
      res=res.data
      if (res && res.data) {
        yield put({
          type: 'userPlatformMy',
          payload: res.data,
        })
      }

    },
    // 优惠券列表
    * couponCenter({ payload, callback }, { call, put }) {
      const res = yield call(couponApi.couponCenter, { ...payload, });
      yield put({
        type: 'optimizationLists',
        payload: res.data.data
      })
    },
    // 获取优惠券
    * bindCoupon({ payload, callback }, { call, put }) {
      const res = yield call(couponApi.bindCoupon, { ...payload, });
      if (res.data.responseType === 'SUCCESS') {
        if(res.data.data){
          Taro.showToast({
            title: res.data.data,
            icon: 'none',
          });
        }
        if (callback) {
          callback(res)
        }
      }else{
        Taro.showToast({
          title: res.data.errorMessage,
          icon: 'none',
        });
      }
    },
    // 获取大礼包
    * bindCouponPackage({ payload, callback }, { call, put }) {
      const res = yield call(couponApi.bindCouponPackage, { ...payload, });
      if (res.data.responseType === 'SUCCESS') {
        if(res.data.data){
          Taro.showToast({
            title: res.data.data,
            icon: 'none',
          });
        }
        if (callback) {
          callback(res.data)
        }
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    equity(state, { payload }) {
      return {
        ...state,
        equity: payload
      };
    },
    optimizationList(state, { payload }) {
      return {
        ...state,
        optimizationList: payload
      };
    },
    optimizationLists(state, { payload }) {
      return {
        ...state,
        optimizationLists: payload.couponList,
        packageData: payload.couponPackageList
      };
    },
    concatCouponList(state, { payload }) {
      const userPlatformCoupon = [...state.userPlatformCoupon];
      const userShopCoupon = [...state.userShopCoupon];
      return {
        ...state,
        userPlatformCoupon: userPlatformCoupon.concat(payload.userPlatformCoupon),
        userShopCoupon: userShopCoupon.concat(payload.userShopCoupon),
        queryInfo: {
          ...state.queryInfo,
          pageNumber: state.queryInfo.pageNumber + 1,
        },
      }
    },
    saveCouponList(state, { payload }) {
      return {
        ...state,
        userPlatformCoupon: payload.data.userPlatformCoupon,
        userShopCoupon: payload.data.userShopCoupon,
        total: payload.data.total,
        queryInfo: {
          ...payload.queryInfo,
          pageNumber: 1,
        },
      };
    },
    userPlatformMy(state, { payload }) {
      return {
        ...state,
        userPlatformCoupons: payload.unUseCouponList || [],
        expiredCouponList: payload.expiredCouponList || [],
        usedCouponList: payload.usedCouponList || [],
      };
    },
  },

};
