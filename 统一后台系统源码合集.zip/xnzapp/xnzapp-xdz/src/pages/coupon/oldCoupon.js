import Taro, { Component } from '@tarojs/taro';
import { ScrollView } from '@tarojs/components';
import { AtTabs, AtTabsPane } from 'taro-ui'
import { connect } from '@tarojs/redux';

import NoData from '../../components/noData/index'
import CardUsed from './component/cardUsed/index';
import Used from './component/used/index';
import Card from './component/card/index';
import Optimization from './component/optimization/index';
import Equity from './component/equity/index'
import './index.scss';
let timer;
@connect(({ coupon, loading }) => ({
  ...coupon,
  loading: loading.models.members,
}))
class oldCoupon extends Component {
  config = {
    navigationBarTitleText: '领券中心',
    allowsBounceVertical:"NO",
  };

  state = {
    display: 'block', // none -> 没数据隐藏
    couponType: 'unUsed',
    scrollTop:0,
  }

  componentDidMount = () => {
    const { queryInfo } = this.props;
    this.setDispatch(queryInfo);
    const { dispatch } = this.props;
    dispatch({
      type: 'coupon/couponMy',
    });
  };

  setDispatch(queryInfo, fetchType) {
    const { dispatch } = this.props;
    const info = { ...queryInfo };
    dispatch({
      type: 'coupon/getAllUserCouponList',
      payload: { ...info },
    });
  }

  onScrollToLower = () => {
    const { queryInfo } = this.props;
    this.setDispatch(queryInfo, 'scroll');
  };

  router(url){
    Taro.navigateTo({
      url
    })
  }
  changeType(type){
      const {scrollTop}=this.state
          const then = this
		const query = Taro.createSelectorQuery()
		query.select('#main').boundingClientRect()
		query.selectViewport().scrollOffset()
		query.exec(function(res) {
            // 如果是距离顶部的是小于等于0 时让其固定
			if (res[0].top<= 0 ) {
				 my.pageScrollTo({
                            scrollTop:0,
                            duration:0,
                            success:data=>{
                            }
                        });
			}else {
            }
		})
    this.setState({
      couponType: type
    })
  }
    onScroll=(e)=>{
     const { scrollTop} = this.state;
    // 原先的逻辑是通过scrollTop滚动的值来让下面的导航固定 有个问题是不同的机子 滚动的高度是不一样的
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (scrollTop !== 0 || e.detail.scrollTop >= 0) {
        this.setState({
        //   scrollTop: e.detail.scrollTop,
        });
      }
    }, 1000);
  }
   handleGotoTake = (shopId) => {
    if (shopId) {
      Taro.navigateTo({
        url: `/pages/couponList/index?shopId=${shopId}`
      })
    }
    else {
      Taro.switchTab({ url: '/pages/home/index' });
    }
  }

  render() {
    const { userPlatformCoupons, userShopCoupon, equity, loading, expiredCouponList, usedCouponList } = this.props;
    const { display ,scrollTop} = this.state;
    const systemInfo = Taro.getSystemInfoSync();
    let fixedHeight = 0;
    if (systemInfo.model.indexOf('iPhone X') > -1) {
      fixedHeight = fixedHeight + 30;
    }
    // 对数据进行处理
  
    const scrollHeight = Taro.getSystemInfoSync().windowHeight - fixedHeight;
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
    return (
      <View className="coupon-view">
        <View className="coupon-title">
            <View className={"coupon-btn4 " + (this.state.couponType === 'unUsed' ? "coupon-btn-active" : "")} onClick={() => this.changeType('unUsed')}>未使用 <Text className="couponTxt"></Text></View>
          <View className={"coupon-btn4 " + (this.state.couponType === 'used' ? "coupon-btn-active" : "")} onClick={() => this.changeType('used')}>已使用<Text className="couponTxt"></Text></View>
          <View className={"coupon-btn5 " + (this.state.couponType === 'overTime' ? "coupon-btn-active" : "")} onClick={() => this.changeType('overTime')}>已过期</View>
        </View>
        <ScrollView
          className='coupon-page'
          id="main"
          scrollY
          scrollWithAnimation
          scrollTop={{scrollTop}}
          style={`height: ${scrollHeight}px;`}
          onScroll={this.onScroll}
          onScrollToLower={this.onScrollToLower}
        >
            {/* // <Card key={coupon.id} couponType="unUsed" data={coupon} /> */}
               {this.state.couponType === 'unUsed' && !!userPlatformCoupons && !!userPlatformCoupons.length && userPlatformCoupons.map(coupon =>
                    <Optimization
                      onGotoTake={id => this.handleGotoTake(id)}
                      key={coupon.id}
                      type='red'
                      isNew={coupon.couponTemplateId === 1}
                      data={coupon}
                    />
                  )}
          {this.state.couponType === 'used' && !!usedCouponList && !!usedCouponList.length && usedCouponList.map(coupon =>
            <Used key={coupon.id} couponType="used" data={coupon} />
          )}
          {this.state.couponType === 'overTime' && !!expiredCouponList && !!expiredCouponList.length && expiredCouponList.map(coupon =>
            <CardUsed key={coupon.id} couponType="overTime" data={coupon} />
          )}
          {/* {((this.state.couponType === 'used' && (!usedCouponList || !usedCouponList.length)) || (this.state.couponType === 'overTime' && (!expiredCouponList || !expiredCouponList.length))) && (
            <NoData type='coupon' display={display} />
          )} */}
        </ScrollView>
        <View className="coupon-btn" >
          {/* <View className="coupon-btn3" onClick={() => this.router('/pages/coupon/collector')}>领券中心</View> */}
          <View className="coupon-btn1"  >我的券包</View>
          <View className="coupon-btn2"  onClick={() => this.router('/pages/coupon/collector')}>去领券
              <Image src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d5c533707d7e4baf976ce591dbc429f0.gif" className="coupon-img" />
          </View>
        </View>
      </View>
    )
  }
}

export default oldCoupon;
