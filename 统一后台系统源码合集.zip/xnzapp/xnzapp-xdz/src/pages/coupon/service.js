import Request from '../../utils/request';
import { getUid } from '../../utils/localStorage';
export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const getAllUserCouponList = data => Request({
  url: 'hzsx/aliPay/couponCenter/getAllUserCouponList',
  method: 'POST',
  data,
});
export const couponMy = data => Request({
  url: `hzsx/aliPay/couponCenter/myCoupons?uid=${getUid()}`,
  method: 'GET',
});


export const couponCenter = data => Request({
  url: `hzsx/aliPay/couponCenter/index?uid=${getUid()}&scene=${data.scene}`,
  method: 'GET',
});
export const bindCouponPackage = data => Request({
  url: `hzsx/aliPay/couponCenter/bindCouponPackage`,
  method: 'POST',
  data,
});

export const bindCoupon = data => Request({
  url: `hzsx/aliPay/couponCenter/bindCoupon`,
  method: 'POST',
  data,
});
export const CouponListIndex = data => Request({
  url: 'hzsx/aliPay/couponCenter/index',
  method: 'GET',
  data,
});
export const getUserMembersEquitiesByUid = data => Request({
  url: 'hzsx/aliPay/user/members/getUserMembersEquitiesByUid',
  method: 'GET',
  data,
});
export const checkInvokeCode = data => Request({
  url: 'checkInvokeCode',
  method: 'POST',
  contentType: 'application/www',
  test: 'report',
  data,
});
export const getRecordByReportNo = data => Request({
  url: 'checkInvokeCode',
  method: 'GET',
  test: 'report',
  data,
});
