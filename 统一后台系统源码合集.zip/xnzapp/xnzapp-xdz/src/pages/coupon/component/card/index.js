import Taro, { Component } from "@tarojs/taro";
import { View, Text, Button, Image } from "@tarojs/components";
import { formatStrDate } from "../../../../utils/utils";
import "./index.scss";

class Card extends Component {
  gotoHome(status) {
    if (status) {
      Taro.navigateTo({
        url: `/pages/couponList/index?shopId=${status}`,
      });
    } else {
      Taro.switchTab({ url: "/pages/home/index" });
    }
  }
/*
  这里是用户页面我的优惠券跳转到优惠券详情页面
  没有后台数据所以样式是写死的   全部为定位
*/
  render() {
    const { type, data } = this.props; // red, yellow
    // const durationStr = `${formatStrDate(
    //   data.startTime,
    //   "yyyy.MM.dd"
    // )}-${formatStrDate(data.endTime, "yyyy.MM.dd")}`;
    // const durationStr = `1`;
    return (
      <View className="container_coupon">
        <View
          className={'content '
            + 
            (data.scene == "RENT" ? 'content-RENT' : '')
            +(data.scene=='FIRST'?'content-BUY_OUT':'')
            +
            (data.scene == "BUY_OUT" ? 'content-BUY_OUT' : '')
            +
            (data.scene == "DELAYED" ? 'content-DELAYED' : '')
          }
        >
          <View className="num">
              {data.discountAmount > 0 ? (<Text className="price">{data.discountAmount}</Text>):(<Text className="price">{data.delayDays}</Text>)}
            <Text className={'yuan '+(data.scene=='FIRST'? 'position':'')}>{data.scene == "DELAYED" ? "天" : "元"}</Text>
            {/* <View className="shop">
              {data.sourceShopName === "OPE" ? "平台券" : data.sourceShopName}
            </View> */}
          </View>
          {/* <View className="item"> */}
            <View className={'li '+(data.scene=='FIRST'? 'positions':'')}>
              {data.minAmount === 0 ? "无门槛" : "满" + data.minAmount + "可用"}
            </View>
            <View className="dec-right">
              <View className="dec-title"> {data.title} </View>
              <View className="dec-classify">
                <View className={
                  'dec-circle '
                  + 
                  (data.scene == "RENT" ? 'dec-RENT' : '')
                  +
                  (data.scene=='FIRST'?'dec-BUY_OUT':'')
                  +
                  (data.scene == "BUY_OUT" ? 'dec-BUY_OUT' : '')
                  +
                  (data.scene == "DELAYED" ? 'dec-DELAYED' : '')
                }> {data.rangeStr}  </View>
              </View>
              <View className="dec-content">
                <View>
                  <View className="dec-content-time">
                      { data && data.startTime
                        ?
                        `${
                          data.startTime.split(' ')[0].split('-')[0]
                        }.${
                          data.startTime.split(' ')[0].split('-')[1]
                        }.${
                          data.startTime.split(' ')[0].split('-')[2]
                        }-${
                          data.endTime.split(' ')[0].split('-')[0]
                        }.${
                          data.endTime.split(' ')[0].split('-')[1]
                        }.${
                          data.endTime.split(' ')[0].split('-')[2]
                        }`
                        : ""
                      }
                    </View>
                </View>
              </View>
            </View>
          <View 
          className="goShop"
          onClick={this.gotoHome.bind(this, data.templateId)}
          >
                  立即使用
          </View>
        </View>
      </View>
    );
  }
}

export default Card;
