import Taro, { Component } from "@tarojs/taro";
import { View, Text, Button, Image } from "@tarojs/components";
import { formatStrDate } from "../../../../utils/utils";
import "./index.scss";

class Used extends Component {
//   gotoHome(status) {
//     if (status) {
//       Taro.navigateTo({
//         url: `/pages/couponList/index?shopId=${status}`,
//       });
//     } else {
//       Taro.switchTab({ url: "/pages/home/index" });
//     }
//   }
/*
  这里是用户页面我的优惠券跳转到优惠券详情页面
  没有后台数据所以样式是写死的   全部为定位
*/
  render() {
    const { data } = this.props; 
    return (
        <View className='containers'>
        <View className='content' >
          <View className="box">
            <View className="box2">
              <View className='item'>
                <View className='li'>{data.name?data.name:data.title}</View>
                <View className='dec'>{ data && data.delayDayNum ? `有效期${data.delayDayNum}日` :  data && data.startTime ?  `${data.startTime.split(' ')[0].split('-')[1]}.${data.startTime.split(' ')[0].split('-')[2]}-${data.endTime.split(' ')[0].split('-')[1]}.${data.endTime.split(' ')[0].split('-')[2]}有效` : ''}  </View>
                <View className='destr'>{data.rangeStr}</View>
              </View>
            </View>
              <View className='num'>
                 {data.discountAmount > 0 ?
                 (<Block> <Text className='bol'>¥</Text><Text className='price'>
                     {data.discountAmount}
                     </Text></Block>)
                 :(<Block> <Text className='bol'>天</Text><Text className='price'>{data.delayDays}</Text></Block>)}
              <View className='shop'>
                                        {
                                            data.minAmount>0? (
                                            <Block>
                                              {  data.minLease>0?(<Block>
                                              满{data.minLease}天可用
                                            </Block>):(<Block>
                                              满{data.minAmount}元可用
                                            </Block>)
                                             }
                                            </Block>
                                            ):(
                                            <Block>
                                             无门槛
                                            </Block>
                                            )
                                        }
                  </View>
            </View>
          </View>
         
        </View>
      </View>
    );
  }
}

export default Used;
