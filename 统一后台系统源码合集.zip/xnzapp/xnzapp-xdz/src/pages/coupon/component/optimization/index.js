import Taro, { Component, Fragment } from '@tarojs/taro'
import { View, Text, Image,Block } from '@tarojs/components'
import { AtProgress } from 'taro-ui';
import './index.scss'

class Optimization extends Component {

  gotoTake = (shopId) => {
    const { onGotoTake } = this.props
    onGotoTake(shopId)
  }
  gotoTakes = () => {

  }
  receive = (id) => {
    const { onReceive } = this.props
    onReceive(id)
  }
  render() {
    const { type, data ,ggId} = this.props; // red, yellow
    return (
      <View className='container_optimization'>
        <View className='content' >
          <View className="box">
            <View className="box2">
              {/* <View className='item' 第一种>
                <View className='li'>{data.name}</View>
                <View className='dec'>{ data && data.delayDayNum ? `有效期${data.delayDayNum}日` :  data && data.startTime ?  `${data.startTime.split(' ')[0].split('-')[1]}.${data.startTime.split(' ')[0].split('-')[2]}-${data.endTime.split(' ')[0].split('-')[1]}.${data.endTime.split(' ')[0].split('-')[2]}有效` : ''} | {data.rangeStr}</View>
                {
                  data.isBind
                    ? <Image onClick={() => this.navigate(item.name)} mode="widthFix" className="get-img" src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/coupon/coupon-get.png" />
                    : ''
                }
              </View>
              <View className='switch_img'>
                {
                  data.isBind
                    ? <Text className="to-use" onClick={() => this.props.onGotoTake(data.id)}>去使用</Text>
                    : <Text className="get-now" onClick={() => this.props.onReceive(data.id)}>立即领取</Text>
                }
              </View> */}
              {/* <View className='item' 第二种方案>
                <View className='li'>{data.name?data.name:data.title}</View>
                <View className='dec'>{ data && data.delayDayNum ? `有效期${data.delayDayNum}日` :  data && data.startTime ?  `${data.startTime.split(' ')[0].split('-')[1]}.${data.startTime.split(' ')[0].split('-')[2]}-${data.endTime.split(' ')[0].split('-')[1]}.${data.endTime.split(' ')[0].split('-')[2]}有效` : ''}  </View>
                <View className='destr'>{data.rangeStr}</View>
              </View>
            </View>
              <View className='num'>
                 {data.discountAmount > 0 ?
                 (<Block> <Text className='bol'>¥</Text><Text className='price'>
                     {data.discountAmount}
                     </Text></Block>)
                 :(<Block> <Text className='bol'>天</Text><Text className='price'>{data.delayDays}</Text></Block>)}
              <View className='shop'>
                                       {
                                            data.minAmount>0? (<Block>
                                              满{data.minAmount}元可用
                                            </Block>):(<Block>
                                              满{data.minLease}天可用
                                            </Block>)
                                        }
                  </View>
              <View className='btn'>
                   {
                  data.isBind
                    ? <Text className="to-use" onClick={() => this.props.onGotoTake(data.id)}>立即使用</Text>
                    : <Text className="get-now" onClick={() => this.props.onReceive(data.id)}>立即领取</Text>
                 }
                  </View>
            </View> */}
            {/* 第三种样式 */}
             <View className='item'>
                <View className='li'>{data.name?data.name:data.title}</View>
                <View className='dec'>{ data && data.delayDayNum ? `有效期${data.delayDayNum}日` :  data && data.startTime ?  `${data.startTime.split(' ')[0].split('-')[1]}.${data.startTime.split(' ')[0].split('-')[2]}-${data.endTime.split(' ')[0].split('-')[1]}.${data.endTime.split(' ')[0].split('-')[2]}有效` : ''}  </View>
                <View className='destr'>{data.rangeStr}</View>
              </View>
            </View>
              <View className='num'>
                 {data.discountAmount > 0 ?
                 (<Block> <Text className='bol'>¥</Text><Text className='price'>
                     {data.discountAmount}
                     </Text></Block>)
                 :(<Block> <Text className='bol'>天</Text><Text className='price'>{data.delayDays}</Text></Block>)}
              <View className='shop'>
                                       {/* {
                                            data.minAmount>0? (<Block>
                                              满{data.minAmount}元可用
                                            </Block>):(<Block>
                                              满{data.minLease}天可用
                                            </Block>)
                                        } */}
                                         {
                                            data.minAmount>0? (
                                            <Block>
                                              {  data.minLease>0?(<Block>
                                              满{data.minLease}天可用
                                            </Block>):(<Block>
                                              满{data.minAmount}元可用
                                            </Block>)
                                             }
                                            </Block>
                                            ):(
                                            <Block>
                                             无门槛
                                            </Block>
                                            )
                                        }
                  </View>
              <View className='btn'>
                   {
                  data.isBind
                    ? <Text className="to-use" onClick={() => this.props.onGotoTake(data.templateId)}>立即使用</Text>
                    : <Text className="get-now" onClick={() => this.props.onReceive(data.id)}>立即领取</Text>
                 }
                  </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

export default Optimization;
