import Taro, { Component } from "@tarojs/taro";
import { View, Text, Button, Image } from "@tarojs/components";
import { formatStrDate } from "../../../../utils/utils";
import "./index.scss";

class CardUsed extends Component {
  render() {
    const { data } = this.props; // red, yellow
    // const durationStr = `${formatStrDate(
    //   data.startTime,
    //   "yyyy.MM.dd"
    // )}-${formatStrDate(data.endTime, "yyyy.MM.dd")}`;
    // const durationStr = `1`;
    return (
    //   <View className="container_coupon">
    //     <View
    //       className="content"
    //     >
    //       <View className="num">
    //         <Text className="bol">¥</Text>
    //         <Text className="price">{data.discountAmount}</Text>
    //         <View className="shop">
    //           {data.sourceShopName === "OPE" ? "平台券" : data.sourceShopName}
    //         </View>
    //       </View>
          
    //       <View className="content_box">
    //       <View className="item">
    //         <View className="li">
    //           {data.minAmount === 0 ? "无门槛" : "满" + data.minAmount + "可用"}
    //         </View>
    //         <View className="dec">
    //           { data && data.delayDayNum
    //             ? `有效期${data.delayDayNum}日`
    //             : data && data.startTime ? 
    //             `${data.startTime.split(" ")[0].split("-")[1]}.${
    //               data.startTime.split(" ")[0].split("-")[2]
    //             }-${data.endTime.split(" ")[0].split("-")[1]}.${
    //               data.endTime.split(" ")[0].split("-")[2]
    //             }有效` : ''
    //           }{" "}
    //           | {data.rangeStr}
    //         </View>
    //       </View>
    //       {
    //         this.props.couponType === 'used'
    //           ? <View className="used-coupon">已使用</View>
    //           : <Image mode="aspectFit" className="used-coupon-img" src="../../../images/home/coupon-over-time.png" />
    //       }
    //     </View>
    //     </View>
    //   </View>
     <View className='container'>
        <View className='content' >
          <View className="box">
            <View className="box2">
              <View className='item'>
                <View className='li'>{data.name?data.name:data.title}</View>
                <View className='dec'>{ data && data.delayDayNum ? `有效期${data.delayDayNum}日` :  data && data.startTime ?  `${data.startTime.split(' ')[0].split('-')[1]}.${data.startTime.split(' ')[0].split('-')[2]}-${data.endTime.split(' ')[0].split('-')[1]}.${data.endTime.split(' ')[0].split('-')[2]}有效` : ''}  </View>
                <View className='destr'>{data.rangeStr}</View>
              </View>
            </View>
              <View className='num'>
                 {data.discountAmount > 0 ?
                 (<Block> <Text className='bol'>¥</Text><Text className='price'>
                     {data.discountAmount}
                     </Text></Block>)
                 :(<Block> <Text className='bol'>天</Text><Text className='price'>{data.delayDays}</Text></Block>)}
              <View className='shop'>
                                        {
                                            data.minAmount>0? (
                                            <Block>
                                              {  data.minLease>0?(<Block>
                                              满{data.minLease}天可用
                                            </Block>):(<Block>
                                              满{data.minAmount}元可用
                                            </Block>)
                                             }
                                            </Block>
                                            ):(
                                            <Block>
                                             无门槛
                                            </Block>
                                            )
                                        }
                  </View>
            </View>
          </View>
         
        </View>
      </View>
    );
  }
}

export default CardUsed;
