import Taro, { Component } from '@tarojs/taro';
import { View, Text, Image, ScrollView } from '@tarojs/components';
import * as ConfigureActivitiesService from './service.js';
import { AtTabs, AtTabsPane } from 'taro-ui';
import ParseComponent from '../productDetail/wxParseComponent';
import { redirectToOtherMiniProgram } from '../../utils/utils';
import './index.scss';
class configureActivities extends Component {
  config = {
    navigationBarTitleText: '',
    usingComponents: {},
  };
  state = {
    activityDescription: '',
    data: {},
    activeIndex: 0,
    swiperindex: 0,
  };
  // componentDidShow(){
  //   const { id } = this.$router.params;
  //   ConfigureActivitiesService.queryActivityWebDetail({ id }).then((res) => {
  //     this.setState({
  //       activityDescription: res.data.data.activityDescription,
  //       data: res.data.data,
  //     });
  //     my.setNavigationBar({
  //       title: res.data.data.pageName || '活动配置',
  //     });
  //     my.setBackgroundColor({
  //       backgroundColor: res.data.data.activityBackgroundColor || '#fff',
  //     });
  //   });
  // }

  componentDidMount = () => {
    const { id } = this.$router.params;
    ConfigureActivitiesService.queryActivityWebDetail({ id }).then((res) => {
      this.setState({
        activityDescription: res.data.data.activityDescription,
        data: res.data.data,
      });
      my.setNavigationBar({
        title: res.data.data.pageName || '活动配置',
      });
      my.setBackgroundColor({
        backgroundColor: res.data.data.activityBackgroundColor || '#fff',
      });
    });
  };
  onGoToMore = (url) => {
    if (url.indexOf('alipays://') === 0) {
      redirectToOtherMiniProgram(url);
    } else {
      Taro.navigateTo({ url });
    }
  };
  menuChange = (index) => {
    this.setState({
      activeIndex: index,
    });
  };
  onSwiperChange = (e) => {
    this.setState({
      swiperindex: e.detail.current,
    });
  };
  toProduct = (id) => {
    let url = `/pages/productDetail/index?itemId=${id}`;
    Taro.navigateTo({ url });
  };
  render() {
    const { data, activeIndex, swiperindex } = this.state;
    return (
      <View
        className="configureActivities"
        style={{
          background:data&& data.activityBackgroundColor,
        }}
      >
        {data && data.titleMaterial && data.titleMaterial.materialImage && (
          <View
            style={{
              backgroundImage: `url(${data.titleMaterial.materialImage})`,
            }}
            onClick={() => this.onGoToMore(data.titleMaterial.jumpUrl)}
            className="header_img"
          ></View>
        )}
        {data && data.activityTime && (
          <View
            className="header_time"
            style={{ background: data && data.activityTimeColor }}
          >
            {data.activityTime}
          </View>
        )}
        <View className="content"></View>
        {data && data.tofuCubes && data.tofuCubes.length && (
          <View className="beanCurd">
            {data &&
              data.tofuCubes &&
              data.tofuCubes.map((item) => (
                <Image
                  src={item.materialImage}
                  className="beanCurd_img"
                  onClick={() => this.onGoToMore(item.jumpUrl)}
                />
              ))}
          </View>
        )}
        {data && data.carouselList && data.carouselList.length && (
          <View
            className="shop-item"
            style={{
              background: data && data.carouselBackgroundColor,
            }}
          >
            <swiper
              className="swipe-list"
              circular="{{true}}"
              indicator-dots
              indicator-active-color="#000000"
              autoplay="{{true}}"
              interval="{{4000}}"
              previousMargin="100px"
              nextMargin="100px"
              onChange={this.onSwiperChange}
            >
              {data &&
                data.carouselList &&
                data.carouselList.length &&
                data.carouselList.map((item, index) => {
                  return (
                    <swiper-item key="swiper-item-{{index}}">
                      <Image
                        src={item.materialImage}
                        className={`slide-image ${
                          swiperindex == index ? 'zoom-in' : 'zoom-out'
                        }`}
                        onClick={() => this.onGoToMore(item.jumpUrl)}
                      />
                    </swiper-item>
                  );
                })}
            </swiper>
          </View>
        )}

        {/* <View className="divider">
          <View
            style={{
              display: 'inline-block',
              padding: '0 24px',
              whiteSpace: 'nowrap',
            }}
          >
            {data && data.productMainTitle}
          </View>
        </View> */}
        {data && data.activityTableList && data.activityTableList.length && (
          <ScrollView
            scrollX
            scrollWithAnimation
            scrollTop="0"
            className="menu-list"
            style={{
              background: data && data.tableBackgroundColor,
            }}
          >
            <View className="menu-list-view">
              {data &&
                data.activityTableList &&
                data.activityTableList.length &&
                data.activityTableList.map((item, i) => (
                  <Text
                    onClick={() => this.menuChange(i)}
                    className={
                      'menu-item ' +
                      (i === activeIndex ? 'menu-item-active' : '')
                    }
                    style={
                      i === activeIndex
                        ? {
                            background: data && data.buttonBackgroundColor,
                            borderRadius: '0.44rem',
                          }
                        : {}
                    }
                  >
                    {item.tableName}
                  </Text>
                ))}
            </View>
          </ScrollView>
        )}
        {data && data.activityTableList && data.activityTableList.length && (
          <View className="product-list2">
            {data &&
              data.activityTableList &&
              data.activityTableList.length &&
              data.activityTableList[activeIndex] &&
              data.activityTableList[activeIndex].activityProductDtoList.map(
                (item, index) => (
                  <View
                    className="product-item2"
                    key={item.itemId}
                    onClick={() => this.toProduct(item.productId)}
                  >
                    <View className="product-info">
                      <Image
                        mode="aspectFit"
                        src={item.image}
                        className="product-img"
                      />
                      <View className="product-name">{item.productName}</View>
                    </View>
                    <View className="product-price">
                      ￥
                      <Text className="price-text">
                        {item.price && item.price.toString().split('.')[0]}.
                      </Text>
                      {(item.price && item.price.toString().split('.')[1]) ||
                        '00'}
                      元/天
                    </View>
                    <Button className="product-btn">立即租</Button>
                  </View>
                ),
              )}
          </View>
        )}

        {data && data.bottomMaterial && data.bottomMaterial.materialImage && (
          <View className="bottomMaterial">
            <Image
              src={data.bottomMaterial.materialImage}
              className="bottomMaterial_img"
              onClick={() => this.onGoToMore(data.bottomMaterial.jumpUrl)}
            />
          </View>
        )}
        {data && data.activityDescription && (
          <View className="activityDescription">
            <ParseComponent mark={data && data.activityDescription} />
          </View>
        )}

        {data && data.searchMaterial && data.searchMaterial.materialImage && (
          <View className="searchMaterial">
            <Image
              src={data.searchMaterial.materialImage}
              className="searchMaterial_img"
              onClick={() => this.onGoToMore(data.searchMaterial.jumpUrl)}
            />
          </View>
        )}

        {data && data.footerMaterial && data.footerMaterial.materialImage && (
          <View className="footerMaterial">
            <Image
              src={data.footerMaterial.materialImage}
              className="footerMaterial_img"
              onClick={() => this.onGoToMore(data.footerMaterial.jumpUrl)}
            />
          </View>
        )}
      </View>
    );
  }
}
export default configureActivities;
