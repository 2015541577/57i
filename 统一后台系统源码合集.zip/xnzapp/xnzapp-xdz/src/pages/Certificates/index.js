import Taro, { Component } from '@tarojs/taro'
import { View, Image, Button } from '@tarojs/components'
import { connect } from '@tarojs/redux'
import { baseUrl } from '../../config/index'
import './index.scss'
import {
  getGloble, 
	getUid,
	getUserName,
	getTelephone,
	setTelephone,
  getBuyerId,
} from '../../utils/localStorage'
import { AtCurtain,AtToast } from 'taro-ui'
import Request from '../../utils/request'
import { startAPVerify, getOpenUserInfo } from '../../utils/openApi';
import IdentityCodeValid from '../../utils/idCard';
@connect(({ certificate, members, loading, realName,confirmOrder,authentication }) => ({
	confirmOrder,
	authentication,
	...members,
	...certificate,
	loading: loading.models.certificate,
	realName,
}))
class Certificate extends Component {
	config = {
		navigationBarTitleText: '实名认证',
	}

	state = {
		frontUrl: null,
		backUrl: null,
		idCardHandHeld: null,
		type: '0',
		count: 0,
		checked: true,
		identityData: {
			idCard: '',
			limitDate: '',
			userName: '',
		},
		codeKey2: '',
		codeTime2: '',
		isOpened: false,
		phone: '',
		modifyName: null, //是否可以修改身份信息  1 是 0否
		modifyPhoto: null, //是否可以修改身份照片  1 是 0否
		AtToastShow:false,
		orderId:null,
		productId:null, 
		skuId:null, 
		addressId:null,
	}

	componentDidMount = () => {
		const { frontUrl, backUrl } = this.state
		let { userName, idCard } = this.state.identityData
		const { productId, skuId, addressId, orderId } = (this.$router.params)
		if(orderId) {
			this.setState({
				productId:productId,
				skuId:skuId,
				addressId:addressId,
				orderId:orderId,
			})
		}
		Request({
			url: `hzsx/userCertification/getByUid?uid=${getUid()}`,
			method: 'GET',
			// data: params,
		}).then((res) => {
			this.setState({
				frontUrl: res.data.data.idCardFrontUrl,
				backUrl: res.data.data.idCardBackUrl,
				identityData: res.data.data,
				modifyName: res.data.data.modifyName, //是否可以修改身份信息  1 是 0否
				modifyPhoto: res.data.data.modifyPhoto, //是否可以修改身份照片  1 是 0否
			})
		})
	}

	showToast(title) {
		if (title) {
			Taro.showToast({
				title,
				icon: 'none',
				mask: true,
			})
		}
	}

	reloadValidate = () => {
		this.setState({
			validateImage: `${baseUrl}hzsx/aliPay/user/certification/validateCode?uid=${getUid()}&t=${new Date().getTime()}`,
		})
	}
	// 提醒用户
	onremind = () => {
		Taro.showToast({
			title:"请联系客服进行修改哦~",
			icon: 'none',
		})
	}
	/**
	 * 上传身份证
	 * @param val
	 */
	update = (val) => {
		const { dispatch } = this.props
		if (val === '1') {
			my.chooseImage({
				chooseImage: 1,
				success: (res) => {
					my.uploadFile({
						url: baseUrl + 'hzsx/api/components/uploadFile',
						fileType: 'image',
						fileName: 'multipartFile',
						filePath: res.apFilePaths[0],
						header: {
							'Content-Type': 'application/x-www-form-urlencoded',
							channelId: getGloble('channelId'),
						},
						success: (data) => {
							data = JSON.parse(data.data)
							if (data.responseType !== 'SUCCESS') {
								if (data.errorMessage) {
									Taro.showToast({
										title: data.errorMessage,
										icon: 'none',
									})
								}
							} else {
								this.setState(
									{
										frontUrl: data.data,
									},
									() => {
										const { frontUrl, backUrl } = this.state
										// if (frontUrl && backUrl) {
										//   dispatch({
										//     type: "certificate/certificationOcr",
										//     payload: {
										//       frontUrl,
										//       backUrl,
										//       uid: getUid(),
										//     },
										//     callback: (res) => {
										//       this.setState({
										//         identityData: res.data.data
										//       });
										//     },
										//   });
										// }
									}
								)
							}
						},
						fail: (res) => {
							my.alert({
								content: '上传错误',
							})
						},
					})
				},
			})
		}
		if (val === '2') {
			my.chooseImage({
				chooseImage: 1,
				success: (res) => {
					my.uploadFile({
						url: baseUrl + 'hzsx/api/components/uploadFile',
						fileType: 'image',
						fileName: 'multipartFile',
						filePath: res.apFilePaths[0],
						header: {
							'Content-Type': 'application/x-www-form-urlencoded',
                            channelId: getGloble('channelId'),
						},
						success: (data) => {
							data = JSON.parse(data.data)
							if (data.responseType !== 'SUCCESS') {
								if (JSON.parse(data.data).errorCode) {
									Taro.showToast({
										title: JSON.parse(data.data).errorCode,
										icon: 'none',
									})
								}
							} else {
								this.setState(
									{
										backUrl: data.data,
									},
									() => {
										const { frontUrl, backUrl } = this.state
										// if (frontUrl && backUrl) {
										//   dispatch({
										//     type: "certificate/certificationOcr",
										//     payload: {
										//       frontUrl,
										//       backUrl,
										//       uid: getUid(),
										//     },
										//     callback: (res) => {
										//       this.setState({
										//         identityData: res.data.data,
										//       });
										//     },
										//   });
										// }
									}
								)
							}
						},
						fail: () => {
							my.alert({
								content: '上传错误',
							})
						},
					})
				},
			})
		}
		if (val === '3') {
			my.chooseImage({
				sourceType: ['camera', 'album'],
				success: (res) => {
					my.uploadFile({
						url: baseUrl + 'hzsx/aliPay/components/uploadFile',
						fileType: 'image',
						fileName: 'multipartFile',
						filePath: res.apFilePaths[0],
						header: {
							'Content-Type': 'application/x-www-form-urlencoded',
						},
						success: (res) => {
							let data = JSON.parse(res.data)
							this.setState({
								idCardHandHeld: data.data,
							})
						},
						fail: (res) => {
							my.alert({
								content: '上传错误',
							})
						},
					})
				},
				fail: () => {
					my.showToast({
						content: '取消成功',
					})
				},
			})
		}
	}
	onClose() {
		this.setState({
			isOpened: false,
		})
	}

	/**
	 *form验证
	 * @param e
	 */
	formSubmit = (e) => {
		const { userName, idcard, mobile, smsCode, limitDate } = e.detail.value
		const { dispatch, codeTime, codeKey, telephone } = this.props
		const { checked, frontUrl, backUrl , modifyName , modifyPhoto  } = this.state
		if (!checked) {
			this.showToast('请同意左下方的协议')
			return
		}
		if (!userName) {
			this.showToast('身份信息有误，请检查后重新上传')
			return
		}
		if (!limitDate) {
			this.showToast('身份信息有误，请检查后重新上传')
			return
		}
		if (!idcard || idcard.length !== 18) {
			this.showToast('身份信息有误，请检查后重新上传')
			return
		}
		dispatch({
			type: 'realName/userCertificationAuth',
			payload: {
				codeKey: this.state.codeKey2,
				codeTime: this.state.codeTime2,
				userName,
				idCard: idcard,
				telephone: this.state.phone,
				// smsCode,
				channel: 6,
				limitDate: limitDate,
				uid: getUid(),
				idCardFrontUrl: frontUrl,
				idCardBackUrl: backUrl,
			},
			callback: () => {
				Taro.navigateBack()
			},
		})
	}
	submitSmsCode = () => {
		const { dispatch, telephone } = this.props
		const { mobile, validateCode } = this.state
		const newMob = mobile
		if (!newMob) {
			this.showToast('手机号不能为空')
			return
		}
		dispatch({
			type: 'realName/sendSmsCode',
			payload: {
				mobile: newMob,
				type: 'realName',
				uid: getUid(),
				channel: 6,
			},
			callback: (res) => {
				this.reloadValidate()
				if (res && res.data.responseType === 'SUCCESS') {
					let count = 59
					this.setState({ count })
					this.interval = setInterval(() => {
						count -= 1
						this.setState({ count })
						if (count === 0) {
							clearInterval(this.interval)
						}
					}, 1000)
					this.showToast('验证码已发送，5分钟内有效')
					this.setState({
						codeKey2: res.data.data.codeKey,
						codeTime2: res.data.data.codeTime,
					})
				} else {
					this.showToast('手机号有误，请重新输入')
				}
			},
		})
	}

	/**
	 * 解码授权信息，从中提取手机号码
	 * @param encryString
	 */
	sucHandler = (encryString) => {
		const reqParams = {
			url: 'hzsx/api/components/decrypt',
			method: 'GET',
			data: { content: encryString },
		}
		Request(reqParams).then((res) => {
			let _data = JSON.parse(res.data.data)
			this.formSubmits(_data.mobile)
		})
	}

	/**
	 * 提交用户信息
	 * @param phone
	 */
	formSubmits = (phone) => {
		const { dispatch} = this.props;
		const {
			identityData: { idCard, limitDate, userName },
			frontUrl,
			backUrl,
      orderId,
			productId, 
			skuId, 
			addressId,
		} = this.state
    const idcards=IdentityCodeValid(idCard)
    if (!userName) {
			this.showToast('身份信息有误，请检查后重新上传')
			return
		}
		if (idcards===false) {
			this.showToast('身份信息有误，请检查后重新上传')
			return
		}else {
			// 判断是否是订单页面跳转认证 有订单号的
			if(this.state.orderId) {
				this.props.dispatch({
					type: 'realName/userCertificationAuthTwo',
					payload: {
						codeKey: this.state.codeKey2,
						codeTime: this.state.codeTime2,
						userName,
						idCard: idCard,
						telephone: phone,
						// smsCode,
						channel: 6,
						limitDate: limitDate,
						uid: getUid(),
						idCardFrontUrl: frontUrl,
						idCardBackUrl: backUrl,
						orderId:orderId,
						productId:productId,
						skuId:skuId,
						addressId:addressId,
					},
					callback: (res) => {
						this.setState({
							AtToastShow:false,
						})
						// 这里写逻辑 不等等1 是没报错吊刷脸认证接口
						if (res !== 1 ) {
							if(this.state.orderId){
								dispatch({
									type: 'confirmOrder/faceRecognition',
									payload: {
										orderId: this.state.orderId,
										uid:getUid(),
									},
									callback: (data) => {
										startAPVerify(
												{
													certifyId: data.certifyId,
													url: data.faceUrl,
												},
												function (verifyResult) {
													// 认证结果回调触发, 以下处理逻辑为示例代码，开发者可根据自身业务特性来自行处理
													if (verifyResult.resultStatus === '9000') {
														// 验证成功，接入方在此处处理后续的业务逻辑
														if (
																verifyResult.result &&
																verifyResult.result.certifyId
														) {
															dispatch({
																type: 'authentication/aliFaceAuthSync',
																payload: {
																	certifyId:data.certifyId,
																},
															});
														}
													} else {
														if (
																verifyResult.result &&
																verifyResult.result.certifyId
														) {
															dispatch({
																type: 'authentication/aliFaceAuthSync',
																payload: {
																	certifyId:data.certifyId,
																			passed: false,
																},
															});
														}
													}
													// 用户主动取消认证-
													if (verifyResult.resultStatus === '6001') {
														// 可做下 toast 弱提示m
														Taro.showToast({
															title: '取消认证成功',
														});
														//取消认证直接返回上一页 预授权时 再调人脸 
														// Taro.navigateBack()
														//  Taro.redirectTo({ url: '/pages/orderList/index?type=all' });
													}
													if (verifyResult.result) {
														// Taro.redirectTo({ url: `/pages/checkSuccess/index?orderId=${orderId}&type=1` });
													}
													// 人脸成功返回上一页
													Taro.navigateBack()
												},
										);
									},
								});
							}else {
								Taro.navigateBack()
								this.showToast('认证成功！')
							}
						}
					},
				})
			}else {
				// 从我的页面进来的授权
				this.props.dispatch({
					type: 'realName/userCertificationAuth',
					payload: {
						codeKey: this.state.codeKey2,
						codeTime: this.state.codeTime2,
						userName,
						idCard: idCard,
						telephone: phone,
						// smsCode,
						channel: 6,
						limitDate: limitDate,
						uid: getUid(),
						idCardFrontUrl: frontUrl,
						idCardBackUrl: backUrl,
					},
					callback: (res) => {
						this.setState({
							AtToastShow:false,
						})
						// 这里写逻辑 不等等1 是没报错吊刷脸认证接口
						if (res !== 1 ) {
							Taro.navigateBack()
							this.showToast('认证成功！')
						}
					},
				})
			}
    }
	}

	/**
	 * 获取用户授权手机号码
	 */
	onGetPhone = () => {
		my.getPhoneNumber({
			success: (res) => {
				let encryptedData = res.response // 支付宝所返回的加密数据
				this.sucHandler(encryptedData)
			},
			fail: () => {
				Taro.showToast({
					title: '授权失败',
					icon: 'none',
					duration: 2000,
				})
			},
		})
	}

	onChangeMent = (e) => {
		const { checked } = this.state
		this.setState({
			checked: !checked,
		})
	}
	handleChange() {
		this.setState({
			isOpened: true,
		})
	}
	gotoProtocol = () => {
		Taro.navigateTo({ url: '/pages/webview/xieyi?signNumber=1' })
	}
	handleMobile = (e) => {
		this.setState({ mobile: e.detail.value })
	}

	/**
	 * 绑定输入框
	 * @param inputName
	 * @param e
	 */
	handleInputChange = (inputName, e) => {
		switch (inputName) {
			case 'userName':
				this.state.identityData.userName = e.detail.value
				this.setState({
					identityData:this.state.identityData
				})
				break
			case 'idcard':
				this.state.identityData.idCard = e.detail.value
				this.setState({
					identityData:this.state.identityData
				})
				break
			default:
				break
		}
	}

	/**
	 * 页面输出
	 * @returns {*}
	 */
	render() {
		const { loading } = this.props
		const {
			frontUrl,
			backUrl,
			idCardHandHeld,
			count,
			checked,
			identityData,
			modifyName, 
			modifyPhoto,
			AtToastShow,
		} = this.state
		// loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading()
		return (
			<View className="container_cer">
				<Form report-submit="true" onSubmit={this.formSubmit}>
					<View className="realName-page">
						<View className="contents">
							<View className="contents-line"></View>
							<View className="contents-item">
								<View>姓名</View>
								<Input
									className="contents-item-input"
									placeholder="请填写身份证姓名"
									name="userName"
									disabled={!modifyName}
									onInput={this.handleInputChange.bind(
										this,
										'userName'
									)}
									value={identityData.userName}
								/>
							</View>
							<View className="contents-item">
								<View>身份证号码</View>
								<Input
									className="contents-item-input"
									placeholder="请填写身份证号码"
									name="idcard"
									disabled={!modifyName}
									onInput={this.handleInputChange.bind(
										this,
										'idcard'
									)}
									value={identityData.idCard}
								/>
							</View>
						</View>

						<View className="header">
							温馨提示：上传身份证可优先发货，如无请忽略
						</View>
						{ identityData && identityData.userName && identityData.idCard && identityData.idCard.length == 18 ? (
							<View className="content">
								<View className="item">
									<View
										className="update update-fir"
										onClick={ modifyPhoto ? this.update.bind(this, '1') : this.onremind.bind()}
									>
										{frontUrl ? (
											<Image
												className="update-img"
												src={frontUrl}
											/>
										) : null}
									</View>
								</View>
								<View className="item">
									<View
										className="update update-sed"
										onClick={ modifyPhoto ? this.update.bind(this, '2') : this.onremind.bind()}
									>
										{backUrl ? (
											<Image
												className="update-img"
												src={backUrl}
											/>
										) : null}
									</View>
								</View>
							</View>
						) : null }
						{modifyPhoto ? (
							<Button
								className={
									checked
										? 'bottom-button'
										: 'bottom-button disabled'
								}
								scope="phoneNumber"
								open-type="getAuthorize"
								// formType="submit"
								onGetAuthorize={this.onGetPhone}
								style={{ marginTop: '0.4rem' }}
							>
								提交
							</Button>
						) : null}
					</View>
				</Form>
				<AtCurtain
					isOpened={this.state.isOpened}
					onClose={this.onClose.bind(this)}
					closeBtnPosition="top-right"
				>
					<Image
						style="width:100%;height:250px"
						src={
							'https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/c2c92934b05f46898377421a004bfa90.png'
						}
					/>
				</AtCurtain>
				<AtToast
          isOpened={AtToastShow}
					duration={0}
          hasMask={false}
          text="正在进行验证，请稍后！"
          status="loading"
        />
			</View>
		)
	}
}

export default Certificate
