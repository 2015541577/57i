import Request from "../../utils/request";

export const upLoad = (data) =>
  Request({
    url: "hzsx/aliPay/user/userIdCardPhoto/upLoad",
    method: "POST",
    data,
  });

export const getUserIdCardPhotoInfo = (data) =>
  Request({
    url: "hzsx/aliPay/user/userIdCardPhoto/getUserIdCardPhotoInfo",
    method: "GET",
    data,
  });
export const updateUpLoad = (data) =>
  Request({
    url: "hzsx/aliPay/user/userIdCardPhoto/updateUpLoad",
    method: "POST",
    data,
  });

export const certificationOcr = (data) =>
  Request({
    url: "hzsx/userCertification/certificationOcr",
    method: "POST",
    data,
  });
