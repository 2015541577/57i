import Taro from "@tarojs/taro";
import * as certificatesApi from "./service";
import { getUid } from "../../utils/localStorage";

export default {
  namespace: "certificate",
  state: {},

  effects: {
    // 上传图片认证
    *upLoad({ payload, callback }, { call, put }) {
      const res = yield call(certificatesApi.upLoad, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        if (res.msg) {
          Taro.showToast({
            title: res.msg,
            icon: "none",
          });
        }
        if (callback) {
          callback(res);
        }
      }
    },
    // 获取用户身份信息
    *getUserIdCardPhotoInfo({ payload, callback }, { call, put }) {
      const res = yield call(certificatesApi.getUserIdCardPhotoInfo, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        Taro.showToast({
          title: res.msg,
          icon: "none",
        });
        if (callback) {
          callback(res);
        }
      }
    },
    // 更新上传认证
    *updateUpLoad({ payload, callback }, { call, put }) {
      const res = yield call(certificatesApi.updateUpLoad, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        Taro.showToast({
          title: res.msg,
          icon: "none",
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *certificationOcr({ payload, callback }, { call, put }) {
      const res = yield call(certificatesApi.certificationOcr, {
        ...payload,
        uid: getUid(),
      });
      if (res) {
        if (callback) {
          callback(res);
        }
      }
    },
  },

  reducers: {},
};
