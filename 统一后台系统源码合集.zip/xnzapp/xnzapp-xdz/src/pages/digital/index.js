import Taro ,{Component} from '@tarojs/taro'
import {View} from '@tarojs/components'
import './index.scss'
class Digital extends Component {
    config = {
        navigationBarTitleText:'信用授权协议'
    }
    
    render () {
        return (
            <View className="digital">
              <Image 
               className="digital_img"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6c4c19dbc95c4c23a483140193a37b21.png"
              />
            </View>
        )
    }
}

export default Digital