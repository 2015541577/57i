import Taro, { Component } from '@tarojs/taro';
import { View, Input, Icon, Text } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import SearchPlate from './component/searchPlate/index';
import { abilitySecondHand, abilityNewPhone } from '../../utils/constant';
import './index.scss';

@connect(({ search, loading }) => ({
  ...search,
  loading: loading.models.search,
}))
class Search extends Component {
  config = {
    navigationBarTitleText: '搜索',
  };

  state = { value: null }

  componentDidMount = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'search/getHistory',
    });
  };

  // fix: 如果使用普通函数的话，那么使用this将会有某些数据获取不到
  navigateToList = (value) => {
    Taro.navigateTo({ url: `/pages/productList/index?type=search&content=${value}&useLoc=${this.$router.params.useLoc}` });
  }
  // 跳转商户列表
  navigateToShopList = (value) => {
    Taro.navigateTo({ url: `/pages/productShopList/index?type=search&content=${value}&useLoc=${this.$router.params.useLoc}` });
  }
  handleClearHistory() {
    const { dispatch } = this.props;
    dispatch({
      type: 'search/clearHistory',
    });
  }

  handleChangeInput(e) {
    this.setState({ value: e.detail.value });
  }

  handleSearch() {
    const { value } = this.state;
    if (value) {
      const { dispatch } = this.props;
      this.navigateToList(value);
    }
  }
  handleSearchShop() {
    const { value } = this.state;
    if (value) {
      const { dispatch } = this.props;
      this.navigateToShopList(value);
    }
  }
  handleClearValue() {
    this.setState({ value: '' });
  }

  handleGoBack = () => {
    const useLoc = this.$router && this.$router.params && this.$router.params.useLoc;
    if (abilityNewPhone === useLoc || abilitySecondHand === useLoc) { // 使用场景在能力中心
      Taro.navigateBack();
    } else {
      Taro.switchTab({ url: '/pages/home/index' });
    }
  }

  render() {
    const { value } = this.state;
    const { recommend, history } = this.props;

    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();

    return (
      <View className='search-page'>
        <View className='search-top'>
          <View className='search-page-input'>
            <Icon
              className='search-icon'
              type='search'
              size='16'
              color='#cccccc'
            />
            <Input
              name='search'
              type='text'
              className='search-input'
              placeholder='搜索你想要的商品'
              value={value}
              confirmType='搜索'
              onInput={this.handleChangeInput}
              onConfirm={this.handleSearch.bind(this)}
            />
            {!!value && (
              <View onClick={this.handleClearValue}>
                <Icon
                  className='search-icon cancel'
                  type='cancel'
                  size='16'
                  color='#cccccc'
                />
              </View>
            )}
          </View>
          <Text className='search-cancel' onClick={this.handleGoBack}>取消</Text>
        </View>
        {!!value && (
          <View>
            <View className="new_search"  onClick={this.handleSearchShop.bind(this)}>
              <Image
                className="new_img"
                src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/68755af91982476d8bc9751861200e6e.png"
              />
              <View className="new_text">
                搜索“<View className="new_textB">{value}</View>”店铺
              </View>
              <View className="new_textA">
                {">"}
              </View>
            </View>
            <View className="new_search" style="padding:0;"  onClick={this.handleSearch.bind(this)}>
              <View className="new_text" style="padding-left:24px;">
                搜索“<View className="new_textB">{value}</View>”商品
              </View>
              <View className="new_textA">
                {">"}
              </View>
            </View>
          </View>
        )}
        {/* 分界线 */}
        {!value &&(
          <View className='search-found'>
            <SearchPlate
              data={recommend}
              type='recommend'
              onClick={this.navigateToList}
            />
          </View>
        )}
        {!!history && !!history.length && !value && (
          <View>
            <View className='search-border'></View>
            <View className='search-found'>
              <SearchPlate
                data={history}
                type='history'
                onClick={this.navigateToList}
                onClear={this.handleClearHistory}
              />
            </View>
          </View>
        )}

      </View>
    )
  }
}

export default Search;
