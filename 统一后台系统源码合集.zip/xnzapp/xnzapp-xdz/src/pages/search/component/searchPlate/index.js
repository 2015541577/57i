import Taro, { Component } from '@tarojs/taro';
import { View, Text } from '@tarojs/components';
import './index.scss';
import { connect } from '@tarojs/redux'
@connect(({ search, loading }) => ({
  ...search,
  loading: loading.models.search,
}))
class SearchPlate extends Component {
  handleClick = (value) => {
    const { onClick } = this.props;
    onClick(value);
  }
  onClear = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'search/clearHistory',
    });
  }
  render() {
    const { data, type, onClear } = this.props;
    return (
      <View className='search-plate'>
        <View className='search-plate-title'>
          <View className='title'>{type === 'recommend' ? '热门推荐' : '历史搜索'}</View>
          {type === 'history' && (
            <View className='title' onClick={this.onClear}>清空</View>
          )}
        </View>
        <View className='search-plate-view'>
          {!!data && !!data.length && data.map(info => (
            <View key={info.id} className='search-plate-view-item'>
              <Text className='text' onClick={this.handleClick.bind(this, info.word)}>{info.word}</Text>
            </View>
          ))}
        </View>
      </View>
    )
  }
}

export default SearchPlate;
