import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const insertHistory = data => Request({
  url: 'hzsx/userWordHistory/addUserWordHistory',
  method: 'POST',
  data,
});

export const selectHistory = data => Request({
  url: 'hzsx/userWordHistory/getUserWordHistory',
  method: 'GET',
  data,
});

export const deleteHistory = data => Request({
  url: 'hzsx/userWordHistory/deleteUserWordHistory',
  method: 'GET',
  data,
});