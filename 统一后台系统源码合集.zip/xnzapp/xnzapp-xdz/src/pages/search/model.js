import Taro from '@tarojs/taro';
import * as searchApi from './service';
import { getUid } from '../../utils/localStorage';

export default {
  namespace: 'search',
  state: {
    recommend: [{ id: 0, word: '苹果' }, { id: 1, word: '华为Mate' }, { id: 2, word: 'iPhone 14' }, { id: 3, word: '台式电脑' }, { id: 4, word: '二手严选' }, { id: 5, word: '短租商品' }],
    history: [],
  },

  effects: {
    // 获取搜索历史
    * getHistory(_, { call, put }) {
      if (!getUid()) {
        return;
      }
      const res = yield call(searchApi.selectHistory, { uid: getUid() });
      if (res) {
        yield put({
          type: 'saveHistory',
          payload: { history: res.data.data },
        });
      }
    },
    // 搜索时保存搜索条件
    * setHistory({ payload }, { call, put }) {
      if (!getUid()) {
        return;
      }
      const res = yield call(searchApi.insertHistory, { ...payload, uid: getUid() });
      if (res) {
        yield put({
          type: 'getHistory',
        });
      }
    },
    // 清空搜索历史
    * clearHistory(_, { call, put }) {
      if (!getUid()) {
        return;
      }
      const res = yield call(searchApi.deleteHistory, { uid: getUid(), type: 0 });
      if (res) {
        yield put({
          type: 'getHistory',
        });
      }
    },
  },

  reducers: {
    saveHistory(state, { payload }) {
      return { ...state, ...payload };
    },
  },

};
