import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const selectByPraentIdToName = data =>
  Request({
    url: 'hzsx/userAddress/selectByPraentIdToName',
    method: 'GET',
    data,
  });

export const insertAddress = data =>
  Request({
    url: 'hzsx/userAddress/addUserAddress',
    method: 'POST',
    data,
  });

export const updateAddress = data =>
  Request({
    url: 'hzsx/userAddress/modifyUserAddress',
    method: 'POST',
    data,
  });

export const deleteAddress = data =>
  Request({
    url: 'hzsx/userAddress/deleteUserAddress',
    method: 'GET',
    data,
  });
  
export const selectByAddressListByUid = data =>
  Request({
    url: 'hzsx/userAddress/getUserAddressById',
    method: 'GET',
    data,
  });

