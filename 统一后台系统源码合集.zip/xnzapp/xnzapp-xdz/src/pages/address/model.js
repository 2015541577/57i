import * as addressApi from './service';
import { getUid } from '../../utils/localStorage';

export default {
  namespace: 'address',
  state: {
    list: [],
  },

  effects: {
    // 获取地址列表
    * getUserAllAddressList({payload,callback}, { call, put }) {
        // 这里新添加了...payload  {payload,callback}, callback()  DY
      const res = yield call(addressApi.getUserAllAddressList, { ...payload,uid: getUid() });
      if (res) {
        callback(res.data.data);
        yield put({
          type: 'saveList',
          payload: res.data.data,
        });
      }
    },
    // 获取上次下单地址
    * getLastUserAddressList({payload,callback}, { call, put }) {
        // 这里新添加了...payload  {payload,callback}, callback()  DY
      const res = yield call(addressApi.getLastUserAddressList, { ...payload,uid: getUid() });
      if (res) {
        callback(res.data.data);
        yield put({
          type: 'saveLastList',
          payload: res.data.data,
        });
      }
    },
    // 保存支付宝地址
    * saveZhifubaoAddress({payload,callback}, { call, put }) {
      const res = yield call(addressApi.saveZhifubaoAddress, { ...payload,uid: getUid() });
      if (res) {
        callback(res)
      }
    },
    // demo
    * effectsDemo(_, { call, put }) {
      const { status, data } = yield call(addressApi.demo, {});
      if (status === 'ok') {
        yield put({
          type: 'save',
          payload: {
            topData: data,
          }
        });
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return { ...state, ...payload };
    },

    saveList(state, { payload }) {
      return {
        ...state,
        list: payload
      };
    },
    saveLastList(state, { payload }) {
      return {
        ...state,
        list: payload
      };
    },
  },

};
