import Taro, { Component } from "@tarojs/taro";
import { View, Button } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import * as addressApi from "./service";
import AddressItem from "./component/addressItem/index";
import "./index.scss";

@connect(({ address, loading }) => ({
  ...address,
  loading: loading.models.address,
}))
class Address extends Component {
  config = {
    navigationBarTitleText: "收货地址",
  };
  componentDidShow() {
    Taro.setStorageSync(`isShow_s`, 1);
  }
  componentDidMount = () => {
    const { dispatch } = this.props;
    dispatch({
      type: "address/getUserAllAddressList",
       callback: (res) => {},
    });
  };
  componentWillUnmount() {
    if (Taro.getStorageSync(`isShow_s`) == 1) {
      Taro.setStorageSync(`isShow`, 1); //1为显示
    }
  }
  gotoAdd = () => {
    Taro.navigateTo({ url: "/pages/addAddress/index" });
  };

  onEditAddress = (id) => {};

  onDelete = (id) => {
    const { dispatch, list } = this.props;
    if (list.length == 1) {
      Taro.setStorageSync(`isShow_s`, 1);
      Taro.setStorageSync(`isShow`, 1);
    } else {
      Taro.setStorageSync(`isShow_s`, 2);
      Taro.setStorageSync(`isShow`, 0); //1为显示
    }
    dispatch({
      type: "addAddress/deleteAddress",
      payload: { id },
    });
  };

  onDefault = (id) => {
    const { dispatch } = this.props;
    dispatch({
      type: "addAddress/subAddress",
      payload: { id, isDefault: 1 },
    });
  };

  handleSelect = (index) => {
    const { dispatch, list } = this.props;
    const { type, orderId, pages, type2, typess } = this.$router.params;
    // 有orderId--》设置订单新地址
    if (typess === "购买") {
      addressApi
        .addressModify({
          orderId,
          area: list[index].area,
          city: list[index].city,
          province: list[index].province,
          realName: list[index].realname,
          street: list[index].street,
          telephone: list[index].telephone,
          zcode: list[index].zcode,
        })
        .then((res) => {
          if (res.data) {
            Taro.navigateBack({
              orderId,
              type: type2,
            });
          }
        });
    } else if (orderId) {
      addressApi
        .userOrderAddressModify({
          orderId,
          area: list[index].area,
          city: list[index].city,
          province: list[index].province,
          realName: list[index].realname,
          street: list[index].street,
          telephone: list[index].telephone,
          zcode: list[index].zcode,
        })
        .then((res) => {
          if (res.data.responseType === "SUCCESS") {
            Taro.navigateBack({
              orderId,
              type: type2,
            });
          }
        });
      return;
    }

    if (list.length == 1) {
      Taro.setStorageSync(`isShow_s`, 1);
      Taro.setStorageSync(`isShow`, 1);
    } else {
      Taro.setStorageSync(`isShow_s`, 2);
      Taro.setStorageSync(`isShow`, 0); //1为显示
    }
    if (type === "select") {
      dispatch({
        type: "confirmOrder/setDefaultUserAddress",
        payload: list[index],
      });
      Taro.navigateBack();
    }else if (type === 'scoreSelect'){
      // 积分订单
      dispatch({
        type: "orderSubmit/addressChange",
        payload: list[index],
      });
      Taro.navigateBack();
    }
  };
  alipayAddress = () => {
    const { dispatch } = this.props;
    my.getAddress({
      success: (res) => {
        const obj = res.result;
        if (res.result) {
          dispatch({
            type: "address/saveZhifubaoAddress",
            payload: {
              areaStr: obj.area,
              cityStr: obj.city,
              isDefault: 0,
              provinceStr: obj.prov,
              realname: obj.fullname,
              street: obj.address,
              telephone: obj.mobilePhone,
            },
            callback: () => {
              dispatch({
                type: "address/getUserAllAddressList",
              });
            },
          });
        }
      },
    });
  };
  render() {
    const { list, loading } = this.props;

    // eslint-disable-next-line no-undef
    // loading ? my.showLoading({ content: "加载中..." }) : my.hideLoading();
    return (
      <View className="address-page">
        {list &&
          list.length &&
          list.map((data, index) => (
            <View onClick={this.handleSelect.bind(this, index)}>
              <AddressItem
                data={data}
                onEditAddress={this.onEditAddress}
                onDefault={this.onDefault}
                onDelete={this.onDelete}
              />
            </View>
          ))}
        <View className="address-page-btn">
            {/* 这里的按钮新增暂时注销 换成了自定义弹框  但是逻辑没有注销只是简单注销了按钮的 */}
          {/* <Button className="btn btn_add" onClick={this.gotoAdd}>
            {" "}
            + 新增地址
          </Button> */}
          <Button className="btn btn_auth" onClick={this.alipayAddress}>
            获取支付宝收货地址
          </Button>
        </View>
      </View>
    );
  }
}

export default Address;
