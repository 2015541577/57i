import Request from "../../utils/request";

export const demo = (data) => {
  return Request({
    url: "路径",
    method: "POST",
    data,
  });
};

export const getUserAllAddressList = (data) =>
  Request({
    url: "hzsx/userAddress/getUserAddress",
    method: "GET",
    data,
  });
export const getLastUserAddressList = (data) =>
  Request({
    url: "hzsx/userAddress/getLastUserAddress",
    method: "GET",
    data,
  });
export const userOrderAddressModify = (data) =>
  Request({
    url: "hzsx/api/order/userOrderAddressModify",
    method: "POST",
    data,
  });
export const addressModify = (data) =>
  Request({
    url: "hzsx/userOrdersPurchase/addressModify",
    method: "POST",
    data,
  });

export const saveZhifubaoAddress = (data) =>
  Request({
    url: "hzsx/userAddress/addUserAddress",
    method: "POST",
    data,
  });
