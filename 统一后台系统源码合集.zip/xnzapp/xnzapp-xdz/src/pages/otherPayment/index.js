import Taro, { Component } from "@tarojs/taro";
import {
  View,
  Button,
  Image,
} from "@tarojs/components";
import "./index.scss";
import { tradePay } from "../../utils/openApi";
import { connect } from '@tarojs/redux';
import * as billDetailApi from "./service";
import Request from "../../utils/request";

@connect(({ billDetail, loading }) => ({
  ...billDetail,
  loading: loading.models.billDetail,
}))
class otherPayment extends Component {
  config = {
    navigationBarTitleText: "代付",
  };

  state = {
    data:[]
  };

  
    

  componentDidMount() {
    const { orderid , periods, totalAmount} = this.$router.params;
    const { dispatch } = this.props;
    // const payTotal = 0.09;
    // const outTradeNo  = "1";
    // const  orderId  = "008OI202107285627890295877804032";
    // const payTotal = periods;
    // const outTradeNo  = totalAmount;
    // const  orderId  = orderid ;
    
    const payTotal = parseFloat(totalAmount);
    const outTradeNo  = periods;
    const  orderId  = orderid;
    dispatch({
      type: 'billDetail/orderbyStagesPay',
      payload: { payTotal, outTradeNo, orderId },
      callback:(data)=>{
        if(data === 'suc'){
          dispatch({
            type: 'billDetail/selectOrderByStagesList',
            payload: { orderId },
          });
        }
      }
    });
    //获取到商品数据  img  价格
    // Request({
    //   url:'hzsx/api/orderByStages/orderByStagesPay',
    //   method:'post',
    //   data:{
    //     buyerId: "2088002371291984",
    //     channelId: "006",
    //     orderId: "008OI202107275624499608176099328",
    //     periodList: ["1"],
    //     totalAmount: 0.09,
    //   }
    // }).then(res=>{
    //   if (res.data.responseType === "SUCCESS") {
    //     try {
    //       const payres = yield tradePay(
    //         "orderStr",
    //         res.data.data.payUrl,
    //         "TradeAppPay",
    //         res.data.data.serialNo
    //       );

    //       let type = "suc";
    //       if (payres.resultCode !== "9000") {
    //         type = "error";
    //       }
    //       if (callback) {
    //         callback(type);
    //       }
    //     } catch (e) {
    //       Taro.showToast({
    //         title: "支付失败，请重试或联系客服",
    //         icon: "none",
    //       });
    //     }
    //   } else {
    //     if (res.data.errorMessage) {
    //       Taro.showToast({
    //         title: res.data.errorMessage,
    //         icon: "none",
    //       });
    //     }
    //   }
    // })
  }
  replaceSubmit = () => {
    
    //获取到商品数据  img  价格
    // Request({
    //   url:'hzsx/api/orderByStages/orderByStagesPay',
    //   method:'post',
    //   data:{
    //     buyerId: "2088002371291984",
    //     channelId: "006",
    //     orderId: "008OI202107275624499608176099328",
    //     periodList: ["1"],
    //     totalAmount: 0.09,
    //   }
    // }).then(res=>{
    //   if (res.data.responseType === "SUCCESS") {
    //     try {
    //       const payres = yield tradePay(
    //         "orderStr",
    //         res.data.data.payUrl,
    //         "TradeAppPay",
    //         res.data.data.serialNo
    //       );
    //       let type = "suc";
    //       if (payres.resultCode !== "9000") {
    //         type = "error";
    //       }
    //       if (callback) {
    //         callback(type);
    //       }
    //     } catch (e) {
    //       Taro.showToast({
    //         title: "支付失败，请重试或联系客服",
    //         icon: "none",
    //       });
    //     }
    //   } else {
    //     if (res.data.errorMessage) {
    //       Taro.showToast({
    //         title: res.data.errorMessage,
    //         icon: "none",
    //       });
    //     }
    //   }
    // })
    // ---------------------------------------
    // const { orderid , periods, totalAmount} = this.$router.params;
    // const { dispatch } = this.props;
    // // const payTotal = 0.09;
    // // const outTradeNo  = "1";
    // // const  orderId  = "008OI202107285627890295877804032";
    // // const payTotal = periods;
    // // const outTradeNo  = totalAmount;
    // // const  orderId  = orderid ;
    
    // const payTotal = parseFloat(totalAmount);
    // const outTradeNo  = periods;
    // const  orderId  = orderid;
    // dispatch({
    //   type: 'billDetail/orderbyStagesPay',
    //   payload: { payTotal, outTradeNo, orderId },
    //   callback:(data)=>{
    //     if(data === 'suc'){
    //       dispatch({
    //         type: 'billDetail/selectOrderByStagesList',
    //         payload: { orderId },
    //       });
    //     }
    //   }
    // });
  }
 

  // loadgoods (e) {
  //   Request({
  //     url:'/pages/productDetail/index?itemId=',
  //     data:{

  //     }
  //   })
  // }


  /*
    本页面为暑期活动页，由于没有接口且只有指定的十八个商品，所以页面数据写死
  */

    //点击商品跳转到商品详情页
  // loadgoods(id){
  //   Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${id}` });
  // }
  

 

  

  

  // onShareAppMessage() {
  //   return {
      
  //     success: () => {
        
  //     },
  //   };
  // }

  

 
  

  
  render() {

    return (
        // <Button onClick={this.replaceSubmit}  className={`btn_b`}  >找人代付</Button>
        <View></View>
    );
  }
}

export default otherPayment;
