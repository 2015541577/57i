import Request from '../../utils/request';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const exemptLogin = data =>
  Request({
    url: 'hzsx/aliPay/user/exemptLogin',
    method: 'GET',
    data,
  });
export const exemptLoginNew = data =>
  Request({
    url: 'hzsx/aliPay/user/exemptLogin',
    method: 'POST',
    data,
  });
export const recommendPoductList = data =>
  Request({
    url: 'hzsx/aliPay/product/recommendPoductList',
    method: 'GET',
    data,
  });

export const userOrderStatusCount = data =>
  Request({
    url: 'hzsx/api/order/userOrderStatusCount',
    method: 'POST',
    data,
  });

  export const getMyOpeConfig = data =>
  Request({
    url: 'hzsx/aliPay/index/getMyOpeConfig',
    method: 'GET',
    data,
  });
  export const getIndexTabAndProduct = (data) => {
    return Request({
      url: "hzsx/aliPay/index/getIndexTabAndProductByPage",
      method: "GET",
      data,
    });
  };

  export const getIndexActionListByPage = (data) => {
    return Request({
      url: "hzsx/aliPay/index/getIndexActionListByPage",
      method: "GET",
      data,
    });
  };