import Taro, { Component } from "@tarojs/taro";
import { View, Image, Text, ScrollView } from "@tarojs/components";
import { connect } from "@tarojs/redux";
import { AtIcon, AtBadge, AtToast } from "taro-ui";
import TagServicePage from "../../components/service";
import * as mineApi from "./service";
// import menuList from './menu.js';
import "./index.scss";
import {
  getUid,
  getAvatar,
  getNickName,
  getServicePhone,
  getBuyerId,
  getGloble,
  getActivityCode,
	getshareCode,
} from "../../utils/localStorage";
import umUpload from "../../utils/umengUploadData";
import TagPage from "../home/component/curtain/index";
import Channel from '../home/component/channel/index'
import Request from "../../utils/request";
import { redirectToOtherMiniProgram, leftTimerMS_C} from '../../utils/utils'
@connect(({ mine, realName }) => ({
  ...mine,
  ...realName,
}))
class Mine extends Component {
  config = {
    navigationBarTitleText: "我的",
    titleBarColor: "#AEABCD",
    usingComponents: {
      modal: "../../npm/mini-antui/es/modal/index",
    },
  };
    activeMenuId = '' // 当前选中菜单的id
	activeMenuIds= ""
	systemInfo = Taro.getSystemInfoSync() // 系统信息，之前在render里面，应避免每次render都执行不变的计算工作
  state = {
    showServicePhone: false,
    isTagOpened: false,
    AtToastIsOpened: false,
    isPhone: false,
    menuList: [],
    // 服务列表
    serverList: [],
    // 工具列表
    toolsList: [],
    // 是否授权
    isSetting: false,
    // 客服弹窗
    isServerTagOpened: false,
    successVip:false,
    orderCounts:0,
    activeMenuIndex: 0, // 当前选中的menu的index
    classifyMenuIndex:0, // 新分类
    // 物流信息
    nodeLista:[],
  };
  goVip(){
    my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
          Taro.navigateTo({ url: '/pages/vip/index' });
        } else {
          // 未授权
          this.setState({
            isTagOpened: true,
            AtToastIsOpened:false
          });
        }
      },
    });
    // Taro.navigateTo({ url: '/pages/vip/index' });
  };
  onClosePhoneModal = () => {
    this.setState({
      showServicePhone: false,
    });
  };

  componentDidShow = () => {
    const { dispatch } = this.props;
    mineApi.getMyOpeConfig({}).then((res) => {
      this.setState({
        serverList: res.data.services || [],
        toolsList: res.data.tools || [],
        menuList: res.data.orders || [],
      });
    });

    dispatch({
      type: "home/getSysConfigByKey",
    });
    my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        console.log(phoneNumber,userInfo,'====================');
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
          this.setState({
            isSetting: true,
          });
          dispatch({
            type: "mine/fetchAuthCode",
            callback: () => {
              setTimeout(() => {
                dispatch({
                  type: "mine/userOrderStatusCount",
                });
              }, 500);
            },
          });
        } else {
          // 未授权
          this.setState({
            isTagOpened: true,
          });
        }
      },
    });
     this.getCount()
     this.showQueryInfo()
  };
  //---------
  componentDidMount() {
   this.getCount()
  }
  getCount =()=>{
     Request({
      // http://192.168.2.118/llxz-api-web/hzsx/aliPay/user/getAliMemberInfo?uid=5a01849cea4b493190b60e6808badc196cd9fcb583d7bflyhbpj
      url: "hzsx/aliPay/user/getAliMemberInfo",
      method: "GET",
      data: {
        uid:getUid(),
      },
    }).then((res) => {
      this.setState({
        successVip: res.data.data.success,
        orderCounts:res.data.data.orderCount,
      });
    });
  }
  handleOrderStatus = (id) => {
    Taro.navigateTo({
      url: `/pages/orderList/index?type=${id}`,
    });
  };

  skipToOrder = () => {
    my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
          Taro.navigateTo({
            url: "/pages/orderList/index?type=all",
          });
        } else {
          // 未授权
          this.setState({
            isTagOpened: true,
            AtToastIsOpened:false
          });
        }
      },
    });
  };

  // skipToOrders = () => {
  //   my.getSetting({
  //     success: (res) => {
  //       const userInfo = res.authSetting.userInfo;
  //       const phoneNumber = res.authSetting.phoneNumber;
  //       // 测试
  //       //if (true) {
  //       if (
  //         !!getUid() &&
  //         // !!getAvatar() &&
  //         !!Taro.getStorageSync("userPhone") &&
  //         userInfo &&
  //         phoneNumber
  //       ) {
  //         Taro.navigateTo({
  //           url: "/pages/orderLists/index",
  //         });
  //       } else {
  //         // 未授权
  //         this.setState({
  //           isTagOpened: true,
  //           AtToastIsOpened:false
  //         });
  //       }
  //     },
  //   });
  // };

  skipOtherPage2 = (url) => {
    my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
          if (!url || url === "customerService") {
            return;
          }
          if (url.indexOf("alipays://") === 0) {
            const index = url.indexOf("appId=");
            const indexPage = url.indexOf("=/");
            const appId = url.substr(index + 6, 16);
            const path = url.substring(indexPage + 1, url.length);
            if (indexPage !== -1) {
              my.navigateToMiniProgram({
                appId,
                path: path,
              });
            } else {
              my.navigateToMiniProgram({
                appId,
              });
            }
          } else {
            Taro.navigateTo({ url });
          }
        } else {
          if(url !== "customerService" ){
            // 未授权
            this.setState({
              isTagOpened: true,
              AtToastIsOpened:false
            });
          }
        }
      },
    });
  };

  // 各小节点击
  skipOtherPage = (type) => {
    // 点击“客服”
       my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
          Taro.navigateTo({ url: '/pages/coupon/oldCoupon' });
        //   if (type === "chat") {
        //     this.setState({
        //       isServerTagOpened: true,
        //     });
        //     return;
        //   }
      
        //   const { isCertified } = this.props;
        //   if ((type === "realName" && isCertified === "F") || type !== "realName") {
        //     Taro.navigateTo({
        //       url: `/pages/${type}/index`,
        //     });
        //   }
        } else {
          // 未授权
          this.setState({
            isTagOpened: true,
            AtToastIsOpened:false
          });
        }
      },
    });
  };
 toLogin =()=>{
      this.setState({
            isTagOpened: true,
            AtToastIsOpened:false
          });
 }
  gotoProductDetail = (itemId) => {
    Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` });
  };

  //客服
  connectService = (number) => {
    let num = String(number);
    my.makePhoneCall({ number: num });
  };

  authOnClose = (val) => {
    this.setState(
      {
        isTagOpened: val,
        AtToastIsOpened: true,
      },
      () => {
        // setTimeout(function () {
        //   Taro.switchTab({
        //     url: `/pages/home/index`,
        //   });
        // }, 1000); //停1秒
      }
    );
  };

  // 登录分为两个步骤走，分别是第一步立即授权 和 第二步 手机号授权，这里是第一步 立即授权。在立即授权阶段将会获取到 用户的一些基本信息，比如说用户名，头像，地址等
  onGetAuthorize = () => {
    const { dispatch } = this.props;
    dispatch({
      type: "mine/fetchAuthCode",
      callback: () => {
        this.setState({
          isPhone: true,
        });
      },
    });
  };

  // 登录的第二个步骤，使用手机号授权, 获取到用户的手机号信息
  onGetPhone = () => {
    const { dispatch } = this.props;
    dispatch({
      type: "realName/getPhoneNumber",
      callback: () => {
        this.setState({
          isPhone: false,
          isTagOpened: false,
          isSetting: true,
        });
        dispatch({
          type: "mine/userOrderStatusCount",
        });
        if (getGloble("formId")) {
          dispatch({
            type: "home/putMessageFn",
            payload: {
              formId: getGloble("formId"),
              // userTemplateId: "ZDlhMmVjNWUxMDUyOTNmNDkyMDJhM2RlNWE5ZTc5MGE="
              userBehaviorType: "AUTHORIZED_LOGIN",
            },
          });
        }
      },
    });
  };

  // 监听点击tab栏，进行事件上报。这是个页面周期方法，试了下在app.js写无效，得复制到各个tab页面中
  onTabItemTap(object) {
    umUpload.bottomNavClickHandler(object);
  }

  // 关闭弹窗
  handleClose = () => {
    this.setState({
      isServerTagOpened: false,
    });
  };

  componentDidHide() {
    this.setState({
      AtToastIsOpened: false,
    });
  }
//  新增的收藏夹跳转
toCollect = ()=>{
      my.getSetting({
      success: (res) => {
        const userInfo = res.authSetting.userInfo;
        const phoneNumber = res.authSetting.phoneNumber;
        // 测试
        //if (true) {
        if (
          !!getUid() &&
          // !!getAvatar() &&
          !!Taro.getStorageSync("userPhone") &&
          userInfo &&
          phoneNumber
        ) {
            Taro.navigateTo({
                url:'/pages/myCollect/index'
            })
        } else {
          // 未授权
          this.setState({
            isTagOpened: true,
            AtToastIsOpened:false
          });
        }
      },
    });
}
  /**
   * 跳转到商品详情页面
   * @param {*} itemId : 商品ID
   */
  onGotoProduct = (itemId) => {
      Taro.navigateTo({ url: `/pages/productDetail/index?itemId=${itemId}` })
  }
  /**
   * 当菜单处于第一个焦点的时候，会显示banner
   * 点击banner触发该方法
   * @param {*} url
   */
  onGoToMore = (url) => {
      if (url.indexOf('alipays://') === 0) {
          redirectToOtherMiniProgram(url)
      } else {
          // if (url == '/SharingRentFree/sharerent/index') {
          // 	this.onShare()
          // } else {
          // 	Taro.navigateTo({ url })
          // }
              Taro.navigateTo({ url })
      }
  }
  // menu激活项改变
  activeMenuIndexChange(index, item) {
      const { dispatch } = this.props
      const id = item.id
      this.activeMenuId = id
      this.setState({ activeMenuIndex: index }, () => {
          const info = { pageNum: 1, pageSize: 10, tabId: id }
          dispatch({
              type: 'mine/getIndexTabAndProduct',
              payload: { ...info },
          })
      })
  }
  // 商品激活项改变
  classifyIndexChange(index, item) {
      const { dispatch } = this.props
      const info = {
          pageNum: 1,
          pageSize: 10,
          tabId: item.id,
      }
      this.activeMenuIds = item.id;
      this.setState({
          classifyMenuIndex: index,
          classifyList:[]
      })
      dispatch({
          type: 'mine/getIndexTabAndProduct',
          payload: { ...info },
          callback: (res) => {
              // this.state.classifyList.push({
              // 	name: item.name,
              // 	id: item.id,
              // 	list: res,
              // })
              this.setState({
                  classifyList:res,
              })
          },
      })
  }
  	/**
	 * 合成请求下一页产品数据接口所需要的参数，发起请求
	 * @param {*} queryInfo
	 * @param {*} fetchType
	 */
	setDispatch(queryInfo, fetchType) {
		const { dispatch } = this.props
		const info = { ...queryInfo }
		if (fetchType === 'scroll') {
			info.pageNum += 1
			info.fetchType = fetchType
			info.type = 0
		}
		info.tabId = this.activeMenuId
		dispatch({
			type: 'mine/getIndexTabAndProduct',
			payload: { ...info },
		})
	}

  /**
   * scrollView的下拉加载更多动作
   */
  onScrollToLower = () => {
      const {
          //total,
          queryInfo,
          queryInfo: { pageNum, pageSize },
      } = this.props
      if (pageNum * pageSize - this.props.total >= 0) {
          Taro.showToast({
              title: '更多商品，敬请期待！',
              icon: 'none',
              duration: 1000,
          })
          return
      }
      this.setDispatch(queryInfo, 'scroll')
  }
    // 对应 onLoad
	componentWillMount = () => {
		const { dispatch } = this.props
		dispatch({
			type: 'mine/getIndexActionListByPage',
			payload: {
				pageNum: 1,
				pageSize: 10,
				channelId: getGloble('channelId'),
			},
			callback: (type) => {
				const list = []
				if (this.props.tabList) {
					this.classifyIndexChange(0, this.props.tabList[0]);
				}
				this.setState({
					shopType: type,
				})
				this.activeMenuId = type
				this.activeMenuIds = type
			},
		})
    }
    // 物流展示
    showQueryInfo = () => {
        Request({
            url:'/hzsx/api/order/queryWaitForReceivingOnTheWay',
            method: 'POST',
            data:{
                uid: getUid(),
                // uid: "13f7aab4763895c0bfe6ebe6042d04d86435c351xkq58gbhid0d",
            }
        }).then(res=> {
            const nodeList = res.data.data.resInfo[0]
            if(res.data.data){
                this.setState({
                    nodeLista:nodeList,
                })
            }
        })
    }
  render() {
    const { activityNo = '', shareCode = '' } = this.$router.params
		getActivityCode(activityNo)
		getshareCode(shareCode)
    const {
      nickName,
      avatar,
      isCertified,
      productList,
      statusNumInfo,
      idCardPhotoStatus,
      certProgress,
      products,
      oldNewDegreeList,
      tabList,
    } = this.props;
    const {
      showServicePhone,
      toolsList,
      isSetting,
      isTagOpened,
      AtToastIsOpened,
      isPhone,
      menuList,
      orderCounts,
      nodeLista,
    } = this.state;

    const statusObj = {
      WAITING_PAYMENT: "01",
      PENDING_DEAL: "02",
      PAYED_USER_APPLY_CLOSE: "03",
      PENDING_DEAL: "04",
      WAITING_USER_RECEIVE_CONFIRM: "05",
      RENTING: "06",
      WAITING_SETTLEMENT: "07",
      WAITING_SETTLEMENT_PAYMENT: "08",
      FINISH: "09",
      CLOSED: "10",
    };
    const menuNumList = menuList.map((menu) => {
      const newMenu = { ...menu };
      newMenu.num = statusNumInfo &&
        statusNumInfo.statusCount &&
        statusNumInfo.statusCount[statusObj[menu.cname]];
      return newMenu;
    });
    const customerServiceTel = getServicePhone();
    // loading ? my.showLoading({ content: '加载中...' }) : my.hideLoading();
        let fixedHeight = 0
		this.systemInfo.model ? this.systemInfo.model.indexOf('iPhone X') > -1 && (fixedHeight = 30) : null
		const scrollHeight = this.systemInfo.windowHeight - fixedHeight
    return (
      <View className="mine-page">
        <View className="mine-page-info">
          <View className="box">
            <Image
              // src={isSetting ? (!!avatar ? avatar : getAvatar()) : "" }
              src={isSetting ? (!!avatar ? avatar : getAvatar() ? getAvatar() : "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0b597a00d8e94419b300a4ac97e02d70.png" ) : "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/0b597a00d8e94419b300a4ac97e02d70.png"}
              className="mine-page-info-img"
              mode="aspectFit"
            />
            <View>
                {
                  isSetting ? ( <Text className="mine-page-info-name">
                               { nickName || getNickName() }
                            </Text>
                     ):(
                         <Text style={{fontSize:'18px'}} onClick={this.toLogin} className="mine-page-info-register">
                               注册/登录
                            </Text>
                     )
                }
            {/* //   <Text className="mine-page-info-name">
            //     {isSetting ? nickName || getNickName() : ''}
            //   </Text> */}
              {isSetting &&
              (nickName || getNickName() || avatar || getAvatar()) ? (
                <View className="mine-page-info-tags">
                  <Image
                    // src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/mine/vip-icon.png"
                    src={
                      successVip ? "http://img.llxzu.com/activity/vip8.png" : "http://img.llxzu.com/activity/vip6.png"
                    }
                    className="mine-page-info-tags-img"
                    mode="aspectFit"
                  />
                  {/* <Text className="mine-page-info-tags-text">普通会员</Text> */}
                </View>
              ) : (
                  <View className="mine-page-info-tags-text">新用户活动</View>
                  )}
                  <Text style={{fontSize:'12px'}}>凭信用0押金就可以租手机！</Text>
            </View>
          </View>
          <View className="box-bottom">
              <View className="box-content">
                   <View className="box-left"  >
                       <View 
                       className="box-left-content"
                       onClick={this.skipOtherPage.bind(this, "coupon")}
                       >
                       红包卡券
                        <View class="box-left-img">
                        </View>
                       </View>
                    </View>
                   <View className="box-right">
                       <View
                        className="box-right-content"
                         onClick={this.toCollect}
                        >
                        我的收藏
                       <View class="box-right-img">
                       </View>
                       </View>
                    </View>
               </View>
               
          </View>
          {/* <View className="box-tips">
            <Image
              src="https://booleandata-zuwuzu.oss-cn-beijing.aliyuncs.com/imgtest/mine/tips.png"
              className="box-tips-img"
              mode="aspectFit"
            />
            <Text className="box-tips-text">凭信用0押金就可以租手机！</Text>
          </View> */}
          {/* 这里新增了会员的图片 */}
          {/* <View className="box-img" >
            <Image
              className="box-image"
              onClick={() => this.goVip()}
            /> 
          </View> */}
        </View>
        {/* 会员 */}
        {/* <View className="mine-page-member">
          <View className="mine-page-member_a">
            {successVip ? (
              <View className="mine-page-member_b" onClick={() => this.goVip()}>已开通</View>  
            ) : (
              <View className="mine-page-member_b" onClick={() => this.goVip()}>去开通</View>  
            )}
          </View>
        </View> */}
        <View className="mine-page-order">
          {/* <View className="mine-page-order-info">
            <View className="title">
              <Text className="text">服务</Text>
            </View>
            <View className="menu">
              {!!serverList &&
                !!serverList.length &&
                serverList.map((menu) => {
                  return (
                    <View
                      key={menu.id}
                      onClick={this.skipOtherPage2.bind(this, menu.jumpUrl)}
                      className={"menu-view menu-view1"}
                    >
                      <Image
                        className="menu-view1-img"
                        mode="aspectFit"
                        src={menu.imgSrc}
                      />
                      <Text className="menu-view1-text">
                        {menu.serviceName}
                      </Text>
                    </View>
                  );
                })}
            </View>
          </View> */}
          <View className="mine-page-order-info mine-page-order-info2">
            <View className="title" onClick={this.skipToOrder}>
              <Text className="text">我的订单</Text>
              <View className="right">
                <Text className="right-text">查看全部</Text>
                <AtIcon value="chevron-right" size="18" color="#d8d8d8" />
              </View>
            </View>
            <View className="menu">
            {!!menuNumList &&
                  !!menuNumList.length &&
                  menuNumList.slice(0, 5).map((menu) => {
                    return (
                      <View
                        onClick={this.skipOtherPage2.bind(this, menu.jumpUrl,menu)}
                        key={menu.id}
                        className={"menu-view " + menu.cname}
                      >
                        {!!menu.num ? (
                          <AtBadge value={menu.num} maxValue={99}>
                            <Image
                              className="menu-view-img"
                              mode="aspectFit"
                              src={menu.imgSrc}
                            />
                          </AtBadge>
                        ) : (
                          <Image
                            className="menu-view-img"
                            mode="aspectFit"
                            src={menu.imgSrc}
                          />
                        )}
                        <Text className="menu-view-text" style={{ color: "#2D3040",fontSize:'24rpx' }}>{menu.orderName}</Text>
                      </View>
                    );
                  })}
            </View>
          </View>
        
          {/* <View className="mine-page-order-info mine-page-order-info2">
            <View
              className="title"
              onClick={this.skipOtherPage.bind(this, "coupon")}
            >
              <Text className="text">我的优惠券</Text>
              <AtIcon value="chevron-right" size="18" color="#d8d8d8" />
            </View>
          </View> */}
            {/* <View className="mine-page-order-info mine-page-order-info2">
            <View
              className="title"
              onClick={this.skipToOrders}
            >
              <Text className="text">质选服务订单</Text>
              <View className="right">
                <AtBadge  value={orderCounts} >
                  <Text className="right-text" style={{marginRight:'8px'}}>查看全部</Text>
                </AtBadge>
                <Text style={{marginLeft:'15px'}}>
                  <AtIcon  value="chevron-right" size="18" color="#d8d8d8" />
                </Text>
              </View>
            </View>
          </View> */}
          {/* 物流信息的展示 */}
          {
            nodeLista && nodeLista =='' ?
            null
            :
            (
              <View className="mine-page-order-info mine-page-order-info2" >
              <View className="title" onClick={this.skipToOrder}>
              <Text className="text-a">物流</Text>
              <ScrollView 
              className="Info"
              scrollY
              scrollWithAnimation
              lowerThreshold={60}>
                 <View
                   className="Info"
                    style={{display: "flex-direction: column"}}
                              >
                     <Text
                       className='Info-text-a'>
                        {nodeLista.titleInfo}
                      </Text>
                      <Text
                        className='Info-text-b'>
                         {nodeLista.detailInfo}
                        </Text>
                  </View>
              </ScrollView>
            </View>
            </View>
            )
          }
          <View className="mine-page-order-info mine-page-order-info2">
            <View className="title">
              <Text className="text">常用功能</Text>
            </View>

            <View className="menu">
              {!!toolsList &&
                !!toolsList.length &&
                toolsList.map((menu) => (
                  <View
                    onClick={this.skipOtherPage2.bind(this, menu.jumpUrl)}
                    key={menu.id}
                    className="menu-view">
                    {menu.jumpUrl === "customerService" ? (
                           <contact-button
                           tnt-inst-id='jDx_rmKU'
                           scene='SCE01336397'
                           size="30"
                           alipay-card-no={getBuyerId()}
                           icon="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/836e328f1d564052ab9ee90689ff3996.png"
                         />
                    ) : (
                      <Image
                        className="menu-view-img"
                        mode="aspectFit"
                        src={menu.imgSrc}
                      />
                    )}
                    <Text className="menu-view-text">{menu.toolName}</Text>
                  </View>
                ))}
            </View>

          </View>

            {/* 换量组件 */}
          {/* <View className='home_ad'>
            <ad
              unit-id="ad_tiny_2021002120621043_202204112200033803"
            />
          </View> */}
        </View>
        
        <ScrollView
				className="products"
				scrollY
				scrollWithAnimation
                style={`height: ${scrollHeight}px;`}
				lowerThreshold={60}
				onScrollToLower={this.onScrollToLower}
				onScroll={this.onScroll}
			>
            <View className="title_a">
              <View className="text_a">.</View>
                {/* 锚点 */}
                {/* <View id="the-id" className="the_id"></View> */}
				{this.state.getScrollTop ? (
					<View className="the_stance"></View>
				) : null}
				{/* <ScrollView
						className={
							'products-lists ' +
							(this.state.getScrollTop ? 'c_getScrollTop' : '')
						}
						scrollX
						scrollWithAnimation
						ref="myScrollView"
					>
						{tabList && tabList.map((item, index) => (
							<View
								className={
									'products-item ' +
									(index === this.state.activeMenuIndex
										? 'products-item-active'
										: '')
								}
								key={'kk' + index}
								onClick={() =>
									this.activeMenuIndexChange(index, item)
								}
							>
								{ index===0?(
									<View>
										<Block>
											{item.name}
										</Block>
									</View>
								):(
									<Block>
										{item.name}
									</Block>
								)}
								{index === this.state.activeMenuIndex ? (
									<View className={"active-line "+(index===0?'active-one':'')}></View>
								) : null}
							</View>
						))}
				</ScrollView> */}
		       
            </View>
             {/** 产品列表显示 */}
             <View className="home-channel">
                    <Channel
                        formType="submit"
                        products={products}
                        oldNewDegreeList={oldNewDegreeList}
                        onGotoProduct={(itemId) =>
                            this.onGotoProduct(itemId)
                        }
                            onGoToMore={this.onGoToMore}
                    />
                    {/* {pageNum * pageSize - total >= 0 && (
                        <View className="home-bottom">
                            <Text className="text">
                                {' '}
                                没有更多啦，快去挑选商品吧～{' '}
                            </Text>
                            </View>
                    )} */}
            </View>
        </ScrollView>
        <modal
          show={showServicePhone}
          showClose={false}
          onModalClick={this.onClosePhoneModal}
          onModalClose={this.onClosePhoneModal}
        >
          <View slot="header">联系客服</View>
          <View
            style={{
              textAlign: "left",
              paddingLeft: "15px",
              marginBottom: "10px",
              marginTop: "10px",
            }}
          >
            平台客服：
            <Text
              style={{ color: "#51A0F9" }}
              onClick={this.connectService.bind(this, customerServiceTel)}
            >
              {customerServiceTel}
            </Text>
          </View>
          <View style={{ textAlign: "left", paddingLeft: "15px" }}>
            工作时间：<Text style={{ color: "#777" }}>10:30 - 19:30</Text>
          </View>
          <View slot="footer">取消拨打</View>
        </modal>
        
        <TagPage
          onGetAuthorize={this.onGetAuthorize}
          onGetPhone={() => this.onGetPhone()}
          onClose={this.authOnClose}
          dispatch={this.props.dispatch}
          isOpened={isTagOpened}
          isPhone={isPhone}
          data="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/623d9fcab7c647abb80655bbc7d39406.jpg"
        />
        <AtToast
          isOpened={AtToastIsOpened}
          hasMask={false}
          text="授权失败"
          status="error"
        />
        <TagServicePage
          onClose={this.handleClose}
          isOpened={this.state.isServerTagOpened}
          // data="12333444444"
          // data={product && product.shop && product.shop.serviceTel}
        />
      </View>
    );
  }
}

export default Mine;
