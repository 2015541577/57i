export default [
  {
    id: 'coupon',
    text: '红包卡券',
  },
  {
    id: 'realName',
    text: '实名认证',

  },
  {
    id: 'address',
    text: '收货地址',
  },
]
