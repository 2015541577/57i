import Taro from '@tarojs/taro';
import * as mineApi from './service';
import { getAuthCode, getOpenUserInfo } from '../../utils/openApi';
import { getGloble, setUid, setBuyerId, setNickName, setUserName, setTelephone, getUid, setAvatar } from '../../utils/localStorage';
import umUploadHandler from "../../utils/umengUploadData";

export default {
  namespace: 'mine',
  state: {
    productList: [],
    statusNumInfo: {},
    alipayUserInfoNewDTO: {}, 
    queryInfo: {
        pageNum: 0,
        pageSize: 10,
      },
  },

  effects: {
    // 获取用户授权等信息
    * fetchAuthCode({ callback }, { call, put }) {
      let res = null;
      try {
        res = yield getAuthCode();
      } catch (e) {
        Taro.showToast({
          title: '授权失败，请重试',
          icon: 'none',
        });
        umUploadHandler.loginFailed("登录时调用getAuthCode方法发生错误");
      }
      if (res) {
        const obj = {
          authCode: res.authCode,
        }
        let newObj = null
        try {
          newObj = yield getOpenUserInfo();
        } catch (e) {
          Taro.showToast({
            title: '授权失败，请重试',
            icon: 'none',
          });
          umUploadHandler.loginFailed("登录时调用getOpenUserInfo方法发生错误");
        }
        let userInfo = JSON.parse(newObj.response).response
        if (userInfo.code !== '40003') {
          let information = {
            authCode: obj.authCode,
            avatar: userInfo.avatar,
            city: userInfo.city,
            gender: userInfo.gender,
            nickName: userInfo.nickName,
            province: userInfo.province,
            telephone: null
          }
          yield put({
            type: 'PhoneSave',
            payload: information
          });
          if (callback) {
            callback()
          }
        } else {
          umUploadHandler.loginFailed(`调用getOpenUserInfo方法所返回的状态码为-${userInfo.code}`);
        }
      }
    },
    // 查询用户各状态订单数量
    * userOrderStatusCount(_, { call, put }) {
      const params = {
        uid: getUid(),
        status: [
          '01', //'WAITING_PAYMENT',
          '04',
          '05', //'WAITING_USER_RECEIVE_CONFIRM',
          '06',
          '07', //'WAITING_SETTLEMENT',
          '08',
          '11',
        ]
      }
      params.channelIdList = [ getGloble('channelId') ]
      const res = yield call(mineApi.userOrderStatusCount, params)
      if (res) {
        yield put({
          type: 'saveStatusNumInfo',
          payload: res.data.data,
        });
      }
    },
    // demo
    * effectsDemo(_, { call, put }) {
      const { status, data } = yield call(mineApi.demo, {});
      if (status === 'ok') {
        yield put({
          type: 'save',
          payload: {
            topData: data,
          }
        });
      }
    },
     // 获取首页各项数据列表
     *getIndexActionListByPage({ payload, callback }, { call, put }) {
        const res = yield call(mineApi.getIndexActionListByPage, { ...payload });
        if (res.data) {
          yield put({
            type: "save_a",
            payload: res.data,
          });
          if (callback && res.data.tabList && res.data.tabList.length) {
            callback(res.data.tabList[0].id);
          }
        }
      },
    // 获取tab栏信息及对应产品列表
    *getIndexTabAndProduct({ payload, callback }, { call, put }) {
        const newPayload = { ...payload };
        const keys = Object.keys(payload);
        if (keys.length) {
          keys.forEach((key) => {
            if (newPayload[key] === null) {
              delete newPayload[key];
            }
          });
        }
        newPayload.tabId = newPayload.tabId || 124
        newPayload.pageNum = newPayload.pageNum || 1
        newPayload.pageSize = newPayload.pageSize || 10
        const res = yield call(mineApi.getIndexTabAndProduct, { ...newPayload });
        if (res) {
          if (payload.fetchType === "scroll") {
            yield put({
              type: "concatProductList",
              payload: res.data.products || res.data,
            });
          } else if(payload.type == 1){
            callback(res.data.products.records);
          } else {
            yield put({
              type: "saveProductList_a",
              payload: {
                data: res.data.products || res.data,
                queryInfo: payload,
              },
            });
          }
          // ----------------
          // if(payload.type == 1) {
          //   callback(res.data.products.records);
          // }
          // if (callback && res.data.tabList && res.data.tabList.length) {
          // }
          // -----------------
        }
      },
  },
  reducers: {
    saveUser(state, { payload }) {
      setAvatar(payload.avatar),
      setUserName(payload.userName);
      setNickName(payload.nickName);
      setTelephone(payload.telephone);
      setUid(payload.uid);
      setBuyerId(payload.thirdId);
      return { ...state, ...payload };
    },
    saveProductList(state, { payload }) {
      return {
        ...state,
        productList: payload,
      };
    },
    saveStatusNumInfo(state, { payload }) {
      return {
        ...state,
        statusNumInfo: payload,
      };
    },
    setIsCertified(state, { payload }) {
      return {
        ...state,
        isCertified: payload,
      };
    },
    save(state, { payload }) {
      return { ...state, ...payload };
    },
    save_a(state, { payload }) {
        delete payload['products'];
          
        return { ...state, ...payload, products: (payload.products && payload.products.records) || [] };
      },
    PhoneSave(state, { payload }) {
      return {
        ...state,
        alipayUserInfoNewDTO: payload
      }
    },
    concatProductList(state, { payload }) {
        const products = [...state.products];
        return {
          ...state,
          products: (products || []).concat(payload.records || []),
          queryInfo: {
            ...state.queryInfo,
            pageNum: state.queryInfo.pageNum + 1,
          },
          total: payload.total,
        };
      },
      saveProductList_a(state, { payload }) {
        return {
          ...state,
          products: payload.data.records,
          queryInfo: {
            ...payload.queryInfo,
            pageNum: payload.data.current,
          },
          // total:payload.data.current
        };
      },
  },
};
