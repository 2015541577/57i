import Taro, { Component, MapContext, uploadFile } from '@tarojs/taro';
import { View, Image, Text, ScrollView, Button, Checkbox } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { baseUrl } from '../../config/index'
import * as orderDetailApi from '../orderDetail/service';
import * as commentOnApi from './service';
import './index.scss';
import { getUid } from '../../utils/localStorage';

@connect(({ productList, loading }) => ({
  ...productList,
  loading: loading.models.productList,
}))
class CommentOn extends Component {
  config = {
    navigationBarTitleText: "发表评论",
    usingComponents: {
      popup: "../../npm/mini-antui/es/popup/index",
    },
  };

  state = {
    orderProductDetailDto: {},
    msgVal: "",
    publicInfo: false,
    starDescribe: 5,
    starLogistics: 5,
    starServer: 5,
    starArr: ["", "极差", "较差", "还行", "比较满意", "非常满意"],
    commentImg: [],
    orderProductDetailDtos: {},
    star1: [1,2,3,4,5],
    star2: [6,7,8,9,10],
    star3: [11,12,13,14,15],
  };

  componentDidMount = () => {
    const { orderId, type } = this.$router.params;

    // 获取订单详情
    if (type) {
      orderDetailApi
        .userOrdersPurchaseDetail({
          orderId,
        })
        .then((res) => {
          if (res.data.responseType === "SUCCESS") {
            this.setState({
              orderProductDetailDto: res.data.data || {},
            });
          }
        });
    } else {
      orderDetailApi
        .selectUserOrderDetail({
          orderId,
        })
        .then((res) => {
          if (res.data.responseType === "SUCCESS") {
            this.setState({
              orderProductDetailDto: res.data.data.orderProductDetailDto || {},
            });
          }
        });
    }

    // userOrdersPurchaseDetail
  };

  // 评分改变
  starChange(key, key2, val) {
    const star = [...this.state[key2]];
    star.map(item => {
      item += 50;
    })

    this.setState({
      [`${key}`]: val,
      key2: star,
    });
  }
  // 意见内容改变
  valChange(e) {
    this.setState({
      msgVal: e.detail.value,
    });
  }
  // 是否公布信息改变
  publicInfoChange(e) {
    this.setState({
      publicInfo: !!(e.detail.value && e.detail.value.length),
    });
  }
  // 删除图片
  deleteImg(index) {
    const commentImg = [...this.state.commentImg];
    commentImg.splice(index, 1);
    this.setState({
      commentImg,
    });
  }
  // 上传图片
  uploadImg() {
    my.chooseImage({
      sourceType: ["camera", "album"],
      success: (res) => {
        my.uploadFile({
          url: baseUrl + "hzsx/api/components/uploadFile",
          fileType: "image",
          fileName: "multipartFile",
          filePath: res.apFilePaths[0],
          header: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          success: (res) => {
            const commentImg = [...this.state.commentImg];
            commentImg.push(JSON.parse(res.data).data);

            this.setState({
              commentImg,
            });
          },
          fail: (res) => {
            my.alert({
              content: "上传错误",
            });
          },
        });
      },
      fail: () => {
        my.showToast({
          content: "取消成功",
        });
      },
    });
  }
  // 发布
  push() {
    const { orderId } = this.$router.params;
    const {
      orderProductDetailDto,
      commentImg,
      starDescribe,
      starLogistics,
      starServer,
      starArr,
      msgVal,
      publicInfo,
    } = this.state;
    if (!msgVal) {
      my.showToast({
        content: "请先填写评论",
      });
      return;
    }

    const images = [];
    if (commentImg.length) {
      commentImg.map((item) => {
        images.push({
          imageUrl: item,
        });
      });
    }

    commentOnApi
      .addProductEvaluation({
        uid: getUid(),
        orderId,
        content: msgVal,
        images,
        starCountService: starServer,
        starCountExpress: starLogistics,
        starCountDescription: starDescribe,
        anonymous: false,
      })
      .then((res) => {
        if (res.data.responseType === "SUCCESS") {
          my.showToast({
            content: "评论发表成功",
          });
          setTimeout(() => {
            Taro.navigateBack({
              delta: 1, // 返回上一级页面。
            });
          }, 1000);
        } else {
          my.showToast({
            content: "评论失败",
          });
        }
      });
  }

  render() {
    const {
      orderProductDetailDto,
      commentImg,
      starDescribe,
      starLogistics,
      starServer,
      starArr,
      msgVal,
      publicInfo,
    } = this.state;
    const { orderId, type } = this.$router.params;
    return (
      <View className="comment-on-page">
        <View className="product-info">
          <Image
            mode="aspectFit"
            className="product-img"
            src={
              type
                ? orderProductDetailDto.productImage
                : orderProductDetailDto.mainImageUrl
            }
          />
          <View className="product-msg">
            <View className="product-name">
              {orderProductDetailDto.productName}
            </View>
            <View className="product-tags">
              {type
                ? orderProductDetailDto.skuInfo
                : orderProductDetailDto.skuTitle}
            </View>
          </View>
        </View>
        <View className="comment-content">
          <View className="point">
            <Text className="point-title">描述相符</Text>
            {
              this.state.star1.map((item, index) => {
                return index < starDescribe
                  ? <Image key={item} onClick={() => this.starChange('starDescribe', 'star1', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/6f4077f3c8eb4674808ff4a15e3e8f0b.png" />
                  : <Image key={item} onClick={() => this.starChange('starDescribe', 'star1', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/7c9e9b46b4724ffcbfbaf1e10cb6e90c.png" />
              })
            }
          </View>
          <Textarea
            value={msgVal}
            onInput={(e) => this.valChange(e)}
            className="comment-text"
            placeholder="请留下您的宝贵意见让我们改进！"
          />
          <View className="img-list">
            {
              commentImg.map((item, index) => (
                <View className="img-item" key={'a'+index}>
                  <Image mode="aspectFit" className="item-img" src={item} />
                  <Image mode="aspectFit" onClick={() => this.deleteImg(index)} className="item-close" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/107d81da3505428b93f6a3f376bbc984.png" />
                </View>
              ))
            }
            {
              commentImg.length > 2
                ? null
                : (
                  <View className="img-item" onClick={() => this.uploadImg()}>
                    <Image mode="aspectFit" className="item-img" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/53bbb2aa45e74520b772e21c68a94116.png" />
                  </View>
                )
            }
          </View>
          <checkbox-group
            className="open-info"
            onChange={(e) => this.publicInfoChange(e)}
            name="libs"
          >
            <label class="checkbox">
              <checkbox value="aa" checked={publicInfo} />
              <text class="checkbox-text">公开头像昵称</text>
            </label>
          </checkbox-group>
          <View className="point">
            <Text className="point-title">物流</Text>
            {
              this.state.star2.map((item, index) => {
                return index < starLogistics
                  ? <Image key={item} onClick={() => this.starChange('starLogistics', 'star2', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d8892607d91e4d5d9c5274c3dd7093d0.png" />
                  : <Image key={item} onClick={() => this.starChange('starLogistics', 'star2', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/50c772ede53d4cee9f13c2c2fe6d5c3b.png" />
              })
            }
            <Text className="point-tips">{starArr[starLogistics]}</Text>
          </View>
          <View className="point">
            <Text className="point-title">服务</Text>
            {
              this.state.star3.map((item, index) => {
                return index < starServer
                  ? <Image key={item} onClick={() => this.starChange('starServer', 'star3', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/d8892607d91e4d5d9c5274c3dd7093d0.png" />
                  : <Image key={item} onClick={() => this.starChange('starServer', 'star3', index + 1)} className="star" src="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/50c772ede53d4cee9f13c2c2fe6d5c3b.png" />
              })
            }
            <Text className="point-tips">{starArr[starServer]}</Text>
          </View>
        </View>
        <Button className="push" onClick={() => this.push()}>
          发布
        </Button>
      </View>
    );
  }
}

export default CommentOn;
