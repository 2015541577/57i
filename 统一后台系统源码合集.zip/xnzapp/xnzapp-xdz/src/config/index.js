
// export const baseUrl = "http://192.168.10.109/llxz-api-web/";
export const baseUrl = "https://api.xxx.com/"; //线上
// export const baseUrl = "https://dev.xxx.com/llxz-api-web/"; //测试

export const noConsole = true;
