// import uma from 'umtrack-alipay';
// import { getGloble } from "../utils/localStorage";
// uma.init({
//     appKey: getGloble("AppKey"),
//     debug: true
// });
// export default uma;