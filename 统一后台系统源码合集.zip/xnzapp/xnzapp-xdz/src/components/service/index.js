import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, Form, ScrollView, Button } from '@tarojs/components'
import { AtCurtain} from 'taro-ui'
import './index.scss'
import { getGloble,getBuyerId, getServicePhone } from '../../utils/localStorage'
import { getGlobalData } from '../../utils/globalVariable'

class TagPage extends Component {

  state = {
  }
  onClose () {
    const { onClose } = this.props
    onClose(false)
  }
  handleCallService =()=>{
    const { data } = this.props
    let num = data ? String(data) : getServicePhone()
    my.makePhoneCall({ number: '13166013996' });
  }
  render() {
    const { isOpened,handleCallService,type,data } = this.props;
    return (
      <View className='container-curtain'>
        <AtCurtain
          className='container-curtain-con'
          isOpened={isOpened}
          onClose={this.onClose.bind(this)}
        >
          <View className='box-service' >
            { !data 
              ? (
                <Image
                  onClick={this.handleCallService}
                  className='img_1'
                  src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/88eb82f97ca14a65a879e277e05e66e1.png'
                  lazyLoad={true}
                />
              )
              : (
                <Image
                  onClick={this.handleCallService}
                  className='img_1'
                  src='https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/8071daa76d974b63b9b8507ba1556c2b.png'
                  lazyLoad={true}
                />
              ) 
            }
            <View>
              <contact-button
                tnt-inst-id='3ig_57kJ'
                scene='SCE01328913'
                size="300"
                alipay-card-no={getBuyerId()}
                icon="https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/8071daa76d974b63b9b8507ba1556c2b.png"
              />
            </View>
          </View>
        </AtCurtain>

      </View>
    )
  }
}

export  default TagPage
