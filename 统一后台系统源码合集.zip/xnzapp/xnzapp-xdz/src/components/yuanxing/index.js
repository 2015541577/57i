import Taro, { Component, Fragment } from "@tarojs/taro";
import { View, Canvas, Image } from "@tarojs/components";

import "./index.scss";

class CanvasProgress extends Component {
  static defaultProps = {
    style: {}, //容器的样式
    progress: 0.6, //进度 [0-1]
    backgroundColor: "#fcc", //背景环颜色
    lineColor: "#02a101", //前景环颜色
    lineWidth: 5, //线宽
  };

  state = {
    wrapperId: "_progress_wrapper" + randomStr(),
    canvasId: "_progress_canvas" + randomStr(),
    canvas: null,
    ctx: null,
    width: 0,
    height: 0,
    imageUrl:
      "https://jiujiuzu.oss-cn-hangzhou.aliyuncs.com/a06e563eaca54cc28cffc28be562f869.png",
  };

  componentDidMount() {
    this.onY();
  }

  init = async () => {
    const { wrapperId, canvasId } = this.state;
    const { width, height } = await getElementRect(wrapperId);
    const { canvas, ctx } = await getCanvas(canvasId);
    const dpr = Taro.getSystemInfoSync().pixelRatio;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    this.setState({ canvas, ctx, width, height }, this.draw);
  };

  draw = () => {
    const { progress, backgroundColor, lineWidth, lineColor } = this.props;
    const { canvas, ctx, width, height } = this.state;
    const radius = toFixed(0.5 * Math.min(width, height)) - lineWidth;
    const range = 2 * progress * Math.PI;
    const offsetRadian = -0.5 * Math.PI;

    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.beginPath();
    // 1
    ctx.strokeStyle = backgroundColor;
    ctx.arc(toFixed(width / 2), toFixed(height / 2), radius, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.closePath();
    // 2
    ctx.beginPath();
    ctx.strokeStyle = lineColor;
    ctx.arc(
      toFixed(width / 2),
      toFixed(height / 2),
      radius,
      offsetRadian,
      range + offsetRadian
    );
    ctx.stroke();
    ctx.closePath();

    const base64URL = canvas.toDataURL("image/png", 0.5);
    this.setState({ imageUrl: base64URL });
  };
  onY = () => {
    var cxt_arc = Taro.createCanvasContext("canvasArc"); //创建并返回绘图上下文context对象。
    cxt_arc.setLineWidth(6);
    cxt_arc.setStrokeStyle("#d2d2d2");
    cxt_arc.setLineCap("round");
    cxt_arc.beginPath(); //开始一个新的路径
    cxt_arc.arc(106, 106, 100, 0, 2 * Math.PI, false); //设置一个原点(106,106)，半径为100的圆的路径到当前路径
    cxt_arc.stroke(); //对当前路径进行描边

    cxt_arc.setLineWidth(6);
    cxt_arc.setStrokeStyle("#3ea6ff");
    cxt_arc.setLineCap("round");
    cxt_arc.beginPath(); //开始一个新的路径
    cxt_arc.arc(106, 106, 100, (-Math.PI * 1) / 7, (Math.PI * 6) / 5, false);
    cxt_arc.stroke(); //对当前路径进行描边

    cxt_arc.draw();
  };

  render() {
    const { style, children } = this.props;

    const { wrapperId, canvasId, imageUrl } = this.state;
    return (
      <View class="wrap">
        <View class="top">
          <Canvas
            class="cir"
            style="width:212px; height:212px;"
            id="canvasArc"
          ></Canvas>

          <View class="cc">中间</View>
        </View>
      </View>
    );
  }
}

// utils
const toFixed = (number = 0) => 0.01 * Math.floor(100 * number);

function randomStr(len = 16) {
  const string =
    "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const l = string.length;
  let str = "";
  for (let i = 0; i < len; i++) {
    const index = Math.floor((Math.random() * 100 * l) % l);
    str += string[index];
  }
  return str;
}

const getElementRect = async (eleId = "", delay = 200) => {
  return new Promise((resovle, reject) => {
    const t = setTimeout(() => {
      clearTimeout(t);

      Taro.createSelectorQuery()
        .select(`#${eleId}`)
        .boundingClientRect((rect) => {
          if (rect) {
            resovle(rect);
          } else {
            reject("获取不到元素");
          }
        })
        .exec();
    }, delay);
  });
};

const getCanvas = async (eleId = "", delay = 200) => {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => {
      clearTimeout(t);
      Taro.createSelectorQuery()
        .select(`#${eleId}`)
        .fields({ node: true })
        .exec((res) => {
          if (res && res[0] && res[0].node) {
            const canvas = res[0].node;
            const ctx = canvas.getContext("2d");
            resolve({ canvas, ctx });
          } else {
            reject("获取canvas失败");
          }
        });
    }, delay);
  });
};

export default CanvasProgress;
