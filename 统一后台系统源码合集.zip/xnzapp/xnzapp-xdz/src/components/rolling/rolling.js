import Taro, { Component } from '@tarojs/taro';


class Rolling extends Component {

  state = {
    value: '',
  }

  render() {
    return (
      <View>222</View>
    )
  }
}

export default Rolling;
