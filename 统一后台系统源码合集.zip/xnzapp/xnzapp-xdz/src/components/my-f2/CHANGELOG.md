#### 1.1.6 (2019-02-11)

##### New Features

*  支持 shadow 阴影样式设置。Closed [#18](https://github.com/antvis/my-f2/pull/18) ([8886a950](https://github.com/antvis/my-f2/commit/8886a950de745cbbdadeac3a95a9c45010bfe78a))

##### Other Changes

*  update @antv/f2 version ([8336f540](https://github.com/antvis/my-f2/commit/8336f540ee05e4e0fd9408e95162f974949b9484))

#### 1.1.3 (2018-10-17)

##### Bug Fixes

* 钉钉小程序适配 measureText() 方法。 ([05d13998](https://github.com/antvis/my-f2/commit/05d139981465e76b8f569aa6999d034d76c51a2b))

 
