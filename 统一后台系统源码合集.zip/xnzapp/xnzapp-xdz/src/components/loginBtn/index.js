/**
 * 封装登录操作，无感登录都放在这里进行完成。
 * 当前项目的登录都是前端自主控制，登录逻辑分散在多处。有的地方是点击按钮然后继续执行登录操作，有的地方是组件一加载便进行登录操作。
 * 这里统一一下使用按钮触发方式，但是这个按钮不一定会包含有授权操作
 * 该组件的所接受的props如下所示：
 * |________________________ forceRefreshToken: 是否需要强制刷新token
 * |________________________ children: 子reactElement
 * |________________________ clickHandler: 点击按钮之后的回调
 * |________________________ isClickReRender: 点击按钮之后父组件是否会重新刷新，如果父组件不会刷新的话，那么子组件得更新一下
 * |________________________ btnClsName: 按钮的样式名称
 * |________________________ needPhone: 是否需要手机号
 */
import Taro, { Component } from '@tarojs/taro'
import { View, Button } from '@tarojs/components'
import { getUid, getGloble, setUid, getTelephone, setTelephone } from '../../utils/localStorage'
import Request from '../../utils/request'
import './index.scss'

class LoginBtn extends Component {
  state = {
    showModal: false, // 是否需要显示登录模态
  }
  authCode = ''               // 支付宝授权码
  channelId = getGloble('channelId')
  logging = false // 判断是否正在登录中

  /**
   * 获取授权码
   */
  componentDidMount() {
    const successHandler = (res={}) => {
      this.authCode = res.authCode                // 获取到最新的授权码
      // if (!getUid() && !this.props.needPhone) {   // 没有uid和手机号那么就要自动登录
      //   this.loginHandler()
      // }
    }
    my.getAuthCode({
      scopes: "auth_base",                // auth_base表示静默授权，不会出现弹窗
      success: successHandler,
    })
  }

  /**
   * 租物租登录流程
   */
  loginHandler = () => {
    if (this.logging) return
    this.logging = true
    const reqParam = {
      url: 'hzsx/aliPay/user/exemptLogin',
      method: 'POST',
      data: { authCode: this.authCode, channelId: this.channelId, telephone: getTelephone() },
    }
    Taro.showToast({
      title: '登录中',
      icon: 'loading',
      mask: true,
    })
    Request(reqParam).then(res => {
      const resObj = (res.data && res.data.data) || {}
      const { uid } = resObj
      setUid(uid)
      Taro.hideToast()
      this.logging = false
      const { clickHandler } = this.props
      clickHandler && clickHandler()
    })
  }

  /**
   * 获取到用户的手机号码
   */
  onGetPhone = () => {
    const sucHandler = encryString => {
      const reqParams = {
        url: 'hzsx/api/components/decrypt',
        method: 'GET',
        data: { content: encryString },
      }
      Request(reqParams).then(res => {
        let resObj = res.data.data
        resObj = JSON.parse(resObj)
        if (resObj.code === '10000') {
          setTelephone(resObj.mobile)
          this.loginHandler()
        }
      })
    }
    my.getPhoneNumber({
      success: res => {
        let encryptedData = res.response // 支付宝所返回的加密数据
        sucHandler(encryptedData)
      },
      fail: () => {
        Taro.showToast({
          title: '授权失败',
          icon: 'none',
          duration: 2000
        })
      },
    })
  }

  render() {
    const { forceRefreshToken, children, btnClsName, needPhone } = this.props

    const hasLogin = getUid() && getTelephone() // uid + 手机号都有才是表明已登录

    if (hasLogin && !forceRefreshToken) {       // 当本地不存在uid 且 没有
      return (
        <View className={`${btnClsName}`}>{ children }</View>
      )
    } 
    if (needPhone) {  // 需要手机号
      return (
        <View className={`${btnClsName} component-loginBtn`}>
          { children }
          {/** 透明的手机号授权按钮 */}
          <Button
            className="userinfo-btn"
            open-type="getAuthorize"
            scope="phoneNumber"
            onGetAuthorize={this.onGetPhone}
          />
        </View>
      )
    } 
    return (
      <View className={`${btnClsName}`}>{ children }</View>
    )
  }
}

LoginBtn.defaultProps = {
  forceRefreshToken: false,         // 默认不强制每次都进行登录
  needPhone: true,                  // 是否需要手机号
}

export default LoginBtn
