import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, Form, ScrollView, Button } from '@tarojs/components'
import { AtCurtain} from 'taro-ui'
import './index.scss'

class PaymentPage extends Component {
  state = {
  }
  onClose () {
    const { onClose } = this.props
    onClose(false)
  }
  render() {
    const { isOpened,handleCallService,type,data } = this.props;
    return (
      <View className='container-curtain'>
        <AtCurtain
          className='container-curtain-con'
          isOpened={isOpened}
          onClose={this.onClose.bind(this)}
        >
          <Image
            className='img_1'
            src={data}
          />
        </AtCurtain>

      </View>
    )
  }
}

export  default PaymentPage
