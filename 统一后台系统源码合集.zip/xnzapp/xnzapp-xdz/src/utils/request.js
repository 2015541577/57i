import Taro from '@tarojs/taro';
import { setUrlEncoded } from './utils';
import { getGlobalData } from './globalVariable'
import { getGloble } from "./localStorage";
import { baseUrl, noConsole } from '../config';

export default (options = { method: 'GET', data: {} }) => {
  if (!noConsole) {
  }
  let data = {
    ...options.data,
  };
  let header = {};
  if (
    options.method === 'POST' ||
    options.method === 'PUT' ||
    options.method === 'DELETE'
  ) {
    if (options.contentType === 'application/www') {
      header = {
        Accept: 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
      };
      data = setUrlEncoded(data);
    } else if (options.contentType === 'formData') {
      header = {
        Accept: 'application/json ',
      };
    } else {
      header = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      };
    }
  }
  header.channelId = getGloble('channelId')
  let requesturl = baseUrl + options.url;
  return Taro.request({
    url: requesturl,
    data,
    header,
    method: options.method.toUpperCase(),
  }).then((res) => {
    if (res.data && res.data.responseType !== 'SUCCESS' && res.data.errorMessage ) {
      Taro.showToast({
        title: res.data.errorMessage,
        icon: 'none',
        mask: true,
      });
      return res;
    } else {
      return res;
    }
  })
}
