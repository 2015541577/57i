import { getUid,getGloble, setUid } from "./localStorage";
import { baseUrl } from "../config";
import { getGlobalData } from "./globalVariable";
import * as utilApi from "./service";
import Request from './request';

export const getAuthCode = () => {
  return new Promise((res, rej) => {
    my.getAuthCode({
      scopes: ['auth_base'],
      success: (data) => {
        res(data);
      },
      fail: (data) => {
        rej(data);
      },
    });
    // 
    // my.getAuthCode({
    //   // 订单服务授权：order_service。如需同时获取用户多项授权，可在 scopes 中传入多个 scope 值。
    //   scopes: ['order_service'],
    //   success: (res) => {
    //   // 订单服务授权成功
    //   },
    //   fail: (res) => {
    //   // 订单服务授权失败，根据自己的业务场景来进行错误处理
    //   },
    //   });
    // 使用my.getAuthCode，scope中再添加一个auth_user或者auth_base
  });
};
export const getCard = (data) => {
  Request({
    url: 'hzsx/components/createMemberCard',
    method: 'POST',
    data: { code : data.code, uid:data.uid},
  }).then(res => {
    const resObj = (res.data && res.data.data) || {}
    const uid = resObj.uid
    setUid(uid)
    cb && cb()
  })
};
/**
 * 只携带授权码进行租物租登录，并且登录完之后具有回调
 * @param {*} cb : 登录之后的回调方法
 */
export const loginWithCb = cb => {
  my.getAuthCode({
    scopes: 'auth_base',
    success: data => {
      const { authCode } = data
      // 接下来使用这个授权码去租物租进行登录
      const reqParam = {
        url: 'hzsx/aliPay/user/exemptLogin',
        method: 'POST',
        data: { authCode },
      }
      Request(reqParam).then(res => {
        const resObj = (res.data && res.data.data) || {}
        const uid = resObj.uid
        setUid(uid)
        cb && cb()
      })
    },
    fail: () => {},
  })
}

export const getOpenUserInfo = () => {
  return new Promise((res, rej) => {
    my.getOpenUserInfo({
      success: (data) => {
        res(data);
        //
      },
      fail: (data) => {
        rej(data);
      },
    });
  });
};
export const getPhoneNumberFn = () => {
  return new Promise((res, rej) => {
    my.getPhoneNumber({
      success: (data) => {
        res(data.response);
      },
      fail: (data) => {
        rej(data);
      },
    });
  });
};
export const startAPVerify = (options, callback) => {
  my.call(
    "startBizService",
    {
      name: "open-certify",
      param: JSON.stringify(options),
    },
    callback
  );
};
// key 是参数名  orderStr 是参数值
export const tradePay = (key, orderStr, type, serialNo, types,tradeNO) => {
  return new Promise((res, rej) => {
    const obj = {
      success: (data) => {
        if (type) {
          res(data);
        } else {
          if (data.resultCode !== "9000") {
            if (type === "Freeze") {
              utilApi.cancelAliPayFreeze({
                serialNo,
              });
            } else if (type === "TradeAppPay") {
              utilApi.cancelAlipayTradeAppPay({
                serialNo,
              });
            }
          }
          res(data);
        }
      },
      fail: (data) => {
        if (type) {
          rej(data);
        } else {
          if (data.resultCode !== "9000") {
            if (type === "Freeze") {
              utilApi.cancelAliPayFreeze({
                serialNo,
              });
            } else if (type === "TradeAppPay") {
              utilApi.cancelAlipayTradeAppPay({
                serialNo,
              });
            }
          }
          rej(data);
        }
      },
    };
    obj[key] = orderStr;
    my.tradePay(obj);
    // my.tradePay({
    //   // 调用统一收单交易创建接口（alipay.trade.create），获得返回字段支付宝交易号trade_no
    //   tradeNO: orderStr,
    //   success: (data) => {
    //     if (type) {
    //       res(data);
    //     } else {
    //       if (data.resultCode !== "9000") {
    //         if (type === "Freeze") {
    //           utilApi.cancelAliPayFreeze({
    //             serialNo,
    //           });
    //         } else if (type === "TradeAppPay") {
    //           utilApi.cancelAlipayTradeAppPay({
    //             serialNo,
    //           });
    //         }
    //       }
    //       res(data);
    //     }
    //   },
    //   fail: (data) => {
    //     if (type) {
    //       rej(data);
    //     } else {
    //       if (data.resultCode !== "9000") {
    //         if (type === "Freeze") {
    //           utilApi.cancelAliPayFreeze({
    //             serialNo,
    //           });
    //         } else if (type === "TradeAppPay") {
    //           utilApi.cancelAlipayTradeAppPay({
    //             serialNo,
    //           });
    //         }
    //       }
    //       rej(data);
    //     }
    //   },
    // });
  });
};

// 废弃代码
// export const apNsf = (context) => {
//   return new Promise((res, rej) => {
//     const obj = {
//       pid: "2088731351123660",
//       appId: getGloble("appId"),
//       bizContext: {
//         risk_type: "riskinfo_nsf_common",
//         pid: "2088731351123660",
//         ...context,
//       },
//       success: (data) => {
//         let newObj = JSON.parse(data.riskResultDesc);
//         let rank = Object.keys(newObj)[0];
//         if (rank.substring(0, 4) !== "rank") {
//           rank = "rank2";
//         }
//         my.httpRequest({
//           url: baseUrl + "hzsx/aliPay/user/userrisk",
//           data: {
//             riskResult: rank,
//             uid: getUid(),
//           },
//           headers: {
//             "Content-Type": "application/json",
//           },
//           method: "POST",
//           success: function() {
//           },
//           fail() {
//             my.alert({
//               title: "fail",
//             });
//           },
//         });
//         res(data);
//       },
//       fail: (data) => {
//         my.alert({
//           title: JSON.stringify(data),
//         });
//         rej(data);
//       },
//     };
//     if (my.ap && my.ap.nsf) {
//       my.ap.nsf(obj);
//     } else {
//       let jsonstr = "rank0";
//       let obj = {
//         riskResult: jsonstr,
//         uid: getUid(),
//       };
//       let data = JSON.stringify(obj);
//       my.httpRequest({
//         url: baseUrl + "hzsx/aliPay/user/userrisk",
//         data,
//         headers: {
//           "Content-Type": "application/json",
//         },
//         method: "POST",
//         success: function(data) {
//           res(data);
//         },
//         fail() {
//           my.alert({
//             title: "fail",
//           });
//         },
//       });
//     }
//   });
// };
