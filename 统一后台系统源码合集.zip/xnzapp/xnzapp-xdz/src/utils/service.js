import Request from './request';
import { getUid } from './localStorage';
import { loginWithCb } from './openApi';

export const demo = (data) => {
  return Request({
    url: '路径',
    method: 'POST',
    data,
  });
};

export const cancelAliPayFreeze = (data) => {
  return Request({
    url: `hzsx/api/order/cancelAliPayFreeze`,
    method: 'POST',
    data
  })
}

export const cancelAlipayTradeAppPay = (data) => {
  return Request({
    url: `hzsx/api/order/cancelAlipayTradeAppPay`,
    method: 'POST',
    data
  })
}

/**
 * 租物租自个的埋点操作
 * @param {*} paramsObj , 在这个对象中所包含的关键字段为: action、channelId、position
 */
export const zwzMaidianhandler = paramsObj => {
  const obj = paramsObj || {}
  const { action, channelId, position } = obj
  if (!action || !channelId || !position) return
  if (!getUid()) {
    loginWithCb(() => zwzMaidianhandler(paramsObj))
    return
  }
  Request({
    url: "hzsx/userPoint/insertUserPoint",
    method: "GET",
    data: {
      uid: getUid(),
      ...paramsObj,
    },
  })
}