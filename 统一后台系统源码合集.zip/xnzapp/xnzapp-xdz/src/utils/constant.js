/**
 * 一些常量定义
 */

export const abilitySecondHand = 'OLD' // 能力中心详情页面的二手购买

export const abilityNewPhone = 'NEW' // 能力中心详情页面的新机易购

export const orderDetailShowType2Cn = {
  [abilityNewPhone]: '新机易购',
  [abilitySecondHand]: '二手购买',
}

export const abilityShowTypeUrlKey = 'showType'

export const miaoShaIndexId = 'seckillIndexId' // 秒杀页面需要把indexId传入到商品详情页面
export const miaoShaPageId = 'seckillPageId' // 秒杀页面把pageId传入到商品详情页面
export const isSeckillProduct = 'isCurrentProductBelongToMiaoSha' // 告诉confirmOrder页面当前页面是否属于秒杀商品