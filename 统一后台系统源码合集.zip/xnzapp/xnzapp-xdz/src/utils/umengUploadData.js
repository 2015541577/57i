/**
 * 使用友盟进行数据上报的方法
 */
import { umaTrackEvent } from "./multiPlatform";
import { generateProductDescForUM, generateTicketDescForUM, getFromPagePath } from "./utils";


const umUpload = {
  /**
   * tabBar埋点上传
   * @param {*} obj 
   */
  bottomNavClickHandler: function(obj) {
    const data = { Um_Key_ButtonName: obj.text };
    umaTrackEvent("Um_Event_BottomNaviClick", data);
  },

  /**
   * 点击免押租按钮进行埋点上传
   * @param {Object} productDetail : 产品详情数据
   */
  clickMianYaZuBtnHandler: function(productDetail) {
    const umProductObj = generateProductDescForUM(productDetail);
    umaTrackEvent("Um_Event_BuySuc", umProductObj);
  },

  /**
   * 调用bindCoupon接口成功领取到单个优惠券的时候调用
   * @param {*} tickerObj : 优惠券对象
   * @param {string} scene : 领券渠道
   */
  bindCouponHandler: function(tickerObj, scene) {
    const data = generateTicketDescForUM(tickerObj);
    data.Um_Key_CouponSource = scene;
    umaTrackEvent("Um_Event_CollectCoupon", data);
  },

  /**
   * 进行商品收藏行为的数据上报
   * @param {*} productDetail : 商品详情对象
   */
  addGoodsToFavorite: function(productDetail) {
    const productObj = generateProductDescForUM(productDetail);
    umaTrackEvent("Um_Event_ItemFavorite", productObj);
  },

  /**
   * 分享商品的时候会被触发
   * @param {Object}} productDetail ： 商品详情对象
   */
  shareGoods: function(productDetail) {
    const productObj = generateProductDescForUM(productDetail);
    umaTrackEvent("Um_Event_ItemShare", productObj);
  },

  /**
   * 取消收藏商品
   * @param {*} productDetail : 商品详情对象
   */
  moveGoodsToUnFavorite: function(productDetail) {
    const productObj = generateProductDescForUM(productDetail);
    umaTrackEvent("Um_Event_Item_Unfavorite", productObj);
  },

  /**
   * 查看商品详情事件
   * @param {*} productDetail 
   */
  seeProductDetail: function(productDetail) {
    const obj = generateProductDescForUM(productDetail);
    obj.Um_Key_ItemPraise = ""; // 商品好评
    obj.Um_Key_SourcePage = getFromPagePath();
    obj.Um_Key_SourceLocation = ""; // 来源位置
    umaTrackEvent("Um_Event_ItemDetail", obj);
  },

  /**
   * 上报登录失败事件
   * @param {string} reason : 登录失败的原因
   */
  loginFailed: function(reason) {
    const obj = { Um_Key_Reasons: reason };
    umaTrackEvent("Um_Event_LoginFailed", obj);
  },

  /**
   * 上报成功登录事件
   * @param {string} uid : 用户ID
   */
  loginSuccess: function(uid) {
    let Um_Key_LoginType = "支付宝登录"; // 登录方式
    const taroEnv = process.env.TARO_ENV;
    if (taroEnv === "weapp") Um_Key_LoginType = "微信登录";
    const obj = { Um_Key_LoginType, Um_Key_UserID: uid };
    umaTrackEvent("Um_Event_LoginSuc", obj);
  },

  /**
   * 搜索点击事件的埋点上报
   */
  searchClick: function(loc) {
    const obj = { Um_Key_SearchLocation: loc };
    umaTrackEvent("Um_Event_SearchClick", obj);
  },

  /**
   * 友盟上传搜索事件
   * @param {Object} searchObj : 搜索对象数据
   * @param {Object} resultObj : 结果数据
   * @param {string} loc : 进行搜索的是哪个功能页面
   */
  searchSuc: function(searchObj, resultObj, loc) {
    const obj = {};
    if (
      Object.prototype.toString.call(searchObj) !== "[object Object]" ||
      Object.prototype.toString.call(resultObj) !== "[object Object]"
    ) return null;
    obj.Um_Key_SearchKeyword = searchObj.content;
    obj.Um_Key_SearchPortal = loc;
    if (resultObj.data && resultObj.data.total) {
      obj.Um_key_SearchRecommend = `有结果，共有${resultObj.data.total}条数据命中`;
    } else {
      obj.Um_key_SearchRecommend = "没有结果"
    }
    umaTrackEvent("Um_Event_SearchSuc", obj);
  },

  /**
   * 使用友盟上报 取消订单 的事件
   * @param {*} goodsObj 
   * @param {*} orderPayload 
   */
  cancelOrder: function(goodsObj) {
    if (Object.prototype.toString.call(goodsObj) !== "[object Object]") return;
    const obj = {
      Um_Key_OrderID: goodsObj.orderId,
      Um_Key_ItemCategory: "", // 在这里取不到商品的分类数据
      Um_Key_ItemName: goodsObj.productName,
      Um_Key_ItemID: goodsObj.productId,
      Um_Key_ItemPrice: goodsObj.totalRent,
      Um_Key_OrderPrice: goodsObj.orderType,
    };
    umaTrackEvent("Um_Event_CancleOrder", obj);
  },

  /**
   * 上报 评论事件
   */
  commentRecord: function(productObj) {
    const obj = generateProductDescForUM(productObj); // 生成用于友盟上报的商品描述数据
    umaTrackEvent("Um_Event_ItemComment", obj);
  },

  /**
   * 生成订单的时候触发，注：只是生成订单，并不一定付钱成功
   */
  submitOrderHandler: function(orderObj) {
    if (Object.prototype.toString.call(orderObj) !== "[object Object]") return;
    let cuponObj = orderObj.defaultCouponDto || {};
    const obj = {
      Um_Key_OrderID: orderObj.orderId,
      Um_Key_OrderPrice: orderObj.orderPricesDto && orderObj.orderPricesDto.totalRent,
      Um_Key_ItemNum: orderObj.num,
      Um_Key_OrderDiscount: "",
      Um_Key_UseCoupon: cuponObj.discountAmount != undefined ? "是" : "否",
      Um_Key_CouponDiscount: "",
      Um_Key_CouponName: cuponObj.name || "",
    };
    umaTrackEvent("Um_Event_SubmitOrder", obj);
  },

  /**
   * 上报成功购买事件
   * @param {*} data : /order/queryOrderSuccessInfo接口所返回数据中的data部分
   */
  successPayMoney: function(data) {
    if (Object.prototype.toString.call(data) !== "[object Object]") return;
    const obj = {
      Um_Key_OrderID: data.orderId,
      Um_Key_OrderPrice: data.firstPeriodsPrice,
    };
    umaTrackEvent("Um_Event_PaymentSuc", obj);
  },
};

export default umUpload;
