import Taro from '@tarojs/taro';

//过滤空格
export const blankSpace = (space) => {
  let newSpack = space.replace(/\s+/g, "");
  return newSpack
}

//数组对象排序
export const compare = (property, desc) => {
  return function (a, b) {
    const value1 = a[property];
    const value2 = b[property];
    if (desc === true) {
      // 升序排列
      return value1 - value2;
    } else {
      // 降序排列
      return value2 - value1;
    }
  }
}
//转换时间 - /
export const dateDiff = (time) => {
  let newTime = time.replace(/-/g, '/')
  return newTime
}
//名字格式
export const formatName = (name) => {
  let newStr = name.substr(0, 1) + '**'
  return newStr;
}
//身份证
export const forIdCard = (num) => {

  let newNum = num.substr(0, 4) + '*******' + num.substr(14, 18)
  return newNum
}
export const setUrlEncoded = (obj) => {
  let urlEncoded = '';
  if (obj && obj instanceof Object) {
    const keys = Object.keys(obj);
    if (keys && keys.length) {
      keys.forEach((key, index) => {
        urlEncoded += `${key}=${obj[key]}`;
        if (index + 1 < keys.length) {
          urlEncoded += '&';
        }
      });
    }
  }
  return urlEncoded;
}
//日期转时间戳
export const transdate = (endTime) => {
  const date = new Date();
  date.setFullYear(endTime.substring(0, 4));
  date.setDate(1)
  date.setMonth(endTime.substring(5, 7) - 1);
  date.setDate(endTime.substring(8, 10));
  date.setHours(endTime.substring(11, 13));
  date.setMinutes(endTime.substring(14, 16));
  date.setSeconds(endTime.substring(17, 19));
  return Date.parse(date);
}
export const formatDate = (date, fmt) => {
  const o = {
    "M+": date.getMonth() + 1, //月份
    "d+": date.getDate(), //日
    "h+": date.getHours(), //小时
    "m+": date.getMinutes(), //分
    "s+": date.getSeconds(), //秒
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度
    "S": date.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
}

export const formatStrDate = (str, fmt) => {
  const o = {
    'y+': str.slice(0, 4),
    'M+': str.slice(5, 7),
    'd+': str.slice(8, 10),
    'h+': str.slice(11, 13),
    'm+': str.slice(14, 16),
    's+': str.slice(17, 19),
  };

  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (str.slice(0, 4) + "").substr(4 - RegExp.$1.length));
  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
    }
  }
  return fmt;
}

// 倒计时
export const leftTimer = (dateStr) => {
  if (dateStr) {
    const date = new Date(dateStr);
    const leftTime = date - (new Date());
    const days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10); //计算剩余的天数
    const hours = parseInt(leftTime / 1000 / 60 / 60 % 24, 10); //计算剩余的小时
    const minutes = parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟
    const seconds = parseInt(leftTime/ 1000 / 60 /60/60,10); // 计算剩余的秒数
    return `${days}天${hours}小时${minutes}分钟${seconds}`;
  }
  return '';
}
// 新封装的倒计时
export const leftTimers = (dateStr) => {
  if (dateStr) {
    const date = new Date(dateStr);
    const leftTime = date - (new Date());
    const leftTimes = date.getTime() + 1440 * 60000 - (new Date()).getTime();
    if (leftTime < 0||leftTimes<0) {
      return null;
    }
    const days = parseInt(leftTime / 1000 / 60 / 60 / 24, 10); //计算剩余的天数
    const hours = parseInt(leftTimes / 1000 / 60 / 60 % 24, 10)>=10?parseInt(leftTimes / 1000 / 60 / 60 % 24, 10):'0'+parseInt(leftTimes / 1000 / 60 / 60 % 24, 10); //计算剩余的小时
    const minutes = parseInt(leftTimes / 1000 / 60 % 60, 10)>=10 ? parseInt(leftTimes / 1000 / 60 % 60, 10):'0'+parseInt(leftTimes / 1000 / 60 % 60, 10);//计算剩余的分钟
    const seconds = parseInt(leftTimes/ 1000 % 60,10)>=10?parseInt(leftTimes/ 1000 % 60,10):'0'+parseInt(leftTimes/ 1000 % 60,10); // 计算剩余的秒数
    return `${days}天 ${hours}:${minutes}:${seconds}`;
  }
  return '';
}
// 24小时倒计时
export const leftTimerMS_C = (dateStr) => {
  if (dateStr) {
    const date = new Date(dateStr);
    const leftTime = date.getTime() + 1440 * 60000 - (new Date()).getTime();
    if (leftTime < 0) {
      return null;
    }
    const hours = parseInt(leftTime / 1000 / 60 / 60 % 24, 10) >=10?parseInt(leftTime / 1000 / 60 / 60 % 24, 10):'0'+parseInt(leftTime / 1000 / 60 / 60 % 24, 10); //计算剩余的小时
    const minutes = parseInt(leftTime / 1000 / 60 % 60, 10)>=10?parseInt(leftTime / 1000 / 60 % 60, 10):'0'+parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟
    const seconds = parseInt(leftTime / 1000 % 60, 10)>=10?parseInt(leftTime / 1000 % 60, 10):'0'+parseInt(leftTime / 1000 % 60, 10);//计算剩余的秒数
    return `${hours}:${minutes}:${seconds}`;
  }
}
// 60分钟倒计时
export const leftTimerMS_B = (dateStr) => {
  if (dateStr) {
    const date = new Date(dateStr);
    const leftTime = date.getTime() + 60 * 60000 - (new Date()).getTime();
    if (leftTime < 0) {
      return null;
    }
    const minutes = parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟
    const seconds = parseInt(leftTime / 1000 % 60, 10);//计算剩余的秒数
    return `${minutes}分${seconds}秒`;
  }
}
// 30分钟倒计时
export const leftTimerMS = (dateStr) => {
  if (dateStr) {
    const date = new Date(dateStr);
    const leftTime = date.getTime() + 30 * 60000 - (new Date()).getTime();
    if (leftTime < 0) {
      return null;
    }
    const minutes = parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟
    const seconds = parseInt(leftTime / 1000 % 60, 10);//计算剩余的秒数
    return `${minutes}分${seconds}秒`;
  }
}
// 日期，在原有日期基础上，增加days天数，默认增加1天
export const addDate = (date, days) => {
  if (days == undefined || days == '') {
    days = 1;
  }
  var date = new Date(date);
  date.setDate(date.getDate() + days);
  var month = date.getMonth() + 1;
  var day = date.getDate();
  return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}

// 日期月份/天的显示，如果是1位数，则在前面加上'0'
function getFormatDate(arg) {
  if (arg == undefined || arg == '') {
    return '';
  }

  var re = arg + '';
  if (re.length < 2) {
    re = '0' + re;
  }

  return re;
}

export const formatSeconds = (value) => {
  setInterval(() => {
    value -= 1;

    if (value === 0) {
      clearInterval(this.interval);
    }
  }, 1000);
  return value;
}

/*获取当前页带参数的url*/
export function getCurrentPageUrlWithArgs() {
  const pages = getCurrentPages()
  const currentPage = pages[pages.length - 1]
  const url = currentPage.route
  const options = currentPage.params
  let urlWithArgs = `/${url}?`
  for (let key in options) {
    const value = options[key]
    urlWithArgs += `${key}=${value}&`
  }
  urlWithArgs = urlWithArgs.substring(0, urlWithArgs.length - 1)
  return urlWithArgs
}
// 节流
export function throttles(fn, ms) {
  let timerId // 创建一个标记用来存放定时器的id
  return function () {
      // 没有定时器等待执行，则表示可以创建新的定时器来执行函数
     if (!timerId) {
        timerId = setTimeout(() => {
            // 定时器id清空，表示可以执行下一次调用了
            timerId = null
            fn.apply(this, arguments)
        }, ms)
      }
  }
}
/*函数节流*/
export function throttle(fn, interval) {
  var enterTime = 0;//触发的时间
  var gapTime = interval || 300;//间隔时间，如果interval不传，则默认300ms
  return function () {
    var context = this;
    var backTime = new Date();//第一次函数return即触发的时间
    if (backTime - enterTime > gapTime) {
      fn.call(context, arguments);
      enterTime = backTime;//赋值给第一次触发的时间，这样就保存了第二次触发的时间
    }
  };
}

/*函数防抖*/

export const debounce = (func, delay = 200) => {
  let timeout = null
  return function () {
    clearTimeout(timeout)
    timeout = setTimeout(() => {
      func.apply(this, arguments)
    }, delay)
  }
}

/*获取当前时间*/
export const timeDate = function () {
  let date = new Date();
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();
  if (month < 10) {
    month = "0" + month;
  }
  if (day < 10) {
    day = "0" + day;
  }
  return year + '-' + month + '-' + day;
}

/**
 * 把options.query中的数据存储到redux中的全局模块中
 * @param {Object} queryObj : 对象，比如传入options.query
 * @param {string} queryKey : 字符串，所需要存储的值在queryObj中的键名
 * @param {string} key : 字符串，存储到storage中的键名
 * @param {Function} dispatch : 触发方法
 */
export const saveQueryValueInGlobal = (queryObj, queryKey, key, dispatch) => {
  const value = (queryObj && queryObj[queryKey]) || ''; // 从queryObj中取出所需要存储的值

  const payload = { key, value, queryObj };

  dispatch({ type: 'global/setKeyValue', payload });
};

/**
 * 小程序之间的跳转，如果携带了页面参数的话，那么跳转到该小程序的指定页面
 * 否则跳转到该小程序的首页
 * @param {*} url 
 */
export const redirectToOtherMiniProgram = url => {
  const index = url.indexOf("appId=");
  const indexPage = url.indexOf("page=");
  const appId = url.substr(index + 6, 16);
  const path = url.substring(indexPage + 5, url.length);
  const businessId = url.indexOf("businessId");

  if (indexPage !== -1) {
    my.navigateToMiniProgram({ appId, path: path });
  } else if (businessId !== -1 ) {
    // 跳转福利社群
    my.ap.navigateToAlipayPage({
    	path: 'alipays://platformapi/startapp?appId=68687451&url=%2Fwww%2Fbc-join.html%3Foid%3D2022062315500300078779%26businessId%3D2022062315500300078779%26businessType%3D18%26source%3DTINYAPP', // 注意 scheme 需要申请添加白名单
    	success:(res) => {
    	},
    	fail:(res) => {
    		// my.alert({ title: 'navigateToAlipayPage fail', content: JSON.stringify(res) });
    	}
    });
  } else {
    my.navigateToMiniProgram({ appId });
  }
};

/**
 * 计算出过期时间
 * @param {*} dayNum
 */
export const computeOverdueTime = dayNum => {
  const currentNum = Date.now();
  const overdueNum = currentNum + dayNum * 24 * 60 * 60 * 1000;
  const dateObj = new Date(overdueNum);
  return `${dateObj.getFullYear()}-${dateObj.getMonth() + 1}-${dateObj.getDate()}`;
}

/**
 * 后端接口到友盟所需要数据的一个映射
 * @param {*} originalValue 
 * @param {*} kvDictionary
 * @param {boolean} containEmpty : 是否需要包含空值
 */
const k2um = (originalValue, kvDictionary, containEmpty=true) => {
  if (
    Object.prototype.toString.call(originalValue) !== "[object Object]" ||
    Object.prototype.toString.call(kvDictionary) !== "[object Object]"
  ) return {};
  let result = {};
  const keys = Object.keys(kvDictionary);
  for (let key of keys) {
    const umKey = kvDictionary[key];
    const val = originalValue[key]; // 获取到该字段所表示的值
    (containEmpty || val) && (result[umKey] = val);
  }
  return result;
};

/**
 * 从租物租接口接口所返回的数据找出友盟自定义上报的关于商品的字段
 * @param {Object} productobj : 商品详情数据
 */
// TODO: 确定如果多传了字段给友盟接口应该也是没有问题的吧
export const generateProductDescForUM = productObj => {
  // 友盟 所需要传的字段 和 商品返回数据的对应关系
  const keyObjs = {
    name: "Um_Key_ItemName",
    productId: "Um_Key_ItemID",
    categoryId: "Um_Key_ItemCategory",
    lowestSalePrice: "Um_Key_ItemPrice",
  };
  const result = k2um(productObj, keyObjs);
  return result;
};

/**
 * 利用接口返回的券对象 合成 友盟需要的和优惠券 所相关的数据
 * @param {Object} tickerObj : 券对象
 * 券有两个ID，分别是模版ID，以及用户领取到了之后的绑定ID，这里上传的是模版ID
 */
export const generateTicketDescForUM = tickerObj => {
  const kvMap = {
    name: "Um_Key_CouponName", // 在领券中心，name属性表示券的名称
    rangeStr: "Um_Key_CouponName", // 在商品详情，rangeStra表示同上
    id: "Um_Key_CouponID", // 在领券中心，这个id对应了模版ID
    templateId: "Um_Key_CouponID", // 在商品详情页面领券，这个字段对应了模版ID
    discountAmount: "Um_Key_CouponDenomination",
    delayDayNum: "Um_Key_CouponExpireTime",
  };
  const result = k2um(tickerObj, kvMap, false);
  result.Um_Key_CouponExpireTime = computeOverdueTime(result.Um_Key_CouponExpireTime); // 转换过期时间
  result.Um_Key_CouponNum = 1; // 默认是1，如果是领取大礼包的话需要修改一下这个券的数量
  return result;
};

/**
 * 获取来源页面的路径并返回
 * @param {number} dep : 表示是倒数第几个页面
 */
export const getFromPagePath = (dep=2) => {
  const historyPages = Taro.getCurrentPages(); // 路由栈

  const historyLength = historyPages.length;

  const lastPageObj = historyPages[historyLength - dep]; // 倒数第二个页面
  if (!lastPageObj) return "";
  return JSON.stringify(lastPageObj.__proto__.route);
};

/**
 * 返回一个数组，数组第一项是小数点之前的数据；第二项是小数点（包括小数点）之后的数据
 * @param {*} price : 接口所返回的价格
 */
export const splicePrice = price => {
  if (typeof price === 'number') price = `${price}`
  if (!price || !price.length) return []
  const result = price.split('.') // 以小数点分割
  if (result.length === 2) {      // 若存在第二项的话，再把小数点加回去
    return [result[0], `.${result[1]}`]
  }
  return result
};

/**
 * 格式化数字，避免出现过多位小数，采用之前的做法，使用toFixed来裁剪小数。注：舍4入6
 * @param {Number} num : 数字
 */
export const numberFormat = num => {
  if (typeof num !== 'number') return;

  if (String(num).includes('.')) return num.toFixed(2);
  else return num;
};

/**
 * 
 * @param {String} longitude 经度
 * @param {String} latitude 维度
 */
 export const convertGPSToAddress = (longitude, latitude) => {
  return new Promise((resolve, reject) => {
    Taro.request({
      url: 'https://restapi.amap.com/v3/geocode/regeo',
      data: {
        key: '6284e10ec73a160532a04eb0b935cf3b',
        location: longitude + ',' + latitude,
        radius: 50,
        extensions: 'base',
        batch: false,
        roadlevel: 0
      },
      success(res) {
        resolve(res.data);
      },
      fail(err) {
        reject(err)
      }
    })
  })
}
// 支付宝小程序内使用蚂蚁链合同小程序版本签署
export const getSignUrl = (aliSchema) => {
  if(!aliSchema){return  ''}
  const querys = aliSchema.split('?')[1].split('&');
  const signUrlKeyValue = querys.find((item) => item.includes('query=')).replace('query=', '');
  const encodedSignUrl = decodeURIComponent(signUrlKeyValue).replace('signUrl=', '');
  return encodedSignUrl
}

// 将 scheme 转换为 my.navigateToMiniProgram 的参数
export const schemeToParams = (scheme) => {
  if (!scheme.startsWith('alipays:')) {
  return { message: '! ⾮ alipays: 开头' };
  }
  const params = {};
  const parseQuery = (str) => {
  return str
  .replace(/^.*?\?/, '')
  .split('&')
  .map((s) => {
  const p = s.includes('=') ? s.indexOf('=') : s.length;
  return [s.slice(0, p), s.slice(p + 1)].map(decodeURIComponent);
  });
  };
  for (let [k, v] of parseQuery(scheme)) {
  if (k === 'appId') {
  if (v.length != 16) {
  return { message: `! ⾮ 16 位 appId '${v}'` };
  }
  } else if (k === 'page') {
  k = 'path';
  } else if (k === 'query') {
  const o = {};
  for (const [x, y] of parseQuery(v)) {
  o[x] = y;
  }
  v = o;
  }
  params[k] = v;
  }
  return { params };
}