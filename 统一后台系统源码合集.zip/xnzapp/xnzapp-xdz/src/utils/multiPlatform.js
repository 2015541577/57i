/**
 * 一些和平台相关的方法封装
 */
import { getUid } from "./localStorage";

/**
 * 使用友盟sdk进行数据上报
 * @param {string} eventName : 上报事件ID
 * @param {Object} data : 上报值
 * @param {boolean} containUserId : 是否需要包含用户ID
 */
export function umaTrackEvent(eventName, data, containUserId=true) {
  // if (!eventName || !data) {
  //   console.error('缺少上报参数，请补全');
  //   return;
  // }

  // let trackFun = null;
  // if (process.env.TARO_ENV === 'alipay') {          // 支付宝小程序
  //   trackFun = my.uma && my.uma.trackEvent;
  // } else if (process.env.TARO_ENV === 'weapp') {    // 微信小程序
  //   trackFun = wx.uma && wx.uma.trackEvent;
  // }

  // if (containUserId) data.Um_Key_UserID = getUid(); // 每次发送都重新取一遍，不缓存，避免缓存值过期，没有用户ID也加入该字段进去，使得问题暴露

  // trackFun && trackFun(eventName, data);
}
