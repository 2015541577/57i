import Taro from "@tarojs/taro";
import { setGlobalData, getGlobalData } from "./globalVariable";

const storageStr = "alipay-h5-x-";

export function setGloble(key, val) {
  if (key) {
    return Taro.setStorageSync(`${key}-globle-data`, val);
  }
}

export function getGloble(key) {
  const tokenString = Taro.getStorageSync(`${key}-globle-data`);
  return tokenString;
}


/**
 * 将用户信息数据存储到全局
 * @param {*} uid : 用户
 */
export function setUid(uid) {
  return Taro.setStorageSync(`${storageStr}-uid`, uid);
}

/**
 * 从全局数据中取出用户uid
 * @param {*} str 
 */
export function getUid(str) {
  const tokenString =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-uid`)
      : Taro.getStorageSync(str);
  return tokenString;
}

export function setBuyerId(buyerId) {
  return Taro.setStorageSync(`${storageStr}-buyerId`, buyerId);
}

export function getBuyerId(str) {
  const tokenString =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-buyerId`)
      : Taro.getStorageSync(str);
  return tokenString;
}

export function setUserName(name) {
  return Taro.setStorageSync(`${storageStr}-userName`, name);
}
export function setAvatar(name) {
  return Taro.setStorageSync(`${storageStr}-avatar`, name);
}
export function getAvatar(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-avatar`)
      : Taro.getStorageSync(str);
  return currStr;
}
export function getUserName(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-userName`)
      : Taro.getStorageSync(str);
  return currStr;
}

export function setNickName(nickName) {
  return Taro.setStorageSync(`${storageStr}-nickName`, nickName);
}
export function getNickName(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-nickName`)
      : Taro.getStorageSync(str);
  return currStr;
}

export function setCounpon(errorCode) {
  return Taro.setStorageSync(`${storageStr}-errorCode`, errorCode);
}
export function getCounpon(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-errorCode`)
      : Taro.getStorageSync(str);
  return currStr;
}
export function setTelephone(phone) {
  return Taro.setStorageSync(`${storageStr}-telephone`, phone);
}

export function getTelephone(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-telephone`)
      : Taro.getStorageSync(str);
  return currStr;
}

export function setServicePhone(phone) {
  if (phone) {
    return Taro.setStorageSync(`${storageStr}-ServicePhone`, phone);
  }
}

export function getServicePhone(str) {
  const currStr =
    typeof str === "undefined"
      ? Taro.getStorageSync(`${storageStr}-ServicePhone`)
      : Taro.getStorageSync(str);
  return currStr;
}

export function getshareCode(code) {
  if (code == undefined) { // 表示读
    return getGlobalData("shareCode");
  } else {                // 表示写
    setGlobalData("shareCode", code);
  }
}
export function getActivityCode(code) {
  if (code == undefined) {  // 表示读
    return getGlobalData("ActivityCode");
  } else {                  // 表示写
    setGlobalData("ActivityCode", code);
  }
}
