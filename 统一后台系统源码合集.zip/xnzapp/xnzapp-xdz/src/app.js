import '@tarojs/async-await'
import Taro, { Component } from '@tarojs/taro'
import { Provider } from '@tarojs/redux'

import Index from './pages/home'
import dva from './utils/dva'
import { saveQueryValueInGlobal } from './utils/utils'
import models from './models'
import { setGloble } from './utils/localStorage'
import './app.scss'


// import uma from 'umtrack-alipay'
const dvaApp = dva.createApp({
	initialState: {},
	models: models,
})
const store = dvaApp.getStore()
if (!my.canIUse('plugin') && !my.isIDE) {
	my.ap && my.ap.updateAlipayClient && my.ap.updateAlipayClient();
  }
class App extends Component {
	config = {
		pages: [
			'pages/home/index',
			'pages/webview/xieyi',
			'pages/webview/credit', // 用户信用查询及报送授权书
			'pages/orderList/index',
			'pages/FilingComplaint/index',
			'pages/mine/index',
			'pages/purchaseDetail/index',
			'pages/myCollect/index',
			'pages/address/index',
			// 'pages/shopSettleIn/index', // 旧招商
			'pages/classify/index',
			'pages/classifyAgain/index',
			'pages/shops/index',
			'pages/productList/index',
			'pages/productShopList/index', // 商户列表
			'pages/productDetail/index',
			'pages/search/index',
			'pages/shops/index',
			'pages/commentOn/index',
			'pages/confirmOrder/index',
			'pages/addAddress/index',
			'pages/realName/index',
			'pages/orderDetail/index',
      'pages/orderDetails/index', //新增的补订单详情
			'pages/coupon/index',
			'pages/coupon/oldCoupon',
			'pages/coupon/collector',
			'pages/billDetail/index',
			'pages/sendBack/index',
			'pages/selAddress/index',
			'pages/express/index',
			'pages/Certificates/index',
			'pages/deposit/index',
			'pages/checkSuccess/index',
			'pages/authentication/index',
			'pages/buyOutOrder/index',
			'pages/couponList/index',
			'pages/productAssess/index',
			'pages/FilingType/index',
			'pages/Complaint/index',
			'pages/configureActivities/index',
			'pages/otherPayment/index', // 找人代付
			// 'pages/sign/index',
			'pages/process/index',
			// 'pages/vip/index',
      'pages/digital/index',
      'pages/allAgreement/index',
      'pages/productImg/index',
      'pages/guarantee/index',
      'pages/service/index',
      'pages/userAnth/index',
      'pages/strictElection/index',
      'pages/serviceAdd/index',
		],

		subPackages: [
			{
				root: 'activity',
				pages: [
					'activityTimeLimitTOPIC/index',
					'anzhuo/index',
					'iphone99/index',
					'signacontract/index'
				],
			},
		],

		window: {
			// titleBarColor: "#fff",
			titleBarColor: '#AEABCD',
			// defaultTitle: 'alipay',
			enableInPageRender: "YES",
		},

		// plugins: {
			// myPlugin: {
			// 	// version: "0.0.38", // 拉取当前上架最新版本
			// 	version: '*', // 拉取当前上架最新版本
			// 	provider: '2021001155688526', // 插件的id
			// },
		// 	alipassToolKit: {
		// 		version: '*', // 目前只支持设置 * 拉取当前上架最新版本   支付宝卡包插件
		// 		provider: '2021001107697072',
		// 	},
		// 	// 直播插件
		// 	tbliveListPlugin: {
    //     version: "*",
    //     provider: "2021001167637066"
    // 	},
		// esign: {
		// 	version: "*",
		// 	provider: "2021001115656413"
		// },
		// esign: {
		// 	version: "*",
		// 	provider: "2021001115656413"
		// },
		// },

		tabBar: {
			textColor: '#333333',
			selectedColor: '#AEABCD',
			backgroundColor: '#fff',
			items: [
				{
					name: '租物',
					pagePath: 'pages/home/index',
					icon: 'images/home/home.png',
					activeIcon: 'images/home/home_b.png',
				},
        //  {
        //     name: "严选",
        //     pagePath: "pages/strictElection/index",
        //     icon: "images/home/strict.png",
        //     activeIcon: "images/home/strict_b.png",
				// },
				{
          name: '分类',
					pagePath: 'pages/classifyAgain/index',
					icon: 'images/home/classify.png',
					activeIcon: 'images/home/classify_b.png',
				},
				{
					name: '我的',
					pagePath: 'pages/mine/index',
					icon: 'images/home/mine.png',
					activeIcon: 'images/home/mine_b.png',
				},
			],
		},
	}
	onLaunch = (options) => {
		
		
		const appId = my.getAppIdSync().appId
		const infoByAppId = {
			// 星动租
			2021004170688639: {
				appTitle: '星动租',
				channelId: '006',
				companyName: '西安鑫盛智达网络科技有限公司',
				tntInstId: '6sL_oWP6',
				scene: 'SCE01269300',
				lifestyleId: '',
				sceneId: '3628e495982744e796df3c42b4eefcc9',
				pid: '2088941062409490', // 先享后付风险检测id
				logo: 'https://i.alipayobjects.com/e/201401/1tdi7nR70h.png', // logo地址
				companyYZ: 'new-img/zyj-yinzhang.png',
				channelId2: '006',
				AppKey: '60d3f1d026a57f10183713ea',  // 友盟appkey
				titleContent: 'iphone 限时秒杀中，立即来抢购',
			},
		}
		setGloble('appId', appId)
		if (infoByAppId[appId]) {
			for (let key in infoByAppId[appId]) {
				setGloble(key, infoByAppId[appId][key])
			}
		}
		// 需要保存到全局里面的值，注：key必须报错唯一
		const theQueryNeedSave = [
			{ queryKey: 'channel', key: 'summerActivityChannel' },
			{ queryKey: 'channelId', key: 'heartActivitychannelId' },
			{ queryKey: 'action', key: 'heartActivityaction' },
			{ queryKey: 'position', key: 'heartActivityposition' },
			{ queryKey: 'channelId', key: 'pre11ActivitychannelId' },
			{ queryKey: 'action', key: 'pre11Activityaction' },
			{ queryKey: 'position', key: 'pre11Activityposition' },
			{ queryKey: 'groupCode', key: 'groupActivityCode' },
			{ queryKey: 'productName', key: 'groupActivityProductName' },
		]
		theQueryNeedSave.forEach((obj) => {
			saveQueryValueInGlobal(
				options.query,
				obj.queryKey,
				obj.key,
				store.dispatch
			)
		})
	}

	// 在 App 类中的 render() 函数没有实际作用
	// 请勿修改此函数
	render() {
		return (
			<Provider store={store}>
				<Index />
			</Provider>
		)
	}
}

Taro.render(<App />, document.getElementById('app'))
